# JSON-Based Syntax Tests

This folder uses a strict split between test input and test expectations.

- `.TXT` files contain only Acurity source.
- `.test-spec.json` files contain metadata and expected results.
- `.FIXED.TXT` files (optional) contain expected result after applying a code action.

This keeps test authors focused on language behavior, not internal validator wiring.

## Directory Structure

Tests are organized into subdirectories by category:

- **`core/`** - General integration tests (functions, types, include resolution)
- **`validators/`** - Tests for diagnostic validators (keyword capitalization, naming conventions, interpolation, etc.)
- **`code-actions/`** - Tests for quick fixes and code transformations with `.FIXED.TXT` files
- **`block-structure/`** - Tests for block structure validation (IF/ENDIF, DO/ENDDO, etc.)

The test runner recursively scans all subdirectories for `.test-spec.json` files.

## Naming

File numbering is **suite-local**. Each subfolder can start at `0001`.

- Entry/input file: `0001.TXT`
- Spec file: `0001.test-spec.json`
- Fixed file (code actions): `0001.FIXED.TXT`
- Include fixtures for a test: `0001.INCLUDE1.TXT`, `0001.INCLUDE2.TXT`, etc.

## Directory Example

```
test/syntax-tests/
├── core/
│   ├── 0001.TXT
│   ├── 0001.test-spec.json
│   └── ...
├── validators/
│   ├── 0001.TXT
│   ├── 0001.test-spec.json
│   └── ...
├── code-actions/
│   ├── 0001.TXT
│   ├── 0001.FIXED.TXT
│   ├── 0001.test-spec.json
│   └── ...
├── block-structure/
│   ├── 0001.TXT
│   ├── 0001.test-spec.json
│   └── ...
└── ...
```

## Spec Schema (Current)

### Validator Test Spec
```json
{
  "schema-version": "1.0",
  "test-id": "0001",
  "test-name": "Built-in function - no error",
  "test-entry": "0001.TXT",
  "description": "Optional free-text context",
  "diagnostic-match-mode": "substring",
  "expected-errors": [],
  "unexpected-errors": ["not defined"],
  "expected-warnings": [],
  "unexpected-warnings": []
}
```

### Code Action Test Spec
```json
{
  "schema-version": "1.0",
  "test-id": "0001",
  "test-name": "Code action - capitalize IF keyword",
  "test-entry": "0001.TXT",
  "description": "Verify that the quick fix properly capitalizes lowercase 'if' keyword",
  "diagnostic-match-mode": "substring",
  "expected-errors": [],
  "unexpected-errors": [],
  "expected-warnings": [
    { "message": "Keyword 'if' should be capitalized", "line": 3 }
  ],
  "unexpected-warnings": [],
  "code-action-tests": [
    {
      "diagnostic-match": "should be capitalized",
      "line": 3,
      "expected-fixed": "0001.FIXED.TXT"
    }
  ]
}
```

## Field Notes

- `schema-version`: Must be `"1.0"`.
- `test-id`: Identifier that matches the filename prefix within its suite folder.
- `test-entry`: entrypoint file the framework should open and evaluate.
- `diagnostic-match-mode`: Either `"substring"` (default) or `"exact"` for message matching.
- `expected-errors`: Messages that must appear in error diagnostics (see Expectation Formats below).
- `unexpected-errors`: Messages that must not appear in error diagnostics.
- `expected-warnings`: Messages that must appear in warnings.
- `unexpected-warnings`: Messages that must not appear in warnings.
- `code-action-tests` (optional): Array of code action tests to run after diagnostics validation.

### Code Action Test Fields
- `diagnostic-match`: Substring to match in the diagnostic message
- `line`: Line number where the diagnostic should appear (1-indexed)
- `expected-fixed`: Filename of the .FIXED.TXT file containing expected result after applying the fix

## Expectation Formats

### String Format (Message Only)
Simple string matching without line validation:
```json
"expected-errors": [
  "Function 'foo' is not defined",
  "Variable 'bar' is not set"
]
```

### Object Format (Message + Line Validation)
Validates both message content and exact line number (1-based):
```json
"expected-errors": [
  {
    "message": "IF at line 5 is not closed with ENDIF",
    "line": 5
  },
  {
    "message": "Unexpected ENDIF without matching IF",
    "line": 22
  }
]
```

**Important**: Line numbers in test specs are 1-based (matching editor line display), even though diagnostics internally use 0-based indexing. The test runner handles this conversion automatically.

### Mixed Format
You can mix both formats in the same spec:
```json
"expected-errors": [
  "Variable 'x' is not defined",
  {
    "message": "IF at line 10 is not closed with ENDIF",
    "line": 10
  }
]
```

## Architectural Direction

The spec intentionally does not include a `validator` field.

The runner should behave like the plugin itself:
- load the entry file,
- run the same diagnostic pipeline the extension uses,
- compare resulting diagnostics to the spec.

This keeps the framework as a thin integration layer over real plugin behavior.

## Include Behavior Example

`0001.TXT` is based on `syntax-test-files/REPORT.TXT` and uses:
- `0001.INCLUDE1.TXT`
- `0001.INCLUDE2.TXT` (includes `0001.INCLUDE3.TXT`)

`0007.test-spec.json` asserts include-scope behavior such as:
- expected early undefined call for `include2Function`,
- expected undefined call for `blahBlah`,
- no false undefined errors for `incVar3` or `blah` from nested include scope.

## Block Structure Validation (`block-structure/0001-0003`)

These tests demonstrate line-precise validation for block structure errors:

- **0001**: Unexpected closing blocks (ENDIF/ENDDO/ENDFUNCTION) without opening blocks
- **0002**: Unclosed blocks detected at end of file  
- **0003**: Mismatched block closures (e.g., IF closed with ENDDO)

These tests use the object format to validate that diagnostics appear on the correct line, ensuring error messages guide developers to the actual problem location.
