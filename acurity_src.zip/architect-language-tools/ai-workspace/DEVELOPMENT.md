# ai-workspace

Stable reference material for AI-assisted development sessions on this project.
Content here has been reviewed and is considered settled — not actively being worked through.

---

## Structure

```
ai-workspace/
├── docs/            ← Strategy, architecture, and feature documentation
├── agent-model/     ← AI methodology reference (Skool download)
└── reference-data/  ← Raw data files for deferred or ongoing work
```

**`docs/`** — Documents that inform how the project is shaped, governed, or deployed.
An AI agent working on architecture, CI/CD, or stakeholder communication should read
the relevant file here first.

**`reference-data/`** — Source data used to build or extend registries (builtins, DB fields).
Not consumed directly by the codebase — used as input when running registry expansion work.

**`agent-model/`** — The AI folder architecture methodology this project follows.
Read if you need to understand why the repo is structured the way it is.

---

## How content arrives here

Content is promoted from `planning/` once a decision is made or a feature is shipped.
Content is not written here directly during active work — use `planning/` for that.

If a `planning/` item is abandoned rather than completed, discard it rather than
promoting it here. `ai-workspace/` should only contain content that reflects
the current state of the project, not dead ends.
