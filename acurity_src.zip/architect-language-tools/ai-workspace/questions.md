# Open Questions

## Resolved
- ~~Can we migrate to a directory structure that does away with the `vs-code-acurity` folder?~~ — Done (renamed to `architect-language-tools/` on 2026-03-21)
- ~~How do we specify which warnings/errors are suitable for CI/CD?~~ — Designed (`--surface` flag + `surfaces` field in diagnostic catalogue); see `project_deferred_cli_features` memory
- ~~In the context of CI/CD, how will tooling ensure review comments only apply to modified code?~~ — Designed (`--diff-only` / `--base-branch` flags); see `project_deferred_cli_features` memory

## Open

- Can we migrate the project elsewhere on disk?
- Can we rebase all earlier commits?
- Can we migrate logger to vscode package?
- Help me create a PowerPoint deck that pitches this project to stakeholders
