# Acurity Database Table Codes

Source: `dev-docs/treedata5.txt` (v15)

These 2-character codes (plus 2 edge cases with digits) are used as string literal arguments to index/position functions such as:
- `INDEX_SAVE_POSITION("MD")`
- `INDEX_RESTORE_POSITION("MD")`
- `INDEX_OPEN_STANDARD("MD")`
- `INDEX_OPEN_CUSTOM("MD")`
- `LEDGER_SAVE_POS`, `LEDGER_RESTORE_POS`, `LEDGER_CHGE_KEY`, etc.

Future work: use this catalogue to validate string literal arguments to those functions.

---

## Table Codes (alphabetical)

| Code | Table Name | Category |
|------|-----------|----------|
| hAB | API CLOB | |
| hAC | Archive | |
| hAD | Member Contribution Adjustment History | |
| hAH | Member Acquisition History | |
| hAK | Member Review Backup | |
| hAN | Address Details | Accounting |
| hAP | Advisor Proportions History | |
| hAQ | Member Review Quotes | |
| hAR | Member Review History | |
| hAT | Audit Trail | Audit |
| hAU | Audit Control | Audit |
| hAV | Advisor History | |
| hAX | Audit Header | Audit |
| hAY | Audit Child | Audit |
| hAZ | Audit Character Large Objects | Audit |
| hBA | Journal | Accounting |
| hBB | BSB Codes | |
| hBC | Job Calculation Variables | |
| hBD | Broker | |
| hBE | Bank Accounts | Accounting |
| hBH | Broker History | |
| hBJ | Background Jobs | |
| hBK | Member Balance History Backup | |
| hBL | Balance History | |
| hBN | Bank Reconciliation History | Accounting |
| hBP | Batch Processing Steps | |
| hBS | Processed Batches | |
| hBT | Batch Codes | |
| hCA | Chart of Accounts | Accounting |
| hCB | Tax Flag History | |
| hCC | Corporate Action Election | |
| hCD | Codes and Descriptions | |
| hCE | Client To Member Relationships | |
| hCF | Configuration Items | Configuration |
| hCG | Capital Gains Indexation Rates | |
| hCH | Benefit Category History | |
| hCK | Benefit Category - Member History Backup | |
| hCL | Employer Location | Employer |
| hCM | Client Match | |
| hCN | Corporate Actions | |
| hCO | Employer Details | Employer |
| hCP | Capital Gains Reporting | |
| hCQ | Cheque Reconciliation | |
| hCR | Commission Rates | |
| hCS | Contribution Accounts | |
| hCT | Benefit Category | Category |
| hCV | Benefit Category - Group Life Insurance | Category |
| hCX | Commissions | |
| hD2 | Personal Details *(edge case — digit in code)* | Member |
| hDA | Data Register | |
| hDH | Tax Rates History | Taxation |
| hDU | User Codes and Descriptions | |
| hDV | Global Information | |
| hDX | Dependants Details | Member |
| hDY | Auto Diary | |
| hEB | Event and Exception Bases | |
| hEC | Message Codes | |
| hED | Member Exit History | |
| hEE | Employer Enquiry | Employer |
| hEH | Exception History | |
| hEI | Event and Exception Information | |
| hEM | Member Enquiry | Member |
| hEN | Event Exception Details | |
| hER | Results (Error) Messages | |
| hES | Eligible Service Date History | |
| hEV | Event Definitions | |
| hEX | Extensions | |
| hFB | Fee Calculation Bases | Fees/Formulas/Tables |
| hFC | Contribution Lines | Accounting |
| hFD | Fee Definitions | Fees/Formulas/Tables |
| hFF | Fund Supplementary Details | Fund |
| hFG | Fee Group | Fees/Formulas/Tables |
| hFH | Fund Supplementary Labels 1 | Fund |
| hFL | Locked Files and Caches | |
| hFP | Fee Parameters | Fees/Formulas/Tables |
| hFQ | Transfer Request Lines | Accounting |
| hFR | Fund Information | Fund |
| hFS | Static Data Lines | Accounting |
| hFT | File Type Details | Accounting |
| hFU | Fund History Details | Fund |
| hFV | Last Member Number | Fund |
| hFW | Workbench Lines | Accounting |
| hFX | Formula Definitions | Fees/Formulas/Tables |
| hFZ | Fund Information 3 (Trustee Details) | Fund |
| hGL | General Ledger | Accounting |
| hGR | Group Certificate | |
| hGV | Division Global Information | |
| hID | Insurer | Insurer |
| hIE | Income Election History | |
| hIH | Investment Manager History | Investment |
| hIL | Insurance Category Defaults | Insurer |
| hIM | Investment Manager Details | Investment |
| hIN | Insurer History | Insurer |
| hIP | Member Investment Profile History | Member |
| hIR | Fund Interest Rate History | Fund |
| hIT | Interest Table History | |
| hJQ | Job Queuing Rules | |
| hKE | Acurity Manager Keys | |
| hMC | Member Contribution Rate History | Member |
| hMD | Member Details | Member |
| hMG | Merge History | Member |
| hMH | Medical History | Member |
| hMS | Message History | Accounting |
| hMU | Multiple Cheques | |
| hNT | New Zealand - Insurance Records | |
| hNX | Notes | |
| hNZ | New Zealand Exchange Rates | |
| hOF | Member Transfer History | Member |
| hOG | Member - Other Fund Details | Member |
| hOH | Member Past Benefit History | Member |
| hPA | Password History | Security |
| hPB | Daily Portfolio Balances | Accounting |
| hPC | Post Code | |
| hPD | AS400 Printer Override | |
| hPE | Member Pension History | Member |
| hPG | Client Groups | |
| hPH | Employer/Payroll History | Employer |
| hPI | Policy Benefit Details | |
| hPL | Policy Details | |
| hPO | Policy Committee | |
| hPP | Temporary P04 and P05 Totals | |
| hPR | Payee Details | Payee |
| hPS | Publishing Details | Reports |
| hPT | Member Periodical Payments | Member |
| hPY | Member Payment History | Member |
| hRA | File Register | |
| hRE | Member Unit Refund Details | Member |
| hRG | Correspondence Register | |
| hRH | Employer Rates History | Employer |
| hRL | Report Control | Reports |
| hRO | Rollover History | |
| hRR | Report History | Reports |
| hRV | Report Variables | Reports |
| hSA | Salary History | Member |
| hSB | Supplementary Details | Member |
| hSC | System Security - Access | Security |
| hSD | Share Certificate Details | |
| hSF | Member Supplementary Labels | Member |
| hSG | Fund Supplementary Labels 2 | Fund |
| hSH | Share Certificate - Redemption History | |
| hSL | SAML Artifacts | Security |
| hSM | System Security - Supplementary Fields | Security |
| hSP | Posting Transaction Control | |
| hSR | Service Request Form | |
| hSS | Jobs System - Global Variables | |
| hST | Share Scheme - Temporary Records | |
| hSU | System Security - Transactions | Security |
| hSX | ATO Data History | Taxation |
| hT4 | Transaction 04 - History *(edge case — digit in code)* | Transactional |
| hTA | Tax Table History | Taxation |
| hTB | Trustee Details | |
| hTC | Transaction Control Lines | Transactional |
| hTD | Transaction Header Details | Transactional |
| hTE | Member Exit Batch Details | |
| hTF | Temporary Payment Records | |
| hTH | Transaction History | Transactional |
| hTN | Temporary Transaction History Records | Transactional |
| hTR | Table Records | Fees/Formulas/Tables |
| hTS | Taxable Salary History | Taxation |
| hTT | Transaction Lines | Transactional |
| hTU | User Defined Transaction (77) | Transactional |
| hTZ | Sliding Scale Tables | Fees/Formulas/Tables |
| hUL | Unpost General Ledger | Accounting |
| hUN | Unit Entitlement History | |
| hUP | Unit Price History Records | |
| hUS | User Details | Security |
| hVA | Contribution Variance History | Accounting |
| hVH | Data Version History | |
| hWH | Working Hours History | |
| hWS | Working Status History | |
| hWU | Web User Details | Security |

---

## Notes

- 171 tables total (169 standard 2-letter codes + `hD2` + `hT4`)
- Type indicator in field names (3rd character): `z`/`c` = STRING, `d` = DATE, `t` = TIME, `l` = INTEGER/LONG, `s` = INTEGER/SHORT, `f` = DOUBLE, `v` = VARSTRING
- Source is v15; v25 may have additional tables
