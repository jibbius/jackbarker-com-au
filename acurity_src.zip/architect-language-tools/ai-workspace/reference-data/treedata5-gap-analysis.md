# treedata5 Gap Analysis — Registry Coverage

Generated: 2026-03-17
Source: `dev-docs/treedata5.txt`
Compared against: `src/builtins/functionsRegistry.js`, `src/builtins/constantsRegistry.js`

---

## Summary

| Category | treedata5 | Registry | Missing |
|---|---|---|---|
| Functions (section 02) | 687 | 349 | **379** |
| Global Variables / Constants (section 03 > 0300) | 204 | 6 | **199** |
| Database Fields (section 03 > 0301–0317) | ~10,533 across 171 tables | 0 | **new category** |

---

## 1. Functions Registry (`functionsRegistry.js`)

### 1a. Missing from registry (in treedata5 but not registered)

379 functions are known to the language but not in `functionsRegistry.js`. These will currently pass through as **unrecognised functions** (false negatives in the undefined-function validator).

Grouped by treedata5 category:

#### Arrays (0200)
`FINALISE_ARRAY`, `GET_SHORT_ARRAY`, `GET_STRING_ARRAY`, `INITIALISED_ARRAY`, `INITIALISE_ARRAY`, `PUT_SHORT_ARRAY`, `PUT_STRING_ARRAY`

#### Conversion (0201)
`DATE_TO_STR`, `STR_TO_SHORT`

#### Database (0202) — large volume
All `AC_*`, `BALANCES_CHGE_KEY`, `BATCH_PROCESS_ORDER`, `CALCULATE_CAPGAINS`, `CALC_CONTS_DUE`, `CALC_MIN_MAX_AMTS`, `CALC_OR_SET_PURCHASE_PRICE`, `CALC_PENSION_AMTS`, `CALC_PENSION_AMTS_EXT`, `CALC_PENSION_AMTS_POST2007`, `CALC_PEN_AMTS_PERIOD`, `CALC_PEN_AMTS_POST2007`, `CATCH_UP_PAYMENTS`, `CHEQUE_WORDS_MILL`, `CLEAR_CORR_REG`, `CLEAR_EXIT_TRANSREF_RBL_FLAG`, `COMPARE_SHARECRT_LEDGER`, `CONFIRM_DOCUMENT_PUBLISHED`, `CONFIRM_EXCEPTION_PUBLISHED`, `COPY_UNIT_ENTIT`, `CREATE_REVERSING_TRAN`, `CREATE_TRANSACTION`, `DB_D`, `DB_F`, `DB_L`, `DB_S`, `DB_T`, `DB_V`, `DB_Z`, `DELETE_CATEGORY_HISTORY`, `DELETE_ERROR_MSG`, `DELETE_FILE_REG`, `DELETE_NOTES`, `DELETE_SUPERGATE`, `DELETE_SUPPMEMB`, `DETERMINE_NEXT_REVIEW`, `DET_SORT_ORDER`, `DV_D`, `DV_F`, `DV_L`, `DV_S`, `DV_T`, `DV_V`, `DV_Z`, `ENQ_MBR_CHGE_KEY`, `FIRST_CONTRIBUTION`, `FIRST_CONTRIBUTION_MBR`, `FONT_FILE`, `GENERATE_AND_PUBLISH_KEYS`, `GET_BAL_SS_CF` *(note: `GET_BAL_SS_CF` is in registry)*, `GET_CLOB`, `GET_CURRENT_INDEX`, `GET_DAILY_ACC_CF`, `GET_LAST`, `GET_MEMBER_ID`, `GET_MSGCODE_BY_ID`, `GET_NEXT_DAILY_SSS_CF`, `GET_NEXT_SSS_ACC_BAL`, `GET_NEXT_SS_ACC_BAL`, `GET_NEXT_SS_CF`, `GET_TRANSREF` *(registry has it)*, `INDEX_INCPRO_AMTS`, `INDEX_OPEN_CUSTOM`, `INDEX_PENSION_AMTS`, `INTEREST_CONTS_DUE`, `INVM_ASSET_ALLOC`, `IsUserMemberOfGroup`, `LAST_CONTRIBUTION`, `LAST_CONTRIBUTION_DATE`, `LAST_CONTRIBUTION_MBR`, `LAST_PENSION_PAYMENT`, `LEDGER_ACCOUNT_TOT`, `LEDGER_ACC_BALS`, `LEDGER_CLEAR_POS`, `LEDGER_CONT_AC_BAL`, `LEDGER_RESTORE_POS`, `LEDGER_SAVE_POS`, `LINK_CHQ_BANK_RECS`, `LINK_TRN_BANK_RECS`, `LIST_SUPERGATE_GROUPS`, `LOAD_EXCEPTION_DATA`, `MAX_VALUE`, `MEMBER_CHGE_KEY`, `MEMEXIT_CHGE_KEY`, `MIN_VALUE`, `NEXT_CHEQUE_ID`, `NEXT_DEPOSIT_ID`, `NEXT_EFT_ID`, `NEXT_FUND_CHEQUE_ID`, `NEXT_FUND_EFT_ID`, `NOTES`, `NUMBER_SUPER_PERIODS`, `PAYHIST_CHGE_KEY`, `PAY_PERIOD_START_DATE`, `PCL2PDF`, `POLICY_CHGE_KEY`, `POST_TRANSACTION`, `PUBLISH_CURRENT_EXCEPTION`, `PUBLISH_DOCUMENT`, `READ_ACCTHIST`, `READ_ACCT_MEM_DIV`, `READ_ANR_HIST_COPY`, `READ_ASCII_TABLE`, `READ_ASCII_TABLE2`, `READ_AWOTE`, `READ_BAL1`, `READ_BATCHIST`, `READ_BATCH_ERRORS` *(registry has it)*, `READ_BTCH_DEF`, `READ_CAPGAINS`, `READ_CAPGNS_R`, `READ_CAPGNS_R_KEY1`, `READ_CHQREC_TRAN`, `READ_CHQR_STAT`, `READ_CHQR_TYPE`, `READ_COMMISSION`, `READ_COMPHIST`, `READ_COMP_LOC`, `READ_CONTRATES_UNPRES`, `READ_CONT_ADJ`, `READ_CONT_ADJ2`, `READ_CONT_ADJ_3`, `READ_CONT_VARIANCE`, `READ_CORR_NO_RECTYPE`, `READ_CORR_PAYROLL`, `READ_CORR_STAT`, `READ_CORR_STAT_PAYROLL`, `READ_DATA_REG`, `READ_DIARY`, `READ_ELS`, `READ_ENQ_EMP`, `READ_ENQ_MBR`, `READ_ENQ_MBR3`, `READ_ENQ_MBR_TOT1`, `READ_ENQ_MBR_TOTS`, `READ_EXIT_DETLS2`, `READ_FUND_GROUP`, `READ_FUND_HIST`, `READ_GCERT_STAT`, `READ_GCERT_TYPE`, `READ_GROUP`, `READ_INSDEFLT`, `READ_INSR_HIST_CLT`, `READ_INT_TABLE`, `READ_LAST_NO`, `READ_MCHQS_REF`, `READ_MCHQS_TRAN`, `READ_MED_HIST`, `READ_MED_HIST_CLIENT`, `READ_MEMB4`, `READ_MERGE_HISTORY`, `READ_MODEL`, `READ_MODEL_MEMBERS`, `READ_NZEXCHGE`, `READ_PAST_HIST`, `READ_PAYHIST_2`, `READ_PAYHIST_4`, `READ_PAY_REINSURER`, `READ_POLCOMM`, `READ_POLICY`, `READ_POLICY_BEN_DTLS`, `READ_PRD_PAYMENT`, `READ_RCT_RFND`, `READ_RCT_RFND_2`, `READ_REFUND`, `READ_RRECS_REP`, `READ_SAL_HIST_RR`, `READ_SERVICE_REQUESTS`, `READ_SUPER_PERIOD`, `READ_SUPPFUND_LABELS`, `READ_SUPPMEMB`, `READ_SUPP_ADVISER_HIST_TYP`, `READ_SUPP_INVMGR_HIST_TYP`, `READ_SUPP_PAY_HIST`, `READ_SURCHARGE2`, `READ_TAXFLAG`, `READ_TAX_SAL`, `READ_TMP_CONT_3`, `READ_TRANSREF_5_EFLG`, `READ_UNIT_ENTIT`, `READ_UNIT_ENTIT3`, `READ_WHRSHIST`, `READ_WHRSHIST_TOT`, `REPUBLISH_DOCUMENT`, `REPUBLISH_EXCEPTION`, `RESET_CLIENT_SYS`, `RESET_REFUND`, `RES_INTEREST_CONTS_DUE`, `SAVE_AS_XLSX`, `SET_CLIENT_SYS`, `SET_PURGE_FLAG`, `SORT_INVMGR_R`, `SORT_INVMGR_W`, `SQL_GET_TIME_COL`, `SQL_INDEX_ADD_CONDITION`, `SQL_INDEX_CLEAR_KEY`, `SQL_INDEX_CLOSE`, `SQL_INDEX_FIX_KEY`, `SQL_INDEX_LOAD_KEY_DATE`, `SQL_INDEX_LOAD_KEY_DOUBLE`, `SQL_INDEX_LOAD_KEY_LONG`, `SQL_INDEX_LOAD_KEY_SHORT`, `SQL_INDEX_LOAD_KEY_STRING`, `SQL_INDEX_LOAD_KEY_TIME`, `SQL_INDEX_OPEN_STANDARD`, `SQL_INDEX_READ_BY_KEY`, `SQL_SET_DATE`, `SQL_SET_DOUBLE`, `SQL_SET_LONG`, `SQL_SET_TIME`, `TABLE_DESC`, `TOT_ACC_AT_EFF`, `TRANSACTION_DESC`, `UNLOAD_EXCEPTION_DATA`, `UNPOST_TRANSACTION`, `UPDATE_AUDITAUTH`, `UPDATE_BROKER`, `UPDATE_CLIENT`, `UPDATE_CLIENT_ELS`, `UPDATE_CLIENT_GROUPS`, `UPDATE_CONTS_TO_BE_TAKEN`, `UPDATE_DEDUCTIBLE_PERCENTAGE`, `UPDATE_EMPLOYER_STATUS`, `UPDATE_EXIT_CO_CONTRIBUTIONS`, `UPDATE_EXIT_TAX`, `UPDATE_MAX_CALC`, `UPDATE_MEMBER`, `UPDATE_MIN_MAX_CALC`, `UPDATE_RCT_RFND`, `UPDATE_ROLLOVER_ELS`, `UPDATE_SHARECRT`, `UPDATE_SHARECRT_REDN`, `UPDATE_SHARE_CERTIFICATE`, `UPDATE_STATEMENT`, `UPDATE_STATEMENT_BY_REPORT`, `UPDATE_SUPER_MATCH`, `UPD_BTCH_REF`, `UPD_CONT_ADJ`, `UPD_CORR_REG`, `UPD_CORR_REG_RECTYPE`, `UPD_MBR_DETAILS`, `UPD_MBR_ISSUED`, `UPD_MBR_NOTFD`, `UPD_PAID_CONTS_TO`, `UPD_SHARECRT_EXITFEE`, `UPD_SUPPFUND_DETLS`, `UPD_SUPPMEMB`, `UPD_SUPPMEMB_FLAGS`, `UPD_SUPP_ADVISER_ALL`, `UPD_SUPP_CLIENT_ALL`, `UPD_SUPP_CLIENT_FLAGS`, `UPD_SUPP_CLIENT_HIST`, `UPD_SUPP_INVMGR_ALL`, `UPD_SUPP_PAY_ALL`, `UPD_SUPP_PAY_FLAGS`, `UPD_SUPP_PAY_HIST`, `UPD_TMP_EXIT`, `UPD_USR_BTCH`, `USER_ENCRYPT_HEX`, `USER_MD5_HASH`, `VALIDATE_WEBUSER`, `WORKING_DAYS_BETWEEN`, `WRITE_ADVISOR_AUTHORITY`, `WRITE_ADVISOR_PROPORTIONS`, `WRITE_ANRHIST`, `WRITE_BANK_REC`, `WRITE_CAT_HIST`, `WRITE_CHQREC`, `WRITE_CHQREC_LINE`, `WRITE_CHQREC_TYPE`, `WRITE_CHQREC_TYPE_LINE`, `WRITE_COMPHIST`, `WRITE_CONTRATES`, `WRITE_CONTRIBUTION_LINE`, `WRITE_CONT_VARIANCE`, `WRITE_DATA_REG`, `WRITE_DATA_REG2`, `WRITE_ERROR_MSG_BY_CDE`, `WRITE_ERR_MSG`, `WRITE_ERR_MSG_BY_CDE_DESC`, `WRITE_FILE_REG2`, `WRITE_INSR_HIST_CLT`, `WRITE_INSR_HIST_CLT1`, `WRITE_INVESTMENT_MANAGER_HISTORY`, `WRITE_INVPROP`, `WRITE_INVPROP_CLT`, `WRITE_MED_HIST`, `WRITE_NOTES_MBR`, `WRITE_NOTES_REG`, `WRITE_PAYMENT`, `WRITE_PAYMENT_OPTIONS_DEFAULTS`, `WRITE_PAY_REINSURER`, `WRITE_PENSION_HISTORY`, `WRITE_REFUND`, `WRITE_REP_VARS`, `WRITE_ROLLOVER`, `WRITE_SAL_HIST`, `WRITE_SAL_HIST_EMP`, `WRITE_STATEMENT`, `WRITE_SUPERGATE`, `WRITE_TAXSAL_HIST`, `WRITE_UNIT_ENTIT`, `WRITE_UNIT_ENTIT3`, `WRITE_UNIT_PRICE`, `WRITE_WHRSHIST`, `WRITE_WRK_HIST`, `WRITE_WRK_HRS_HIST`

#### Date (0203)
`DAY_ABV`, `DAY_NAME`, `DAY_OF_YEAR`, `DAY_TO_DATE`, `ISLEAP`, `JULIAN_TO_DATE` *(registry has `DATE_TO_JULIAN`)*, `LDM`, `MMADD`, `MONTH_NAME`, `PERIOD`, `PERIOD_RND`, `VALIDATE_DATE`, `YEARS`

#### File (0204)
`DO_PRINT_FILE`, `FILE_APPEND_DELETE`, `FILE_INSERT_DELETE`, `FILE_SIZE`, `GET_VARIABLE`, `JAVA_ARCHITECT`, `OUTPUT_FILE_CLOSE`, `OUTPUT_FILE_OPEN`, `OUTPUT_WRITE`, `REPORT_FILENAME`, `SET_VARIABLE`, `SYMBOL_LIST`

#### Numeric (0205)
`NUMBER_FRIDAYS`, `RANDOM_NO`, `RNDHI` *(note: `RNDHI` return type is DOUBLE in treedata5; registry has `RNDHI`)*

#### String (0206)
`CHECK_SYMBOL`, `DSPACE`, `NUMBER_OF_TOKENS`, `OCCURS`, `RANK`, `REPLACE`, `RIGHT`, `SPAN`, `UNSANITISE_XML`, `WORDS_WITH_CAPITAL`

#### Time (0207)
`ELAPSED_SECONDS`, `GET_TIME`, `MILLISECONDS`, `SET_TIME_VAR`, `SYS_SECONDS` *(see note below)*

#### Miscellaneous (0208)
`ABN_VALIDATE`, `BARCODE`, `BASE64_DECODE`, `BASE64_ENCODE`, `DOS_COMMAND_WAIT`, `EMAIL`, `EMAILX_WARN`, `FORM_EXTENSION`, `FORM_NAME`, `FORM_OPTIONS`, `GET_CONFIGURATION_STRING_BY_ID`, `GET_TABLE_NAME`, `HTTPS_POST_AUTHENTICATE`, `HTTP_GET`, `HTTP_POST`, `HTTP_POST_SOAPACTION`, `IPATH`, `JAVA_EXECUTE`, `LOG_STRING`, `NEXT_WORKING_DAY`, `NO_SWITCHES_SINCE_EOY`, `OUTPUT_FILENAME_COMPONENTS`, `PAYROLL_ACCESS_DAYS`, `PRINT_CMD`, `PRINT_IMAGE`, `REPAIR_FILENAME`, `REPORT_VARCHAR_PARAM`, `RUN_BATCH_JOB_EX`, `SAVE_AS_XLSX`, `SET_PURGE_FLAG`, `SYS_VERSION`, `TFN_ENCRYPT`, `TFN_VALIDATE`, `WORKING_DAYS_BETWEEN`

#### GUI Extension (0209) — all missing
`GUI_GET_DATE_VALUE`, `GUI_GET_DOUBLE_VALUE`, `GUI_GET_FOCUSABLE`, `GUI_GET_LONG_VALUE`, `GUI_GET_SHORT_VALUE`, `GUI_GET_TIME_VALUE`, `GUI_GET_VALUE_REQUIRED`, `GUI_GET_VISIBLE`, `GUI_POP_VALIDATION_ERROR`, `GUI_PUSH_VALIDATION_ERROR`, `GUI_SET_DATE_FIELD`, `GUI_SET_DATE_VALUE`, `GUI_SET_DOUBLE_FIELD`, `GUI_SET_DOUBLE_VALUE`, `GUI_SET_LONG_FIELD`, `GUI_SET_LONG_VALUE`, `GUI_SET_SHORT_FIELD`, `GUI_SET_SHORT_VALUE`, `GUI_SET_STRING_FIELD`, `GUI_SET_TIME_FIELD`, `GUI_SET_TIME_VALUE`, `GUI_SET_VALUE_REQUIRED`, `GUI_SET_VISIBLE`, `GUI_VAR_GET_DATE`, `GUI_VAR_GET_DOUBLE`, `GUI_VAR_GET_SHORT`, `GUI_VAR_GET_STRING`, `GUI_VAR_GET_TIME`, `GUI_VAR_SET_DATE`, `GUI_VAR_SET_DOUBLE`, `GUI_VAR_SET_SHORT`, `GUI_VAR_SET_STRING`, `GUI_VAR_SET_TIME`, `PROMPT_FORM`

---

### 1b. Registry-only (not in treedata5 — possibly internal or inferred from corpus)

These 41 entries exist in the registry but have no counterpart in treedata5. They may be internal helpers, corpus-inferred, or client-specific extensions.

`ABN`, `ARRAY_LONG_TO_KEY`, `ARRAY_SHORT_TO_KEY`, `ASSERT`, `CENTER`, `CHECK_ZERO_DATE`, `CMD`, `CWB_ADD_MESSAGE`, `CWB_TRANS_GET_FIELD_VALUE`, `CWB_TRANS_READ_STATIC`, `DESCRIPTION_USER`, `EXISTS`, `FROM`, `GET_STR`, `INSURED`, `INTEGER`, `NUMBER`, `READ_ERRORS_INDEX2`, `READ_FILE`, `READ_FILEREG_INDEX1`, `READ_WORKBENCH_LINES_INDEX0`, `REGEX_LAST_MATCHED_GROUP`, `REGEX_MATCH`, `REGEX_MATCH_SIMPLE`, `SCH_TRANSLATE_FILE`, `SMEMBER_READ`, `SQL_FREE_HANDLE`, `TO`, `TRANSLATE_CLICKSUPER_FILE`, `UPDATE_STATIC_LINES_TO_MATCHED_FOR_RECEIPT`, `USI`, `VARCHAR_FORMAT`, `VERIFY_FILE_REG_STATUS`, `WESTPAC_TRANSLATE_FILE`, `XMLDOCUMENT_CREATE_FROM_FILE`, `XMLDOCUMENT_CREATE_FROM_STRING`, `XPATHCONTEXT_CHECK_XPATH`, `XPATHCONTEXT_COUNT_ELEMENTS`, `XPATHCONTEXT_CREATE`, `XPATHCONTEXT_GET_STRING`, `YYYY`

**Notable:** `FROM` and `TO` are formatting statements in treedata5 (section 0111), not functions. `CENTER` is also a formatting statement. These may need to remain in the registry but their category/treatment should be reviewed.

---

### 1c. Type discrepancies (return type differs between treedata5 and registry)

| Function | treedata5 return type | Registry return type |
|---|---|---|
| `SYS_SECONDS` | `DOUBLE` (Time Functions) | Treated as constant `LONG` in constantsRegistry |
| `LENGTH` | `LONG` | `SHORT` |
| `INDEX` | `LONG` | `SHORT` |
| `SEARCH` | `LONG` | `SHORT` |
| `OCCURS` | `LONG` | (missing) |
| `SPAN` | `LONG` | (missing) |
| `NUMBER_OF_TOKENS` | `LONG` | (missing) |
| `SYS_TIME` | `STRING` | `LONG` |
| `GET_TIME` | `SHORT` | (missing) |

---

## 2. Constants Registry (`constantsRegistry.js`)

Currently only 6 entries. treedata5 section 03 > Global Variables lists 204 built-in global variables.

### 2a. Missing globals (199 entries)

| Name | Type | Notes |
|---|---|---|
| `DB_STATUS` | SHORT | Very commonly used — database operation return status |
| `HEADER` | BOOLEAN | Report context flag |
| `BODY` | BOOLEAN | Report context flag |
| `FOOTER` | BOOLEAN | Report context flag |
| `INIT_SCHED` | BOOLEAN | Report context flag |
| `FIN_SCHED` | BOOLEAN | Report context flag |
| `ACCEPT_REC` | BOOLEAN | |
| `FORM_FEED` | BOOLEAN | |
| `SUB_TOTALLING` | BOOLEAN | |
| `SUBTOTAL` | BOOLEAN | |
| `PAGE_NUMBER` | LONG | |
| `CURRENT_PRINTER` | SHORT | |
| `NUM_HEADER_LINES` | SHORT | |
| `NUM_BODY_LINES` | SHORT | |
| `NUM_FOOTER_LINES` | SHORT | |
| `NUM_FINAL_LINES` | SHORT | |
| `NUM_LINES_PER_PAGE` | SHORT | |
| `NUM_LINES_PRINTED` | SHORT | |
| `TAB_STR` | STRING | |
| `NEW_LINE_STR` | STRING | Already in registry ✓ |
| `UNALLOC_FLAG` | STRING | |
| `REPORT_LEVEL` | SHORT | |
| `FATAL_ERROR_FLAG` | SHORT | |
| `SCH_COMPANY` | STRING | |
| `CLIENT_SYS_FLAG` | STRING | |
| `INV_BANK_ACC` | STRING | |
| `CONT_CALCS_ONLY` | STRING | |
| `CONFIRM_REVIEW` | STRING | |
| `PROCESS_DESC` | STRING | |
| `INTERIM_REVIEW` | STRING | |
| `EXITING_FLAG` | STRING | |
| `MIN_STR` | STRING | Already in registry ✓ |
| `MAX_STR` | STRING | Already in registry ✓ |
| `MIN_DATE` | DATE | Already in registry ✓ |
| `MAX_DATE` | DATE | Already in registry ✓ |
| `MIN_TIME` | TIME | |
| `MAX_TIME` | TIME | |
| `MIN_DOUBLE` | DOUBLE | |
| `MAX_DOUBLE` | DOUBLE | |
| `MIN_SHORT` | SHORT | |
| `MAX_SHORT` | SHORT | |
| `MIN_LONG` | LONG | |
| `MAX_LONG` | LONG | |
| `CLIENT_CODE` | STRING | |
| `WEB_USERID` | STRING | |
| `WEB_PASSWORD` | STRING | |
| `CONFIG_FILENAME` | STRING | |
| `WEB_TEXT_STR1`–`WEB_TEXT_STR5` | STRING | |
| `WEB_TEXT_TYPE` | STRING | |
| `WEB_FILE_REF_ID` | LONG | |
| `WEB_FILE_LINE_NO` | LONG | |
| `SEP0`–`SEP5` | STRING | |
| `SEP_CP`, `SEP_FOLDER`, `SEP_LDAP_GROUP` | STRING | |
| `ERRORS_TO_WARNINGS` | SHORT | |
| `OUTPUT_TEMPLATE` | STRING | |
| `RTF_DEBUG` | STRING | |
| `UNIT_TESTING` | SHORT | |
| `OUTPUT_FILE_TYPE` | SHORT | |
| `LAST_ERROR` | STRING | |
| `REPORT_CUSTOM_DATA` | STRING | |
| `REPORT_AMT` | DOUBLE | |
| `DIVISION` | STRING | |
| `COMPANY_CODE` | STRING | |
| `EXIT_FLAG` | STRING | |
| `USE_EXIT_DATE` | STRING | |
| `SYSTEM_DATE` | DATE | |
| `DAT_PATH` | STRING | |
| `TRANS_REF` | LONG | |
| `BATCH_REF` | LONG | |
| `SORT_FLAG` | STRING | |
| `MBR_GL_KEY` | SHORT | |
| `SCREEN_UPDATES` | SHORT | |
| `START_DATE` | DATE | |
| `QQTE_SURCHARGE` | DOUBLE | |
| `VERSION_NBR` | STRING | |
| `ATO_IDENTITY` | STRING | |
| `QQTE_PRE83` | DOUBLE | |
| `WEB_REQUEST` | STRING | |
| `TESTING_BATCH` | SHORT | |
| `GCF_SHORT_FUND`–`GCF_VEST_PRES` | STRING | 9 GCF_ flags |
| `SAL_FREQ` | DOUBLE | |
| `REPORT_FILTERING_PARAMS` | STRING | |
| `EXTENSION_MESSAGE` | STRING | |
| `EXTENSION_CONTEXT` | STRING | |
| `SCRIPT_HAS_OUTPUT` | SHORT | |
| `AUTOMATIC_PRINT` | SHORT | |
| `PRN_NAME`–`PRN_FILENAME` | STRING | 7 PRN_ print config vars |
| `LDAP_USER_GROUPS_PREFIX` | STRING | |
| `AIS_URL` | STRING | |
| `TOTCOL_1`–`TOTCOL_30` | DOUBLE | 30 column total accumulators |
| `SUBCOL_1`–`SUBCOL_30` | DOUBLE | 30 sub-total accumulators |
| `GNDCOL_1`–`GNDCOL_30` | DOUBLE | 30 grand total accumulators |

### 2b. Registry entry with wrong type

| Name | Registry type | treedata5 type |
|---|---|---|
| `SYS_SECONDS` | `LONG` (in constantsRegistry) | `DOUBLE` (in functionsRegistry as a function) |

`SYS_SECONDS` appears in treedata5 as a **function** (section 0207 Time Functions, returns `DOUBLE`), not a constant. It should likely be in `functionsRegistry` only, and removed from `constantsRegistry`.

---

## 3. Database Fields — New Category (not yet represented)

treedata5 section 03 (Variables) contains ~10,533 database field entries across **171 tables** grouped under 17 categories (Accounting, Audit, Fund, Employer, Member, Category, Fees/Formulas/Tables, Payee, Investment, Insurer, Adviser, Configuration, Reports, Security, Taxation, Tools, Transactional).

These are prefixed `h` + two-letter table code + one-letter type indicator + `_` + field name
e.g. `hMBz_Surname` (Member table, STRING field), `hMBd_Birth` (Member table, DATE field).

**Type indicator convention (from the field names):**
- `z` / `c` — STRING
- `d` — DATE
- `t` — TIME
- `l` — INTEGER (LONG)
- `s` — INTEGER (SHORT)
- `f` — DOUBLE (float)
- `v` — VARSTRING

These are currently not validated at all — any `hXX_` reference passes through silently. Whether to add a database fields registry depends on whether false-positive suppression or field-name completion is desired.

---

## Recommendations

### Priority 1 — High value, low effort
1. **Expand `constantsRegistry`** with all 199 missing global variables — these are very commonly used in real reports and would eliminate a large class of false-positive "undefined variable" diagnostics (once that validator exists).
2. **Fix `SYS_SECONDS`** — move from `constantsRegistry` (wrong) to `functionsRegistry` with `DOUBLE` return type.
3. **Fix return type mismatches** — `LENGTH`, `INDEX`, `SEARCH` should return `LONG` not `SHORT`; `SYS_TIME` returns `STRING` not `LONG`.

### Priority 2 — Broad coverage
4. **Add the 379 missing functions** to `functionsRegistry`. Since parameter signatures aren't in treedata5, add them with `params: []`, `varArgs: true`, and the correct return type — this is enough to suppress false-positive undefined-function diagnostics.

### Priority 3 — New work
5. **Database fields registry** — decide whether to create a `dbFieldsRegistry.js`. Given the naming convention (`h` + 2-letter code + type char + `_` + name), a regex-based approach in the validator (suppress errors for identifiers matching `/^h[A-Z]{2}[zdtlsfvc]_/i`) might be simpler than a full registry, and would handle the entire class of ~10,533 fields without enumerating them.
6. **Review registry-only functions** — validate whether the 41 registry-only entries (`REGEX_*`, `XML*`, `CWB_*`, etc.) exist in real code and if so document their origin.
