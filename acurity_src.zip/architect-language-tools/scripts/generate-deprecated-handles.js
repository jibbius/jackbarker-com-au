/**
 * generate-deprecated-handles.js
 *
 * Generates core/src/builtins/deprecatedHandlesRegistry.js from the
 * "Deprecated Variables" section (ID "04") of treedata5.txt.
 *
 * Each entry in section 04 maps an old-style TABLE_FIELD handle name to its
 * canonical replacement (the current h-prefix handle name). The javaparser
 * stores the deprecated name in the Description column (col 4) and the
 * replacement in the Name column (col 2).
 *
 * Entries whose replacement value is an expression pattern (contains '(' or
 * whitespace) are still included — the replacement string appears verbatim in
 * the ACU-SYM-001 diagnostic message, which is useful guidance for the user.
 *
 * Run from the architect-language-tools/ directory:
 *   node scripts/generate-deprecated-handles.js
 *
 * Commit the output file. Re-run if treedata5.txt is updated.
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname  = dirname(__filename);

const INPUT  = path.join(__dirname, "../../reference-data/treedata5.txt");
const OUTPUT = path.join(__dirname, "../core/src/builtins/deprecatedHandlesRegistry.js");

// ── Parse treedata5.txt ──────────────────────────────────────────────────────

const lines = fs.readFileSync(INPUT, "utf8").split(/\r?\n/);

// Section 04 entries have IDs that begin with "04" followed by digits,
// with any amount of leading whitespace before the ID.
const SECTION_04_ENTRY = /^\s*(04\d+):/;

// A valid Architect identifier: starts with a letter, contains only letters,
// digits, and underscores. This guards against registering entry IDs, partial
// lines, or other artefacts as deprecated names.
const VALID_IDENTIFIER = /^[A-Za-z][A-Za-z0-9_]*$/;

/** @type {Map<string, string>}  upperDeprecatedName → canonicalReplacement */
const entries = new Map();
const duplicates = [];

for (const line of lines) {
    if (!SECTION_04_ENTRY.test(line)) continue;

    const trimmed = line.trim();
    const cols = trimmed.split(":");

    // cols: [entry_id, parent_id, name(replacement), type, description(deprecated), help]
    if (cols.length < 5) continue;

    const replacement  = cols[2].trim();   // new h-prefix handle name (or expression)
    const deprecated   = cols[4].trim();   // old TABLE_FIELD style name

    // Both columns must be non-empty.
    if (!replacement || !deprecated) continue;

    // The deprecated name (col 4) must be a valid plain identifier — skip anything
    // that looks like an expression, a partial ID, or contains special characters.
    if (!VALID_IDENTIFIER.test(deprecated)) continue;

    // Skip entries that look like h-prefix handles already — they belong to
    // section 03 and would conflict with the active handle registry.
    // (In practice section 04 description col is never h-prefixed, but guard anyway.)
    if (/^h[A-Z]/i.test(deprecated)) continue;

    const key = deprecated.toUpperCase();

    if (entries.has(key)) {
        duplicates.push({ key, existing: entries.get(key), incoming: replacement });
    } else {
        entries.set(key, replacement);
    }
}

if (duplicates.length > 0) {
    console.warn(`\nWarning: ${duplicates.length} duplicate deprecated name(s) — first occurrence kept:`);
    for (const { key, existing, incoming } of duplicates) {
        console.warn(`  ${key}: existing='${existing}'  incoming='${incoming}'`);
    }
}

// ── Emit the registry file ───────────────────────────────────────────────────

const sortedKeys = [...entries.keys()].sort();

const objectBody = sortedKeys
    .map(key => `    ${JSON.stringify(key)}: ${JSON.stringify(entries.get(key))}`)
    .join(",\n");

const now = new Date().toISOString().slice(0, 10);

const output = `\
/**
 * deprecatedHandlesRegistry.js — deprecated field handle aliases.
 *
 * Maps old-style TABLE_FIELD handle names (the pre-h-prefix naming convention)
 * to their canonical replacement h-prefix names.
 *
 * Keys are upper-cased for case-insensitive lookup. Values are the canonical
 * replacement name as it appears in the current field handle registry, or an
 * expression pattern for the handful of entries that were deprecated in favour
 * of a computed value (e.g. SUBSTR(...)).
 *
 * Source: reference-data/treedata5.txt section 04 (Deprecated Variables)
 * Generated: ${now}
 * Entries: ${entries.size}
 *
 * Re-generate with:
 *   node scripts/generate-deprecated-handles.js
 */

const DeprecatedHandles = {
${objectBody}
};

export { DeprecatedHandles };
`;

fs.writeFileSync(OUTPUT, output, "utf8");
console.log(`Written ${entries.size} deprecated handle entries to ${path.relative(process.cwd(), OUTPUT)}`);
