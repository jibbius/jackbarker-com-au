/**
 * generate-table-structures.js
 *
 * Generates tableStructures/<CODE>.js for all tables registered in tableRegistry.js
 * that do not yet have a structure file.
 *
 * Sources:
 *   - fieldRegistry.js   — field handle data, grouped by tableCode
 *   - tableRegistry.js   — table names (TABLE_REGISTRY)
 *
 * Existing files are never overwritten by default; they may contain authoritative
 * index data that cannot be regenerated from available sources.
 *
 * Usage (from architect-language-tools/ directory):
 *
 *   Generate all missing files:
 *     node scripts/generate-table-structures.js
 *
 *   Force-regenerate the fields block for a specific table (preserves nothing —
 *   use only for tables whose structure file has no authoritative index data yet):
 *     node scripts/generate-table-structures.js --force AB
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath, pathToFileURL } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname  = dirname(__filename);

const FIELD_REGISTRY_PATH = path.join(__dirname, "../core/src/builtins/fieldRegistry.js");
const TABLE_REGISTRY_PATH = path.join(__dirname, "../core/src/builtins/tableRegistry.js");
const OUTPUT_DIR          = path.join(__dirname, "../core/src/builtins/tableStructures");

// ── CLI args ────────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
let forceCode = null;
const forceIdx = args.indexOf("--force");
if (forceIdx !== -1) {
    forceCode = args[forceIdx + 1]?.toUpperCase() ?? null;
    if (!forceCode) {
        console.error("Error: --force requires a table code (e.g. --force AB)");
        process.exit(1);
    }
}

// ── Load source data ─────────────────────────────────────────────────────────

const { FIELD_REGISTRY } = await import(pathToFileURL(FIELD_REGISTRY_PATH).href);
const { TABLE_REGISTRY } = await import(pathToFileURL(TABLE_REGISTRY_PATH).href);

// ── Group fields by table code ───────────────────────────────────────────────

/** @type {Map<string, Array<[string, {canonical: string, type: string}]>>} */
const fieldsByTable = new Map();

for (const [key, entry] of Object.entries(FIELD_REGISTRY)) {
    const code = entry.tableCode;
    if (!fieldsByTable.has(code)) fieldsByTable.set(code, []);
    fieldsByTable.get(code).push([key, entry]);
}

// Sort each table's fields alphabetically within each type-prefix group.
for (const entries of fieldsByTable.values()) {
    entries.sort(([a], [b]) => a.localeCompare(b));
}

// ── Type-prefix metadata ──────────────────────────────────────────────────────

// Maps the 4th character of a lowercase field key (e.g. "hmdz_member"[3] === 'z')
// to a human-readable section label used in the comment header.
const PREFIX_ORDER  = ['b', 'c', 'd', 'f', 'i', 'l', 's', 't', 'z'];
const PREFIX_LABELS = {
    b: 'CLOB',
    c: 'STRING',
    d: 'DATE',
    f: 'DOUBLE',
    i: 'BIGINT',
    l: 'INTEGER',
    s: 'INTEGER',
    t: 'TIME',
    z: 'STRING',
};

function typePrefix(key) {
    // key format: h + XX (2-char table code) + prefix-letter + _ + FieldName
    // All lowercase, so prefix letter is at index 3.
    return key[3] ?? '?';
}

// ── File generator ────────────────────────────────────────────────────────────

function generateFile(code, tableEntry, fields) {
    const humanName  = tableEntry.name;
    const schemaName = humanName.replace(/ /g, "_");
    const pkField    = `${code}i_Identity`;

    // Column-align keys and canonical values independently.
    const maxKeyLen = fields.reduce((m, [k]) => Math.max(m, k.length), 0);
    const maxCanLen = fields.reduce((m, [, e]) => Math.max(m, e.canonical.length), 0);

    // Group by prefix
    const byPrefix = new Map();
    for (const [key, entry] of fields) {
        const p = typePrefix(key);
        if (!byPrefix.has(p)) byPrefix.set(p, []);
        byPrefix.get(p).push([key, entry]);
    }

    const out = [];

    out.push(`/**`);
    out.push(` * ${code}.js — table structure for the ${code} (${humanName}) table.`);
    out.push(` *`);
    out.push(` * Indexes: PK only — replace with authoritative schema data when available.`);
    out.push(` * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "${code}").`);
    out.push(` *`);
    out.push(` * Re-generate the fields block with:`);
    out.push(` *   node scripts/generate-table-structures.js --force ${code}`);
    out.push(` */`);
    out.push(``);
    out.push(`/** @type {Object} */`);
    out.push(`const ${code} = {`);
    out.push(`    code: "${code}",`);
    out.push(`    name: "${schemaName}",`);
    out.push(`    recordLength: null,`);
    out.push(`    helpRegistry: "h${code}.htm",`);
    out.push(`    indexes: [`);
    out.push(`        {`);
    out.push(`            name: "PK",`);
    out.push(`            modifiable: false,`);
    out.push(`            duplicates: false,`);
    out.push(`            segments: [`);
    out.push(`                { position: 0, field: "${pkField}", type: "BIGINT", length: 8 }`);
    out.push(`            ]`);
    out.push(`        }`);
    out.push(`    ],`);
    out.push(`    fields: {`);

    if (fields.length === 0) {
        out.push(`        // No fields found in fieldRegistry for table ${code}`);
    } else {
        let firstSection = true;
        for (const prefix of PREFIX_ORDER) {
            const group = byPrefix.get(prefix);
            if (!group) continue;

            const label = PREFIX_LABELS[prefix] ?? prefix.toUpperCase();
            const dashes = '─'.repeat(Math.max(4, 68 - label.length - prefix.length - 12));
            if (!firstSection) out.push('');
            out.push(`        // ── ${label} (${prefix}-prefix) ${dashes}`);
            firstSection = false;

            for (const [key, entry] of group) {
                const paddedKey = `"${key}"`.padEnd(maxKeyLen + 2);
                const paddedCan = JSON.stringify(entry.canonical).padEnd(maxCanLen + 2);
                out.push(`        ${paddedKey}: { canonical: ${paddedCan}, type: ${JSON.stringify(entry.type)}, tableCode: "${code}" },`);
            }
        }

        // Catch any prefix letters not in PREFIX_ORDER (defensive)
        for (const [prefix, group] of byPrefix) {
            if (PREFIX_ORDER.includes(prefix)) continue;
            out.push('');
            out.push(`        // ── (${prefix}-prefix) ──────────────────────────────────────────────────`);
            for (const [key, entry] of group) {
                const paddedKey = `"${key}"`.padEnd(maxKeyLen + 2);
                const paddedCan = JSON.stringify(entry.canonical).padEnd(maxCanLen + 2);
                out.push(`        ${paddedKey}: { canonical: ${paddedCan}, type: ${JSON.stringify(entry.type)}, tableCode: "${code}" },`);
            }
        }
    }

    out.push(`    }`);
    out.push(`};`);
    out.push(``);
    out.push(`export default ${code};`);
    out.push(``);

    return out.join('\n');
}

// ── Main loop ─────────────────────────────────────────────────────────────────

let generated = 0;
let skipped   = 0;
let forced    = 0;

for (const [code, tableEntry] of Object.entries(TABLE_REGISTRY)) {
    const outputPath = path.join(OUTPUT_DIR, `${code}.js`);
    const exists     = fs.existsSync(outputPath);
    const fields     = fieldsByTable.get(code) ?? [];

    if (exists && forceCode !== code) {
        process.stdout.write(`  skip   ${code}.js\n`);
        skipped++;
        continue;
    }

    const content = generateFile(code, tableEntry, fields);
    fs.writeFileSync(outputPath, content, "utf8");

    if (exists) {
        process.stdout.write(`  forced ${code}.js  (${fields.length} fields)\n`);
        forced++;
    } else {
        process.stdout.write(`  write  ${code}.js  (${fields.length} fields)\n`);
        generated++;
    }
}

console.log(`\nDone: ${generated} generated, ${forced} force-regenerated, ${skipped} skipped.`);
