module.exports = {
    transform: {},
    moduleNameMapper: {
        '^vscode$': '<rootDir>/test/__mocks__/vscode.js'
    },
    testEnvironment: 'node',
    testMatch: ['**/test/**/*.test.js'],
    collectCoverageFrom: [
        'src/**/*.js',
        '!core/src/build-metadata.json'
    ],
    coverageDirectory: 'coverage',
    verbose: true,
    testTimeout: 5000
};
