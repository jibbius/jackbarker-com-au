/**
 * Variable declaration validator for Acurity Architect.
 *
 * ACU-SYN-010 — keywordUsedAsVariableName
 *   Fires when a VAR statement uses a reserved keyword as the variable name.
 *   e.g. `VAR IF : STRING` — IF is a reserved keyword and cannot be a variable name.
 *
 *   The AST parser tokenises keywords as KEYWORD tokens (not IDENTIFIER tokens), so
 *   `collectIdentifiers` skips them and the resulting VarStatement has an empty names
 *   array. The parser also captures these rejected names in `keywordNames` so this
 *   validator can report them with accurate character positions.
 *
 * ACU-VAR-010 — variableNameCollidesWithCallable
 *   Fires when a variable declaration uses the same name (case-insensitive) as a
 *   user-defined function or macro declared in the same document.
 */

import { NodeType } from "../ast/nodes.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";
import { BuiltInFunctions, BuiltInGlobalVariables } from "../builtins/functions.js";
import { walkWithGuardContext } from "../analysis/functionAnalysis.js";

/**
 * @param {object} document
 * @param {Function} getRuleSeverity
 * @param {object} [options={}]
 * @param {object} [options.ast]                        - Parsed AST from facts
 * @param {object} [options.userDefinedFunctionCatalog] - facts.userDefinedFunctionCatalog
 * @param {object} [options.macroCatalog]               - facts.macroCatalog
 * @returns {object[]}
 */
function validateVarDeclarations(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const { ast, userDefinedFunctionCatalog = {}, macroCatalog = {} } = options;
    if (!ast) return diagnostics;

    walkWithGuardContext(ast.statements, new Set(), (stmt, guardedNames) => {
        if (stmt.type !== NodeType.VarStatement) return;

        // ACU-SYN-010: reserved keyword used as variable name
        for (const { name, char } of stmt.keywordNames ?? []) {
            const range = {
                start: { line: stmt.line, character: char },
                end:   { line: stmt.line, character: char + name.length }
            };
            const diag = createDiagnostic(
                range,
                { messageId: "ACU-SYN-010", params: { name } },
                getRuleSeverity
            );
            if (diag) diagnostics.push(diag);
        }

        for (const { name, char } of stmt.names ?? []) {
            const upper = name.toUpperCase();

            // ACU-VAR-010: variable name shadows a user-defined function or macro
            const kind  = upper in userDefinedFunctionCatalog ? "function"
                        : upper in macroCatalog               ? "macro"
                        : null;
            if (kind) {
                const range = {
                    start: { line: stmt.line, character: char },
                    end:   { line: stmt.line, character: char + name.length }
                };
                const diag = createDiagnostic(
                    range,
                    { messageId: "ACU-VAR-010", params: { name, kind } },
                    getRuleSeverity
                );
                if (diag) diagnostics.push(diag);
                continue;
            }

            // ACU-VAR-011: variable name shadows a built-in global variable or function
            if (upper in BuiltInGlobalVariables || upper in BuiltInFunctions) {
                if (guardedNames.has(upper)) continue;

                const range = {
                    start: { line: stmt.line, character: char },
                    end:   { line: stmt.line, character: char + name.length }
                };
                const diag = createDiagnostic(
                    range,
                    { messageId: "ACU-VAR-011", params: { name } },
                    getRuleSeverity
                );
                if (diag) diagnostics.push(diag);
            }
        }
    });

    return diagnostics;
}

export { validateVarDeclarations };
