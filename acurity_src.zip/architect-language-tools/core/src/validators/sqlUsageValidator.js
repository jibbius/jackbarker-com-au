/**
 * SQL usage validator for Acurity Architect.
 *
 * ACU-SQL-001 — sqlDirectMutation
 *   Fires when SQL_EXEC_DIRECT is called with a string literal that begins with
 *   a mutating SQL verb, or when SQL_EXECUTE is called and the nearest preceding
 *   SQL_PREPARE on the same handle contains a mutating verb.
 *   Severity: warning in default/legacy, error in strict.
 *
 * ACU-SQL-002 — sqlDynamicString
 *   Fires when SQL_EXEC_DIRECT is called with a non-literal SQL string argument
 *   (variable, concatenated expression, or function call result).
 *   ACU-SQL-001 and ACU-SQL-002 are mutually exclusive for any given call.
 *   Severity: warning in default/strict, information in legacy.
 */

import { NodeType } from "../ast/nodes.js";
import { ExprNodeType } from "../ast/expressionNodes.js";
import { buildDocumentAst } from "../ast/documentAst.js";
import { parseExpression } from "../ast/expressionParser.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";

// SQL verbs that constitute a mutation (write operation).
const MUTATING_VERBS = new Set([
    "INSERT", "UPDATE", "DELETE", "MERGE", "TRUNCATE", "DROP", "CREATE", "ALTER"
]);

/**
 * Extracts the leading SQL verb from a string literal token value.
 * Token values for STRING_LITERAL include surrounding quote characters —
 * this function strips them before extracting the first word.
 * Returns the verb uppercased, or null if none found.
 * @param {string} sqlStr  Raw token value, possibly surrounded by " or ' delimiters.
 */
function extractSqlVerb(sqlStr) {
    let s = sqlStr;
    // Strip surrounding " or ' delimiters that the lexer includes in token values.
    if (s.length >= 2) {
        const first = s[0];
        const last  = s[s.length - 1];
        if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            s = s.slice(1, -1);
        }
    }
    const trimmed = s.trim();
    const match = trimmed.match(/^([A-Za-z]+)/);
    return match ? match[1].toUpperCase() : null;
}

/**
 * Returns true if the expression node is a plain string literal
 * (ExprNodeType.LITERAL with a string inferredType).
 */
function isStringLiteral(node) {
    return node?.type === ExprNodeType.LITERAL && node?.inferredType === "STRING";
}

/**
 * Returns the first meaningful token from an expression node, for position reporting.
 */
function getExprToken(node) {
    if (!node) return null;
    if (node.token) return node.token;
    if (node.callee?.token) return node.callee.token;
    if (node.startToken) return node.startToken;
    return null;
}

/**
 * Attempts to get the simple identifier name from a handle expression node.
 * Returns null if the handle is not a plain identifier (e.g. it is a complex expression).
 */
function getHandleName(node) {
    if (!node) return null;
    if (node.type === ExprNodeType.IDENTIFIER) return node.name?.toUpperCase();
    return null;
}

// ---------------------------------------------------------------------------
// Statement collector — mirrors argumentTypeValidator's collectExpressionSpans
// ---------------------------------------------------------------------------

/**
 * Walks the AST and collects { lineIndex, span } for all expression-bearing
 * statement nodes. Descends into block bodies, conditionals, and branches.
 */
function collectExpressionSpans(statements, out = []) {
    for (const node of statements) {
        if (
            node.type === NodeType.AssignStatement      ||
            node.type === NodeType.SetStatement         ||
            node.type === NodeType.ExpressionStatement  ||
            node.type === NodeType.FunctionCallStatement
        ) {
            if (node.value) out.push({ span: node.value, lineIndex: node.line });
        }

        if (node.consequent?.length) collectExpressionSpans(node.consequent, out);
        if (node.alternate?.length)  collectExpressionSpans(node.alternate, out);
        if (Array.isArray(node.body)) collectExpressionSpans(node.body, out);
        if (node.branches) {
            for (const branch of node.branches) {
                if (branch.body) collectExpressionSpans(branch.body, out);
            }
        }
        if (Array.isArray(node.otherwise)) collectExpressionSpans(node.otherwise, out);
    }
    return out;
}

/**
 * Walks an expression tree and calls visitor for each CALL node.
 */
function walkCalls(node, visitor) {
    if (!node) return;
    switch (node.type) {
        case ExprNodeType.CALL:
            visitor(node);
            for (const arg of node.args || []) walkCalls(arg, visitor);
            break;
        case ExprNodeType.BINARY:
            walkCalls(node.left, visitor);
            walkCalls(node.right, visitor);
            break;
        case ExprNodeType.UNARY:
            walkCalls(node.operand, visitor);
            break;
        case ExprNodeType.PAREN:
            walkCalls(node.expr, visitor);
            break;
        default:
            break;
    }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Validates SQL_EXEC_DIRECT and SQL_EXECUTE usage.
 *
 * @param {object} document        VS Code TextDocument or test shim
 * @param {Function} getRuleSeverity
 * @param {object} [options]
 * @returns {object[]}  Diagnostic array
 */
function validateSqlUsage(document, getRuleSeverity, options = {}) {
    const diagnostics = [];

    const { ast } = buildDocumentAst(document);
    const spans = collectExpressionSpans(ast.statements);

    // First pass: collect all SQL_PREPARE calls keyed by handle name and line.
    // prepareByHandle: Map<handleName, { verb: string, lineIndex: number }[]>
    // We keep all (not just the last) so we can do nearest-preceding lookup by lineIndex.
    const prepareByHandle = new Map();

    for (const { span, lineIndex } of spans) {
        const exprTree = parseExpression(span);
        if (!exprTree) continue;

        walkCalls(exprTree, (callNode) => {
            const name = callNode.callee?.name?.toUpperCase();
            if (name !== "SQL_PREPARE") return;

            const handleArg = callNode.args?.[0];
            const sqlArg    = callNode.args?.[1];
            if (!handleArg || !sqlArg) return;

            const handleName = getHandleName(handleArg);
            if (!handleName) return;

            if (!isStringLiteral(sqlArg)) return; // dynamic prepare — can't statically analyse

            const verb = extractSqlVerb(sqlArg.value ?? "");
            if (!verb) return;

            if (!prepareByHandle.has(handleName)) prepareByHandle.set(handleName, []);
            prepareByHandle.get(handleName).push({ verb, lineIndex });
        });
    }

    // Second pass: validate SQL_EXEC_DIRECT and SQL_EXECUTE.
    for (const { span, lineIndex } of spans) {
        const exprTree = parseExpression(span);
        if (!exprTree) continue;

        walkCalls(exprTree, (callNode) => {
            const name = callNode.callee?.name?.toUpperCase();
            if (name !== "SQL_EXEC_DIRECT" && name !== "SQL_EXECUTE") return;

            const callToken = callNode.callee?.token ?? callNode.startToken;
            if (!callToken) return;

            const callRange = {
                start: { line: callToken.line, character: callToken.char },
                end:   { line: callToken.line, character: callToken.char + name.length }
            };

            if (name === "SQL_EXEC_DIRECT") {
                const sqlArg = callNode.args?.[1];
                if (!sqlArg) return;

                if (isStringLiteral(sqlArg)) {
                    // Static analysis possible — check for mutating verb.
                    const verb = extractSqlVerb(sqlArg.value ?? "");
                    if (verb && MUTATING_VERBS.has(verb)) {
                        const diag = createDiagnostic(callRange, {
                            messageId: "ACU-SQL-001",
                            params: { function: "SQL_EXEC_DIRECT", verb }
                        }, getRuleSeverity);
                        if (diag) diagnostics.push(diag);
                    }
                    // SELECT or other non-mutating verb — no diagnostic.
                } else {
                    // Non-literal (variable, concatenation, call) — fire ACU-SQL-002.
                    const diag = createDiagnostic(callRange, {
                        messageId: "ACU-SQL-002",
                        params: { function: "SQL_EXEC_DIRECT" }
                    }, getRuleSeverity);
                    if (diag) diagnostics.push(diag);
                }

            } else {
                // SQL_EXECUTE — look back to nearest SQL_PREPARE on the same handle.
                const handleArg = callNode.args?.[0];
                if (!handleArg) return;

                const handleName = getHandleName(handleArg);
                if (!handleName) return;

                const prepares = prepareByHandle.get(handleName);
                if (!prepares) return;

                // Find nearest preceding prepare (largest lineIndex < current lineIndex).
                let nearest = null;
                for (const p of prepares) {
                    if (p.lineIndex < lineIndex) {
                        if (!nearest || p.lineIndex > nearest.lineIndex) nearest = p;
                    }
                }
                if (!nearest) return;

                if (MUTATING_VERBS.has(nearest.verb)) {
                    const diag = createDiagnostic(callRange, {
                        messageId: "ACU-SQL-001",
                        params: { function: "SQL_EXECUTE", verb: nearest.verb }
                    }, getRuleSeverity);
                    if (diag) diagnostics.push(diag);
                }
            }
        });
    }

    return diagnostics;
}

export { validateSqlUsage };
