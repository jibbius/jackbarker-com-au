/**
 * Break/Continue level validator for Acurity Architect.
 *
 * ACU-SYN-011 — breakContinueLevelExceeded
 *   Fires when BREAK N or CONTINUE N specifies a level that exceeds the number
 *   of enclosing DO loops at that point in the code.
 *
 *   Examples:
 *     DO WHILE x < 10       ← depth 1
 *       BREAK 2             ← ERROR: level 2 > depth 1
 *       DO WHILE y < 10     ← depth 2
 *         BREAK 3           ← ERROR: level 3 > depth 2
 *         BREAK 2           ← OK
 *       ENDDO
 *     ENDDO
 */

import { NodeType } from "../ast/nodes.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";

// ---------------------------------------------------------------------------
// Recursive depth-aware walk
// ---------------------------------------------------------------------------

/**
 * Recursively checks BREAK/CONTINUE level arguments against the current DO
 * loop nesting depth.
 *
 * @param {object[]} stmts       Statement list to scan
 * @param {number}   depth       Number of enclosing DO loops at this point
 * @param {object[]} out         Accumulated diagnostics
 * @param {object}   document    TextDocument (for line text lookup)
 * @param {Function} getRuleSeverity
 */
function checkBreakLevels(stmts, depth, out, document, getRuleSeverity) {
    for (const stmt of stmts) {
        const isBreak    = stmt.type === NodeType.BreakStatement;
        const isContinue = stmt.type === NodeType.ContinueStatement;

        if (isBreak || isContinue) {
            const level   = stmt.level ?? 1;
            const keyword = isBreak ? "BREAK" : "CONTINUE";
            // Only validate when we're inside at least one loop; bare BREAK/CONTINUE
            // outside any DO is already caught by the block-structure validator.
            if (depth > 0 && level > depth) {
                const lineText = document.lineAt(stmt.line).text;
                const kwPos    = lineText.toUpperCase().indexOf(keyword);
                const charStart = kwPos >= 0 ? kwPos : 0;
                const diag = createDiagnostic(
                    {
                        start: { line: stmt.line, character: charStart },
                        end:   { line: stmt.line, character: charStart + keyword.length }
                    },
                    { messageId: "ACU-SYN-011", params: { keyword, level, depth } },
                    getRuleSeverity
                );
                if (diag) out.push(diag);
            }
            continue;
        }

        if (stmt.type === NodeType.DoStatement) {
            // Each DO layer increments the available depth for its body.
            if (Array.isArray(stmt.body)) {
                checkBreakLevels(stmt.body, depth + 1, out, document, getRuleSeverity);
            }
        } else if (stmt.type === NodeType.FunctionDeclaration) {
            // A function is an independent call frame — BREAK/CONTINUE cannot
            // escape its boundary, so depth resets to 0 inside.
            if (Array.isArray(stmt.body)) {
                checkBreakLevels(stmt.body, 0, out, document, getRuleSeverity);
            }
        } else if (stmt.type === NodeType.IfStatement) {
            if (Array.isArray(stmt.consequent)) checkBreakLevels(stmt.consequent, depth, out, document, getRuleSeverity);
            if (Array.isArray(stmt.alternate))  checkBreakLevels(stmt.alternate,  depth, out, document, getRuleSeverity);
        } else if (stmt.type === NodeType.CaseStatement) {
            if (stmt.branches) {
                for (const branch of stmt.branches) {
                    if (Array.isArray(branch.body)) checkBreakLevels(branch.body, depth, out, document, getRuleSeverity);
                }
            }
            if (Array.isArray(stmt.otherwise)) checkBreakLevels(stmt.otherwise, depth, out, document, getRuleSeverity);
        }
    }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Validates BREAK/CONTINUE level arguments across a document.
 *
 * @param {object}   document         TextDocument (VS Code or test shim)
 * @param {Function} getRuleSeverity
 * @param {object}   [options={}]
 * @param {object}   [options.ast]    Parsed AST from facts
 * @returns {object[]} Diagnostics array
 */
function validateBreakLevels(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const { ast } = options;
    if (!ast) return diagnostics;
    checkBreakLevels(ast.statements, 0, diagnostics, document, getRuleSeverity);
    return diagnostics;
}

export { validateBreakLevels };
