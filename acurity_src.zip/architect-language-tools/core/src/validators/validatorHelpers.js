/**
 * Shared helpers used by multiple validators.
 * Kept here to avoid duplicating logic across validator files.
 */

/**
 * Builds a Map<UPPERCASE_NAME, type> for user-declared variables visible at a given line.
 * Includes file-scope (module-level) variables, overlaid with any function-scope
 * variables (params + locals) active at lineIndex. Function-scoped symbols shadow
 * file-scope symbols when names collide.
 *
 * Only 'variable' and 'param' symbol kinds are included — built-ins are excluded
 * so that type inference sees the same set that was previously in declaredVariables.
 *
 * @param {object} symbolTable - from facts.symbolTable
 * @param {number} lineIndex - 0-based line index
 * @returns {Map<string, string>} Uppercase name → type string
 */
function buildVariablesMapFromSymbolTable(symbolTable, lineIndex) {
    const map = new Map();

    // File-scope variables (globals) first
    for (const sym of symbolTable.fileScope.symbols.values()) {
        if ((sym.kind === 'variable' || sym.kind === 'param') && sym.type) {
            map.set(sym.upperName, sym.type);
        }
    }

    // Function-scope symbols shadow file-scope entries
    const fnEntry = symbolTable.functionScopes.find(
        fs => lineIndex >= fs.startLine && lineIndex <= fs.endLine
    );
    if (fnEntry) {
        for (const sym of fnEntry.scope.symbols.values()) {
            if ((sym.kind === 'variable' || sym.kind === 'param') && sym.type) {
                map.set(sym.upperName, sym.type);
            }
        }
    }

    return map;
}

/**
 * Extracts the argument text from between the outer parentheses of a function-like call.
 * Handles nested parentheses and quoted strings correctly.
 *
 * @param {string} lineText - The full line (or code snippet) being scanned
 * @param {number} startPos - Position of the opening parenthesis
 * @returns {string|null} - The text between the outer parens, or null if the call is unclosed
 */
function extractFunctionArgs(lineText, startPos) {
    let depth = 0;
    let inString = false;
    let stringChar = null;

    for (let i = startPos; i < lineText.length; i++) {
        const char = lineText[i];

        if (!inString) {
            if (char === "'" || char === '"') {
                inString = true;
                stringChar = char;
            } else if (char === "(") {
                depth++;
            } else if (char === ")") {
                depth--;
                if (depth === 0) {
                    return lineText.substring(startPos + 1, i);
                }
            }
        } else {
            if (char === stringChar) {
                inString = false;
            }
        }
    }

    return null; // Unclosed
}

/**
 * Counts the number of comma-separated arguments in an argument string.
 * Handles nested parentheses and quoted strings correctly.
 *
 * @param {string} argsText - The text between the outer parentheses
 * @returns {number} - Number of arguments (0 for empty/blank string)
 */
function countArguments(argsText) {
    if (!argsText || argsText.trim() === "") {
        return 0;
    }

    let count = 1;
    let depth = 0;
    let inString = false;
    let stringChar = null;

    for (let i = 0; i < argsText.length; i++) {
        const char = argsText[i];

        if (!inString) {
            if (char === "'" || char === '"') {
                inString = true;
                stringChar = char;
            } else if (char === "(") {
                depth++;
            } else if (char === ")") {
                depth--;
            } else if (char === "," && depth === 0) {
                count++;
            }
        } else {
            if (char === stringChar) {
                inString = false;
            }
        }
    }

    return count;
}

export { buildVariablesMapFromSymbolTable, extractFunctionArgs, countArguments };
