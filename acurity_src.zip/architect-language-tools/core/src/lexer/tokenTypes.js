/**
 * Token type constants for the Architect language lexer.
 * Defined as a frozen object so token types are usable as both keys and values.
 */

const TokenType = Object.freeze({
    // Structure
    HASH_PREFIX:      "HASH_PREFIX",      // The '#' at the start of a hash-on code line
    COMMENT:          "COMMENT",          // // to end of line
    WHITESPACE:       "WHITESPACE",       // spaces and tabs
    NEWLINE:          "NEWLINE",          // \n or \r\n

    // Literals
    STRING_LITERAL:   "STRING_LITERAL",   // "..." or '...'
    NUMBER_LITERAL:   "NUMBER_LITERAL",   // integer or decimal digits
    DATE_LITERAL:     "DATE_LITERAL",     // DD/MM/YYYY (no spaces around slashes)
    TIME_LITERAL:     "TIME_LITERAL",     // HH:MM:SS:CC (no spaces, 1-2 digits per component)

    // Identifiers and keywords
    KEYWORD:          "KEYWORD",          // reserved control word (IF, ENDIF, VAR, SET, etc.)
    TYPE_KEYWORD:     "TYPE_KEYWORD",     // type name (STRING, SHORT, LONG, DATE, etc.)
    IDENTIFIER:       "IDENTIFIER",       // any other word token (variable, function name, constant)

    // Punctuation
    COLON:            "COLON",            // :
    COMMA:            "COMMA",            // ,
    LPAREN:           "LPAREN",           // (
    RPAREN:           "RPAREN",           // )
    LBRACKET:         "LBRACKET",         // [
    RBRACKET:         "RBRACKET",         // ]

    // Operators
    EQUALS:           "EQUALS",           // =
    PLUS:             "PLUS",             // +
    MINUS:            "MINUS",            // -
    STAR:             "STAR",             // *
    DOUBLE_STAR:      "DOUBLE_STAR",      // **  (exponentiation)
    SLASH:            "SLASH",            // /
    QUESTION:         "QUESTION",         // ?
    DOUBLE_QUESTION:  "DOUBLE_QUESTION",  // ??
    HASH:             "HASH",             // # appearing mid-line in code content (not an operator; effectively dead in valid Architect)
    AMPERSAND:        "AMPERSAND",        // &
    PIPE:             "PIPE",             // |
    CARET:            "CARET",            // ^
    TILDE:            "TILDE",            // ~
    PERCENT:          "PERCENT",          // %
    LT:               "LT",              // <
    GT:               "GT",              // >
    LT_EQ:            "LT_EQ",           // <=
    GT_EQ:            "GT_EQ",           // >=
    NOT_EQ:           "NOT_EQ",          // <>
    DOT:              "DOT",             // .
    CONTINUATION:     "CONTINUATION",    // ... (multi-line continuation operator)

    // Special line types
    OUTPUT_TEXT:      "OUTPUT_TEXT",      // the entire content of an output line (not tokenised further)
    UNKNOWN:          "UNKNOWN",          // character(s) that don't match any pattern

    // Sentinel
    EOF:              "EOF"              // end of input
});

export { TokenType };
