/**
 * Completion context helpers for Acurity Architect.
 * Pure module — no VS Code dependency.
 */

const BLOCK_CLOSER_RE = /\b(ENDIF|ENDDO|ENDCASE|ENDFUNCTION)\b/i;

/**
 * Keywords that introduce an expression context on the same line (no `=` needed).
 * E.g. `IF GET_TOK` — cursor is inside the IF condition, not at statement start.
 * The `#?` covers HASH-ON prefixed lines like `#IF GET_TOK`.
 */
const EXPRESSION_OPENER_RE = /^\s*#?\s*(IF|CASE|UNTIL|RETURN|VALUE|DO\s+WHILE)\s+/i;

/**
 * Returns true if the cursor (end of linePrefix) is at statement start:
 * - The line does not start with an expression-opening keyword (IF, CASE, UNTIL, etc.)
 * - No assignment operator `=` has been typed on this line
 * - The cursor is not inside open parentheses
 *
 * @param {string} linePrefix  Text from column 0 to the cursor position.
 * @returns {boolean}
 */
function isStatementStart(linePrefix) {
    if (EXPRESSION_OPENER_RE.test(linePrefix)) return false;
    const trimmed = linePrefix.trimStart();
    if (trimmed.includes("=")) return false;
    let depth = 0;
    for (const ch of trimmed) {
        if (ch === "(") depth++;
        else if (ch === ")") depth = Math.max(0, depth - 1);
    }
    return depth === 0;
}

/**
 * Returns true if the line prefix already contains a block-closing keyword
 * (ENDIF, ENDDO, ENDCASE, ENDFUNCTION). Nothing valid may follow these on
 * the same line (other than a trailing comment).
 *
 * @param {string} linePrefix
 * @returns {boolean}
 */
function isAfterBlockCloser(linePrefix) {
    return BLOCK_CLOSER_RE.test(linePrefix);
}

/**
 * Returns true if the line is a comment or NOTE directive — no completions apply.
 * @param {string} lineText
 * @returns {boolean}
 */
function isSuppressedLine(lineText) {
    const trimmed = lineText.trimStart();
    return (
        trimmed.startsWith("//") ||
        /^#\s*\/\//.test(trimmed) ||
        /^#\s*NOTE\b/i.test(trimmed)
    );
}

/**
 * Returns true if the line is a hash-mode output line (>>, ??, #??).
 * Completions inside these lines are restricted to interpolation zones.
 * @param {string} lineText
 * @returns {boolean}
 */
function isOutputLine(lineText) {
    const trimmed = lineText.trimStart();
    return (
        trimmed.startsWith(">>") ||
        trimmed.startsWith("??") ||
        /^#\s*\?\?/.test(trimmed)
    );
}

/**
 * Returns true if the cursor position (end of linePrefix) is inside an open
 * interpolation delimiter pair defined by oicc/cicc.
 *
 * When oicc === cicc (e.g. both "@"), parity counting applies.
 * When they differ, depth counting applies.
 *
 * @param {string} linePrefix  Text from column 0 to the cursor
 * @param {string} oicc        Opening interpolation delimiter character
 * @param {string} cicc        Closing interpolation delimiter character
 * @returns {boolean}
 */
function isInsideInterpolation(linePrefix, oicc, cicc) {
    if (oicc === cicc) {
        let count = 0;
        for (const ch of linePrefix) {
            if (ch === oicc) count++;
        }
        return count % 2 === 1;
    }
    let depth = 0;
    for (const ch of linePrefix) {
        if (ch === oicc) depth++;
        else if (ch === cicc && depth > 0) depth--;
    }
    return depth > 0;
}

/**
 * Returns true if the line is a variable declaration — completions are suppressed
 * to avoid polluting the name-writing experience.
 * @param {string} lineText
 * @returns {boolean}
 */
function isVarDeclarationLine(lineText) {
    return /^\s*(VAR\s+.*:|(?:STRING|SHORT|LONG|DOUBLE|BOOLEAN|DATE|TIME|BIGINT|INTEGER|TIMESTAMP)\s+\w)/i.test(lineText);
}

/**
 * Returns the identifier fragment immediately before the cursor (case-preserved).
 * Returns an empty string when the cursor is not directly after an identifier character.
 * @param {string} linePrefix
 * @returns {string}
 */
function getTypedPrefix(linePrefix) {
    const match = linePrefix.match(/([A-Za-z_][A-Za-z0-9_]*)$/);
    return match ? match[1] : "";
}

export { isStatementStart, isAfterBlockCloser, isSuppressedLine, isOutputLine, isInsideInterpolation, isVarDeclarationLine, getTypedPrefix };
