# Architecture Note: semanticTokenClassifier.js

## Purpose

Assigns VS Code semantic token types and modifiers to tokens in an Architect document.
The output drives syntax colouring in the editor (e.g. built-in functions rendered
differently from user variables, annotation keywords highlighted in comments).

## Key data structures

**Input:** Any VS Code `TextDocument` (or compatible plain object with `lineAt` / `lineCount`).

**Output:** An array of plain token objects, sorted by line then character position:
```js
{ line: number, char: number, length: number, tokenType: number, tokenModifiers: number }
```
`tokenType` and `tokenModifiers` are integer indices/bitmasks that **must match the legend**
declared in `vscode-extension/src/semanticTokensProvider.js`. The two constants exported
from this module (`SEMANTIC_TOKEN_TYPES`, `SEMANTIC_TOKEN_MODIFIERS`) are the source of
truth — the provider legend must be kept in sync with them.

## Algorithm

Two independent passes are merged into one sorted result:

1. **AST token walk** — iterates the flat token stream from `buildDocumentAst`.
   - `IDENTIFIER` tokens are looked up in `BuiltInGlobalVariables` → classified as
     `VARIABLE + READONLY` (if `readOnly`) or `VARIABLE`.
   - `IDENTIFIER` tokens matched in `BuiltInFunctions` are classified as
     `FUNCTION + DEFAULT_LIBRARY` **only** when the next non-whitespace token is `LPAREN`.
     This prevents false positives when a user variable shadows a built-in name.

2. **Line annotation walk** — iterates raw line text (regex-based):
   - `// @mode:strict/legacy/default` → `ANNOTATION_KEYWORD`
   - `// @rule-ignore` keyword → `ANNOTATION_KEYWORD`; each `ACU-XXX-NNN` rule ID on the
     same line → `ANNOTATION_RULE_ID`

Results are merged and sorted by `(line, char)` before returning.

## Consumers

| Consumer | Why |
|---|---|
| `vscode-extension/src/semanticTokensProvider.js` | Encodes the plain-object array into the binary `SemanticTokens` format required by the VS Code API |
