# Architecture Note: indexLoadPositionAnalysis.js

## Purpose

Tracks the *load position* state for each open index handle at a given line —
i.e. how many `INDEX_LOAD_KEY_*` calls have been made since the handle was
last opened or cleared. This tells the hover and completion providers which
index segment the *next* load call will fill.

This is a read-only analysis module; it does not emit diagnostics.
(Diagnostic enforcement is in `indexUsageValidator.js`.)

## Key data structures

**`buildLoadPositionsAtLine(document, targetLine)`**

Returns `Map<string, { tableCode, indexName, nextLoadPosition }>`:
- Key: handle variable name (lowercased)
- `tableCode`: uppercase table code string (e.g. `"MD"`)
- `indexName`: index name as written in source
- `nextLoadPosition`: count of `INDEX_LOAD_KEY_*` calls since last open/clear —
  i.e. the zero-based segment position the *next* load will target

**`resolveFieldInStructure(structure, word)`**

Returns field metadata and index appearances for a given field word (either
handle form `hXXy_Name` or raw segment form `XXy_Name`), or `null` if not found:
```js
{ canonical: string, type: string, appearances: [{ indexName, position, type, length }] }
```

## Algorithm (`buildLoadPositionsAtLine`)

Single forward scan from line 0 to `targetLine - 1`. For each function call found by regex:

| Call pattern | Action |
|---|---|
| `INDEX_OPEN_*` / `SQL_INDEX_OPEN_STANDARD` | Register handle → `{ tableCode, indexName, nextLoadPosition: 0 }` |
| `INDEX_CLEAR_KEY` / `SQL_INDEX_CLEAR_KEY` | Reset `nextLoadPosition = 0` for that handle |
| `INDEX_CLOSE` / `SQL_INDEX_CLOSE` | Remove handle from map |
| Any key in `LOAD_KEY_SUFFIX_TO_TYPES` | Increment `nextLoadPosition` for that handle |

## Supporting constants

- `LOAD_KEY_SUFFIX_TO_TYPES` — maps each `INDEX_LOAD_KEY_*` call name to the set of
  segment types it can satisfy (e.g. `INDEX_LOAD_KEY_STRING` → `{ "STRING", "ZSTRING" }`)
- `TYPE_TO_LOAD_KEY_SUFFIX` — inverse map: segment type → canonical load-key suffix
  (used by completion provider to suggest the correct call variant)

## Consumers

| Consumer | Why |
|---|---|
| `vscode-extension/src/hoverProvider.js` | Shows which index segment the cursor's field belongs to, and what load position it occupies |
| `vscode-extension/src/indexCompletionProvider.js` | Suggests the correct `INDEX_LOAD_KEY_*` variant for the next segment of the active index |
