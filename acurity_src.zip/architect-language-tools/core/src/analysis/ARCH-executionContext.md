# Architecture Note: executionContext.js

## Purpose

Classifies every line in a document as output text, executable code, or neither —
and extracts the sub-expressions within each line that need validation.

This is the document-wide state machine that all content validators depend on.
It is the only place where HASH-ON/HASH-OFF transitions, output delimiters (OICC/CICC),
line continuation (`...`), and line-type classification are computed.

## Key data structures

**`buildExecutionClassificationMap(document, ast)`** (primary entry point)

Returns one entry per line:
```js
{
  isOutput: boolean,          // true → line is output text
  outputKind: 'explicit'|'debug'|'implicit'|null,
  isExecutable: boolean,      // true → line is valid executable code
  isInvalidExecutable: boolean, // true → line looks like code but has a syntax error
  isContinuationFollower: boolean, // true → continued from previous line with ...
  hashMode: 'HASH-ON'|'HASH-OFF',
  effectiveContent: string,   // line text with hash prefix / >> / ?? stripped
  hasHashPrefix: boolean,
  rawLine: string
}
```

**`buildOutputLineMap(document)`** — simpler boolean-only predecessor, used by some
validators that only need to know if a line is output or not.

**`buildFunctionValidationTargetsByLine(document, outputDelimiters)`**

Pre-computes the code snippets on each line that need function-call validation.
Output lines yield the `@...@`-delimited segments; code lines yield the whole line.

**`buildInterpolationTargetsByLine(document, outputLineMap, outputDelimiters)`**

Pre-computes interpolation variable references (`@varName@`) on output lines.

## Algorithm — HASH mode state machine

Reports begin in `HASH-ON` (default). The classification scan processes lines in order:

```
HASH-ON:  non-# lines → output; #-prefixed lines → executable code
HASH-OFF: >> lines → explicit output; #?? / ?? lines → debug output; all others → code
```

Transitions:
- `HASH-ON` directive (or AST `HashOnDirective` node) → switch to `HASH-ON`
- `HASH-OFF` directive (or AST `HashOffDirective` node) → switch to `HASH-OFF`

Hash mode is read from AST node types where available; raw regex is the fallback for
lines the parser did not classify.

## Line classification priority (within `buildExecutionClassificationMap`)

1. Hash-mode directive nodes → `isExecutable = true`, continue
2. Empty / `//`-comment lines → not output, not executable
3. `>>` prefix → explicit output
4. `??` / `#??` prefix → debug output
5. `#NOTE` in HASH-ON → comment, not executable
6. `#//` in HASH-ON → comment, not executable
7. `OutputLine` AST node → implicit output
8. `CommentLine` AST node → not executable
9. `AssignStatement` → valid if simple (`x = y`) or compound with adjacent operator (`x+=y`)
10. `UnknownLine` → executable only if it carries a `keyword` field (misplaced structural keyword)
11. `ExpressionStatement` → executable only if it contains a function call (`IDENTIFIER LPAREN`)
12. No AST node → fall back to `hasCodePattern` text heuristic

## Line continuation

`...` at the end of a code line (before any comment) marks continuation. The following
line's `isContinuationFollower` is set to `true`, which suppresses `isInvalidExecutable`
for lines that are fragments of a multi-line expression.

## Consumers

| Consumer | Why |
|---|---|
| `core/src/analysis/documentFacts.js` | Feeds `executionClassificationMap`, `functionValidationTargets`, and `interpolationTargets` into the per-document facts object used by all validators |
| `core/src/validators/functionValidator.js` | Calls `extractOutputDelimiters` and `getFunctionValidationTargetsForLine` directly for per-line validation |
| `core/src/validators/interpolationValidator.js` | Calls `getInterpolationTargetsForLine` for interpolation variable checks |
| `vscode-extension/src/builtinCompletionProvider.js` | Reads OICC/CICC to determine interpolation delimiters for completion |
| `vscode-extension/src/udfCompletionProvider.js` | Same — needs OICC/CICC for output-line completion |
| `vscode-extension/src/variableCompletionProvider.js` | Same |
