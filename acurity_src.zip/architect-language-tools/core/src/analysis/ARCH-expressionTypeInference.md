# Architecture Note: expressionTypeInference.js

## Purpose

Given an `ExprNode` tree (produced by `parseExpression`) and a variable context,
returns the inferred `AcurityTypes` value for the expression — or `null` when the
type cannot be determined.

`null` means *unknown*, not *error*. Validators treat `null` as a pass-through so
that missing type information never produces spurious diagnostics.

## Key data structures

**Input:**
- `node` — `ExprNode` from `ast/expressionNodes.js`
- `context` (optional):
  - `context.variables` — `Map<string, string>` of uppercase variable name → `AcurityTypes`
    (built from `declaredVariables` / function-scope params before calling)
  - `context.userDefinedFunctionCatalog` — UDF catalog from `documentFacts` for return-type
    lookup

**Output:** `AcurityTypes` string (e.g. `"STRING"`, `"LONG"`, `"DATE"`) or `null`.

## Algorithm

Recursive switch on `node.type`:

| Node type | Result |
|---|---|
| `LITERAL` / `DATE` / `TIME` | `node.inferredType` (set by the parser) |
| `PAREN` | recurse into `node.expr` |
| `IDENTIFIER` | look up in `context.variables`, then `BuiltInGlobalVariables` |
| `CALL` | look up return type via `getResolvedFunctionReturnType` |
| `UNARY NOT` | always `BOOLEAN` |
| `UNARY -` | operand type if numeric, else `null` |
| `BINARY` | see widening rules below |

**Numeric widening** (`widenNumericTypes`): `SHORT < LONG < BIGINT < DOUBLE`.
`INTEGER` is a synonym for `LONG` and is normalised before comparison.

**Binary operator type rules:**
- Comparison operators (`=`, `<>`, `<`, `>`, `<=`, `>=`) → always `BOOLEAN`
- `AND` / `OR` → always `BOOLEAN`
- `**` (exponentiation) → always `DOUBLE`
- `MOD` → type of dividend (left operand), if numeric
- `+`: numeric + numeric → widened numeric; `STRING` + `STRING` → `STRING`;
  `DATE` ± numeric → `DATE`; `TIME` ± numeric → `TIME`
- `-`: numeric - numeric → widened numeric; `DATE - DATE` → `LONG` (days between)
- `*` / `/`: numeric × numeric → widened numeric

## Consumers

| Consumer | Why |
|---|---|
| `core/src/validators/typeValidator.js` | Checks that assigned/returned types are compatible |
| `core/src/validators/argumentTypeValidator.js` | Checks that function argument types match parameter expectations |
| `core/src/validators/functionReturnTypeValidator.js` | Checks that function return expressions match the declared return type |
