/**
 * Symbol table and scope hierarchy for Acurity Architect.
 *
 * Provides a formal two-phase analysis foundation:
 *   Phase 1 (this module): build a scope chain populated with all declarations.
 *   Phase 2 (future):      validators call scope.resolve(name) instead of
 *                          manually constructing flat-map lookup keys.
 *
 * Scope hierarchy per document:
 *   GlobalScope  — built-in functions and variables (singleton, shared across all docs)
 *     └── FileScope    — module-level variables, macros, and function definitions
 *           └── FunctionScope (one per FUNCTION...ENDFUNCTION)
 *
 * Usage:
 *   const table = buildSymbolTable(ast, document.lineCount);
 *   const sym = table.resolve('MY_VAR', lineIndex);
 */

import { NodeType } from '../ast/nodes.js';
import { walkStatements } from '../ast/astHelpers.js';
import { BuiltInFunctions } from '../builtins/functionsRegistry.js';
import { BuiltInGlobalVariables } from '../builtins/globalVariablesRegistry.js';

// ---------------------------------------------------------------------------
// Scope class
// ---------------------------------------------------------------------------

/**
 * A single scope in the symbol table chain.
 *
 * @property {'global'|'file'|'function'} kind
 * @property {Scope|null} parent
 * @property {Map<string, object>} symbols  — keyed by upper-case name
 */
class Scope {
    /**
     * @param {'global'|'file'|'function'} kind
     * @param {Scope|null} parent
     */
    constructor(kind, parent = null) {
        this.kind = kind;
        this.parent = parent;
        this.symbols = new Map();
    }

    /**
     * Registers a symbol in this scope and sets its back-reference.
     * The first definition wins — duplicates are silently ignored.
     * @param {object} symbol
     */
    define(symbol) {
        if (!this.symbols.has(symbol.upperName)) {
            this.symbols.set(symbol.upperName, symbol);
            symbol.scope = this;
        }
    }

    /**
     * Resolves a name by walking up the parent chain.
     * Returns null when the name is not found in any enclosing scope.
     * @param {string} name
     * @returns {object|null}
     */
    resolve(name) {
        const upper = name.toUpperCase();
        const sym = this.symbols.get(upper);
        if (sym !== undefined) return sym;
        if (this.parent !== null) return this.parent.resolve(name);
        return null;
    }
}

// ---------------------------------------------------------------------------
// GlobalScope singleton
// ---------------------------------------------------------------------------

/** @type {Scope|null} */
let _globalScope = null;

/**
 * Returns the module-level GlobalScope, creating it on first call.
 * Populated from the built-in functions and global-variables registries.
 * Immutable after first call.
 * @returns {Scope}
 */
function getGlobalScope() {
    if (_globalScope !== null) return _globalScope;

    _globalScope = new Scope('global', null);

    for (const [name, sig] of Object.entries(BuiltInFunctions)) {
        _globalScope.define({
            upperName: name,
            declaredName: name,
            kind: 'builtin',
            type: sig.returns || null,
            scope: null,
            line: null,
            params: sig.params || [],
            returnType: sig.returns || null,
            isParam: false,
        });
    }

    for (const [name, meta] of Object.entries(BuiltInGlobalVariables)) {
        _globalScope.define({
            upperName: name.toUpperCase(),
            declaredName: name,
            kind: 'builtin-var',
            type: meta.type || null,
            scope: null,
            line: null,
            params: null,
            returnType: null,
            isParam: false,
        });
    }

    return _globalScope;
}

// ---------------------------------------------------------------------------
// FileScope / FunctionScope construction
// ---------------------------------------------------------------------------

/**
 * Collects variable declarations from a statement list into a scope,
 * without crossing FunctionDeclaration boundaries.
 * @param {object[]} statements
 * @param {Scope} scope
 */
function collectVarsIntoScope(statements, scope) {
    walkStatements(statements, stmt => {
        if (stmt.type === NodeType.FunctionDeclaration) return false; // don't cross function boundaries
        if (stmt.type === NodeType.VarStatement) {
            for (const { name } of stmt.names) {
                scope.define({
                    upperName: name.toUpperCase(),
                    declaredName: name,
                    kind: 'variable',
                    type: stmt.varType || null,
                    scope: null,
                    line: stmt.line,
                    params: null,
                    returnType: null,
                    isParam: false,
                });
            }
        }
    });
}

/**
 * Populates a FileScope by walking the top-level AST statements.
 * Also builds the functionScopes array (one entry per FUNCTION declaration).
 *
 * @param {object[]} statements   — ast.statements or a nested block body
 * @param {Scope} fileScope
 * @param {Array<{scope:Scope, startLine:number, endLine:number, name:string, upperName:string}>} functionScopes
 * @param {number} lineCount      — total document lines (fallback for unclosed functions)
 */
function populateFileScope(statements, fileScope, functionScopes, lineCount) {
    for (let i = 0; i < statements.length; i++) {
        const stmt = statements[i];

        if (stmt.type === NodeType.VarStatement) {
            for (const { name } of stmt.names) {
                fileScope.define({
                    upperName: name.toUpperCase(),
                    declaredName: name,
                    kind: 'variable',
                    type: stmt.varType || null,
                    scope: null,
                    line: stmt.line,
                    params: null,
                    returnType: null,
                    isParam: false,
                });
            }

        } else if (stmt.type === NodeType.MacroDeclaration) {
            fileScope.define({
                upperName: stmt.name.toUpperCase(),
                declaredName: stmt.name,
                kind: 'macro',
                type: null,
                scope: null,
                line: stmt.line,
                params: stmt.params || [],
                returnType: null,
                isParam: false,
            });

        } else if (stmt.type === NodeType.FunctionDeclaration) {
            // Register the function itself in the file scope
            fileScope.define({
                upperName: stmt.name.toUpperCase(),
                declaredName: stmt.name,
                kind: 'function',
                type: stmt.returnType || null,
                scope: null,
                line: stmt.line,
                params: stmt.params || [],
                returnType: stmt.returnType || null,
                isParam: false,
            });

            // Determine the end line by finding the matching ENDFUNCTION
            let endLine = lineCount - 1;
            for (let j = i + 1; j < statements.length; j++) {
                if (statements[j].type === NodeType.EndFunctionStatement) {
                    endLine = statements[j].line;
                    break;
                }
            }

            // Build a FunctionScope with params + body locals
            const fnScope = new Scope('function', fileScope);

            for (const param of (stmt.params || [])) {
                fnScope.define({
                    upperName: param.name.toUpperCase(),
                    declaredName: param.name,
                    kind: 'param',
                    type: param.type || null,
                    scope: null,
                    line: stmt.line,
                    params: null,
                    returnType: null,
                    isParam: true,
                });
            }

            collectVarsIntoScope(stmt.body || [], fnScope);

            functionScopes.push({
                scope: fnScope,
                startLine: stmt.line,
                endLine,
                name: stmt.name,
                upperName: stmt.name.toUpperCase(),
            });

        } else {
            // Recurse into block bodies for module-level symbols that appear inside
            // guard patterns like IF NOT SYMBOL(...) ... ENDIF
            if (Array.isArray(stmt.body))       populateFileScope(stmt.body,       fileScope, functionScopes, lineCount);
            if (Array.isArray(stmt.consequent)) populateFileScope(stmt.consequent, fileScope, functionScopes, lineCount);
            if (Array.isArray(stmt.alternate))  populateFileScope(stmt.alternate,  fileScope, functionScopes, lineCount);
            if (stmt.branches) {
                for (const b of stmt.branches) {
                    if (Array.isArray(b.body)) populateFileScope(b.body, fileScope, functionScopes, lineCount);
                }
            }
            if (Array.isArray(stmt.otherwise)) populateFileScope(stmt.otherwise,  fileScope, functionScopes, lineCount);
        }
    }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Builds a symbol table for a parsed document AST.
 *
 * Returns an object with:
 *   globalScope     — the shared GlobalScope (read-only)
 *   fileScope       — the document's FileScope
 *   functionScopes  — array of {scope, startLine, endLine, name, upperName}
 *   resolve(name, lineIndex) — resolves a name from the scope active at lineIndex
 *
 * @param {object} ast         — document AST from buildDocumentAst()
 * @param {number} lineCount   — document.lineCount
 * @returns {{
 *   globalScope: Scope,
 *   fileScope: Scope,
 *   functionScopes: Array,
 *   resolve: (name: string, lineIndex: number) => object|null
 * }}
 */
function buildSymbolTable(ast, lineCount) {
    const globalScope = getGlobalScope();
    const fileScope = new Scope('file', globalScope);
    const functionScopes = [];

    populateFileScope(ast.statements || [], fileScope, functionScopes, lineCount);

    return {
        globalScope,
        fileScope,
        functionScopes,

        /**
         * Resolves a name from the scope active at the given line.
         * Checks the enclosing FunctionScope first, then FileScope, then GlobalScope.
         * @param {string} name
         * @param {number} lineIndex — 0-based
         * @returns {object|null}
         */
        resolve(name, lineIndex) {
            const entry = functionScopes.find(
                fs => lineIndex >= fs.startLine && lineIndex <= fs.endLine
            );
            const startScope = entry ? entry.scope : fileScope;
            return startScope.resolve(name);
        }
    };
}

export { Scope, getGlobalScope, buildSymbolTable };
