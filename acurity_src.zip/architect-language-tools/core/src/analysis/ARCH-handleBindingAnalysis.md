# Architecture Note: handleBindingAnalysis.js

## Purpose

Answers the question: *at a given line in the document, which handle variables are
open and what table is each one bound to?*

Consumed by the hover provider to show table/field metadata when the cursor is on a
handle variable, and is intended for future use in completion hints.
This module produces no diagnostics.

## Key data structures

**Input:**
- `document` — VS Code `TextDocument` (or compatible plain object)
- `targetLine` — scan lines `0..(targetLine - 1)` inclusive

**Output:** `Map<string, string>` — handle variable name (lowercased) → table code string.
```
"shandle" → "MD"
"lhandle" → "PT"
```

## Algorithm

Single forward scan from line 0 to `targetLine - 1`:

- **Open:** Any function call whose `BuiltInFunctions` entry has a `bindsHandle` metadata
  object (`{ handleParam, tableCodeParam }`) extracts the handle variable and table code
  from the call arguments and adds them to the map.
- **Close:** `INDEX_CLOSE` / `SQL_INDEX_CLOSE` calls remove the handle variable from the
  map (argument 0 is the handle).

Map keys are lowercased so all lookups are case-insensitive. Only syntactically valid
variable names (`[A-Za-z_][A-Za-z0-9_]*`) are stored — malformed arguments are ignored.

## Consumers

| Consumer | Why |
|---|---|
| `vscode-extension/src/hoverProvider.js` | Resolves handle variable to a table so it can show field-level hover info |
