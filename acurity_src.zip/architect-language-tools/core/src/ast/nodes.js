/**
 * AST node type constants for the Architect language parser.
 */

const NodeType = Object.freeze({
    // Root
    Program:                "Program",

    // Variable declarations
    VarStatement:           "VarStatement",           // VAR name : TYPE  or  TYPE name

    // Assignment
    AssignStatement:        "AssignStatement",         // name = expr (bare form)
    SetStatement:           "SetStatement",            // SET name = expr

    // Control flow — IF
    IfStatement:            "IfStatement",
    ElseStatement:          "ElseStatement",
    EndIfStatement:         "EndIfStatement",

    // Control flow — DO loops
    DoStatement:            "DoStatement",
    EndDoStatement:         "EndDoStatement",          // ENDDO or standalone UNTIL (...)

    // Control flow — CASE
    CaseStatement:          "CaseStatement",
    OtherwiseStatement:     "OtherwiseStatement",
    EndCaseStatement:       "EndCaseStatement",

    // Functions
    FunctionDeclaration:    "FunctionDeclaration",
    EndFunctionStatement:   "EndFunctionStatement",

    // Macros
    MacroDeclaration:       "MacroDeclaration",

    // Simple statements
    ReturnStatement:        "ReturnStatement",
    BreakStatement:         "BreakStatement",
    ContinueStatement:      "ContinueStatement",
    ExitStatement:          "ExitStatement",
    EndOfCodeStatement:     "EndOfCodeStatement",

    // Directives
    IncludeDirective:       "IncludeDirective",
    RequireDirective:       "RequireDirective",
    HashOnDirective:        "HashOnDirective",
    HashOffDirective:       "HashOffDirective",
    OptionDirective:        "OptionDirective",
    NewInterpreterDirective:"NewInterpreterDirective",

    // Expression / unknown
    FunctionCallStatement:  "FunctionCallStatement",  // standalone function call: IDENTIFIER ( ... )
    ExpressionStatement:    "ExpressionStatement",    // bare expression or keyword-led non-assignment line

    // Line types
    OutputLine:             "OutputLine",             // output text line
    CommentLine:            "CommentLine",            // // comment line
    UnknownLine:            "UnknownLine",            // unrecognised syntax
});

export { NodeType };
