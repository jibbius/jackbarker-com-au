/**
 * Include resolver facade for Acurity Architect.
 * Public API is preserved while internals are split into focused modules.
 */

import {
    Include,
    parseIncludes,
    getIncludesInScopeAtLine,
    findIncludeFilenameCaseMismatches,
    findMissingIncludeDirectives,
    findCircularIncludeDirectives,
    isFunctionInScope
} from "./includeResolver/graph.js";

import {
    buildIncludedSymbolsInScope,
    buildIncludedFunctionsInScope,
    buildIncludedFunctionCasesInScope,
    collectIncludeDependenciesForDocument,
    invalidateIncludeCacheForPath,
    warmIncludeCacheForDocument
} from "./includeResolver/traversal.js";

export {
    parseIncludes,
    getIncludesInScopeAtLine,
    buildIncludedSymbolsInScope,
    buildIncludedFunctionsInScope,
    buildIncludedFunctionCasesInScope,
    findIncludeFilenameCaseMismatches,
    findMissingIncludeDirectives,
    findCircularIncludeDirectives,
    collectIncludeDependenciesForDocument,
    invalidateIncludeCacheForPath,
    warmIncludeCacheForDocument,
    isFunctionInScope,
    Include
};
