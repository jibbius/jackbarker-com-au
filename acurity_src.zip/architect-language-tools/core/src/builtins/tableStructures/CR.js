/**
 * CR.js — table structure for the CR (Commission Rates) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CR").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CR
 */

/** @type {Object} */
const CR = {
    code: "CR",
    name: "Commission_Rates",
    recordLength: null,
    helpRegistry: "hCR.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CRi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hcrd_effective"       : { canonical: "hCRd_Effective"       , type: "DATE", tableCode: "CR" },
        "hcrd_mod_date"        : { canonical: "hCRd_Mod_Date"        , type: "DATE", tableCode: "CR" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hcrf__single_fee_rate": { canonical: "hCRf__Single_Fee_Rate", type: "DOUBLE", tableCode: "CR" },
        "hcrf_gl_comm_rate01"  : { canonical: "hCRf_GL_Comm_Rate01"  , type: "DOUBLE", tableCode: "CR" },
        "hcrf_gl_comm_rate02"  : { canonical: "hCRf_GL_Comm_Rate02"  , type: "DOUBLE", tableCode: "CR" },
        "hcrf_gl_comm_rate03"  : { canonical: "hCRf_GL_Comm_Rate03"  , type: "DOUBLE", tableCode: "CR" },
        "hcrf_gl_comm_rate04"  : { canonical: "hCRf_GL_Comm_Rate04"  , type: "DOUBLE", tableCode: "CR" },
        "hcrf_gl_comm_rate05"  : { canonical: "hCRf_GL_Comm_Rate05"  , type: "DOUBLE", tableCode: "CR" },
        "hcrf_gl_comm_rate06"  : { canonical: "hCRf_GL_Comm_Rate06"  , type: "DOUBLE", tableCode: "CR" },
        "hcrf_renewal_fee_rate": { canonical: "hCRf_Renewal_Fee_Rate", type: "DOUBLE", tableCode: "CR" },
        "hcrf_renewl_comm_rate": { canonical: "hCRf_Renewl_Comm_Rate", type: "DOUBLE", tableCode: "CR" },
        "hcrf_rnwl_gl_comm_rte": { canonical: "hCRf_Rnwl_GL_Comm_Rte", type: "DOUBLE", tableCode: "CR" },
        "hcrf_single_comm_rate": { canonical: "hCRf_Single_Comm_Rate", type: "DOUBLE", tableCode: "CR" },
        "hcrf_transfr_fee_rate": { canonical: "hCRf_Transfr_Fee_Rate", type: "DOUBLE", tableCode: "CR" },
        "hcrf_trnsfr_comm_rate": { canonical: "hCRf_Trnsfr_Comm_Rate", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorinccmmrte01": { canonical: "hCRfInitOrIncCmmRte01", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorinccmmrte02": { canonical: "hCRfInitOrIncCmmRte02", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorinccmmrte03": { canonical: "hCRfInitOrIncCmmRte03", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorinccmmrte04": { canonical: "hCRfInitOrIncCmmRte04", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorinccmmrte05": { canonical: "hCRfInitOrIncCmmRte05", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorinccmmrte06": { canonical: "hCRfInitOrIncCmmRte06", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorincfeerte01": { canonical: "hCRfInitOrIncFeeRte01", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorincfeerte02": { canonical: "hCRfInitOrIncFeeRte02", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorincfeerte03": { canonical: "hCRfInitOrIncFeeRte03", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorincfeerte04": { canonical: "hCRfInitOrIncFeeRte04", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorincfeerte05": { canonical: "hCRfInitOrIncFeeRte05", type: "DOUBLE", tableCode: "CR" },
        "hcrfinitorincfeerte06": { canonical: "hCRfInitOrIncFeeRte06", type: "DOUBLE", tableCode: "CR" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hcrs_mths_gl_rate01"  : { canonical: "hCRs_Mths_GL_Rate01"  , type: "INTEGER", tableCode: "CR" },
        "hcrs_mths_gl_rate02"  : { canonical: "hCRs_Mths_GL_Rate02"  , type: "INTEGER", tableCode: "CR" },
        "hcrs_mths_gl_rate03"  : { canonical: "hCRs_Mths_GL_Rate03"  , type: "INTEGER", tableCode: "CR" },
        "hcrs_mths_gl_rate04"  : { canonical: "hCRs_Mths_GL_Rate04"  , type: "INTEGER", tableCode: "CR" },
        "hcrs_mths_gl_rate05"  : { canonical: "hCRs_Mths_GL_Rate05"  , type: "INTEGER", tableCode: "CR" },
        "hcrs_mths_gl_rate06"  : { canonical: "hCRs_Mths_GL_Rate06"  , type: "INTEGER", tableCode: "CR" },
        "hcrs_spare01"         : { canonical: "hCRs_Spare01"         , type: "INTEGER", tableCode: "CR" },
        "hcrs_spare02"         : { canonical: "hCRs_Spare02"         , type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincfee01": { canonical: "hCRsMthInitOrIncFee01", type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincfee02": { canonical: "hCRsMthInitOrIncFee02", type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincfee03": { canonical: "hCRsMthInitOrIncFee03", type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincfee04": { canonical: "hCRsMthInitOrIncFee04", type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincfee05": { canonical: "hCRsMthInitOrIncFee05", type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincfee06": { canonical: "hCRsMthInitOrIncFee06", type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincrte01": { canonical: "hCRsMthInitOrIncRte01", type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincrte02": { canonical: "hCRsMthInitOrIncRte02", type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincrte03": { canonical: "hCRsMthInitOrIncRte03", type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincrte04": { canonical: "hCRsMthInitOrIncRte04", type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincrte05": { canonical: "hCRsMthInitOrIncRte05", type: "INTEGER", tableCode: "CR" },
        "hcrsmthinitorincrte06": { canonical: "hCRsMthInitOrIncRte06", type: "INTEGER", tableCode: "CR" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hcrt_mod_time"        : { canonical: "hCRt_Mod_Time"        , type: "TIME", tableCode: "CR" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcrz_addtnl_fee_rate" : { canonical: "hCRz_Addtnl_Fee_Rate" , type: "STRING", tableCode: "CR" },
        "hcrz_commission_basis": { canonical: "hCRz_Commission_Basis", type: "STRING", tableCode: "CR" },
        "hcrz_mod_user"        : { canonical: "hCRz_Mod_User"        , type: "STRING", tableCode: "CR" },
        "hcrz_spare"           : { canonical: "hCRz_Spare"           , type: "STRING", tableCode: "CR" },
    }
};

export default CR;
