/**
 * RV.js — table structure for the RV (Report Variables) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "RV").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force RV
 */

/** @type {Object} */
const RV = {
    code: "RV",
    name: "Report_Variables",
    recordLength: null,
    helpRegistry: "hRV.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "RVi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hrvc_flags_ext01"     : { canonical: "hRVc_Flags_Ext01"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext02"     : { canonical: "hRVc_Flags_Ext02"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext03"     : { canonical: "hRVc_Flags_Ext03"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext04"     : { canonical: "hRVc_Flags_Ext04"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext05"     : { canonical: "hRVc_Flags_Ext05"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext06"     : { canonical: "hRVc_Flags_Ext06"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext07"     : { canonical: "hRVc_Flags_Ext07"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext08"     : { canonical: "hRVc_Flags_Ext08"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext09"     : { canonical: "hRVc_Flags_Ext09"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext10"     : { canonical: "hRVc_Flags_Ext10"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext11"     : { canonical: "hRVc_Flags_Ext11"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext12"     : { canonical: "hRVc_Flags_Ext12"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext13"     : { canonical: "hRVc_Flags_Ext13"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags_ext14"     : { canonical: "hRVc_Flags_Ext14"     , type: "STRING", tableCode: "RV" },
        "hrvc_flags01"         : { canonical: "hRVc_Flags01"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags02"         : { canonical: "hRVc_Flags02"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags03"         : { canonical: "hRVc_Flags03"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags04"         : { canonical: "hRVc_Flags04"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags05"         : { canonical: "hRVc_Flags05"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags06"         : { canonical: "hRVc_Flags06"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags07"         : { canonical: "hRVc_Flags07"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags08"         : { canonical: "hRVc_Flags08"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags09"         : { canonical: "hRVc_Flags09"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags10"         : { canonical: "hRVc_Flags10"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags11"         : { canonical: "hRVc_Flags11"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags12"         : { canonical: "hRVc_Flags12"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags13"         : { canonical: "hRVc_Flags13"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags14"         : { canonical: "hRVc_Flags14"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags15"         : { canonical: "hRVc_Flags15"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags16"         : { canonical: "hRVc_Flags16"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags17"         : { canonical: "hRVc_Flags17"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags18"         : { canonical: "hRVc_Flags18"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags19"         : { canonical: "hRVc_Flags19"         , type: "STRING", tableCode: "RV" },
        "hrvc_flags20"         : { canonical: "hRVc_Flags20"         , type: "STRING", tableCode: "RV" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hrvd_effective"       : { canonical: "hRVd_Effective"       , type: "DATE", tableCode: "RV" },
        "hrvd_mod_date"        : { canonical: "hRVd_Mod_Date"        , type: "DATE", tableCode: "RV" },
        "hrvd_reckoning"       : { canonical: "hRVd_Reckoning"       , type: "DATE", tableCode: "RV" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hrvf_addtnl_amts01"   : { canonical: "hRVf_Addtnl_Amts01"   , type: "DOUBLE", tableCode: "RV" },
        "hrvf_addtnl_amts02"   : { canonical: "hRVf_Addtnl_Amts02"   , type: "DOUBLE", tableCode: "RV" },
        "hrvf_curr_amts_ext01" : { canonical: "hRVf_Curr_Amts_Ext01" , type: "DOUBLE", tableCode: "RV" },
        "hrvf_curr_amts_ext02" : { canonical: "hRVf_Curr_Amts_Ext02" , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts01"  : { canonical: "hRVf_Current_Amts01"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts02"  : { canonical: "hRVf_Current_Amts02"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts03"  : { canonical: "hRVf_Current_Amts03"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts04"  : { canonical: "hRVf_Current_Amts04"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts05"  : { canonical: "hRVf_Current_Amts05"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts06"  : { canonical: "hRVf_Current_Amts06"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts07"  : { canonical: "hRVf_Current_Amts07"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts08"  : { canonical: "hRVf_Current_Amts08"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts09"  : { canonical: "hRVf_Current_Amts09"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts10"  : { canonical: "hRVf_Current_Amts10"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts11"  : { canonical: "hRVf_Current_Amts11"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts12"  : { canonical: "hRVf_Current_Amts12"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts13"  : { canonical: "hRVf_Current_Amts13"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts14"  : { canonical: "hRVf_Current_Amts14"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts15"  : { canonical: "hRVf_Current_Amts15"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts16"  : { canonical: "hRVf_Current_Amts16"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts17"  : { canonical: "hRVf_Current_Amts17"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts18"  : { canonical: "hRVf_Current_Amts18"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts19"  : { canonical: "hRVf_Current_Amts19"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts20"  : { canonical: "hRVf_Current_Amts20"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts21"  : { canonical: "hRVf_Current_Amts21"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts22"  : { canonical: "hRVf_Current_Amts22"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts23"  : { canonical: "hRVf_Current_Amts23"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts24"  : { canonical: "hRVf_Current_Amts24"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts25"  : { canonical: "hRVf_Current_Amts25"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts26"  : { canonical: "hRVf_Current_Amts26"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts27"  : { canonical: "hRVf_Current_Amts27"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts28"  : { canonical: "hRVf_Current_Amts28"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_current_amts29"  : { canonical: "hRVf_Current_Amts29"  , type: "DOUBLE", tableCode: "RV" },
        "hrvf_previous_amts01" : { canonical: "hRVf_Previous_Amts01" , type: "DOUBLE", tableCode: "RV" },
        "hrvf_previous_amts02" : { canonical: "hRVf_Previous_Amts02" , type: "DOUBLE", tableCode: "RV" },
        "hrvf_previous_amts03" : { canonical: "hRVf_Previous_Amts03" , type: "DOUBLE", tableCode: "RV" },
        "hrvf_previous_amts04" : { canonical: "hRVf_Previous_Amts04" , type: "DOUBLE", tableCode: "RV" },
        "hrvf_previous_amts05" : { canonical: "hRVf_Previous_Amts05" , type: "DOUBLE", tableCode: "RV" },
        "hrvf_previous_amts06" : { canonical: "hRVf_Previous_Amts06" , type: "DOUBLE", tableCode: "RV" },
        "hrvf_previous_amts07" : { canonical: "hRVf_Previous_Amts07" , type: "DOUBLE", tableCode: "RV" },
        "hrvf_previous_amts08" : { canonical: "hRVf_Previous_Amts08" , type: "DOUBLE", tableCode: "RV" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hrvt_mod_time"        : { canonical: "hRVt_Mod_Time"        , type: "TIME", tableCode: "RV" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hrvz_addtnl_names01"  : { canonical: "hRVz_Addtnl_Names01"  , type: "STRING", tableCode: "RV" },
        "hrvz_addtnl_names02"  : { canonical: "hRVz_Addtnl_Names02"  , type: "STRING", tableCode: "RV" },
        "hrvz_agents_ref_no"   : { canonical: "hRVz_Agents_Ref_No"   , type: "STRING", tableCode: "RV" },
        "hrvz_client_ref_no"   : { canonical: "hRVz_Client_Ref_No"   , type: "STRING", tableCode: "RV" },
        "hrvz_curr_address01"  : { canonical: "hRVz_Curr_Address01"  , type: "STRING", tableCode: "RV" },
        "hrvz_curr_address02"  : { canonical: "hRVz_Curr_Address02"  , type: "STRING", tableCode: "RV" },
        "hrvz_curr_address03"  : { canonical: "hRVz_Curr_Address03"  , type: "STRING", tableCode: "RV" },
        "hrvz_curr_address04"  : { canonical: "hRVz_Curr_Address04"  , type: "STRING", tableCode: "RV" },
        "hrvz_curr_post_code"  : { canonical: "hRVz_Curr_Post_Code"  , type: "STRING", tableCode: "RV" },
        "hrvz_fund"            : { canonical: "hRVz_Fund"            , type: "STRING", tableCode: "RV" },
        "hrvz_mod_user"        : { canonical: "hRVz_Mod_User"        , type: "STRING", tableCode: "RV" },
        "hrvz_prev_address01"  : { canonical: "hRVz_Prev_Address01"  , type: "STRING", tableCode: "RV" },
        "hrvz_prev_address02"  : { canonical: "hRVz_Prev_Address02"  , type: "STRING", tableCode: "RV" },
        "hrvz_prev_address03"  : { canonical: "hRVz_Prev_Address03"  , type: "STRING", tableCode: "RV" },
        "hrvz_prev_address04"  : { canonical: "hRVz_Prev_Address04"  , type: "STRING", tableCode: "RV" },
        "hrvz_prev_name01"     : { canonical: "hRVz_Prev_Name01"     , type: "STRING", tableCode: "RV" },
        "hrvz_prev_name02"     : { canonical: "hRVz_Prev_Name02"     , type: "STRING", tableCode: "RV" },
        "hrvz_prev_post_code"  : { canonical: "hRVz_Prev_Post_Code"  , type: "STRING", tableCode: "RV" },
        "hrvz_spare"           : { canonical: "hRVz_Spare"           , type: "STRING", tableCode: "RV" },
        "hrvz_tax_agents_c_nme": { canonical: "hRVz_Tax_Agents_C_Nme", type: "STRING", tableCode: "RV" },
        "hrvz_tax_agents_name" : { canonical: "hRVz_Tax_Agents_Name" , type: "STRING", tableCode: "RV" },
        "hrvz_tax_agents_phone": { canonical: "hRVz_Tax_Agents_Phone", type: "STRING", tableCode: "RV" },
        "hrvz_trustees_c_name" : { canonical: "hRVz_Trustees_C_Name" , type: "STRING", tableCode: "RV" },
        "hrvz_trustees_phone"  : { canonical: "hRVz_Trustees_Phone"  , type: "STRING", tableCode: "RV" },
    }
};

export default RV;
