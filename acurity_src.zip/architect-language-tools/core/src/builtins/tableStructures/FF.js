/**
 * FF.js — table structure for the FF (Fund Supplementary Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FF").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FF
 */

/** @type {Object} */
const FF = {
    code: "FF",
    name: "Fund_Supplementary_Details",
    recordLength: null,
    helpRegistry: "hFF.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FFi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hffc_flags01"    : { canonical: "hFFc_Flags01"    , type: "STRING", tableCode: "FF" },
        "hffc_flags02"    : { canonical: "hFFc_Flags02"    , type: "STRING", tableCode: "FF" },
        "hffc_flags03"    : { canonical: "hFFc_Flags03"    , type: "STRING", tableCode: "FF" },
        "hffc_flags04"    : { canonical: "hFFc_Flags04"    , type: "STRING", tableCode: "FF" },
        "hffc_flags05"    : { canonical: "hFFc_Flags05"    , type: "STRING", tableCode: "FF" },
        "hffc_flags06"    : { canonical: "hFFc_Flags06"    , type: "STRING", tableCode: "FF" },
        "hffc_flags07"    : { canonical: "hFFc_Flags07"    , type: "STRING", tableCode: "FF" },
        "hffc_flags08"    : { canonical: "hFFc_Flags08"    , type: "STRING", tableCode: "FF" },
        "hffc_flags09"    : { canonical: "hFFc_Flags09"    , type: "STRING", tableCode: "FF" },
        "hffc_flags10"    : { canonical: "hFFc_Flags10"    , type: "STRING", tableCode: "FF" },
        "hffc_flags11"    : { canonical: "hFFc_Flags11"    , type: "STRING", tableCode: "FF" },
        "hffc_flags12"    : { canonical: "hFFc_Flags12"    , type: "STRING", tableCode: "FF" },
        "hffc_flags13"    : { canonical: "hFFc_Flags13"    , type: "STRING", tableCode: "FF" },
        "hffc_flags14"    : { canonical: "hFFc_Flags14"    , type: "STRING", tableCode: "FF" },
        "hffc_flags15"    : { canonical: "hFFc_Flags15"    , type: "STRING", tableCode: "FF" },
        "hffc_flags16"    : { canonical: "hFFc_Flags16"    , type: "STRING", tableCode: "FF" },
        "hffc_flags17"    : { canonical: "hFFc_Flags17"    , type: "STRING", tableCode: "FF" },
        "hffc_flags18"    : { canonical: "hFFc_Flags18"    , type: "STRING", tableCode: "FF" },
        "hffc_flags19"    : { canonical: "hFFc_Flags19"    , type: "STRING", tableCode: "FF" },
        "hffc_flags20"    : { canonical: "hFFc_Flags20"    , type: "STRING", tableCode: "FF" },
        "hffc_flags21"    : { canonical: "hFFc_Flags21"    , type: "STRING", tableCode: "FF" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hffd_dates01"    : { canonical: "hFFd_Dates01"    , type: "DATE", tableCode: "FF" },
        "hffd_dates02"    : { canonical: "hFFd_Dates02"    , type: "DATE", tableCode: "FF" },
        "hffd_dates03"    : { canonical: "hFFd_Dates03"    , type: "DATE", tableCode: "FF" },
        "hffd_dates04"    : { canonical: "hFFd_Dates04"    , type: "DATE", tableCode: "FF" },
        "hffd_dates05"    : { canonical: "hFFd_Dates05"    , type: "DATE", tableCode: "FF" },
        "hffd_dates06"    : { canonical: "hFFd_Dates06"    , type: "DATE", tableCode: "FF" },
        "hffd_dates07"    : { canonical: "hFFd_Dates07"    , type: "DATE", tableCode: "FF" },
        "hffd_dates08"    : { canonical: "hFFd_Dates08"    , type: "DATE", tableCode: "FF" },
        "hffd_dates09"    : { canonical: "hFFd_Dates09"    , type: "DATE", tableCode: "FF" },
        "hffd_dates10"    : { canonical: "hFFd_Dates10"    , type: "DATE", tableCode: "FF" },
        "hffd_dates11"    : { canonical: "hFFd_Dates11"    , type: "DATE", tableCode: "FF" },
        "hffd_dates12"    : { canonical: "hFFd_Dates12"    , type: "DATE", tableCode: "FF" },
        "hffd_dates13"    : { canonical: "hFFd_Dates13"    , type: "DATE", tableCode: "FF" },
        "hffd_dates14"    : { canonical: "hFFd_Dates14"    , type: "DATE", tableCode: "FF" },
        "hffd_dates15"    : { canonical: "hFFd_Dates15"    , type: "DATE", tableCode: "FF" },
        "hffd_dates16"    : { canonical: "hFFd_Dates16"    , type: "DATE", tableCode: "FF" },
        "hffd_dates17"    : { canonical: "hFFd_Dates17"    , type: "DATE", tableCode: "FF" },
        "hffd_dates18"    : { canonical: "hFFd_Dates18"    , type: "DATE", tableCode: "FF" },
        "hffd_dates19"    : { canonical: "hFFd_Dates19"    , type: "DATE", tableCode: "FF" },
        "hffd_dates20"    : { canonical: "hFFd_Dates20"    , type: "DATE", tableCode: "FF" },
        "hffd_mod_date"   : { canonical: "hFFd_Mod_Date"   , type: "DATE", tableCode: "FF" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hfff_amounts01"  : { canonical: "hFFf_Amounts01"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts02"  : { canonical: "hFFf_Amounts02"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts03"  : { canonical: "hFFf_Amounts03"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts04"  : { canonical: "hFFf_Amounts04"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts05"  : { canonical: "hFFf_Amounts05"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts06"  : { canonical: "hFFf_Amounts06"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts07"  : { canonical: "hFFf_Amounts07"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts08"  : { canonical: "hFFf_Amounts08"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts09"  : { canonical: "hFFf_Amounts09"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts10"  : { canonical: "hFFf_Amounts10"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts11"  : { canonical: "hFFf_Amounts11"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts12"  : { canonical: "hFFf_Amounts12"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts13"  : { canonical: "hFFf_Amounts13"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts14"  : { canonical: "hFFf_Amounts14"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts15"  : { canonical: "hFFf_Amounts15"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts16"  : { canonical: "hFFf_Amounts16"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts17"  : { canonical: "hFFf_Amounts17"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts18"  : { canonical: "hFFf_Amounts18"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts19"  : { canonical: "hFFf_Amounts19"  , type: "DOUBLE", tableCode: "FF" },
        "hfff_amounts20"  : { canonical: "hFFf_Amounts20"  , type: "DOUBLE", tableCode: "FF" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hffs_record_no"  : { canonical: "hFFs_Record_No"  , type: "INTEGER", tableCode: "FF" },
        "hffs_spare01"    : { canonical: "hFFs_Spare01"    , type: "INTEGER", tableCode: "FF" },
        "hffs_spare02"    : { canonical: "hFFs_Spare02"    , type: "INTEGER", tableCode: "FF" },
        "hffs_spare03"    : { canonical: "hFFs_Spare03"    , type: "INTEGER", tableCode: "FF" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfft_mod_time"   : { canonical: "hFFt_Mod_Time"   , type: "TIME", tableCode: "FF" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hffz_deleted"    : { canonical: "hFFz_Deleted"    , type: "STRING", tableCode: "FF" },
        "hffz_division"   : { canonical: "hFFz_Division"   , type: "STRING", tableCode: "FF" },
        "hffz_fund"       : { canonical: "hFFz_Fund"       , type: "STRING", tableCode: "FF" },
        "hffz_mod_user"   : { canonical: "hFFz_Mod_User"   , type: "STRING", tableCode: "FF" },
        "hffz_spare"      : { canonical: "hFFz_Spare"      , type: "STRING", tableCode: "FF" },
        "hffz_variables01": { canonical: "hFFz_Variables01", type: "STRING", tableCode: "FF" },
        "hffz_variables02": { canonical: "hFFz_Variables02", type: "STRING", tableCode: "FF" },
        "hffz_variables03": { canonical: "hFFz_Variables03", type: "STRING", tableCode: "FF" },
        "hffz_variables04": { canonical: "hFFz_Variables04", type: "STRING", tableCode: "FF" },
        "hffz_variables05": { canonical: "hFFz_Variables05", type: "STRING", tableCode: "FF" },
        "hffz_variables06": { canonical: "hFFz_Variables06", type: "STRING", tableCode: "FF" },
        "hffz_variables07": { canonical: "hFFz_Variables07", type: "STRING", tableCode: "FF" },
        "hffz_variables08": { canonical: "hFFz_Variables08", type: "STRING", tableCode: "FF" },
        "hffz_variables09": { canonical: "hFFz_Variables09", type: "STRING", tableCode: "FF" },
        "hffz_variables10": { canonical: "hFFz_Variables10", type: "STRING", tableCode: "FF" },
        "hffz_variables11": { canonical: "hFFz_Variables11", type: "STRING", tableCode: "FF" },
        "hffz_variables12": { canonical: "hFFz_Variables12", type: "STRING", tableCode: "FF" },
        "hffz_variables13": { canonical: "hFFz_Variables13", type: "STRING", tableCode: "FF" },
        "hffz_variables14": { canonical: "hFFz_Variables14", type: "STRING", tableCode: "FF" },
        "hffz_variables15": { canonical: "hFFz_Variables15", type: "STRING", tableCode: "FF" },
        "hffz_variables16": { canonical: "hFFz_Variables16", type: "STRING", tableCode: "FF" },
        "hffz_variables17": { canonical: "hFFz_Variables17", type: "STRING", tableCode: "FF" },
        "hffz_variables18": { canonical: "hFFz_Variables18", type: "STRING", tableCode: "FF" },
        "hffz_variables19": { canonical: "hFFz_Variables19", type: "STRING", tableCode: "FF" },
        "hffz_variables20": { canonical: "hFFz_Variables20", type: "STRING", tableCode: "FF" },
    }
};

export default FF;
