/**
 * EM.js — table structure for the EM (Member Enquiry) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "EM").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force EM
 */

/** @type {Object} */
const EM = {
    code: "EM",
    name: "Member_Enquiry",
    recordLength: null,
    helpRegistry: "hEM.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "EMi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hemc_tran_type"       : { canonical: "hEMc_Tran_Type"       , type: "STRING", tableCode: "EM" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hemd_effective"       : { canonical: "hEMd_Effective"       , type: "DATE", tableCode: "EM" },
        "hemd_fees_paid_from01": { canonical: "hEMd_Fees_Paid_From01", type: "DATE", tableCode: "EM" },
        "hemd_fees_paid_from02": { canonical: "hEMd_Fees_Paid_From02", type: "DATE", tableCode: "EM" },
        "hemd_fees_paid_from03": { canonical: "hEMd_Fees_Paid_From03", type: "DATE", tableCode: "EM" },
        "hemd_fees_paid_from04": { canonical: "hEMd_Fees_Paid_From04", type: "DATE", tableCode: "EM" },
        "hemd_fees_paid_to01"  : { canonical: "hEMd_Fees_Paid_To01"  , type: "DATE", tableCode: "EM" },
        "hemd_fees_paid_to02"  : { canonical: "hEMd_Fees_Paid_To02"  , type: "DATE", tableCode: "EM" },
        "hemd_fees_paid_to03"  : { canonical: "hEMd_Fees_Paid_To03"  , type: "DATE", tableCode: "EM" },
        "hemd_fees_paid_to04"  : { canonical: "hEMd_Fees_Paid_To04"  , type: "DATE", tableCode: "EM" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hemf_acct_bal_for_fee": { canonical: "hEMf_Acct_Bal_For_Fee", type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions01" : { canonical: "hEMf_Contributions01" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions02" : { canonical: "hEMf_Contributions02" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions03" : { canonical: "hEMf_Contributions03" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions04" : { canonical: "hEMf_Contributions04" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions05" : { canonical: "hEMf_Contributions05" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions06" : { canonical: "hEMf_Contributions06" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions07" : { canonical: "hEMf_Contributions07" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions08" : { canonical: "hEMf_Contributions08" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions09" : { canonical: "hEMf_Contributions09" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions10" : { canonical: "hEMf_Contributions10" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions11" : { canonical: "hEMf_Contributions11" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions12" : { canonical: "hEMf_Contributions12" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions13" : { canonical: "hEMf_Contributions13" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions14" : { canonical: "hEMf_Contributions14" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions15" : { canonical: "hEMf_Contributions15" , type: "DOUBLE", tableCode: "EM" },
        "hemf_contributions16" : { canonical: "hEMf_Contributions16" , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee01"           : { canonical: "hEMf_Fee01"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee02"           : { canonical: "hEMf_Fee02"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee03"           : { canonical: "hEMf_Fee03"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee04"           : { canonical: "hEMf_Fee04"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee05"           : { canonical: "hEMf_Fee05"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee06"           : { canonical: "hEMf_Fee06"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee07"           : { canonical: "hEMf_Fee07"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee08"           : { canonical: "hEMf_Fee08"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee09"           : { canonical: "hEMf_Fee09"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee10"           : { canonical: "hEMf_Fee10"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee11"           : { canonical: "hEMf_Fee11"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee12"           : { canonical: "hEMf_Fee12"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee13"           : { canonical: "hEMf_Fee13"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee14"           : { canonical: "hEMf_Fee14"           , type: "DOUBLE", tableCode: "EM" },
        "hemf_fee15"           : { canonical: "hEMf_Fee15"           , type: "DOUBLE", tableCode: "EM" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "heml_fees_paid_by01"  : { canonical: "hEMl_Fees_Paid_By01"  , type: "INTEGER", tableCode: "EM" },
        "heml_fees_paid_by02"  : { canonical: "hEMl_Fees_Paid_By02"  , type: "INTEGER", tableCode: "EM" },
        "heml_fees_paid_by03"  : { canonical: "hEMl_Fees_Paid_By03"  , type: "INTEGER", tableCode: "EM" },
        "heml_fees_paid_by04"  : { canonical: "hEMl_Fees_Paid_By04"  , type: "INTEGER", tableCode: "EM" },
        "heml_orig_trans_ref"  : { canonical: "hEMl_Orig_Trans_Ref"  , type: "INTEGER", tableCode: "EM" },
        "heml_trans_ref"       : { canonical: "hEMl_Trans_Ref"       , type: "INTEGER", tableCode: "EM" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hems_spare"           : { canonical: "hEMs_Spare"           , type: "INTEGER", tableCode: "EM" },
        "hems_spare_101"       : { canonical: "hEMs_Spare_101"       , type: "INTEGER", tableCode: "EM" },
        "hems_spare_102"       : { canonical: "hEMs_Spare_102"       , type: "INTEGER", tableCode: "EM" },
        "hems_spare_103"       : { canonical: "hEMs_Spare_103"       , type: "INTEGER", tableCode: "EM" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hemz_client"          : { canonical: "hEMz_Client"          , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts01"    : { canonical: "hEMz_Cont_Accts01"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts02"    : { canonical: "hEMz_Cont_Accts02"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts03"    : { canonical: "hEMz_Cont_Accts03"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts04"    : { canonical: "hEMz_Cont_Accts04"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts05"    : { canonical: "hEMz_Cont_Accts05"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts06"    : { canonical: "hEMz_Cont_Accts06"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts07"    : { canonical: "hEMz_Cont_Accts07"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts08"    : { canonical: "hEMz_Cont_Accts08"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts09"    : { canonical: "hEMz_Cont_Accts09"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts10"    : { canonical: "hEMz_Cont_Accts10"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts11"    : { canonical: "hEMz_Cont_Accts11"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts12"    : { canonical: "hEMz_Cont_Accts12"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts13"    : { canonical: "hEMz_Cont_Accts13"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts14"    : { canonical: "hEMz_Cont_Accts14"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts15"    : { canonical: "hEMz_Cont_Accts15"    , type: "STRING", tableCode: "EM" },
        "hemz_cont_accts16"    : { canonical: "hEMz_Cont_Accts16"    , type: "STRING", tableCode: "EM" },
        "hemz_fee_code01"      : { canonical: "hEMz_Fee_Code01"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code02"      : { canonical: "hEMz_Fee_Code02"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code03"      : { canonical: "hEMz_Fee_Code03"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code04"      : { canonical: "hEMz_Fee_Code04"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code05"      : { canonical: "hEMz_Fee_Code05"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code06"      : { canonical: "hEMz_Fee_Code06"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code07"      : { canonical: "hEMz_Fee_Code07"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code08"      : { canonical: "hEMz_Fee_Code08"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code09"      : { canonical: "hEMz_Fee_Code09"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code10"      : { canonical: "hEMz_Fee_Code10"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code11"      : { canonical: "hEMz_Fee_Code11"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code12"      : { canonical: "hEMz_Fee_Code12"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code13"      : { canonical: "hEMz_Fee_Code13"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code14"      : { canonical: "hEMz_Fee_Code14"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_code15"      : { canonical: "hEMz_Fee_Code15"      , type: "STRING", tableCode: "EM" },
        "hemz_fee_paid"        : { canonical: "hEMz_Fee_Paid"        , type: "STRING", tableCode: "EM" },
        "hemz_fund"            : { canonical: "hEMz_Fund"            , type: "STRING", tableCode: "EM" },
        "hemz_long_payroll"    : { canonical: "hEMz_Long_Payroll"    , type: "STRING", tableCode: "EM" },
        "hemz_member"          : { canonical: "hEMz_Member"          , type: "STRING", tableCode: "EM" },
        "hemz_orig_fee_paid"   : { canonical: "hEMz_Orig_Fee_Paid"   , type: "STRING", tableCode: "EM" },
        "hemz_original_fund"   : { canonical: "hEMz_Original_Fund"   , type: "STRING", tableCode: "EM" },
        "hemz_original_mbr"    : { canonical: "hEMz_Original_Mbr"    , type: "STRING", tableCode: "EM" },
        "hemz_payroll"         : { canonical: "hEMz_Payroll"         , type: "STRING", tableCode: "EM" },
        "hemz_preserved"       : { canonical: "hEMz_Preserved"       , type: "STRING", tableCode: "EM" },
        "hemz_spare"           : { canonical: "hEMz_Spare"           , type: "STRING", tableCode: "EM" },
        "hemz_transaction"     : { canonical: "hEMz_Transaction"     , type: "STRING", tableCode: "EM" },
    }
};

export default EM;
