/**
 * BT.js — table structure for the BT (Batch Codes) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BT").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BT
 */

/** @type {Object} */
const BT = {
    code: "BT",
    name: "Batch_Codes",
    recordLength: null,
    helpRegistry: "hBT.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BTi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hbtc_auto_report"  : { canonical: "hBTc_Auto_Report"  , type: "STRING", tableCode: "BT" },
        "hbtc_deleted"      : { canonical: "hBTc_Deleted"      , type: "STRING", tableCode: "BT" },
        "hbtc_processed"    : { canonical: "hBTc_Processed"    , type: "STRING", tableCode: "BT" },
        "hbtc_quote_batch"  : { canonical: "hBTc_Quote_Batch"  , type: "STRING", tableCode: "BT" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hbtz_batch_group"  : { canonical: "hBTz_Batch_Group"  , type: "STRING", tableCode: "BT" },
        "hbtz_code"         : { canonical: "hBTz_Code"         , type: "STRING", tableCode: "BT" },
        "hbtz_description"  : { canonical: "hBTz_Description"  , type: "STRING", tableCode: "BT" },
        "hbtz_exit_reason01": { canonical: "hBTz_Exit_Reason01", type: "STRING", tableCode: "BT" },
        "hbtz_exit_reason02": { canonical: "hBTz_Exit_Reason02", type: "STRING", tableCode: "BT" },
        "hbtz_exit_reason03": { canonical: "hBTz_Exit_Reason03", type: "STRING", tableCode: "BT" },
        "hbtz_exit_reason04": { canonical: "hBTz_Exit_Reason04", type: "STRING", tableCode: "BT" },
        "hbtz_exit_reason05": { canonical: "hBTz_Exit_Reason05", type: "STRING", tableCode: "BT" },
        "hbtz_job_queue"    : { canonical: "hBTz_Job_Queue"    , type: "STRING", tableCode: "BT" },
        "hbtz_job_queue_2"  : { canonical: "hBTz_Job_Queue_2"  , type: "STRING", tableCode: "BT" },
        "hbtz_spare"        : { canonical: "hBTz_Spare"        , type: "STRING", tableCode: "BT" },
        "hbtz_user_dates01" : { canonical: "hBTz_User_Dates01" , type: "STRING", tableCode: "BT" },
        "hbtz_user_dates02" : { canonical: "hBTz_User_Dates02" , type: "STRING", tableCode: "BT" },
        "hbtz_validations01": { canonical: "hBTz_Validations01", type: "STRING", tableCode: "BT" },
        "hbtz_validations02": { canonical: "hBTz_Validations02", type: "STRING", tableCode: "BT" },
        "hbtz_validations03": { canonical: "hBTz_Validations03", type: "STRING", tableCode: "BT" },
        "hbtz_validations04": { canonical: "hBTz_Validations04", type: "STRING", tableCode: "BT" },
        "hbtz_validations05": { canonical: "hBTz_Validations05", type: "STRING", tableCode: "BT" },
    }
};

export default BT;
