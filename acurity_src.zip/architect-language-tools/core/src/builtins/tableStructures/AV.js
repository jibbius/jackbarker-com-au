/**
 * AV.js — table structure for the AV (Advisor History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AV").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AV
 */

/** @type {Object} */
const AV = {
    code: "AV",
    name: "Advisor_History",
    recordLength: null,
    helpRegistry: "hAV.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "AVi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "havd_effective_date"  : { canonical: "hAVd_Effective_Date"  , type: "DATE", tableCode: "AV" },
        "havd_expiry_date"     : { canonical: "hAVd_Expiry_Date"     , type: "DATE", tableCode: "AV" },
        "havd_mod_date"        : { canonical: "hAVd_Mod_Date"        , type: "DATE", tableCode: "AV" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "havt_mod_time"        : { canonical: "hAVt_Mod_Time"        , type: "TIME", tableCode: "AV" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "havz_advisor_code"    : { canonical: "hAVz_Advisor_Code"    , type: "STRING", tableCode: "AV" },
        "havz_client"          : { canonical: "hAVz_Client"          , type: "STRING", tableCode: "AV" },
        "havz_company_code"    : { canonical: "hAVz_Company_Code"    , type: "STRING", tableCode: "AV" },
        "havz_fund"            : { canonical: "hAVz_Fund"            , type: "STRING", tableCode: "AV" },
        "havz_member"          : { canonical: "hAVz_Member"          , type: "STRING", tableCode: "AV" },
        "havz_mod_user"        : { canonical: "hAVz_Mod_User"        , type: "STRING", tableCode: "AV" },
        "havz_payroll"         : { canonical: "hAVz_Payroll"         , type: "STRING", tableCode: "AV" },
        "havz_record_type"     : { canonical: "hAVz_Record_Type"     , type: "STRING", tableCode: "AV" },
        "havz_spare"           : { canonical: "hAVz_Spare"           , type: "STRING", tableCode: "AV" },
        "havz_type_of_authorty": { canonical: "hAVz_Type_of_Authorty", type: "STRING", tableCode: "AV" },
    }
};

export default AV;
