/**
 * PC.js — table structure for the PC (Post Code) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PC").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PC
 */

/** @type {Object} */
const PC = {
    code: "PC",
    name: "Post_Code",
    recordLength: null,
    helpRegistry: "hPC.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PCi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hpcz_bsp_name"       : { canonical: "hPCz_BSP_Name"       , type: "STRING", tableCode: "PC" },
        "hpcz_bsp_number"     : { canonical: "hPCz_BSP_Number"     , type: "STRING", tableCode: "PC" },
        "hpcz_comments"       : { canonical: "hPCz_Comments"       , type: "STRING", tableCode: "PC" },
        "hpcz_delivery_office": { canonical: "hPCz_Delivery_Office", type: "STRING", tableCode: "PC" },
        "hpcz_parcel_zone"    : { canonical: "hPCz_Parcel_Zone"    , type: "STRING", tableCode: "PC" },
        "hpcz_place_name"     : { canonical: "hPCz_Place_Name"     , type: "STRING", tableCode: "PC" },
        "hpcz_post_code"      : { canonical: "hPCz_Post_Code"      , type: "STRING", tableCode: "PC" },
        "hpcz_presort_ind"    : { canonical: "hPCz_Presort_Ind"    , type: "STRING", tableCode: "PC" },
        "hpcz_spare"          : { canonical: "hPCz_Spare"          , type: "STRING", tableCode: "PC" },
        "hpcz_state"          : { canonical: "hPCz_State"          , type: "STRING", tableCode: "PC" },
    }
};

export default PC;
