/**
 * EB.js — table structure for the EB (Event and Exception Bases) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "EB").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force EB
 */

/** @type {Object} */
const EB = {
    code: "EB",
    name: "Event_and_Exception_Bases",
    recordLength: null,
    helpRegistry: "hEB.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "EBi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hebc_basestype"      : { canonical: "hEBc_BasesType"      , type: "STRING", tableCode: "EB" },
        "hebc_deleted"        : { canonical: "hEBc_Deleted"        , type: "STRING", tableCode: "EB" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hebd_mod_date"       : { canonical: "hEBd_Mod_Date"       , type: "DATE", tableCode: "EB" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hebl_clob_id"        : { canonical: "hEBl_CLOB_ID"        , type: "INTEGER", tableCode: "EB" },
        "hebl_record_id"      : { canonical: "hEBl_Record_Id"      , type: "INTEGER", tableCode: "EB" },
        "hebl_sequence"       : { canonical: "hEBl_Sequence"       , type: "INTEGER", tableCode: "EB" },
        "hebl_spare"          : { canonical: "hEBl_Spare"          , type: "INTEGER", tableCode: "EB" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hebt_mod_time"       : { canonical: "hEBt_Mod_Time"       , type: "TIME", tableCode: "EB" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hebz_category"       : { canonical: "hEBz_Category"       , type: "STRING", tableCode: "EB" },
        "hebz_code"           : { canonical: "hEBz_Code"           , type: "STRING", tableCode: "EB" },
        "hebz_division"       : { canonical: "hEBz_Division"       , type: "STRING", tableCode: "EB" },
        "hebz_field"          : { canonical: "hEBz_Field"          , type: "STRING", tableCode: "EB" },
        "hebz_form_extension" : { canonical: "hEBz_Form_Extension" , type: "STRING", tableCode: "EB" },
        "hebz_form_name"      : { canonical: "hEBz_Form_Name"      , type: "STRING", tableCode: "EB" },
        "hebz_functioncode"   : { canonical: "hEBz_FunctionCode"   , type: "STRING", tableCode: "EB" },
        "hebz_fund"           : { canonical: "hEBz_Fund"           , type: "STRING", tableCode: "EB" },
        "hebz_handling_method": { canonical: "hEBz_Handling_Method", type: "STRING", tableCode: "EB" },
        "hebz_mod_user"       : { canonical: "hEBz_Mod_User"       , type: "STRING", tableCode: "EB" },
        "hebz_parameters"     : { canonical: "hEBz_Parameters"     , type: "STRING", tableCode: "EB" },
        "hebz_spare"          : { canonical: "hEBz_Spare"          , type: "STRING", tableCode: "EB" },
        "hebz_type"           : { canonical: "hEBz_Type"           , type: "STRING", tableCode: "EB" },
    }
};

export default EB;
