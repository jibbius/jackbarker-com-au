/**
 * PR.js — table structure for the PR (Payee Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PR").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PR
 */

/** @type {Object} */
const PR = {
    code: "PR",
    name: "Payee_Details",
    recordLength: null,
    helpRegistry: "hPR.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PRi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hprc_deleted"         : { canonical: "hPRc_Deleted"         , type: "STRING", tableCode: "PR" },
        "hprc_rollover"        : { canonical: "hPRc_Rollover"        , type: "STRING", tableCode: "PR" },
        "hprc_spare"           : { canonical: "hPRc_Spare"           , type: "STRING", tableCode: "PR" },
        "hprc_swimec_enabled"  : { canonical: "hPRc_SwimEC_Enabled"  , type: "STRING", tableCode: "PR" },
        "hprc_type"            : { canonical: "hPRc_Type"            , type: "STRING", tableCode: "PR" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hprd_mod_date"        : { canonical: "hPRd_Mod_Date"        , type: "DATE", tableCode: "PR" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hprt_mod_time"        : { canonical: "hPRt_Mod_Time"        , type: "TIME", tableCode: "PR" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hprz_address01"       : { canonical: "hPRz_Address01"       , type: "STRING", tableCode: "PR" },
        "hprz_address02"       : { canonical: "hPRz_Address02"       , type: "STRING", tableCode: "PR" },
        "hprz_address03"       : { canonical: "hPRz_Address03"       , type: "STRING", tableCode: "PR" },
        "hprz_admin_name"      : { canonical: "hPRz_Admin_Name"      , type: "STRING", tableCode: "PR" },
        "hprz_aust_business_no": { canonical: "hPRz_Aust_Business_No", type: "STRING", tableCode: "PR" },
        "hprz_auth_sig_givnnme": { canonical: "hPRz_Auth_Sig_GivnNme", type: "STRING", tableCode: "PR" },
        "hprz_auth_sig_surname": { canonical: "hPRz_Auth_Sig_Surname", type: "STRING", tableCode: "PR" },
        "hprz_bank_acct_name"  : { canonical: "hPRz_Bank_Acct_Name"  , type: "STRING", tableCode: "PR" },
        "hprz_bank_acct_no"    : { canonical: "hPRz_Bank_Acct_No"    , type: "STRING", tableCode: "PR" },
        "hprz_bsb"             : { canonical: "hPRz_BSB"             , type: "STRING", tableCode: "PR" },
        "hprz_c_fax"           : { canonical: "hPRz_C_Fax"           , type: "STRING", tableCode: "PR" },
        "hprz_c_name"          : { canonical: "hPRz_C_Name"          , type: "STRING", tableCode: "PR" },
        "hprz_c_phone"         : { canonical: "hPRz_C_Phone"         , type: "STRING", tableCode: "PR" },
        "hprz_c_position"      : { canonical: "hPRz_C_Position"      , type: "STRING", tableCode: "PR" },
        "hprz_category"        : { canonical: "hPRz_Category"        , type: "STRING", tableCode: "PR" },
        "hprz_cheque_name"     : { canonical: "hPRz_Cheque_Name"     , type: "STRING", tableCode: "PR" },
        "hprz_code"            : { canonical: "hPRz_Code"            , type: "STRING", tableCode: "PR" },
        "hprz_dest_prod_id_no" : { canonical: "hPRz_Dest_Prod_ID_No" , type: "STRING", tableCode: "PR" },
        "hprz_email"           : { canonical: "hPRz_Email"           , type: "STRING", tableCode: "PR" },
        "hprz_grouping"        : { canonical: "hPRz_Grouping"        , type: "STRING", tableCode: "PR" },
        "hprz_mod_user"        : { canonical: "hPRz_Mod_User"        , type: "STRING", tableCode: "PR" },
        "hprz_name"            : { canonical: "hPRz_Name"            , type: "STRING", tableCode: "PR" },
        "hprz_old_fax"         : { canonical: "hPRz_Old_Fax"         , type: "STRING", tableCode: "PR" },
        "hprz_old_home_phone"  : { canonical: "hPRz_Old_Home_Phone"  , type: "STRING", tableCode: "PR" },
        "hprz_post_code"       : { canonical: "hPRz_Post_Code"       , type: "STRING", tableCode: "PR" },
        "hprz_prodid"          : { canonical: "hPRz_ProdID"          , type: "STRING", tableCode: "PR" },
        "hprz_super_fund_num"  : { canonical: "hPRz_Super_Fund_Num"  , type: "STRING", tableCode: "PR" },
        "hprz_tax_file_no"     : { canonical: "hPRz_Tax_File_No"     , type: "STRING", tableCode: "PR" },
    }
};

export default PR;
