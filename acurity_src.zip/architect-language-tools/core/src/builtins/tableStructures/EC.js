/**
 * EC.js — table structure for the EC (Message Codes) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "EC").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force EC
 */

/** @type {Object} */
const EC = {
    code: "EC",
    name: "Message_Codes",
    recordLength: null,
    helpRegistry: "hEC.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ECi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hecc_spare"           : { canonical: "hECc_Spare"           , type: "STRING", tableCode: "EC" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hecd_mod_date"        : { canonical: "hECd_Mod_Date"        , type: "DATE", tableCode: "EC" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hecl_message_code"    : { canonical: "hECl_Message_Code"    , type: "INTEGER", tableCode: "EC" },
        "hecl_spare"           : { canonical: "hECl_Spare"           , type: "INTEGER", tableCode: "EC" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hect_mod_time"        : { canonical: "hECt_Mod_Time"        , type: "TIME", tableCode: "EC" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hecz_description"     : { canonical: "hECz_Description"     , type: "STRING", tableCode: "EC" },
        "hecz_long_description": { canonical: "hECz_Long_Description", type: "STRING", tableCode: "EC" },
        "hecz_macro"           : { canonical: "hECz_Macro"           , type: "STRING", tableCode: "EC" },
        "hecz_message_type"    : { canonical: "hECz_Message_Type"    , type: "STRING", tableCode: "EC" },
        "hecz_mod_user"        : { canonical: "hECz_Mod_User"        , type: "STRING", tableCode: "EC" },
        "hecz_process_type"    : { canonical: "hECz_Process_Type"    , type: "STRING", tableCode: "EC" },
        "hecz_spare"           : { canonical: "hECz_Spare"           , type: "STRING", tableCode: "EC" },
        "hecz_table"           : { canonical: "hECz_Table"           , type: "STRING", tableCode: "EC" },
    }
};

export default EC;
