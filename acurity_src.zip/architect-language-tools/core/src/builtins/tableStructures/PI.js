/**
 * PI.js — table structure for the PI (Policy Benefit Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PI").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PI
 */

/** @type {Object} */
const PI = {
    code: "PI",
    name: "Policy_Benefit_Details",
    recordLength: null,
    helpRegistry: "hPI.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PIi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hpic_benefit_roll_in" : { canonical: "hPIc_Benefit_Roll_In" , type: "STRING", tableCode: "PI" },
        "hpic_deleted"         : { canonical: "hPIc_Deleted"         , type: "STRING", tableCode: "PI" },
        "hpic_exclusions_apply": { canonical: "hPIc_Exclusions_Apply", type: "STRING", tableCode: "PI" },
        "hpic_notes"           : { canonical: "hPIc_Notes"           , type: "STRING", tableCode: "PI" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hpid_effective"       : { canonical: "hPId_Effective"       , type: "DATE", tableCode: "PI" },
        "hpid_lapsed"          : { canonical: "hPId_Lapsed"          , type: "DATE", tableCode: "PI" },
        "hpid_mod_date"        : { canonical: "hPId_Mod_Date"        , type: "DATE", tableCode: "PI" },
        "hpid_pec_end"         : { canonical: "hPId_PEC_End"         , type: "DATE", tableCode: "PI" },
        "hpid_pec_start"       : { canonical: "hPId_PEC_Start"       , type: "DATE", tableCode: "PI" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hpif_crb"             : { canonical: "hPIf_CRB"             , type: "DOUBLE", tableCode: "PI" },
        "hpif_dollar_default"  : { canonical: "hPIf_Dollar_Default"  , type: "DOUBLE", tableCode: "PI" },
        "hpif_dollaradditional": { canonical: "hPIf_DollarAdditional", type: "DOUBLE", tableCode: "PI" },
        "hpif_ip_salary_pcnt"  : { canonical: "hPIf_IP_Salary_Pcnt"  , type: "DOUBLE", tableCode: "PI" },
        "hpif_premium"         : { canonical: "hPIf_Premium"         , type: "DOUBLE", tableCode: "PI" },
        "hpif_premium_default" : { canonical: "hPIf_Premium_Default" , type: "DOUBLE", tableCode: "PI" },
        "hpif_premiumadditionl": { canonical: "hPIf_PremiumAdditionl", type: "DOUBLE", tableCode: "PI" },
        "hpif_salary"          : { canonical: "hPIf_Salary"          , type: "DOUBLE", tableCode: "PI" },
        "hpif_si_additional"   : { canonical: "hPIf_SI_Additional"   , type: "DOUBLE", tableCode: "PI" },
        "hpif_si_default"      : { canonical: "hPIf_SI_Default"      , type: "DOUBLE", tableCode: "PI" },
        "hpif_si_excess"       : { canonical: "hPIf_SI_Excess"       , type: "DOUBLE", tableCode: "PI" },
        "hpif_stamp_duty"      : { canonical: "hPIf_Stamp_Duty"      , type: "DOUBLE", tableCode: "PI" },
        "hpif_units_default"   : { canonical: "hPIf_Units_Default"   , type: "DOUBLE", tableCode: "PI" },
        "hpif_unitsadditional" : { canonical: "hPIf_UnitsAdditional" , type: "DOUBLE", tableCode: "PI" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hpil_policy_number"   : { canonical: "hPIl_Policy_Number"   , type: "INTEGER", tableCode: "PI" },
        "hpil_spare"           : { canonical: "hPIl_Spare"           , type: "INTEGER", tableCode: "PI" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hpit_mod_time"        : { canonical: "hPIt_Mod_Time"        , type: "TIME", tableCode: "PI" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hpiz_benefit_feature" : { canonical: "hPIz_Benefit_Feature" , type: "STRING", tableCode: "PI" },
        "hpiz_benefit_period"  : { canonical: "hPIz_Benefit_Period"  , type: "STRING", tableCode: "PI" },
        "hpiz_benefit_type"    : { canonical: "hPIz_Benefit_Type"    , type: "STRING", tableCode: "PI" },
        "hpiz_client"          : { canonical: "hPIz_Client"          , type: "STRING", tableCode: "PI" },
        "hpiz_financial_uwrite": { canonical: "hPIz_Financial_Uwrite", type: "STRING", tableCode: "PI" },
        "hpiz_insurance_cat"   : { canonical: "hPIz_Insurance_Cat"   , type: "STRING", tableCode: "PI" },
        "hpiz_mod_user"        : { canonical: "hPIz_Mod_User"        , type: "STRING", tableCode: "PI" },
        "hpiz_occupation"      : { canonical: "hPIz_Occupation"      , type: "STRING", tableCode: "PI" },
        "hpiz_significantevent": { canonical: "hPIz_SignificantEvent", type: "STRING", tableCode: "PI" },
        "hpiz_status"          : { canonical: "hPIz_Status"          , type: "STRING", tableCode: "PI" },
        "hpiz_supp_record_type": { canonical: "hPIz_Supp_Record_Type", type: "STRING", tableCode: "PI" },
        "hpiz_waiting_period"  : { canonical: "hPIz_Waiting_Period"  , type: "STRING", tableCode: "PI" },
    }
};

export default PI;
