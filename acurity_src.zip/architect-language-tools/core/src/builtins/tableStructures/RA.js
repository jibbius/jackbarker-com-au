/**
 * RA.js — table structure for the RA (Remittance Advice) table.
 *
 * Indexes: sourced from authoritative schema data.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "RA").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structure.js RA
 */

/** @type {Object} */
const RA = {
    code: "RA",
    name: "Remittance_Advice",
    recordLength: null,
    helpRegistry: "hRA.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "RAi_Identity", type: "BIGINT", length: 8 }
            ]
        },
        {
            name: "0",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "RAz_Division",    type: "ZSTRING", length: 2  },
                { position: 1, field: "RAz_Fund",         type: "ZSTRING", length: 5  },
                { position: 2, field: "RAz_Long_Payroll", type: "ZSTRING", length: 11 },
                { position: 3, field: "RAc_Group",        type: "STRING",  length: 1  },
                { position: 4, field: "RAs_Cycle_No",     type: "SHORT",   length: 2  }
            ]
        },
        {
            name: "1",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "RAz_Division",  type: "ZSTRING", length: 2 },
                { position: 1, field: "RAl_Trans_Ref", type: "LONG",    length: 1 }
            ]
        },
        {
            name: "2",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "RAz_Division",  type: "ZSTRING", length: 2  },
                { position: 1, field: "RAc_File_Type", type: "STRING",  length: 1  },
                { position: 2, field: "RAc_Status",    type: "STRING",  length: 1  },
                { position: 3, field: "RAz_Filename",  type: "ZSTRING", length: 13 },
                { position: 4, field: "RAd_Registered", type: "DATE",   length: 4  }
            ]
        }
    ],
    fields: {
        // ── CHAR (c-prefix) ──────────────────────────────────────────────────
        "hrac_contrib_type":   { canonical: "hRAc_Contrib_Type",   type: "STRING",  tableCode: "RA" },
        "hrac_file_type":      { canonical: "hRAc_File_Type",       type: "STRING",  tableCode: "RA" },
        "hrac_group":          { canonical: "hRAc_Group",           type: "STRING",  tableCode: "RA" },
        "hrac_long_filename":  { canonical: "hRAc_Long_Filename",   type: "STRING",  tableCode: "RA" },
        "hrac_notes":          { canonical: "hRAc_Notes",           type: "STRING",  tableCode: "RA" },
        "hrac_proc_new_mbrs":  { canonical: "hRAc_Proc_New_Mbrs",   type: "STRING",  tableCode: "RA" },
        "hrac_status":         { canonical: "hRAc_Status",          type: "STRING",  tableCode: "RA" },
        // ── DATE (d-prefix) ──────────────────────────────────────────────────
        "hrad_authorised_date": { canonical: "hRAd_Authorised_Date", type: "DATE",   tableCode: "RA" },
        "hrad_last_test_run":   { canonical: "hRAd_Last_Test_Run",   type: "DATE",   tableCode: "RA" },
        "hrad_mod_date":        { canonical: "hRAd_Mod_Date",        type: "DATE",   tableCode: "RA" },
        "hrad_paperwork":       { canonical: "hRAd_Paperwork",       type: "DATE",   tableCode: "RA" },
        "hrad_period_end":      { canonical: "hRAd_Period_End",      type: "DATE",   tableCode: "RA" },
        "hrad_period_start":    { canonical: "hRAd_Period_Start",    type: "DATE",   tableCode: "RA" },
        "hrad_posted":          { canonical: "hRAd_Posted",          type: "DATE",   tableCode: "RA" },
        "hrad_registered":      { canonical: "hRAd_Registered",      type: "DATE",   tableCode: "RA" },
        "hrad_status":          { canonical: "hRAd_Status",          type: "DATE",   tableCode: "RA" },
        "hrad_user01":          { canonical: "hRAd_User01",          type: "DATE",   tableCode: "RA" },
        "hrad_user02":          { canonical: "hRAd_User02",          type: "DATE",   tableCode: "RA" },
        // ── DOUBLE (f-prefix) ────────────────────────────────────────────────
        "hraf_total":          { canonical: "hRAf_Total",           type: "DOUBLE",  tableCode: "RA" },
        "hraf_unposted_amt":   { canonical: "hRAf_Unposted_Amt",    type: "DOUBLE",  tableCode: "RA" },
        "hraf_unposted_amt2":  { canonical: "hRAf_Unposted_Amt2",   type: "DOUBLE",  tableCode: "RA" },
        // ── LONG (l-prefix) ──────────────────────────────────────────────────
        "hral_bank_ref":       { canonical: "hRAl_Bank_Ref",        type: "INTEGER", tableCode: "RA" },
        "hral_job_ref":        { canonical: "hRAl_Job_Ref",         type: "INTEGER", tableCode: "RA" },
        "hral_receipt_ref":    { canonical: "hRAl_Receipt_Ref",     type: "INTEGER", tableCode: "RA" },
        "hral_total_records":  { canonical: "hRAl_Total_Records",   type: "INTEGER", tableCode: "RA" },
        "hral_trans_ref":      { canonical: "hRAl_Trans_Ref",       type: "INTEGER", tableCode: "RA" },
        // ── SHORT (s-prefix) ─────────────────────────────────────────────────
        "hras_cycle_no":       { canonical: "hRAs_Cycle_No",        type: "INTEGER", tableCode: "RA" },
        "hras_no_of_weeks":    { canonical: "hRAs_No_Of_Weeks",     type: "INTEGER", tableCode: "RA" },
        "hras_spare01":        { canonical: "hRAs_Spare01",         type: "INTEGER", tableCode: "RA" },
        "hras_spare02":        { canonical: "hRAs_Spare02",         type: "INTEGER", tableCode: "RA" },
        // ── TIME (t-prefix) ──────────────────────────────────────────────────
        "hrat_authorised_time": { canonical: "hRAt_Authorised_Time", type: "TIME",   tableCode: "RA" },
        "hrat_mod_time":        { canonical: "hRAt_Mod_Time",        type: "TIME",   tableCode: "RA" },
        // ── ZSTRING (z-prefix) ───────────────────────────────────────────────
        "hraz_authorisedbyuser":  { canonical: "hRAz_AuthorisedByUser",  type: "STRING", tableCode: "RA" },
        "hraz_bank_st_ref":       { canonical: "hRAz_Bank_St_Ref",       type: "STRING", tableCode: "RA" },
        "hraz_biller_code":       { canonical: "hRAz_Biller_Code",       type: "STRING", tableCode: "RA" },
        "hraz_division":          { canonical: "hRAz_Division",          type: "STRING", tableCode: "RA" },
        "hraz_file_type_id":      { canonical: "hRAz_File_Type_Id",      type: "STRING", tableCode: "RA" },
        "hraz_filename":          { canonical: "hRAz_Filename",          type: "STRING", tableCode: "RA" },
        "hraz_fund":              { canonical: "hRAz_Fund",              type: "STRING", tableCode: "RA" },
        "hraz_long_payroll":      { canonical: "hRAz_Long_Payroll",      type: "STRING", tableCode: "RA" },
        "hraz_message_service":   { canonical: "hRAz_Message_Service",   type: "STRING", tableCode: "RA" },
        "hraz_mod_user":          { canonical: "hRAz_Mod_User",          type: "STRING", tableCode: "RA" },
        "hraz_orig_filename":     { canonical: "hRAz_Orig_FileName",     type: "STRING", tableCode: "RA" },
        "hraz_payee":             { canonical: "hRAz_Payee",             type: "STRING", tableCode: "RA" },
        "hraz_payroll":           { canonical: "hRAz_Payroll",           type: "STRING", tableCode: "RA" },
        "hraz_reference":         { canonical: "hRAz_Reference",         type: "STRING", tableCode: "RA" },
        "hraz_reject_reason":     { canonical: "hRAz_Reject_Reason",     type: "STRING", tableCode: "RA" },
        "hraz_report_id":         { canonical: "hRAz_Report_ID",         type: "STRING", tableCode: "RA" },
        "hraz_sal_upd_rep_id":    { canonical: "hRAz_Sal_Upd_Rep_ID",    type: "STRING", tableCode: "RA" },
        "hraz_status_user":       { canonical: "hRAz_Status_User",       type: "STRING", tableCode: "RA" },
        "hraz_user_def_flags01":  { canonical: "hRAz_User_Def_Flags01",  type: "STRING", tableCode: "RA" },
        "hraz_user_def_flags02":  { canonical: "hRAz_User_Def_Flags02",  type: "STRING", tableCode: "RA" }
    }
};

export default RA;
