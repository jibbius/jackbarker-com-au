/**
 * SF.js — table structure for the SF (Member Supplementary Labels) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SF").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SF
 */

/** @type {Object} */
const SF = {
    code: "SF",
    name: "Member_Supplementary_Labels",
    recordLength: null,
    helpRegistry: "hSF.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SFi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hsfc_label_type"      : { canonical: "hSFc_Label_Type"      , type: "STRING", tableCode: "SF" },
        "hsfc_record_type"     : { canonical: "hSFc_Record_Type"     , type: "STRING", tableCode: "SF" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hsfd_mod_date"        : { canonical: "hSFd_Mod_Date"        , type: "DATE", tableCode: "SF" },
        "hsfd_spare"           : { canonical: "hSFd_Spare"           , type: "DATE", tableCode: "SF" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hsff_spare01"         : { canonical: "hSFf_Spare01"         , type: "DOUBLE", tableCode: "SF" },
        "hsff_spare02"         : { canonical: "hSFf_Spare02"         , type: "DOUBLE", tableCode: "SF" },
        "hsff_spare03"         : { canonical: "hSFf_Spare03"         , type: "DOUBLE", tableCode: "SF" },
        "hsff_spare04"         : { canonical: "hSFf_Spare04"         , type: "DOUBLE", tableCode: "SF" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hsfl_spare"           : { canonical: "hSFl_Spare"           , type: "INTEGER", tableCode: "SF" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hsfs_dp_misc01"       : { canonical: "hSFs_DP_Misc01"       , type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_misc02"       : { canonical: "hSFs_DP_Misc02"       , type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld01": { canonical: "hSFs_DP_MiscRvw_Fld01", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld02": { canonical: "hSFs_DP_MiscRvw_Fld02", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld03": { canonical: "hSFs_DP_MiscRvw_Fld03", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld04": { canonical: "hSFs_DP_MiscRvw_Fld04", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld05": { canonical: "hSFs_DP_MiscRvw_Fld05", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld06": { canonical: "hSFs_DP_MiscRvw_Fld06", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld07": { canonical: "hSFs_DP_MiscRvw_Fld07", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld08": { canonical: "hSFs_DP_MiscRvw_Fld08", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld09": { canonical: "hSFs_DP_MiscRvw_Fld09", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld10": { canonical: "hSFs_DP_MiscRvw_Fld10", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld11": { canonical: "hSFs_DP_MiscRvw_Fld11", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld12": { canonical: "hSFs_DP_MiscRvw_Fld12", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld13": { canonical: "hSFs_DP_MiscRvw_Fld13", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld14": { canonical: "hSFs_DP_MiscRvw_Fld14", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld15": { canonical: "hSFs_DP_MiscRvw_Fld15", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld16": { canonical: "hSFs_DP_MiscRvw_Fld16", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld17": { canonical: "hSFs_DP_MiscRvw_Fld17", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld18": { canonical: "hSFs_DP_MiscRvw_Fld18", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld19": { canonical: "hSFs_DP_MiscRvw_Fld19", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld20": { canonical: "hSFs_DP_MiscRvw_Fld20", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld21": { canonical: "hSFs_DP_MiscRvw_Fld21", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld22": { canonical: "hSFs_DP_MiscRvw_Fld22", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld23": { canonical: "hSFs_DP_MiscRvw_Fld23", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld24": { canonical: "hSFs_DP_MiscRvw_Fld24", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld25": { canonical: "hSFs_DP_MiscRvw_Fld25", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld26": { canonical: "hSFs_DP_MiscRvw_Fld26", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld27": { canonical: "hSFs_DP_MiscRvw_Fld27", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld28": { canonical: "hSFs_DP_MiscRvw_Fld28", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld29": { canonical: "hSFs_DP_MiscRvw_Fld29", type: "INTEGER", tableCode: "SF" },
        "hsfs_dp_miscrvw_fld30": { canonical: "hSFs_DP_MiscRvw_Fld30", type: "INTEGER", tableCode: "SF" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hsft_mod_time"        : { canonical: "hSFt_Mod_Time"        , type: "TIME", tableCode: "SF" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hsfz_misc_desc_101"   : { canonical: "hSFz_Misc_Desc_101"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_102"   : { canonical: "hSFz_Misc_Desc_102"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_103"   : { canonical: "hSFz_Misc_Desc_103"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_104"   : { canonical: "hSFz_Misc_Desc_104"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_105"   : { canonical: "hSFz_Misc_Desc_105"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_106"   : { canonical: "hSFz_Misc_Desc_106"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_107"   : { canonical: "hSFz_Misc_Desc_107"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_108"   : { canonical: "hSFz_Misc_Desc_108"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_109"   : { canonical: "hSFz_Misc_Desc_109"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_110"   : { canonical: "hSFz_Misc_Desc_110"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_201"   : { canonical: "hSFz_Misc_Desc_201"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_202"   : { canonical: "hSFz_Misc_Desc_202"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_203"   : { canonical: "hSFz_Misc_Desc_203"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_204"   : { canonical: "hSFz_Misc_Desc_204"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_205"   : { canonical: "hSFz_Misc_Desc_205"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc_206"   : { canonical: "hSFz_Misc_Desc_206"   , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc01"     : { canonical: "hSFz_Misc_Desc01"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc02"     : { canonical: "hSFz_Misc_Desc02"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc03"     : { canonical: "hSFz_Misc_Desc03"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc04"     : { canonical: "hSFz_Misc_Desc04"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc05"     : { canonical: "hSFz_Misc_Desc05"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc06"     : { canonical: "hSFz_Misc_Desc06"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc07"     : { canonical: "hSFz_Misc_Desc07"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc08"     : { canonical: "hSFz_Misc_Desc08"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc09"     : { canonical: "hSFz_Misc_Desc09"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc10"     : { canonical: "hSFz_Misc_Desc10"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc11"     : { canonical: "hSFz_Misc_Desc11"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc12"     : { canonical: "hSFz_Misc_Desc12"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc13"     : { canonical: "hSFz_Misc_Desc13"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_desc14"     : { canonical: "hSFz_Misc_Desc14"     , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field01"    : { canonical: "hSFz_Misc_Field01"    , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field02"    : { canonical: "hSFz_Misc_Field02"    , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field03"    : { canonical: "hSFz_Misc_Field03"    , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field04"    : { canonical: "hSFz_Misc_Field04"    , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field05"    : { canonical: "hSFz_Misc_Field05"    , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field06"    : { canonical: "hSFz_Misc_Field06"    , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field07"    : { canonical: "hSFz_Misc_Field07"    , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field08"    : { canonical: "hSFz_Misc_Field08"    , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field09"    : { canonical: "hSFz_Misc_Field09"    , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field10"    : { canonical: "hSFz_Misc_Field10"    , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field11"    : { canonical: "hSFz_Misc_Field11"    , type: "STRING", tableCode: "SF" },
        "hsfz_misc_field12"    : { canonical: "hSFz_Misc_Field12"    , type: "STRING", tableCode: "SF" },
        "hsfz_mod_user"        : { canonical: "hSFz_Mod_User"        , type: "STRING", tableCode: "SF" },
        "hsfz_payroll"         : { canonical: "hSFz_Payroll"         , type: "STRING", tableCode: "SF" },
        "hsfz_record_type"     : { canonical: "hSFz_Record_Type"     , type: "STRING", tableCode: "SF" },
        "hsfz_spare"           : { canonical: "hSFz_Spare"           , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_101": { canonical: "hSFz_Supp_FldName_101", type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_102": { canonical: "hSFz_Supp_FldName_102", type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_103": { canonical: "hSFz_Supp_FldName_103", type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_104": { canonical: "hSFz_Supp_FldName_104", type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_105": { canonical: "hSFz_Supp_FldName_105", type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_106": { canonical: "hSFz_Supp_FldName_106", type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_201": { canonical: "hSFz_Supp_FldName_201", type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_202": { canonical: "hSFz_Supp_FldName_202", type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_203": { canonical: "hSFz_Supp_FldName_203", type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_204": { canonical: "hSFz_Supp_FldName_204", type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_205": { canonical: "hSFz_Supp_FldName_205", type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_3"  : { canonical: "hSFz_Supp_FldName_3"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname_4"  : { canonical: "hSFz_Supp_FldName_4"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname01"  : { canonical: "hSFz_Supp_FldName01"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname02"  : { canonical: "hSFz_Supp_FldName02"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname03"  : { canonical: "hSFz_Supp_FldName03"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname04"  : { canonical: "hSFz_Supp_FldName04"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname05"  : { canonical: "hSFz_Supp_FldName05"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname06"  : { canonical: "hSFz_Supp_FldName06"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname07"  : { canonical: "hSFz_Supp_FldName07"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname08"  : { canonical: "hSFz_Supp_FldName08"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname09"  : { canonical: "hSFz_Supp_FldName09"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname10"  : { canonical: "hSFz_Supp_FldName10"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname11"  : { canonical: "hSFz_Supp_FldName11"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname12"  : { canonical: "hSFz_Supp_FldName12"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname13"  : { canonical: "hSFz_Supp_FldName13"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname14"  : { canonical: "hSFz_Supp_FldName14"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname15"  : { canonical: "hSFz_Supp_FldName15"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname16"  : { canonical: "hSFz_Supp_FldName16"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname17"  : { canonical: "hSFz_Supp_FldName17"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fldname18"  : { canonical: "hSFz_Supp_FldName18"  , type: "STRING", tableCode: "SF" },
        "hsfz_supp_fund"       : { canonical: "hSFz_Supp_Fund"       , type: "STRING", tableCode: "SF" },
    }
};

export default SF;
