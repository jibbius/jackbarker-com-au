/**
 * SB.js — table structure for the SB (Supplementary Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SB").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SB
 */

/** @type {Object} */
const SB = {
    code: "SB",
    name: "Supplementary_Details",
    recordLength: null,
    helpRegistry: "hSB.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SBi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hsbc_indexation"      : { canonical: "hSBc_Indexation"      , type: "STRING", tableCode: "SB" },
        "hsbc_notes"           : { canonical: "hSBc_Notes"           , type: "STRING", tableCode: "SB" },
        "hsbc_one_off_payment" : { canonical: "hSBc_One_Off_Payment" , type: "STRING", tableCode: "SB" },
        "hsbc_pay_frequency"   : { canonical: "hSBc_Pay_Frequency"   , type: "STRING", tableCode: "SB" },
        "hsbc_record_type"     : { canonical: "hSBc_Record_Type"     , type: "STRING", tableCode: "SB" },
        "hsbc_tax_specified"   : { canonical: "hSBc_Tax_Specified"   , type: "STRING", tableCode: "SB" },
        "hsbc_user_flags01"    : { canonical: "hSBc_User_Flags01"    , type: "STRING", tableCode: "SB" },
        "hsbc_user_flags02"    : { canonical: "hSBc_User_Flags02"    , type: "STRING", tableCode: "SB" },
        "hsbc_user_flags03"    : { canonical: "hSBc_User_Flags03"    , type: "STRING", tableCode: "SB" },
        "hsbc_user_flags04"    : { canonical: "hSBc_User_Flags04"    , type: "STRING", tableCode: "SB" },
        "hsbc_user_flags05"    : { canonical: "hSBc_User_Flags05"    , type: "STRING", tableCode: "SB" },
        "hsbc_userdefndflags01": { canonical: "hSBc_UserDefndFlags01", type: "STRING", tableCode: "SB" },
        "hsbc_userdefndflags02": { canonical: "hSBc_UserDefndFlags02", type: "STRING", tableCode: "SB" },
        "hsbc_userdefndflags03": { canonical: "hSBc_UserDefndFlags03", type: "STRING", tableCode: "SB" },
        "hsbc_userdefndflags04": { canonical: "hSBc_UserDefndFlags04", type: "STRING", tableCode: "SB" },
        "hsbc_userdefndflags05": { canonical: "hSBc_UserDefndFlags05", type: "STRING", tableCode: "SB" },
        "hsbc_userdefndflags06": { canonical: "hSBc_UserDefndFlags06", type: "STRING", tableCode: "SB" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hsbd_anniversary"     : { canonical: "hSBd_Anniversary"     , type: "DATE", tableCode: "SB" },
        "hsbd_effective"       : { canonical: "hSBd_Effective"       , type: "DATE", tableCode: "SB" },
        "hsbd_indexation"      : { canonical: "hSBd_Indexation"      , type: "DATE", tableCode: "SB" },
        "hsbd_mod_date"        : { canonical: "hSBd_Mod_Date"        , type: "DATE", tableCode: "SB" },
        "hsbd_pay_termination" : { canonical: "hSBd_Pay_Termination" , type: "DATE", tableCode: "SB" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hsbf_notionaltaxedcnt": { canonical: "hSBf_NotionalTaxedCnt", type: "DOUBLE", tableCode: "SB" },
        "hsbf_pay_contribution": { canonical: "hSBf_Pay_Contribution", type: "DOUBLE", tableCode: "SB" },
        "hsbf_pay_index"       : { canonical: "hSBf_Pay_Index"       , type: "DOUBLE", tableCode: "SB" },
        "hsbf_pay_offset"      : { canonical: "hSBf_Pay_Offset"      , type: "DOUBLE", tableCode: "SB" },
        "hsbf_payment_amt"     : { canonical: "hSBf_Payment_Amt"     , type: "DOUBLE", tableCode: "SB" },
        "hsbf_surch_conts"     : { canonical: "hSBf_Surch_Conts"     , type: "DOUBLE", tableCode: "SB" },
        "hsbf_surch_surplus"   : { canonical: "hSBf_Surch_Surplus"   , type: "DOUBLE", tableCode: "SB" },
        "hsbf_tax_payable"     : { canonical: "hSBf_Tax_Payable"     , type: "DOUBLE", tableCode: "SB" },
        "hsbf_tax_payable_pcnt": { canonical: "hSBf_Tax_Payable_Pcnt", type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt_1"  : { canonical: "hSBf_User_Def_Amt_1"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt_2"  : { canonical: "hSBf_User_Def_Amt_2"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt_3"  : { canonical: "hSBf_User_Def_Amt_3"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt_4"  : { canonical: "hSBf_User_Def_Amt_4"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt_5"  : { canonical: "hSBf_User_Def_Amt_5"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt_6"  : { canonical: "hSBf_User_Def_Amt_6"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt_7"  : { canonical: "hSBf_User_Def_Amt_7"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt_8"  : { canonical: "hSBf_User_Def_Amt_8"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt_9"  : { canonical: "hSBf_User_Def_Amt_9"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt01"  : { canonical: "hSBf_User_Def_Amt01"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt02"  : { canonical: "hSBf_User_Def_Amt02"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt03"  : { canonical: "hSBf_User_Def_Amt03"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt04"  : { canonical: "hSBf_User_Def_Amt04"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt05"  : { canonical: "hSBf_User_Def_Amt05"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt06"  : { canonical: "hSBf_User_Def_Amt06"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt07"  : { canonical: "hSBf_User_Def_Amt07"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt08"  : { canonical: "hSBf_User_Def_Amt08"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt09"  : { canonical: "hSBf_User_Def_Amt09"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt10"  : { canonical: "hSBf_User_Def_Amt10"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt11"  : { canonical: "hSBf_User_Def_Amt11"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_amt12"  : { canonical: "hSBf_User_Def_Amt12"  , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_mult_1" : { canonical: "hSBf_User_Def_Mult_1" , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_mult_2" : { canonical: "hSBf_User_Def_Mult_2" , type: "DOUBLE", tableCode: "SB" },
        "hsbf_user_def_mult_3" : { canonical: "hSBf_User_Def_Mult_3" , type: "DOUBLE", tableCode: "SB" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hsbt_mod_time"        : { canonical: "hSBt_Mod_Time"        , type: "TIME", tableCode: "SB" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hsbz_adviser"         : { canonical: "hSBz_Adviser"         , type: "STRING", tableCode: "SB" },
        "hsbz_branch_region"   : { canonical: "hSBz_Branch_Region"   , type: "STRING", tableCode: "SB" },
        "hsbz_bsb_no"          : { canonical: "hSBz_BSB_No"          , type: "STRING", tableCode: "SB" },
        "hsbz_client"          : { canonical: "hSBz_Client"          , type: "STRING", tableCode: "SB" },
        "hsbz_fund"            : { canonical: "hSBz_Fund"            , type: "STRING", tableCode: "SB" },
        "hsbz_last_given_names": { canonical: "hSBz_Last_Given_names", type: "STRING", tableCode: "SB" },
        "hsbz_last_surname"    : { canonical: "hSBz_Last_Surname"    , type: "STRING", tableCode: "SB" },
        "hsbz_manager"         : { canonical: "hSBz_Manager"         , type: "STRING", tableCode: "SB" },
        "hsbz_member"          : { canonical: "hSBz_Member"          , type: "STRING", tableCode: "SB" },
        "hsbz_mod_user"        : { canonical: "hSBz_Mod_User"        , type: "STRING", tableCode: "SB" },
        "hsbz_other_code"      : { canonical: "hSBz_Other_Code"      , type: "STRING", tableCode: "SB" },
        "hsbz_other_details"   : { canonical: "hSBz_Other_Details"   , type: "STRING", tableCode: "SB" },
        "hsbz_other_name"      : { canonical: "hSBz_Other_Name"      , type: "STRING", tableCode: "SB" },
        "hsbz_other_ref"       : { canonical: "hSBz_Other_Ref"       , type: "STRING", tableCode: "SB" },
        "hsbz_payee"           : { canonical: "hSBz_Payee"           , type: "STRING", tableCode: "SB" },
        "hsbz_payroll"         : { canonical: "hSBz_Payroll"         , type: "STRING", tableCode: "SB" },
        "hsbz_prev_client_no"  : { canonical: "hSBz_Prev_Client_No"  , type: "STRING", tableCode: "SB" },
        "hsbz_record_type"     : { canonical: "hSBz_Record_Type"     , type: "STRING", tableCode: "SB" },
        "hsbz_spare"           : { canonical: "hSBz_Spare"           , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_date_1" : { canonical: "hSBz_User_Def_Date_1" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_date_2" : { canonical: "hSBz_User_Def_Date_2" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_date_3" : { canonical: "hSBz_User_Def_Date_3" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_date_4" : { canonical: "hSBz_User_Def_Date_4" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_date_5" : { canonical: "hSBz_User_Def_Date_5" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_date_6" : { canonical: "hSBz_User_Def_Date_6" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_strg01" : { canonical: "hSBz_User_Def_Strg01" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_strg02" : { canonical: "hSBz_User_Def_Strg02" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_strg03" : { canonical: "hSBz_User_Def_Strg03" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_strg04" : { canonical: "hSBz_User_Def_Strg04" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_strg05" : { canonical: "hSBz_User_Def_Strg05" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_strg06" : { canonical: "hSBz_User_Def_Strg06" , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_strg3"  : { canonical: "hSBz_User_Def_Strg3"  , type: "STRING", tableCode: "SB" },
        "hsbz_user_def_strg4"  : { canonical: "hSBz_User_Def_Strg4"  , type: "STRING", tableCode: "SB" },
    }
};

export default SB;
