/**
 * FW.js — table structure for the FW (Workbench Lines) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FW").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FW
 */

/** @type {Object} */
const FW = {
    code: "FW",
    name: "Workbench_Lines",
    recordLength: null,
    helpRegistry: "hFW.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FWi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hfwc_deleted"         : { canonical: "hFWc_Deleted"         , type: "STRING", tableCode: "FW" },
        "hfwc_insurance"       : { canonical: "hFWc_Insurance"       , type: "STRING", tableCode: "FW" },
        "hfwc_tfn_provided"    : { canonical: "hFWc_TFN_Provided"    , type: "STRING", tableCode: "FW" },
        "hfwc_transfer_balance": { canonical: "hFWc_Transfer_Balance", type: "STRING", tableCode: "FW" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfwd_birth"           : { canonical: "hFWd_Birth"           , type: "DATE", tableCode: "FW" },
        "hfwd_cessation"       : { canonical: "hFWd_Cessation"       , type: "DATE", tableCode: "FW" },
        "hfwd_commencement"    : { canonical: "hFWd_Commencement"    , type: "DATE", tableCode: "FW" },
        "hfwd_conts_sal_end"   : { canonical: "hFWd_Conts_Sal_End"   , type: "DATE", tableCode: "FW" },
        "hfwd_conts_sal_start" : { canonical: "hFWd_Conts_Sal_Start" , type: "DATE", tableCode: "FW" },
        "hfwd_employment_end"  : { canonical: "hFWd_Employment_End"  , type: "DATE", tableCode: "FW" },
        "hfwd_employment_start": { canonical: "hFWd_Employment_Start", type: "DATE", tableCode: "FW" },
        "hfwd_mod_date"        : { canonical: "hFWd_Mod_Date"        , type: "DATE", tableCode: "FW" },
        "hfwd_period_end"      : { canonical: "hFWd_Period_End"      , type: "DATE", tableCode: "FW" },
        "hfwd_period_start"    : { canonical: "hFWd_Period_Start"    , type: "DATE", tableCode: "FW" },
        "hfwd_registration"    : { canonical: "hFWd_Registration"    , type: "DATE", tableCode: "FW" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hfwf_benefit_salary"  : { canonical: "hFWf_Benefit_Salary"  , type: "DOUBLE", tableCode: "FW" },
        "hfwf_conts_salary"    : { canonical: "hFWf_Conts_Salary"    , type: "DOUBLE", tableCode: "FW" },
        "hfwf_hours_worked"    : { canonical: "hFWf_Hours_Worked"    , type: "DOUBLE", tableCode: "FW" },
        "hfwf_insurance_salary": { canonical: "hFWf_Insurance_Salary", type: "DOUBLE", tableCode: "FW" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hfwl_file_reg_ref"    : { canonical: "hFWl_File_Reg_Ref"    , type: "INTEGER", tableCode: "FW" },
        "hfwl_line_no"         : { canonical: "hFWl_Line_No"         , type: "INTEGER", tableCode: "FW" },
        "hfwl_line_type"       : { canonical: "hFWl_Line_Type"       , type: "INTEGER", tableCode: "FW" },
        "hfwl_message_code"    : { canonical: "hFWl_Message_Code"    , type: "INTEGER", tableCode: "FW" },
        "hfwl_ms_record_no"    : { canonical: "hFWl_MS_Record_No"    , type: "INTEGER", tableCode: "FW" },
        "hfwl_trans_ref"       : { canonical: "hFWl_Trans_Ref"       , type: "INTEGER", tableCode: "FW" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfwt_mod_time"        : { canonical: "hFWt_Mod_Time"        , type: "TIME", tableCode: "FW" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfwz_aust_business_no": { canonical: "hFWz_Aust_Business_No", type: "STRING", tableCode: "FW" },
        "hfwz_client"          : { canonical: "hFWz_Client"          , type: "STRING", tableCode: "FW" },
        "hfwz_division"        : { canonical: "hFWz_Division"        , type: "STRING", tableCode: "FW" },
        "hfwz_email"           : { canonical: "hFWz_Email"           , type: "STRING", tableCode: "FW" },
        "hfwz_fund"            : { canonical: "hFWz_Fund"            , type: "STRING", tableCode: "FW" },
        "hfwz_given_names"     : { canonical: "hFWz_Given_Names"     , type: "STRING", tableCode: "FW" },
        "hfwz_matching_abn"    : { canonical: "hFWz_Matching_ABN"    , type: "STRING", tableCode: "FW" },
        "hfwz_matching_prodid" : { canonical: "hFWz_Matching_ProdID" , type: "STRING", tableCode: "FW" },
        "hfwz_member"          : { canonical: "hFWz_Member"          , type: "STRING", tableCode: "FW" },
        "hfwz_memberid"        : { canonical: "hFWz_MemberID"        , type: "STRING", tableCode: "FW" },
        "hfwz_mobile_phone"    : { canonical: "hFWz_Mobile_Phone"    , type: "STRING", tableCode: "FW" },
        "hfwz_mod_user"        : { canonical: "hFWz_Mod_User"        , type: "STRING", tableCode: "FW" },
        "hfwz_name_suffix"     : { canonical: "hFWz_Name_Suffix"     , type: "STRING", tableCode: "FW" },
        "hfwz_payroll"         : { canonical: "hFWz_Payroll"         , type: "STRING", tableCode: "FW" },
        "hfwz_payroll_name"    : { canonical: "hFWz_Payroll_Name"    , type: "STRING", tableCode: "FW" },
        "hfwz_payroll_no"      : { canonical: "hFWz_Payroll_No"      , type: "STRING", tableCode: "FW" },
        "hfwz_phone"           : { canonical: "hFWz_Phone"           , type: "STRING", tableCode: "FW" },
        "hfwz_prodid"          : { canonical: "hFWz_ProdID"          , type: "STRING", tableCode: "FW" },
        "hfwz_record_type"     : { canonical: "hFWz_Record_Type"     , type: "STRING", tableCode: "FW" },
        "hfwz_reject_reason"   : { canonical: "hFWz_Reject_Reason"   , type: "STRING", tableCode: "FW" },
        "hfwz_sex"             : { canonical: "hFWz_Sex"             , type: "STRING", tableCode: "FW" },
        "hfwz_spare"           : { canonical: "hFWz_Spare"           , type: "STRING", tableCode: "FW" },
        "hfwz_status"          : { canonical: "hFWz_Status"          , type: "STRING", tableCode: "FW" },
        "hfwz_supplied_acc_ref": { canonical: "hFWz_Supplied_Acc_Ref", type: "STRING", tableCode: "FW" },
        "hfwz_surname"         : { canonical: "hFWz_Surname"         , type: "STRING", tableCode: "FW" },
        "hfwz_tax_file_no"     : { canonical: "hFWz_Tax_File_No"     , type: "STRING", tableCode: "FW" },
        "hfwz_title"           : { canonical: "hFWz_Title"           , type: "STRING", tableCode: "FW" },
        "hfwz_user_def_flags01": { canonical: "hFWz_User_Def_Flags01", type: "STRING", tableCode: "FW" },
        "hfwz_user_def_flags02": { canonical: "hFWz_User_Def_Flags02", type: "STRING", tableCode: "FW" },
        "hfwz_user_def_flags03": { canonical: "hFWz_User_Def_Flags03", type: "STRING", tableCode: "FW" },
        "hfwz_user_def_flags04": { canonical: "hFWz_User_Def_Flags04", type: "STRING", tableCode: "FW" },

        // ── (v-prefix) ──────────────────────────────────────────────────
        "hfwv_contextmemberid" : { canonical: "hFWv_ContextMemberID" , type: "VARSTRING", tableCode: "FW" },
        "hfwv_empcontextid"    : { canonical: "hFWv_EmpContextID"    , type: "VARSTRING", tableCode: "FW" },
        "hfwv_membercontextid" : { canonical: "hFWv_MemberContextID" , type: "VARSTRING", tableCode: "FW" },
    }
};

export default FW;
