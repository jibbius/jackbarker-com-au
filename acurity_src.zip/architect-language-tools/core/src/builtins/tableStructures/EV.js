/**
 * EV.js — table structure for the EV (Event Definitions) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "EV").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force EV
 */

/** @type {Object} */
const EV = {
    code: "EV",
    name: "Event_Definitions",
    recordLength: null,
    helpRegistry: "hEV.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "EVi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hevc_deleted"    : { canonical: "hEVc_Deleted"    , type: "STRING", tableCode: "EV" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hevd_mod_date"   : { canonical: "hEVd_Mod_Date"   , type: "DATE", tableCode: "EV" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hevt_mod_time"   : { canonical: "hEVt_Mod_Time"   , type: "TIME", tableCode: "EV" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hevz_action"     : { canonical: "hEVz_Action"     , type: "STRING", tableCode: "EV" },
        "hevz_eventcode"  : { canonical: "hEVz_EventCode"  , type: "STRING", tableCode: "EV" },
        "hevz_mod_user"   : { canonical: "hEVz_Mod_User"   , type: "STRING", tableCode: "EV" },
        "hevz_process"    : { canonical: "hEVz_Process"    , type: "STRING", tableCode: "EV" },
        "hevz_spare"      : { canonical: "hEVz_Spare"      , type: "STRING", tableCode: "EV" },
        "hevz_table"      : { canonical: "hEVz_Table"      , type: "STRING", tableCode: "EV" },
        "hevz_transaction": { canonical: "hEVz_Transaction", type: "STRING", tableCode: "EV" },
    }
};

export default EV;
