/**
 * SG.js — table structure for the SG (Fund Supplementary Labels 2) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SG").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SG
 */

/** @type {Object} */
const SG = {
    code: "SG",
    name: "Fund_Supplementary_Labels_2",
    recordLength: null,
    helpRegistry: "hSG.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SGi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hsgc_label_type"     : { canonical: "hSGc_Label_Type"     , type: "STRING", tableCode: "SG" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hsgd_mod_date"       : { canonical: "hSGd_Mod_Date"       , type: "DATE", tableCode: "SG" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hsgt_mod_time"       : { canonical: "hSGt_Mod_Time"       , type: "TIME", tableCode: "SG" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hsgz_fund"           : { canonical: "hSGz_Fund"           , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld01" : { canonical: "hSGz_Misc_Rvw_Fld01" , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld02" : { canonical: "hSGz_Misc_Rvw_Fld02" , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld03" : { canonical: "hSGz_Misc_Rvw_Fld03" , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld04" : { canonical: "hSGz_Misc_Rvw_Fld04" , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld05" : { canonical: "hSGz_Misc_Rvw_Fld05" , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld06" : { canonical: "hSGz_Misc_Rvw_Fld06" , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld07" : { canonical: "hSGz_Misc_Rvw_Fld07" , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld08" : { canonical: "hSGz_Misc_Rvw_Fld08" , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld09" : { canonical: "hSGz_Misc_Rvw_Fld09" , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld10" : { canonical: "hSGz_Misc_Rvw_Fld10" , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld11" : { canonical: "hSGz_Misc_Rvw_Fld11" , type: "STRING", tableCode: "SG" },
        "hsgz_misc_rvw_fld12" : { canonical: "hSGz_Misc_Rvw_Fld12" , type: "STRING", tableCode: "SG" },
        "hsgz_mod_user"       : { canonical: "hSGz_Mod_User"       , type: "STRING", tableCode: "SG" },
        "hsgz_payroll"        : { canonical: "hSGz_Payroll"        , type: "STRING", tableCode: "SG" },
        "hsgz_record_type"    : { canonical: "hSGz_Record_Type"    , type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name01": { canonical: "hSGz_Supp_Fld_Name01", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name02": { canonical: "hSGz_Supp_Fld_Name02", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name03": { canonical: "hSGz_Supp_Fld_Name03", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name04": { canonical: "hSGz_Supp_Fld_Name04", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name05": { canonical: "hSGz_Supp_Fld_Name05", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name06": { canonical: "hSGz_Supp_Fld_Name06", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name07": { canonical: "hSGz_Supp_Fld_Name07", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name08": { canonical: "hSGz_Supp_Fld_Name08", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name09": { canonical: "hSGz_Supp_Fld_Name09", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name10": { canonical: "hSGz_Supp_Fld_Name10", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name11": { canonical: "hSGz_Supp_Fld_Name11", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name12": { canonical: "hSGz_Supp_Fld_Name12", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name13": { canonical: "hSGz_Supp_Fld_Name13", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name14": { canonical: "hSGz_Supp_Fld_Name14", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name15": { canonical: "hSGz_Supp_Fld_Name15", type: "STRING", tableCode: "SG" },
        "hsgz_supp_fld_name16": { canonical: "hSGz_Supp_Fld_Name16", type: "STRING", tableCode: "SG" },
    }
};

export default SG;
