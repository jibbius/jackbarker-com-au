/**
 * NX.js — table structure for the NX (Notes) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "NX").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force NX
 */

/** @type {Object} */
const NX = {
    code: "NX",
    name: "Notes",
    recordLength: null,
    helpRegistry: "hNX.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "NXi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hnxz_description": { canonical: "hNXz_Description", type: "STRING", tableCode: "NX" },
        "hnxz_element"    : { canonical: "hNXz_Element"    , type: "STRING", tableCode: "NX" },
        "hnxz_line_no"    : { canonical: "hNXz_Line_No"    , type: "STRING", tableCode: "NX" },
        "hnxz_spare"      : { canonical: "hNXz_Spare"      , type: "STRING", tableCode: "NX" },
        "hnxz_type"       : { canonical: "hNXz_Type"       , type: "STRING", tableCode: "NX" },
    }
};

export default NX;
