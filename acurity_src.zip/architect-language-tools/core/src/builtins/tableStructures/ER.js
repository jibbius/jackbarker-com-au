/**
 * ER.js — table structure for the ER (Results (Error) Messages) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "ER").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force ER
 */

/** @type {Object} */
const ER = {
    code: "ER",
    name: "Results_(Error)_Messages",
    recordLength: null,
    helpRegistry: "hER.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ERi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "herc_basestype"      : { canonical: "hERc_BasesType"      , type: "STRING", tableCode: "ER" },
        "herc_division"       : { canonical: "hERc_Division"       , type: "STRING", tableCode: "ER" },
        "herc_error_type"     : { canonical: "hERc_Error_Type"     , type: "STRING", tableCode: "ER" },
        "herc_process_type"   : { canonical: "hERc_Process_Type"   , type: "STRING", tableCode: "ER" },
        "herc_record_type"    : { canonical: "hERc_Record_Type"    , type: "STRING", tableCode: "ER" },
        "herc_suppressrprtout": { canonical: "hERc_SuppressRprtOut", type: "STRING", tableCode: "ER" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "herd_cleared"        : { canonical: "hERd_Cleared"        , type: "DATE", tableCode: "ER" },
        "herd_mod_date"       : { canonical: "hERd_Mod_Date"       , type: "DATE", tableCode: "ER" },
        "herd_raised"         : { canonical: "hERd_Raised"         , type: "DATE", tableCode: "ER" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "herl_batch_ref"      : { canonical: "hERl_Batch_Ref"      , type: "INTEGER", tableCode: "ER" },
        "herl_clob_id"        : { canonical: "hERl_CLOB_ID"        , type: "INTEGER", tableCode: "ER" },
        "herl_counter"        : { canonical: "hERl_Counter"        , type: "INTEGER", tableCode: "ER" },
        "herl_errno"          : { canonical: "hERl_Errno"          , type: "INTEGER", tableCode: "ER" },
        "herl_error_code"     : { canonical: "hERl_Error_Code"     , type: "INTEGER", tableCode: "ER" },
        "herl_file_reg_ref"   : { canonical: "hERl_File_Reg_Ref"   , type: "INTEGER", tableCode: "ER" },
        "herl_interface_id"   : { canonical: "hERl_Interface_ID"   , type: "INTEGER", tableCode: "ER" },
        "herl_job_ref"        : { canonical: "hERl_Job_Ref"        , type: "INTEGER", tableCode: "ER" },
        "herl_line_number"    : { canonical: "hERl_Line_Number"    , type: "INTEGER", tableCode: "ER" },
        "herl_ms_record_no"   : { canonical: "hERl_MS_Record_No"   , type: "INTEGER", tableCode: "ER" },
        "herl_record_id"      : { canonical: "hERl_Record_Id"      , type: "INTEGER", tableCode: "ER" },
        "herl_source_line"    : { canonical: "hERl_Source_Line"    , type: "INTEGER", tableCode: "ER" },
        "herl_trans_ref"      : { canonical: "hERl_Trans_Ref"      , type: "INTEGER", tableCode: "ER" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hers_accounting_step": { canonical: "hERs_Accounting_Step", type: "INTEGER", tableCode: "ER" },
        "hers_field_number"   : { canonical: "hERs_Field_Number"   , type: "INTEGER", tableCode: "ER" },
        "hers_line_sequence"  : { canonical: "hERs_Line_Sequence"  , type: "INTEGER", tableCode: "ER" },
        "hers_sequence"       : { canonical: "hERs_Sequence"       , type: "INTEGER", tableCode: "ER" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hert_mod_time"       : { canonical: "hERt_Mod_Time"       , type: "TIME", tableCode: "ER" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "herz_category"       : { canonical: "hERz_Category"       , type: "STRING", tableCode: "ER" },
        "herz_excp_msgid"     : { canonical: "hERz_Excp_MsgID"     , type: "STRING", tableCode: "ER" },
        "herz_fund"           : { canonical: "hERz_Fund"           , type: "STRING", tableCode: "ER" },
        "herz_invmgr"         : { canonical: "hERz_Invmgr"         , type: "STRING", tableCode: "ER" },
        "herz_member"         : { canonical: "hERz_Member"         , type: "STRING", tableCode: "ER" },
        "herz_message"        : { canonical: "hERz_Message"        , type: "STRING", tableCode: "ER" },
        "herz_mod_user"       : { canonical: "hERz_Mod_User"       , type: "STRING", tableCode: "ER" },
        "herz_payroll"        : { canonical: "hERz_Payroll"        , type: "STRING", tableCode: "ER" },
        "herz_report_id"      : { canonical: "hERz_Report_ID"      , type: "STRING", tableCode: "ER" },
        "herz_source_file"    : { canonical: "hERz_Source_File"    , type: "STRING", tableCode: "ER" },
        "herz_spare"          : { canonical: "hERz_Spare"          , type: "STRING", tableCode: "ER" },

        // ── (v-prefix) ──────────────────────────────────────────────────
        "herv_message"        : { canonical: "hERv_Message"        , type: "VARSTRING", tableCode: "ER" },
    }
};

export default ER;
