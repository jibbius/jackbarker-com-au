/**
 * FP.js — table structure for the FP (Fee Parameters) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FP").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FP
 */

/** @type {Object} */
const FP = {
    code: "FP",
    name: "Fee_Parameters",
    recordLength: null,
    helpRegistry: "hFP.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FPi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfpd_effective"  : { canonical: "hFPd_Effective"  , type: "DATE", tableCode: "FP" },
        "hfpd_mod_date"   : { canonical: "hFPd_Mod_Date"   , type: "DATE", tableCode: "FP" },
        "hfpd_spare"      : { canonical: "hFPd_Spare"      , type: "DATE", tableCode: "FP" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hfpf_amounts01"  : { canonical: "hFPf_Amounts01"  , type: "DOUBLE", tableCode: "FP" },
        "hfpf_amounts02"  : { canonical: "hFPf_Amounts02"  , type: "DOUBLE", tableCode: "FP" },
        "hfpf_amounts03"  : { canonical: "hFPf_Amounts03"  , type: "DOUBLE", tableCode: "FP" },
        "hfpf_amounts04"  : { canonical: "hFPf_Amounts04"  , type: "DOUBLE", tableCode: "FP" },
        "hfpf_amounts05"  : { canonical: "hFPf_Amounts05"  , type: "DOUBLE", tableCode: "FP" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfpt_mod_time"   : { canonical: "hFPt_Mod_Time"   , type: "TIME", tableCode: "FP" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfpz_adviser"    : { canonical: "hFPz_Adviser"    , type: "STRING", tableCode: "FP" },
        "hfpz_deleted"    : { canonical: "hFPz_Deleted"    , type: "STRING", tableCode: "FP" },
        "hfpz_division"   : { canonical: "hFPz_Division"   , type: "STRING", tableCode: "FP" },
        "hfpz_fee_code"   : { canonical: "hFPz_Fee_Code"   , type: "STRING", tableCode: "FP" },
        "hfpz_fee_group"  : { canonical: "hFPz_Fee_Group"  , type: "STRING", tableCode: "FP" },
        "hfpz_fund"       : { canonical: "hFPz_Fund"       , type: "STRING", tableCode: "FP" },
        "hfpz_inv_mgr"    : { canonical: "hFPz_Inv_Mgr"    , type: "STRING", tableCode: "FP" },
        "hfpz_mod_user"   : { canonical: "hFPz_Mod_User"   , type: "STRING", tableCode: "FP" },
        "hfpz_record_type": { canonical: "hFPz_Record_Type", type: "STRING", tableCode: "FP" },
        "hfpz_spare"      : { canonical: "hFPz_Spare"      , type: "STRING", tableCode: "FP" },
        "hfpz_table_code" : { canonical: "hFPz_Table_Code" , type: "STRING", tableCode: "FP" },
    }
};

export default FP;
