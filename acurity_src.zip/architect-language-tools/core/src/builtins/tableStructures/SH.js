/**
 * SH.js — table structure for the SH (Share Certificate - Redemption History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SH
 */

/** @type {Object} */
const SH = {
    code: "SH",
    name: "Share_Certificate_-_Redemption_History",
    recordLength: null,
    helpRegistry: "hSH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hshc_capital_expense" : { canonical: "hSHc_Capital_Expense" , type: "STRING", tableCode: "SH" },
        "hshc_cgt_calculated"  : { canonical: "hSHc_CGT_Calculated"  , type: "STRING", tableCode: "SH" },
        "hshc_excl_cgt_history": { canonical: "hSHc_Excl_CGT_History", type: "STRING", tableCode: "SH" },
        "hshc_reset"           : { canonical: "hSHc_Reset"           , type: "STRING", tableCode: "SH" },
        "hshc_spare"           : { canonical: "hSHc_Spare"           , type: "STRING", tableCode: "SH" },
        "hshc_tran_40"         : { canonical: "hSHc_Tran_40"         , type: "STRING", tableCode: "SH" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hshd_effective"       : { canonical: "hSHd_Effective"       , type: "DATE", tableCode: "SH" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hshf_accrued_cg"      : { canonical: "hSHf_Accrued_CG"      , type: "DOUBLE", tableCode: "SH" },
        "hshf_amt_redeemed"    : { canonical: "hSHf_Amt_Redeemed"    , type: "DOUBLE", tableCode: "SH" },
        "hshf_cap_base_reduct" : { canonical: "hSHf_Cap_Base_Reduct" , type: "DOUBLE", tableCode: "SH" },
        "hshf_cgt"             : { canonical: "hSHf_CGT"             , type: "DOUBLE", tableCode: "SH" },
        "hshf_exit_fee"        : { canonical: "hSHf_Exit_Fee"        , type: "DOUBLE", tableCode: "SH" },
        "hshf_expenses"        : { canonical: "hSHf_Expenses"        , type: "DOUBLE", tableCode: "SH" },
        "hshf_return_of_cap"   : { canonical: "hSHf_Return_of_Cap"   , type: "DOUBLE", tableCode: "SH" },
        "hshf_revaluation_ytd" : { canonical: "hSHf_Revaluation_YTD" , type: "DOUBLE", tableCode: "SH" },
        "hshf_tax_free_income" : { canonical: "hSHf_Tax_Free_Income" , type: "DOUBLE", tableCode: "SH" },
        "hshf_total_redeemed"  : { canonical: "hSHf_Total_Redeemed"  , type: "DOUBLE", tableCode: "SH" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hshl_cgt_trans_ref"   : { canonical: "hSHl_CGT_Trans_Ref"   , type: "INTEGER", tableCode: "SH" },
        "hshl_orig_tref"       : { canonical: "hSHl_Orig_Tref"       , type: "INTEGER", tableCode: "SH" },
        "hshl_shr_cert_no_sys" : { canonical: "hSHl_Shr_Cert_No_Sys" , type: "INTEGER", tableCode: "SH" },
        "hshl_spare"           : { canonical: "hSHl_Spare"           , type: "INTEGER", tableCode: "SH" },
        "hshl_trans_ref"       : { canonical: "hSHl_Trans_Ref"       , type: "INTEGER", tableCode: "SH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hshz_division"        : { canonical: "hSHz_Division"        , type: "STRING", tableCode: "SH" },
    }
};

export default SH;
