/**
 * BE.js — table structure for the BE (Bank Accounts) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BE").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BE
 */

/** @type {Object} */
const BE = {
    code: "BE",
    name: "Bank_Accounts",
    recordLength: null,
    helpRegistry: "hBE.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BEi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hbec_deleted"         : { canonical: "hBEc_Deleted"         , type: "STRING", tableCode: "BE" },
        "hbec_direct_debit"    : { canonical: "hBEc_Direct_Debit"    , type: "STRING", tableCode: "BE" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hbed_mod_date"        : { canonical: "hBEd_Mod_Date"        , type: "DATE", tableCode: "BE" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hbet_mod_time"        : { canonical: "hBEt_Mod_Time"        , type: "TIME", tableCode: "BE" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hbez_bank_account"    : { canonical: "hBEz_Bank_Account"    , type: "STRING", tableCode: "BE" },
        "hbez_bank_acct_name"  : { canonical: "hBEz_Bank_Acct_Name"  , type: "STRING", tableCode: "BE" },
        "hbez_bank_acct_no"    : { canonical: "hBEz_Bank_Acct_No"    , type: "STRING", tableCode: "BE" },
        "hbez_bsb"             : { canonical: "hBEz_BSB"             , type: "STRING", tableCode: "BE" },
        "hbez_client"          : { canonical: "hBEz_Client"          , type: "STRING", tableCode: "BE" },
        "hbez_fund"            : { canonical: "hBEz_Fund"            , type: "STRING", tableCode: "BE" },
        "hbez_itl_bank_acct_no": { canonical: "hBEz_Itl_Bank_Acct_No", type: "STRING", tableCode: "BE" },
        "hbez_member"          : { canonical: "hBEz_Member"          , type: "STRING", tableCode: "BE" },
        "hbez_mod_user"        : { canonical: "hBEz_Mod_User"        , type: "STRING", tableCode: "BE" },
        "hbez_payroll"         : { canonical: "hBEz_Payroll"         , type: "STRING", tableCode: "BE" },
        "hbez_record_type"     : { canonical: "hBEz_Record_Type"     , type: "STRING", tableCode: "BE" },
        "hbez_spare"           : { canonical: "hBEz_Spare"           , type: "STRING", tableCode: "BE" },
    }
};

export default BE;
