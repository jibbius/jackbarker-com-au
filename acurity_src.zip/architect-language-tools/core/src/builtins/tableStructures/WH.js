/**
 * WH.js — table structure for the WH (Working Hours History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "WH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force WH
 */

/** @type {Object} */
const WH = {
    code: "WH",
    name: "Working_Hours_History",
    recordLength: null,
    helpRegistry: "hWH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "WHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hwhc_deleted"         : { canonical: "hWHc_Deleted"         , type: "STRING", tableCode: "WH" },
        "hwhc_emp_rate"        : { canonical: "hWHc_Emp_Rate"        , type: "STRING", tableCode: "WH" },
        "hwhc_fund_choice"     : { canonical: "hWHc_Fund_Choice"     , type: "STRING", tableCode: "WH" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hwhd_actual_update"   : { canonical: "hWHd_Actual_Update"   , type: "DATE", tableCode: "WH" },
        "hwhd_effective"       : { canonical: "hWHd_Effective"       , type: "DATE", tableCode: "WH" },
        "hwhd_last_update"     : { canonical: "hWHd_Last_Update"     , type: "DATE", tableCode: "WH" },
        "hwhd_mod_date"        : { canonical: "hWHd_Mod_Date"        , type: "DATE", tableCode: "WH" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hwhf_base_time_hrs"   : { canonical: "hWHf_Base_Time_Hrs"   , type: "DOUBLE", tableCode: "WH" },
        "hwhf_full_time_hrs"   : { canonical: "hWHf_Full_Time_Hrs"   , type: "DOUBLE", tableCode: "WH" },
        "hwhf_hours_worked"    : { canonical: "hWHf_Hours_Worked"    , type: "DOUBLE", tableCode: "WH" },
        "hwhf_last_base_time"  : { canonical: "hWHf_Last_Base_Time"  , type: "DOUBLE", tableCode: "WH" },
        "hwhf_last_full_time"  : { canonical: "hWHf_Last_Full_Time"  , type: "DOUBLE", tableCode: "WH" },
        "hwhf_part_time_ratio" : { canonical: "hWHf_Part_Time_Ratio" , type: "DOUBLE", tableCode: "WH" },
        "hwhf_pef_factor"      : { canonical: "hWHf_PEF_Factor"      , type: "DOUBLE", tableCode: "WH" },
        "hwhf_service_ratio"   : { canonical: "hWHf_Service_Ratio"   , type: "DOUBLE", tableCode: "WH" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hwhl_trans_ref"       : { canonical: "hWHl_Trans_Ref"       , type: "INTEGER", tableCode: "WH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hwht_mod_time"        : { canonical: "hWHt_Mod_Time"        , type: "TIME", tableCode: "WH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hwhz_cont_type"       : { canonical: "hWHz_Cont_Type"       , type: "STRING", tableCode: "WH" },
        "hwhz_current_payroll" : { canonical: "hWHz_Current_Payroll" , type: "STRING", tableCode: "WH" },
        "hwhz_division"        : { canonical: "hWHz_Division"        , type: "STRING", tableCode: "WH" },
        "hwhz_eligibility_code": { canonical: "hWHz_Eligibility_Code", type: "STRING", tableCode: "WH" },
        "hwhz_fund"            : { canonical: "hWHz_Fund"            , type: "STRING", tableCode: "WH" },
        "hwhz_half_conts"      : { canonical: "hWHz_Half_Conts"      , type: "STRING", tableCode: "WH" },
        "hwhz_member"          : { canonical: "hWHz_Member"          , type: "STRING", tableCode: "WH" },
        "hwhz_mod_user"        : { canonical: "hWHz_Mod_User"        , type: "STRING", tableCode: "WH" },
        "hwhz_payroll"         : { canonical: "hWHz_Payroll"         , type: "STRING", tableCode: "WH" },
        "hwhz_reason_code"     : { canonical: "hWHz_Reason_Code"     , type: "STRING", tableCode: "WH" },
        "hwhz_record_type"     : { canonical: "hWHz_Record_Type"     , type: "STRING", tableCode: "WH" },
        "hwhz_spare"           : { canonical: "hWHz_Spare"           , type: "STRING", tableCode: "WH" },
        "hwhz_status"          : { canonical: "hWHz_Status"          , type: "STRING", tableCode: "WH" },
    }
};

export default WH;
