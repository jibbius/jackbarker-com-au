/**
 * BB.js — table structure for the BB (BSB Codes) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BB").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BB
 */

/** @type {Object} */
const BB = {
    code: "BB",
    name: "BSB_Codes",
    recordLength: null,
    helpRegistry: "hBB.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BBi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hbbc_payment_type_e": { canonical: "hBBc_Payment_Type_E", type: "STRING", tableCode: "BB" },
        "hbbc_payment_type_h": { canonical: "hBBc_Payment_Type_H", type: "STRING", tableCode: "BB" },
        "hbbc_payment_type_p": { canonical: "hBBc_Payment_Type_P", type: "STRING", tableCode: "BB" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hbbz_bank"          : { canonical: "hBBz_Bank"          , type: "STRING", tableCode: "BB" },
        "hbbz_bank_name"     : { canonical: "hBBz_Bank_Name"     , type: "STRING", tableCode: "BB" },
        "hbbz_bsb"           : { canonical: "hBBz_BSB"           , type: "STRING", tableCode: "BB" },
        "hbbz_postcode"      : { canonical: "hBBz_Postcode"      , type: "STRING", tableCode: "BB" },
        "hbbz_spare"         : { canonical: "hBBz_Spare"         , type: "STRING", tableCode: "BB" },
        "hbbz_state"         : { canonical: "hBBz_State"         , type: "STRING", tableCode: "BB" },
        "hbbz_street_address": { canonical: "hBBz_Street_Address", type: "STRING", tableCode: "BB" },
        "hbbz_suburb"        : { canonical: "hBBz_Suburb"        , type: "STRING", tableCode: "BB" },
    }
};

export default BB;
