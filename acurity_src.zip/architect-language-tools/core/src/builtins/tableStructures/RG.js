/**
 * RG.js — table structure for the RG (Correspondence Register) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "RG").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force RG
 */

/** @type {Object} */
const RG = {
    code: "RG",
    name: "Correspondence_Register",
    recordLength: null,
    helpRegistry: "hRG.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "RGi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hrgc_deleted_contact" : { canonical: "hRGc_Deleted_Contact" , type: "STRING", tableCode: "RG" },
        "hrgc_online"          : { canonical: "hRGc_Online"          , type: "STRING", tableCode: "RG" },
        "hrgc_url_template"    : { canonical: "hRGc_Url_Template"    , type: "STRING", tableCode: "RG" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hrgd_action01"        : { canonical: "hRGd_Action01"        , type: "DATE", tableCode: "RG" },
        "hrgd_action02"        : { canonical: "hRGd_Action02"        , type: "DATE", tableCode: "RG" },
        "hrgd_action03"        : { canonical: "hRGd_Action03"        , type: "DATE", tableCode: "RG" },
        "hrgd_action04"        : { canonical: "hRGd_Action04"        , type: "DATE", tableCode: "RG" },
        "hrgd_action05"        : { canonical: "hRGd_Action05"        , type: "DATE", tableCode: "RG" },
        "hrgd_action06"        : { canonical: "hRGd_Action06"        , type: "DATE", tableCode: "RG" },
        "hrgd_action07"        : { canonical: "hRGd_Action07"        , type: "DATE", tableCode: "RG" },
        "hrgd_action08"        : { canonical: "hRGd_Action08"        , type: "DATE", tableCode: "RG" },
        "hrgd_action09"        : { canonical: "hRGd_Action09"        , type: "DATE", tableCode: "RG" },
        "hrgd_action10"        : { canonical: "hRGd_Action10"        , type: "DATE", tableCode: "RG" },
        "hrgd_closed"          : { canonical: "hRGd_Closed"          , type: "DATE", tableCode: "RG" },
        "hrgd_correspondence"  : { canonical: "hRGd_Correspondence"  , type: "DATE", tableCode: "RG" },
        "hrgd_created"         : { canonical: "hRGd_Created"         , type: "DATE", tableCode: "RG" },
        "hrgd_mod_date"        : { canonical: "hRGd_Mod_Date"        , type: "DATE", tableCode: "RG" },
        "hrgd_opened"          : { canonical: "hRGd_Opened"          , type: "DATE", tableCode: "RG" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hrgf_spare"           : { canonical: "hRGf_Spare"           , type: "DOUBLE", tableCode: "RG" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hrgl_corresondence_no": { canonical: "hRGl_Corresondence_No", type: "INTEGER", tableCode: "RG" },
        "hrgl_spare"           : { canonical: "hRGl_Spare"           , type: "INTEGER", tableCode: "RG" },
        "hrgl_task_no"         : { canonical: "hRGl_Task_No"         , type: "INTEGER", tableCode: "RG" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hrgs_action_days01"   : { canonical: "hRGs_Action_Days01"   , type: "INTEGER", tableCode: "RG" },
        "hrgs_action_days02"   : { canonical: "hRGs_Action_Days02"   , type: "INTEGER", tableCode: "RG" },
        "hrgs_action_days03"   : { canonical: "hRGs_Action_Days03"   , type: "INTEGER", tableCode: "RG" },
        "hrgs_action_days04"   : { canonical: "hRGs_Action_Days04"   , type: "INTEGER", tableCode: "RG" },
        "hrgs_action_days05"   : { canonical: "hRGs_Action_Days05"   , type: "INTEGER", tableCode: "RG" },
        "hrgs_action_days06"   : { canonical: "hRGs_Action_Days06"   , type: "INTEGER", tableCode: "RG" },
        "hrgs_action_days07"   : { canonical: "hRGs_Action_Days07"   , type: "INTEGER", tableCode: "RG" },
        "hrgs_action_days08"   : { canonical: "hRGs_Action_Days08"   , type: "INTEGER", tableCode: "RG" },
        "hrgs_action_days09"   : { canonical: "hRGs_Action_Days09"   , type: "INTEGER", tableCode: "RG" },
        "hrgs_action_days10"   : { canonical: "hRGs_Action_Days10"   , type: "INTEGER", tableCode: "RG" },
        "hrgs_spare01"         : { canonical: "hRGs_Spare01"         , type: "INTEGER", tableCode: "RG" },
        "hrgs_spare02"         : { canonical: "hRGs_Spare02"         , type: "INTEGER", tableCode: "RG" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hrgt_mod_time"        : { canonical: "hRGt_Mod_Time"        , type: "TIME", tableCode: "RG" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hrgz_action_desc01"   : { canonical: "hRGz_Action_Desc01"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_desc02"   : { canonical: "hRGz_Action_Desc02"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_desc03"   : { canonical: "hRGz_Action_Desc03"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_desc04"   : { canonical: "hRGz_Action_Desc04"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_desc05"   : { canonical: "hRGz_Action_Desc05"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_desc06"   : { canonical: "hRGz_Action_Desc06"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_desc07"   : { canonical: "hRGz_Action_Desc07"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_desc08"   : { canonical: "hRGz_Action_Desc08"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_desc09"   : { canonical: "hRGz_Action_Desc09"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_desc10"   : { canonical: "hRGz_Action_Desc10"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_user01"   : { canonical: "hRGz_Action_User01"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_user02"   : { canonical: "hRGz_Action_User02"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_user03"   : { canonical: "hRGz_Action_User03"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_user04"   : { canonical: "hRGz_Action_User04"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_user05"   : { canonical: "hRGz_Action_User05"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_user06"   : { canonical: "hRGz_Action_User06"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_user07"   : { canonical: "hRGz_Action_User07"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_user08"   : { canonical: "hRGz_Action_User08"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_user09"   : { canonical: "hRGz_Action_User09"   , type: "STRING", tableCode: "RG" },
        "hrgz_action_user10"   : { canonical: "hRGz_Action_User10"   , type: "STRING", tableCode: "RG" },
        "hrgz_created"         : { canonical: "hRGz_Created"         , type: "STRING", tableCode: "RG" },
        "hrgz_division"        : { canonical: "hRGz_Division"        , type: "STRING", tableCode: "RG" },
        "hrgz_fund"            : { canonical: "hRGz_Fund"            , type: "STRING", tableCode: "RG" },
        "hrgz_member"          : { canonical: "hRGz_Member"          , type: "STRING", tableCode: "RG" },
        "hrgz_mod_user"        : { canonical: "hRGz_Mod_User"        , type: "STRING", tableCode: "RG" },
        "hrgz_payroll"         : { canonical: "hRGz_Payroll"         , type: "STRING", tableCode: "RG" },
        "hrgz_payroll_records" : { canonical: "hRGz_Payroll_Records" , type: "STRING", tableCode: "RG" },
        "hrgz_record_type"     : { canonical: "hRGz_Record_Type"     , type: "STRING", tableCode: "RG" },
        "hrgz_status"          : { canonical: "hRGz_Status"          , type: "STRING", tableCode: "RG" },
        "hrgz_task_type"       : { canonical: "hRGz_Task_Type"       , type: "STRING", tableCode: "RG" },
        "hrgz_type"            : { canonical: "hRGz_Type"            , type: "STRING", tableCode: "RG" },
        "hrgz_url_general01"   : { canonical: "hRGz_Url_General01"   , type: "STRING", tableCode: "RG" },
        "hrgz_url_general02"   : { canonical: "hRGz_Url_General02"   , type: "STRING", tableCode: "RG" },
        "hrgz_url_general03"   : { canonical: "hRGz_Url_General03"   , type: "STRING", tableCode: "RG" },
        "hrgz_url_long"        : { canonical: "hRGz_Url_Long"        , type: "STRING", tableCode: "RG" },
    }
};

export default RG;
