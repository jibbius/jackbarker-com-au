/**
 * TT.js — table structure for the TT (Transaction Lines) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "TT").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force TT
 */

/** @type {Object} */
const TT = {
    code: "TT",
    name: "Transaction_Lines",
    recordLength: null,
    helpRegistry: "hTT.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "TTi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "httc_deleted"        : { canonical: "hTTc_Deleted"        , type: "STRING", tableCode: "TT" },
        "httc_flag_5"         : { canonical: "hTTc_Flag_5"         , type: "STRING", tableCode: "TT" },
        "httc_flag_6"         : { canonical: "hTTc_Flag_6"         , type: "STRING", tableCode: "TT" },
        "httc_flags01"        : { canonical: "hTTc_Flags01"        , type: "STRING", tableCode: "TT" },
        "httc_flags02"        : { canonical: "hTTc_Flags02"        , type: "STRING", tableCode: "TT" },
        "httc_flags03"        : { canonical: "hTTc_Flags03"        , type: "STRING", tableCode: "TT" },
        "httc_flags04"        : { canonical: "hTTc_Flags04"        , type: "STRING", tableCode: "TT" },
        "httc_flags05"        : { canonical: "hTTc_Flags05"        , type: "STRING", tableCode: "TT" },
        "httc_flags06"        : { canonical: "hTTc_Flags06"        , type: "STRING", tableCode: "TT" },
        "httc_flags07"        : { canonical: "hTTc_Flags07"        , type: "STRING", tableCode: "TT" },
        "httc_flags08"        : { canonical: "hTTc_Flags08"        , type: "STRING", tableCode: "TT" },
        "httc_flags09"        : { canonical: "hTTc_Flags09"        , type: "STRING", tableCode: "TT" },
        "httc_flags10"        : { canonical: "hTTc_Flags10"        , type: "STRING", tableCode: "TT" },
        "httc_flags11"        : { canonical: "hTTc_Flags11"        , type: "STRING", tableCode: "TT" },
        "httc_no_of_journals" : { canonical: "hTTc_No_Of_Journals" , type: "STRING", tableCode: "TT" },
        "httc_posted"         : { canonical: "hTTc_Posted"         , type: "STRING", tableCode: "TT" },
        "httc_record_no"      : { canonical: "hTTc_Record_No"      , type: "STRING", tableCode: "TT" },
        "httc_unit_price_meth": { canonical: "hTTc_Unit_Price_Meth", type: "STRING", tableCode: "TT" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "httd_fields01"       : { canonical: "hTTd_Fields01"       , type: "DATE", tableCode: "TT" },
        "httd_fields02"       : { canonical: "hTTd_Fields02"       , type: "DATE", tableCode: "TT" },
        "httd_fields03"       : { canonical: "hTTd_Fields03"       , type: "DATE", tableCode: "TT" },
        "httd_fields04"       : { canonical: "hTTd_Fields04"       , type: "DATE", tableCode: "TT" },
        "httd_fields05"       : { canonical: "hTTd_Fields05"       , type: "DATE", tableCode: "TT" },
        "httd_fields06"       : { canonical: "hTTd_Fields06"       , type: "DATE", tableCode: "TT" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "httf_amounts01"      : { canonical: "hTTf_Amounts01"      , type: "DOUBLE", tableCode: "TT" },
        "httf_amounts02"      : { canonical: "hTTf_Amounts02"      , type: "DOUBLE", tableCode: "TT" },
        "httf_amounts03"      : { canonical: "hTTf_Amounts03"      , type: "DOUBLE", tableCode: "TT" },
        "httf_amounts04"      : { canonical: "hTTf_Amounts04"      , type: "DOUBLE", tableCode: "TT" },
        "httf_amounts05"      : { canonical: "hTTf_Amounts05"      , type: "DOUBLE", tableCode: "TT" },
        "httf_amounts06"      : { canonical: "hTTf_Amounts06"      , type: "DOUBLE", tableCode: "TT" },
        "httf_amounts07"      : { canonical: "hTTf_Amounts07"      , type: "DOUBLE", tableCode: "TT" },
        "httf_amounts08"      : { canonical: "hTTf_Amounts08"      , type: "DOUBLE", tableCode: "TT" },
        "httf_amounts09"      : { canonical: "hTTf_Amounts09"      , type: "DOUBLE", tableCode: "TT" },
        "httf_amounts10"      : { canonical: "hTTf_Amounts10"      , type: "DOUBLE", tableCode: "TT" },
        "httf_amounts11"      : { canonical: "hTTf_Amounts11"      , type: "DOUBLE", tableCode: "TT" },
        "httf_amounts12"      : { canonical: "hTTf_Amounts12"      , type: "DOUBLE", tableCode: "TT" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "httl_fields01"       : { canonical: "hTTl_Fields01"       , type: "INTEGER", tableCode: "TT" },
        "httl_fields02"       : { canonical: "hTTl_Fields02"       , type: "INTEGER", tableCode: "TT" },
        "httl_fields03"       : { canonical: "hTTl_Fields03"       , type: "INTEGER", tableCode: "TT" },
        "httl_fields04"       : { canonical: "hTTl_Fields04"       , type: "INTEGER", tableCode: "TT" },
        "httl_fields05"       : { canonical: "hTTl_Fields05"       , type: "INTEGER", tableCode: "TT" },
        "httl_fields06"       : { canonical: "hTTl_Fields06"       , type: "INTEGER", tableCode: "TT" },
        "httl_trans_ref"      : { canonical: "hTTl_Trans_Ref"      , type: "INTEGER", tableCode: "TT" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "htts_fields01"       : { canonical: "hTTs_Fields01"       , type: "INTEGER", tableCode: "TT" },
        "htts_fields02"       : { canonical: "hTTs_Fields02"       , type: "INTEGER", tableCode: "TT" },
        "htts_fields03"       : { canonical: "hTTs_Fields03"       , type: "INTEGER", tableCode: "TT" },
        "htts_fields04"       : { canonical: "hTTs_Fields04"       , type: "INTEGER", tableCode: "TT" },
        "htts_fields05"       : { canonical: "hTTs_Fields05"       , type: "INTEGER", tableCode: "TT" },
        "htts_fields06"       : { canonical: "hTTs_Fields06"       , type: "INTEGER", tableCode: "TT" },
        "htts_fields07"       : { canonical: "hTTs_Fields07"       , type: "INTEGER", tableCode: "TT" },
        "htts_sequence_no"    : { canonical: "hTTs_Sequence_No"    , type: "INTEGER", tableCode: "TT" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "httz_codes01"        : { canonical: "hTTz_Codes01"        , type: "STRING", tableCode: "TT" },
        "httz_codes02"        : { canonical: "hTTz_Codes02"        , type: "STRING", tableCode: "TT" },
        "httz_division"       : { canonical: "hTTz_Division"       , type: "STRING", tableCode: "TT" },
        "httz_filename"       : { canonical: "hTTz_Filename"       , type: "STRING", tableCode: "TT" },
        "httz_fund"           : { canonical: "hTTz_Fund"           , type: "STRING", tableCode: "TT" },
        "httz_group01"        : { canonical: "hTTz_Group01"        , type: "STRING", tableCode: "TT" },
        "httz_group02"        : { canonical: "hTTz_Group02"        , type: "STRING", tableCode: "TT" },
        "httz_header"         : { canonical: "hTTz_Header"         , type: "STRING", tableCode: "TT" },
        "httz_mbr_surname"    : { canonical: "hTTz_Mbr_Surname"    , type: "STRING", tableCode: "TT" },
        "httz_member"         : { canonical: "hTTz_Member"         , type: "STRING", tableCode: "TT" },
        "httz_payroll"        : { canonical: "hTTz_Payroll"        , type: "STRING", tableCode: "TT" },
        "httz_posting"        : { canonical: "hTTz_Posting"        , type: "STRING", tableCode: "TT" },
        "httz_spare"          : { canonical: "hTTz_Spare"          , type: "STRING", tableCode: "TT" },
        "httz_string"         : { canonical: "hTTz_String"         , type: "STRING", tableCode: "TT" },
        "httz_transaction"    : { canonical: "hTTz_Transaction"    , type: "STRING", tableCode: "TT" },
        "httz_user_def_strg01": { canonical: "hTTz_User_Def_Strg01", type: "STRING", tableCode: "TT" },
        "httz_user_def_strg02": { canonical: "hTTz_User_Def_Strg02", type: "STRING", tableCode: "TT" },
        "httz_user_def_strg03": { canonical: "hTTz_User_Def_Strg03", type: "STRING", tableCode: "TT" },

        // ── (y-prefix) ──────────────────────────────────────────────────
        "htty_desc_flds01"    : { canonical: "hTTy_Desc_Flds01"    , type: "STRING", tableCode: "TT" },
        "htty_desc_flds02"    : { canonical: "hTTy_Desc_Flds02"    , type: "STRING", tableCode: "TT" },
    }
};

export default TT;
