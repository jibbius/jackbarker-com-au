/**
 * PH.js — table structure for the PH (Employer/Payroll History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PH
 */

/** @type {Object} */
const PH = {
    code: "PH",
    name: "Employer/Payroll_History",
    recordLength: null,
    helpRegistry: "hPH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hphc_fund_choice"     : { canonical: "hPHc_Fund_Choice"     , type: "STRING", tableCode: "PH" },
        "hphc_primary_payroll" : { canonical: "hPHc_Primary_Payroll" , type: "STRING", tableCode: "PH" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hphd_contract_end"    : { canonical: "hPHd_Contract_End"    , type: "DATE", tableCode: "PH" },
        "hphd_contract_start"  : { canonical: "hPHd_Contract_Start"  , type: "DATE", tableCode: "PH" },
        "hphd_effective"       : { canonical: "hPHd_Effective"       , type: "DATE", tableCode: "PH" },
        "hphd_mod_date"        : { canonical: "hPHd_Mod_Date"        , type: "DATE", tableCode: "PH" },
        "hphd_termination"     : { canonical: "hPHd_Termination"     , type: "DATE", tableCode: "PH" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hphl_spare"           : { canonical: "hPHl_Spare"           , type: "INTEGER", tableCode: "PH" },
        "hphl_trans_ref"       : { canonical: "hPHl_Trans_Ref"       , type: "INTEGER", tableCode: "PH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hpht_mod_time"        : { canonical: "hPHt_Mod_Time"        , type: "TIME", tableCode: "PH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hphz_cessation_reason": { canonical: "hPHz_Cessation_Reason", type: "STRING", tableCode: "PH" },
        "hphz_division"        : { canonical: "hPHz_Division"        , type: "STRING", tableCode: "PH" },
        "hphz_employment_type" : { canonical: "hPHz_Employment_Type" , type: "STRING", tableCode: "PH" },
        "hphz_fund"            : { canonical: "hPHz_Fund"            , type: "STRING", tableCode: "PH" },
        "hphz_long_location"   : { canonical: "hPHz_Long_Location"   , type: "STRING", tableCode: "PH" },
        "hphz_member"          : { canonical: "hPHz_Member"          , type: "STRING", tableCode: "PH" },
        "hphz_mod_user"        : { canonical: "hPHz_Mod_User"        , type: "STRING", tableCode: "PH" },
        "hphz_payroll"         : { canonical: "hPHz_Payroll"         , type: "STRING", tableCode: "PH" },
        "hphz_payroll_no"      : { canonical: "hPHz_Payroll_No"      , type: "STRING", tableCode: "PH" },
        "hphz_payroll_no_2"    : { canonical: "hPHz_Payroll_No_2"    , type: "STRING", tableCode: "PH" },
        "hphz_payroll_no_3"    : { canonical: "hPHz_Payroll_No_3"    , type: "STRING", tableCode: "PH" },
        "hphz_payroll_no_4"    : { canonical: "hPHz_Payroll_No_4"    , type: "STRING", tableCode: "PH" },
        "hphz_payroll_no_5"    : { canonical: "hPHz_Payroll_No_5"    , type: "STRING", tableCode: "PH" },
        "hphz_payroll_no_6"    : { canonical: "hPHz_Payroll_No_6"    , type: "STRING", tableCode: "PH" },
        "hphz_reason"          : { canonical: "hPHz_Reason"          , type: "STRING", tableCode: "PH" },
    }
};

export default PH;
