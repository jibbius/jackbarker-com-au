/**
 * AH.js — table structure for the AH (Member Acquisition History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AH
 */

/** @type {Object} */
const AH = {
    code: "AH",
    name: "Member_Acquisition_History",
    recordLength: null,
    helpRegistry: "hAH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "AHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hahd_effective"     : { canonical: "hAHd_Effective"     , type: "DATE", tableCode: "AH" },
        "hahd_mod_date"      : { canonical: "hAHd_Mod_Date"      , type: "DATE", tableCode: "AH" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hahf_max_no"        : { canonical: "hAHf_Max_No"        , type: "DOUBLE", tableCode: "AH" },
        "hahf_max_pref_no"   : { canonical: "hAHf_Max_Pref_No"   , type: "DOUBLE", tableCode: "AH" },
        "hahf_max_pref_price": { canonical: "hAHf_Max_Pref_Price", type: "DOUBLE", tableCode: "AH" },
        "hahf_max_price"     : { canonical: "hAHf_Max_Price"     , type: "DOUBLE", tableCode: "AH" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hahl_spare"         : { canonical: "hAHl_Spare"         , type: "INTEGER", tableCode: "AH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "haht_mod_time"      : { canonical: "hAHt_Mod_Time"      , type: "TIME", tableCode: "AH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hahz_fund"          : { canonical: "hAHz_Fund"          , type: "STRING", tableCode: "AH" },
        "hahz_member"        : { canonical: "hAHz_Member"        , type: "STRING", tableCode: "AH" },
        "hahz_mod_user"      : { canonical: "hAHz_Mod_User"      , type: "STRING", tableCode: "AH" },
    }
};

export default AH;
