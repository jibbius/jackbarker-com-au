/**
 * FX.js — table structure for the FX (Formula Definitions) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FX").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FX
 */

/** @type {Object} */
const FX = {
    code: "FX",
    name: "Formula_Definitions",
    recordLength: null,
    helpRegistry: "hFX.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FXi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hfxc_sup_level"      : { canonical: "hFXc_Sup_Level"      , type: "STRING", tableCode: "FX" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfxd_i"              : { canonical: "hFXd_I"              , type: "DATE", tableCode: "FX" },
        "hfxd_j"              : { canonical: "hFXd_J"              , type: "DATE", tableCode: "FX" },
        "hfxd_k"              : { canonical: "hFXd_K"              , type: "DATE", tableCode: "FX" },
        "hfxd_l"              : { canonical: "hFXd_L"              , type: "DATE", tableCode: "FX" },
        "hfxd_mod_date"       : { canonical: "hFXd_Mod_Date"       , type: "DATE", tableCode: "FX" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hfxf_amount_a"       : { canonical: "hFXf_Amount_A"       , type: "DOUBLE", tableCode: "FX" },
        "hfxf_amount_b"       : { canonical: "hFXf_Amount_B"       , type: "DOUBLE", tableCode: "FX" },
        "hfxf_amount_c"       : { canonical: "hFXf_Amount_C"       , type: "DOUBLE", tableCode: "FX" },
        "hfxf_amount_d"       : { canonical: "hFXf_Amount_D"       , type: "DOUBLE", tableCode: "FX" },
        "hfxf_factor_e"       : { canonical: "hFXf_Factor_E"       , type: "DOUBLE", tableCode: "FX" },
        "hfxf_factor_f"       : { canonical: "hFXf_Factor_F"       , type: "DOUBLE", tableCode: "FX" },
        "hfxf_factor_g"       : { canonical: "hFXf_Factor_G"       , type: "DOUBLE", tableCode: "FX" },
        "hfxf_factor_h"       : { canonical: "hFXf_Factor_H"       , type: "DOUBLE", tableCode: "FX" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hfxl_spare"          : { canonical: "hFXl_Spare"          , type: "INTEGER", tableCode: "FX" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hfxs_code"           : { canonical: "hFXs_Code"           , type: "INTEGER", tableCode: "FX" },
        "hfxs_free_switch_prd": { canonical: "hFXs_Free_Switch_Prd", type: "INTEGER", tableCode: "FX" },
        "hfxs_spare01"        : { canonical: "hFXs_Spare01"        , type: "INTEGER", tableCode: "FX" },
        "hfxs_spare02"        : { canonical: "hFXs_Spare02"        , type: "INTEGER", tableCode: "FX" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfxt_mod_time"       : { canonical: "hFXt_Mod_Time"       , type: "TIME", tableCode: "FX" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfxz_date_str_n"     : { canonical: "hFXz_Date_Str_N"     , type: "STRING", tableCode: "FX" },
        "hfxz_date_str_o"     : { canonical: "hFXz_Date_Str_O"     , type: "STRING", tableCode: "FX" },
        "hfxz_date_str_p"     : { canonical: "hFXz_Date_Str_P"     , type: "STRING", tableCode: "FX" },
        "hfxz_date_string"    : { canonical: "hFXz_Date_String"    , type: "STRING", tableCode: "FX" },
        "hfxz_deleted"        : { canonical: "hFXz_Deleted"        , type: "STRING", tableCode: "FX" },
        "hfxz_description"    : { canonical: "hFXz_Description"    , type: "STRING", tableCode: "FX" },
        "hfxz_interest_table" : { canonical: "hFXz_Interest_Table" , type: "STRING", tableCode: "FX" },
        "hfxz_mod_user"       : { canonical: "hFXz_Mod_User"       , type: "STRING", tableCode: "FX" },
        "hfxz_spare"          : { canonical: "hFXz_Spare"          , type: "STRING", tableCode: "FX" },
        "hfxz_spare_1"        : { canonical: "hFXz_Spare_1"        , type: "STRING", tableCode: "FX" },
        "hfxz_string"         : { canonical: "hFXz_String"         , type: "STRING", tableCode: "FX" },
        "hfxz_sup_fund_flag"  : { canonical: "hFXz_Sup_Fund_Flag"  , type: "STRING", tableCode: "FX" },
        "hfxz_table"          : { canonical: "hFXz_Table"          , type: "STRING", tableCode: "FX" },
        "hfxz_table_type"     : { canonical: "hFXz_Table_Type"     , type: "STRING", tableCode: "FX" },
        "hfxz_tokens"         : { canonical: "hFXz_Tokens"         , type: "STRING", tableCode: "FX" },
        "hfxz_type"           : { canonical: "hFXz_Type"           , type: "STRING", tableCode: "FX" },
    }
};

export default FX;
