/**
 * DH.js — table structure for the DH (Tax Rates History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "DH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force DH
 */

/** @type {Object} */
const DH = {
    code: "DH",
    name: "Tax_Rates_History",
    recordLength: null,
    helpRegistry: "hDH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "DHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hdhc_ben_liab_level"  : { canonical: "hDHc_Ben_Liab_Level"  , type: "STRING", tableCode: "DH" },
        "hdhc_cont_tax"        : { canonical: "hDHc_Cont_tax"        , type: "STRING", tableCode: "DH" },
        "hdhc_liability_level" : { canonical: "hDHc_Liability_Level" , type: "STRING", tableCode: "DH" },
        "hdhc_tfn_req"         : { canonical: "hDHc_TFN_Req"         , type: "STRING", tableCode: "DH" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hdhd_effective"       : { canonical: "hDHd_Effective"       , type: "DATE", tableCode: "DH" },
        "hdhd_mod_date"        : { canonical: "hDHd_Mod_Date"        , type: "DATE", tableCode: "DH" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hdhf_award_min_cont"  : { canonical: "hDHf_Award_Min_Cont"  , type: "DOUBLE", tableCode: "DH" },
        "hdhf_cont_tax_rate"   : { canonical: "hDHf_Cont_Tax_Rate"   , type: "DOUBLE", tableCode: "DH" },
        "hdhf_corp_tax_rate"   : { canonical: "hDHf_Corp_Tax_Rate"   , type: "DOUBLE", tableCode: "DH" },
        "hdhf_empl_deductible" : { canonical: "hDHf_Empl_Deductible" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_fas_band_1"      : { canonical: "hDHf_FAS_Band_1"      , type: "DOUBLE", tableCode: "DH" },
        "hdhf_fas_band_2"      : { canonical: "hDHf_FAS_Band_2"      , type: "DOUBLE", tableCode: "DH" },
        "hdhf_gst_rate"        : { canonical: "hDHf_GST_Rate"        , type: "DOUBLE", tableCode: "DH" },
        "hdhf_gst_ritc_rate"   : { canonical: "hDHf_GST_RITC_Rate"   , type: "DOUBLE", tableCode: "DH" },
        "hdhf_lump_sum_1"      : { canonical: "hDHf_Lump_Sum_1"      , type: "DOUBLE", tableCode: "DH" },
        "hdhf_lump_sum_2"      : { canonical: "hDHf_Lump_Sum_2"      , type: "DOUBLE", tableCode: "DH" },
        "hdhf_lump_sum_3"      : { canonical: "hDHf_Lump_Sum_3"      , type: "DOUBLE", tableCode: "DH" },
        "hdhf_marginal_rate01" : { canonical: "hDHf_Marginal_Rate01" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_marginal_rate02" : { canonical: "hDHf_Marginal_Rate02" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_marginal_rate03" : { canonical: "hDHf_Marginal_Rate03" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_marginal_rate04" : { canonical: "hDHf_Marginal_Rate04" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_marginal_rate05" : { canonical: "hDHf_Marginal_Rate05" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_marginal_rate06" : { canonical: "hDHf_Marginal_Rate06" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_marginal_rate07" : { canonical: "hDHf_Marginal_Rate07" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_marginal_rate08" : { canonical: "hDHf_Marginal_Rate08" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_marginal_rate09" : { canonical: "hDHf_Marginal_Rate09" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_marginal_rate10" : { canonical: "hDHf_Marginal_Rate10" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_max_amt_pres"    : { canonical: "hDHf_Max_Amt_Pres"    , type: "DOUBLE", tableCode: "DH" },
        "hdhf_max_cgt_exempt"  : { canonical: "hDHf_Max_CGT_Exempt"  , type: "DOUBLE", tableCode: "DH" },
        "hdhf_min_salary_isc"  : { canonical: "hDHf_Min_Salary_ISC"  , type: "DOUBLE", tableCode: "DH" },
        "hdhf_nconc_cap_o65"   : { canonical: "hDHf_NConc_Cap_O65"   , type: "DOUBLE", tableCode: "DH" },
        "hdhf_nconc_cap_u65"   : { canonical: "hDHf_NConc_Cap_U65"   , type: "DOUBLE", tableCode: "DH" },
        "hdhf_no_tfn_thresh"   : { canonical: "hDHf_No_TFN_Thresh"   , type: "DOUBLE", tableCode: "DH" },
        "hdhf_old_maxtax_mult" : { canonical: "hDHf_Old_Maxtax_Mult" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_old_maxtax_pens" : { canonical: "hDHf_Old_Maxtax_Pens" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_over_thold_taxr" : { canonical: "hDHf_Over_Thold_TaxR" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_pension_1"       : { canonical: "hDHf_Pension_1"       , type: "DOUBLE", tableCode: "DH" },
        "hdhf_pension_2"       : { canonical: "hDHf_Pension_2"       , type: "DOUBLE", tableCode: "DH" },
        "hdhf_pension_3"       : { canonical: "hDHf_Pension_3"       , type: "DOUBLE", tableCode: "DH" },
        "hdhf_rebate_rule"     : { canonical: "hDHf_Rebate_Rule"     , type: "DOUBLE", tableCode: "DH" },
        "hdhf_rebate_rule_bal" : { canonical: "hDHf_Rebate_Rule_Bal" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_ret_exempt_cap"  : { canonical: "hDHf_Ret_Exempt_Cap"  , type: "DOUBLE", tableCode: "DH" },
        "hdhf_sal_margnl_rte01": { canonical: "hDHf_Sal_Margnl_Rte01", type: "DOUBLE", tableCode: "DH" },
        "hdhf_sal_margnl_rte02": { canonical: "hDHf_Sal_Margnl_Rte02", type: "DOUBLE", tableCode: "DH" },
        "hdhf_sal_margnl_rte03": { canonical: "hDHf_Sal_Margnl_Rte03", type: "DOUBLE", tableCode: "DH" },
        "hdhf_sal_margnl_rte04": { canonical: "hDHf_Sal_Margnl_Rte04", type: "DOUBLE", tableCode: "DH" },
        "hdhf_sal_margnl_rte05": { canonical: "hDHf_Sal_Margnl_Rte05", type: "DOUBLE", tableCode: "DH" },
        "hdhf_sal_margnl_rte06": { canonical: "hDHf_Sal_Margnl_Rte06", type: "DOUBLE", tableCode: "DH" },
        "hdhf_sal_margnl_rte07": { canonical: "hDHf_Sal_Margnl_Rte07", type: "DOUBLE", tableCode: "DH" },
        "hdhf_sal_margnl_rte08": { canonical: "hDHf_Sal_Margnl_Rte08", type: "DOUBLE", tableCode: "DH" },
        "hdhf_sal_margnl_rte09": { canonical: "hDHf_Sal_Margnl_Rte09", type: "DOUBLE", tableCode: "DH" },
        "hdhf_sal_margnl_rte10": { canonical: "hDHf_Sal_Margnl_Rte10", type: "DOUBLE", tableCode: "DH" },
        "hdhf_surch_cont_thold": { canonical: "hDHf_Surch_Cont_Thold", type: "DOUBLE", tableCode: "DH" },
        "hdhf_surch_divisor"   : { canonical: "hDHf_Surch_Divisor"   , type: "DOUBLE", tableCode: "DH" },
        "hdhf_surch_max_thold" : { canonical: "hDHf_Surch_Max_Thold" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_surch_min_thold" : { canonical: "hDHf_Surch_Min_Thold" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_tax_conc_thold"  : { canonical: "hDHf_Tax_Conc_Thold"  , type: "DOUBLE", tableCode: "DH" },
        "hdhf_tax_dedn_thold"  : { canonical: "hDHf_Tax_Dedn_Thold"  , type: "DOUBLE", tableCode: "DH" },
        "hdhf_tax_free_thresh" : { canonical: "hDHf_Tax_Free_Thresh" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_tax_pcnt_unsup"  : { canonical: "hDHf_Tax_Pcnt_Unsup"  , type: "DOUBLE", tableCode: "DH" },
        "hdhf_tax_thold_rebate": { canonical: "hDHf_Tax_Thold_Rebate", type: "DOUBLE", tableCode: "DH" },
        "hdhf_tax_thold_unsup" : { canonical: "hDHf_Tax_Thold_Unsup" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_termap_pay_var"  : { canonical: "hDHf_TermAP_Pay_Var"  , type: "DOUBLE", tableCode: "DH" },
        "hdhf_tmp_res_taxr"    : { canonical: "hDHf_Tmp_Res_TaxR"    , type: "DOUBLE", tableCode: "DH" },
        "hdhf_tmp_res_untaxed" : { canonical: "hDHf_Tmp_Res_Untaxed" , type: "DOUBLE", tableCode: "DH" },
        "hdhf_under_55_taxr"   : { canonical: "hDHf_Under_55_TaxR"   , type: "DOUBLE", tableCode: "DH" },
        "hdhf_under_thold_taxr": { canonical: "hDHf_Under_Thold_TaxR", type: "DOUBLE", tableCode: "DH" },
        "hdhf_untaxed_rebate"  : { canonical: "hDHf_Untaxed_Rebate"  , type: "DOUBLE", tableCode: "DH" },
        "hdhf_untaxed_tax_rate": { canonical: "hDHf_Untaxed_Tax_Rate", type: "DOUBLE", tableCode: "DH" },
        "hdhf_withhold_thold"  : { canonical: "hDHf_Withhold_Thold"  , type: "DOUBLE", tableCode: "DH" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hdhs_cooling_off"     : { canonical: "hDHs_Cooling_Off"     , type: "INTEGER", tableCode: "DH" },
        "hdhs_spare01"         : { canonical: "hDHs_Spare01"         , type: "INTEGER", tableCode: "DH" },
        "hdhs_spare02"         : { canonical: "hDHs_Spare02"         , type: "INTEGER", tableCode: "DH" },
        "hdhs_spare03"         : { canonical: "hDHs_Spare03"         , type: "INTEGER", tableCode: "DH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hdht_mod_time"        : { canonical: "hDHt_Mod_Time"        , type: "TIME", tableCode: "DH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hdhz_division"        : { canonical: "hDHz_Division"        , type: "STRING", tableCode: "DH" },
        "hdhz_mod_user"        : { canonical: "hDHz_Mod_User"        , type: "STRING", tableCode: "DH" },
        "hdhz_spare"           : { canonical: "hDHz_Spare"           , type: "STRING", tableCode: "DH" },
    }
};

export default DH;
