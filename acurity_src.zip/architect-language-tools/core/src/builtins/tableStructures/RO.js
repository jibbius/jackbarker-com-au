/**
 * RO.js — table structure for the RO (Rollover History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "RO").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force RO
 */

/** @type {Object} */
const RO = {
    code: "RO",
    name: "Rollover_History",
    recordLength: null,
    helpRegistry: "hRO.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ROi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hroc_in_or_out"       : { canonical: "hROc_In_Or_Out"       , type: "STRING", tableCode: "RO" },
        "hroc_posted"          : { canonical: "hROc_Posted"          , type: "STRING", tableCode: "RO" },
        "hroc_pre_jul94_anuity": { canonical: "hROc_Pre_Jul94_Anuity", type: "STRING", tableCode: "RO" },
        "hroc_total"           : { canonical: "hROc_Total"           , type: "STRING", tableCode: "RO" },
        "hroc_transfer_type"   : { canonical: "hROc_Transfer_Type"   , type: "STRING", tableCode: "RO" },
        "hroc_untaxed"         : { canonical: "hROc_Untaxed"         , type: "STRING", tableCode: "RO" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hrod_2nd_start_ropn"  : { canonical: "hROd_2nd_Start_ROPN"  , type: "DATE", tableCode: "RO" },
        "hrod_calc_service"    : { canonical: "hROd_Calc_Service"    , type: "DATE", tableCode: "RO" },
        "hrod_effective"       : { canonical: "hROd_Effective"       , type: "DATE", tableCode: "RO" },
        "hrod_eligible_service": { canonical: "hROd_Eligible_Service", type: "DATE", tableCode: "RO" },
        "hrod_etp_payment"     : { canonical: "hROd_ETP_Payment"     , type: "DATE", tableCode: "RO" },
        "hrod_interest"        : { canonical: "hROd_Interest"        , type: "DATE", tableCode: "RO" },
        "hrod_mod_date"        : { canonical: "hROd_Mod_Date"        , type: "DATE", tableCode: "RO" },
        "hrod_qrops_start"     : { canonical: "hROd_QROPS_Start"     , type: "DATE", tableCode: "RO" },
        "hrod_spare"           : { canonical: "hROd_Spare"           , type: "DATE", tableCode: "RO" },
        "hrod_start_ropn"      : { canonical: "hROd_Start_ROPN"      , type: "DATE", tableCode: "RO" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hrof_1st_start_d_amt" : { canonical: "hROf_1st_Start_D_Amt" , type: "DOUBLE", tableCode: "RO" },
        "hrof_2nd_start_d_amt" : { canonical: "hROf_2nd_Start_D_Amt" , type: "DOUBLE", tableCode: "RO" },
        "hrof_accum_entit"     : { canonical: "hROf_Accum_Entit"     , type: "DOUBLE", tableCode: "RO" },
        "hrof_additional_conts": { canonical: "hROf_Additional_Conts", type: "DOUBLE", tableCode: "RO" },
        "hrof_alloc_surplus"   : { canonical: "hROf_Alloc_Surplus"   , type: "DOUBLE", tableCode: "RO" },
        "hrof_cap_gains_cgt"   : { canonical: "hROf_Cap_Gains_CGT"   , type: "DOUBLE", tableCode: "RO" },
        "hrof_cap_gains_tax"   : { canonical: "hROf_Cap_Gains_Tax"   , type: "DOUBLE", tableCode: "RO" },
        "hrof_cf_etp_comp"     : { canonical: "hROf_CF_ETP_Comp"     , type: "DOUBLE", tableCode: "RO" },
        "hrof_cgt_exempt_amt"  : { canonical: "hROf_CGT_Exempt_Amt"  , type: "DOUBLE", tableCode: "RO" },
        "hrof_concessional"    : { canonical: "hROf_Concessional"    , type: "DOUBLE", tableCode: "RO" },
        "hrof_death_amt"       : { canonical: "hROf_Death_Amt"       , type: "DOUBLE", tableCode: "RO" },
        "hrof_disablement_amt" : { canonical: "hROf_Disablement_Amt" , type: "DOUBLE", tableCode: "RO" },
        "hrof_emp_cont_amt"    : { canonical: "hROf_Emp_Cont_Amt"    , type: "DOUBLE", tableCode: "RO" },
        "hrof_emp_db_cont_amt" : { canonical: "hROf_Emp_DB_Cont_Amt" , type: "DOUBLE", tableCode: "RO" },
        "hrof_fund_etp_comp"   : { canonical: "hROf_Fund_ETP_Comp"   , type: "DOUBLE", tableCode: "RO" },
        "hrof_income_protn_amt": { canonical: "hROf_Income_Protn_Amt", type: "DOUBLE", tableCode: "RO" },
        "hrof_injury_payment"  : { canonical: "hROf_Injury_Payment"  , type: "DOUBLE", tableCode: "RO" },
        "hrof_invalidity"      : { canonical: "hROf_Invalidity"      , type: "DOUBLE", tableCode: "RO" },
        "hrof_kiwi_preserved"  : { canonical: "hROf_Kiwi_Preserved"  , type: "DOUBLE", tableCode: "RO" },
        "hrof_kiwi_tax_free"   : { canonical: "hROf_Kiwi_Tax_Free"   , type: "DOUBLE", tableCode: "RO" },
        "hrof_non_assess_amt"  : { canonical: "hROf_Non_Assess_Amt"  , type: "DOUBLE", tableCode: "RO" },
        "hrof_non_concess"     : { canonical: "hROf_Non_Concess"     , type: "DOUBLE", tableCode: "RO" },
        "hrof_oth_cont_amt"    : { canonical: "hROf_Oth_Cont_Amt"    , type: "DOUBLE", tableCode: "RO" },
        "hrof_pers_cont_amt"   : { canonical: "hROf_Pers_Cont_Amt"   , type: "DOUBLE", tableCode: "RO" },
        "hrof_post_taxed"      : { canonical: "hROf_Post_Taxed"      , type: "DOUBLE", tableCode: "RO" },
        "hrof_post_untaxed"    : { canonical: "hROf_Post_Untaxed"    , type: "DOUBLE", tableCode: "RO" },
        "hrof_post06_noncompl" : { canonical: "hROf_Post06_NonCompl" , type: "DOUBLE", tableCode: "RO" },
        "hrof_pre_83"          : { canonical: "hROf_Pre_83"          , type: "DOUBLE", tableCode: "RO" },
        "hrof_preserved"       : { canonical: "hROf_Preserved"       , type: "DOUBLE", tableCode: "RO" },
        "hrof_prev_exempt_amt" : { canonical: "hROf_Prev_Exempt_Amt" , type: "DOUBLE", tableCode: "RO" },
        "hrof_rcv_cgt_exempt"  : { canonical: "hROf_Rcv_CGT_Exempt"  , type: "DOUBLE", tableCode: "RO" },
        "hrof_rcv_concessional": { canonical: "hROf_RCV_Concessional", type: "DOUBLE", tableCode: "RO" },
        "hrof_rcv_etp"         : { canonical: "hROf_RCV_ETP"         , type: "DOUBLE", tableCode: "RO" },
        "hrof_rcv_invalidity"  : { canonical: "hROf_RCV_Invalidity"  , type: "DOUBLE", tableCode: "RO" },
        "hrof_rcv_post_taxed"  : { canonical: "hROf_RCV_Post_Taxed"  , type: "DOUBLE", tableCode: "RO" },
        "hrof_rcv_post_untaxed": { canonical: "hROf_RCV_Post_Untaxed", type: "DOUBLE", tableCode: "RO" },
        "hrof_rcv_pre_83"      : { canonical: "hROf_RCV_Pre_83"      , type: "DOUBLE", tableCode: "RO" },
        "hrof_rcv_preserved"   : { canonical: "hROf_RCV_Preserved"   , type: "DOUBLE", tableCode: "RO" },
        "hrof_rcv_unded"       : { canonical: "hROf_RCV_Unded"       , type: "DOUBLE", tableCode: "RO" },
        "hrof_rest_cgt_exempt" : { canonical: "hROf_Rest_CGT_Exempt" , type: "DOUBLE", tableCode: "RO" },
        "hrof_rest_concess"    : { canonical: "hROf_Rest_Concess"    , type: "DOUBLE", tableCode: "RO" },
        "hrof_rest_invalidity" : { canonical: "hROf_Rest_Invalidity" , type: "DOUBLE", tableCode: "RO" },
        "hrof_rest_post_taxed" : { canonical: "hROf_Rest_Post_Taxed" , type: "DOUBLE", tableCode: "RO" },
        "hrof_rest_post_untax" : { canonical: "hROf_Rest_Post_Untax" , type: "DOUBLE", tableCode: "RO" },
        "hrof_rest_pre_83"     : { canonical: "hROf_Rest_Pre_83"     , type: "DOUBLE", tableCode: "RO" },
        "hrof_rest_preserved"  : { canonical: "hROf_Rest_Preserved"  , type: "DOUBLE", tableCode: "RO" },
        "hrof_rest_total_etp"  : { canonical: "hROf_Rest_Total_ETP"  , type: "DOUBLE", tableCode: "RO" },
        "hrof_rest_undeducted" : { canonical: "hROf_Rest_Undeducted" , type: "DOUBLE", tableCode: "RO" },
        "hrof_rnpb_retrenchmnt": { canonical: "hROf_RNPB_Retrenchmnt", type: "DOUBLE", tableCode: "RO" },
        "hrof_rnpb_withdrawal" : { canonical: "hROf_RNPB_Withdrawal" , type: "DOUBLE", tableCode: "RO" },
        "hrof_roll_bal_15_2_90": { canonical: "hROf_Roll_Bal_15_2_90", type: "DOUBLE", tableCode: "RO" },
        "hrof_spec_ro_amt"     : { canonical: "hROf_Spec_RO_Amt"     , type: "DOUBLE", tableCode: "RO" },
        "hrof_spouse_cont_amt" : { canonical: "hROf_Spouse_Cont_Amt" , type: "DOUBLE", tableCode: "RO" },
        "hrof_surcharge_debt"  : { canonical: "hROf_Surcharge_Debt"  , type: "DOUBLE", tableCode: "RO" },
        "hrof_tcont_nonassess" : { canonical: "hROf_TCont_NonAssess" , type: "DOUBLE", tableCode: "RO" },
        "hrof_tfree_foreign"   : { canonical: "hROf_TFree_Foreign"   , type: "DOUBLE", tableCode: "RO" },
        "hrof_tot_cont_amt"    : { canonical: "hROf_Tot_Cont_Amt"    , type: "DOUBLE", tableCode: "RO" },
        "hrof_total_etp"       : { canonical: "hROf_Total_ETP"       , type: "DOUBLE", tableCode: "RO" },
        "hrof_undeducted"      : { canonical: "hROf_Undeducted"      , type: "DOUBLE", tableCode: "RO" },
        "hrof_unpb"            : { canonical: "hROf_UNPB"            , type: "DOUBLE", tableCode: "RO" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hrol_file_reg_ref"    : { canonical: "hROl_File_Reg_Ref"    , type: "INTEGER", tableCode: "RO" },
        "hrol_line_no"         : { canonical: "hROl_Line_No"         , type: "INTEGER", tableCode: "RO" },
        "hrol_trans_ref"       : { canonical: "hROl_Trans_Ref"       , type: "INTEGER", tableCode: "RO" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hros_no_weeks"        : { canonical: "hROs_No_Weeks"        , type: "INTEGER", tableCode: "RO" },
        "hros_post_83_days"    : { canonical: "hROs_Post_83_Days"    , type: "INTEGER", tableCode: "RO" },
        "hros_pre_83_days"     : { canonical: "hROs_Pre_83_Days"     , type: "INTEGER", tableCode: "RO" },
        "hros_resident_days"   : { canonical: "hROs_Resident_Days"   , type: "INTEGER", tableCode: "RO" },
        "hros_spare01"         : { canonical: "hROs_Spare01"         , type: "INTEGER", tableCode: "RO" },
        "hros_spare02"         : { canonical: "hROs_Spare02"         , type: "INTEGER", tableCode: "RO" },
        "hros_spare03"         : { canonical: "hROs_Spare03"         , type: "INTEGER", tableCode: "RO" },
        "hros_total_days"      : { canonical: "hROs_Total_Days"      , type: "INTEGER", tableCode: "RO" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hrot_mod_time"        : { canonical: "hROt_Mod_Time"        , type: "TIME", tableCode: "RO" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hroz_aust_business_no": { canonical: "hROz_Aust_Business_No", type: "STRING", tableCode: "RO" },
        "hroz_deleted"         : { canonical: "hROz_Deleted"         , type: "STRING", tableCode: "RO" },
        "hroz_division"        : { canonical: "hROz_Division"        , type: "STRING", tableCode: "RO" },
        "hroz_fund"            : { canonical: "hROz_Fund"            , type: "STRING", tableCode: "RO" },
        "hroz_member"          : { canonical: "hROz_Member"          , type: "STRING", tableCode: "RO" },
        "hroz_mod_user"        : { canonical: "hROz_Mod_User"        , type: "STRING", tableCode: "RO" },
        "hroz_orgname"         : { canonical: "hROz_OrgName"         , type: "STRING", tableCode: "RO" },
        "hroz_payee"           : { canonical: "hROz_Payee"           , type: "STRING", tableCode: "RO" },
        "hroz_prodid"          : { canonical: "hROz_ProdID"          , type: "STRING", tableCode: "RO" },
        "hroz_spare"           : { canonical: "hROz_Spare"           , type: "STRING", tableCode: "RO" },
    }
};

export default RO;
