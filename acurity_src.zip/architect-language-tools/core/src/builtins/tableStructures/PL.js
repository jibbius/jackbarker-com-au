/**
 * PL.js — table structure for the PL (Policy Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PL").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PL
 */

/** @type {Object} */
const PL = {
    code: "PL",
    name: "Policy_Details",
    recordLength: null,
    helpRegistry: "hPL.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PLi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hplc_at_work_on_join" : { canonical: "hPLc_At_Work_On_Join" , type: "STRING", tableCode: "PL" },
        "hplc_stamp_duty"      : { canonical: "hPLc_Stamp_Duty"      , type: "STRING", tableCode: "PL" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hpld_commencement"    : { canonical: "hPLd_Commencement"    , type: "DATE", tableCode: "PL" },
        "hpld_lapsed"          : { canonical: "hPLd_Lapsed"          , type: "DATE", tableCode: "PL" },
        "hpld_mod_date"        : { canonical: "hPLd_Mod_Date"        , type: "DATE", tableCode: "PL" },
        "hpld_premium_deductn" : { canonical: "hPLd_Premium_Deductn" , type: "DATE", tableCode: "PL" },
        "hpld_spare"           : { canonical: "hPLd_Spare"           , type: "DATE", tableCode: "PL" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hpll_policy_number"   : { canonical: "hPLl_Policy_Number"   , type: "INTEGER", tableCode: "PL" },
        "hpll_spare"           : { canonical: "hPLl_Spare"           , type: "INTEGER", tableCode: "PL" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hplt_mod_time"        : { canonical: "hPLt_Mod_Time"        , type: "TIME", tableCode: "PL" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hplz_client"          : { canonical: "hPLz_Client"          , type: "STRING", tableCode: "PL" },
        "hplz_insurer"         : { canonical: "hPLz_Insurer"         , type: "STRING", tableCode: "PL" },
        "hplz_mod_user"        : { canonical: "hPLz_Mod_User"        , type: "STRING", tableCode: "PL" },
        "hplz_spare"           : { canonical: "hPLz_Spare"           , type: "STRING", tableCode: "PL" },
        "hplz_status"          : { canonical: "hPLz_Status"          , type: "STRING", tableCode: "PL" },
        "hplz_supp_record_type": { canonical: "hPLz_Supp_Record_Type", type: "STRING", tableCode: "PL" },
    }
};

export default PL;
