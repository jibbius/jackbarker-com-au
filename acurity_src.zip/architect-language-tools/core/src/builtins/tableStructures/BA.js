/**
 * BA.js — table structure for the BA (Journal) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BA").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BA
 */

/** @type {Object} */
const BA = {
    code: "BA",
    name: "Journal",
    recordLength: null,
    helpRegistry: "hBA.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BAi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hbac_change_djp"      : { canonical: "hBAc_Change_DJP"      , type: "STRING", tableCode: "BA" },
        "hbac_debit_or_credit" : { canonical: "hBAc_Debit_Or_Credit" , type: "STRING", tableCode: "BA" },
        "hbac_division"        : { canonical: "hBAc_Division"        , type: "STRING", tableCode: "BA" },
        "hbac_leave_total"     : { canonical: "hBAc_Leave_Total"     , type: "STRING", tableCode: "BA" },
        "hbac_preservation"    : { canonical: "hBAc_Preservation"    , type: "STRING", tableCode: "BA" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hbad_effective"       : { canonical: "hBAd_Effective"       , type: "DATE", tableCode: "BA" },
        "hbad_interest"        : { canonical: "hBAd_Interest"        , type: "DATE", tableCode: "BA" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hbaf_amount"          : { canonical: "hBAf_Amount"          , type: "DOUBLE", tableCode: "BA" },
        "hbaf_units"           : { canonical: "hBAf_Units"           , type: "DOUBLE", tableCode: "BA" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hbal_partially_posted": { canonical: "hBAl_Partially_Posted", type: "INTEGER", tableCode: "BA" },
        "hbal_share_cert"      : { canonical: "hBAl_Share_Cert"      , type: "INTEGER", tableCode: "BA" },
        "hbal_trans_ref"       : { canonical: "hBAl_Trans_Ref"       , type: "INTEGER", tableCode: "BA" },

        // ── (y-prefix) ──────────────────────────────────────────────────
        "hbay_account"         : { canonical: "hBAy_Account"         , type: "STRING", tableCode: "BA" },
        "hbay_actual_fund"     : { canonical: "hBAy_Actual_Fund"     , type: "STRING", tableCode: "BA" },
        "hbay_actual_member"   : { canonical: "hBAy_Actual_Member"   , type: "STRING", tableCode: "BA" },
        "hbay_cont_acct"       : { canonical: "hBAy_Cont_Acct"       , type: "STRING", tableCode: "BA" },
        "hbay_fund"            : { canonical: "hBAy_Fund"            , type: "STRING", tableCode: "BA" },
        "hbay_member"          : { canonical: "hBAy_Member"          , type: "STRING", tableCode: "BA" },
        "hbay_payroll"         : { canonical: "hBAy_Payroll"         , type: "STRING", tableCode: "BA" },
        "hbay_sub_acct"        : { canonical: "hBAy_Sub_Acct"        , type: "STRING", tableCode: "BA" },
        "hbay_sub_sub_acct"    : { canonical: "hBAy_Sub_Sub_Acct"    , type: "STRING", tableCode: "BA" },
    }
};

export default BA;
