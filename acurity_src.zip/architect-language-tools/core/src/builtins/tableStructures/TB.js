/**
 * TB.js — table structure for the TB (Trustee Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "TB").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force TB
 */

/** @type {Object} */
const TB = {
    code: "TB",
    name: "Trustee_Details",
    recordLength: null,
    helpRegistry: "hTB.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "TBi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "htbd_birth"       : { canonical: "hTBd_Birth"       , type: "DATE", tableCode: "TB" },
        "htbd_kyc_supplied": { canonical: "hTBd_KYC_Supplied", type: "DATE", tableCode: "TB" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "htbz_abn"         : { canonical: "hTBz_ABN"         , type: "STRING", tableCode: "TB" },
        "htbz_client"      : { canonical: "hTBz_Client"      , type: "STRING", tableCode: "TB" },
        "htbz_given_names" : { canonical: "hTBz_Given_Names" , type: "STRING", tableCode: "TB" },
        "htbz_kyc_status"  : { canonical: "hTBz_KYC_Status"  , type: "STRING", tableCode: "TB" },
        "htbz_occupation"  : { canonical: "hTBz_Occupation"  , type: "STRING", tableCode: "TB" },
        "htbz_rec_no"      : { canonical: "hTBz_Rec_No"      , type: "STRING", tableCode: "TB" },
        "htbz_spare"       : { canonical: "hTBz_Spare"       , type: "STRING", tableCode: "TB" },
        "htbz_surname"     : { canonical: "hTBz_Surname"     , type: "STRING", tableCode: "TB" },
        "htbz_tax_file_no" : { canonical: "hTBz_Tax_File_No" , type: "STRING", tableCode: "TB" },
        "htbz_title"       : { canonical: "hTBz_Title"       , type: "STRING", tableCode: "TB" },
    }
};

export default TB;
