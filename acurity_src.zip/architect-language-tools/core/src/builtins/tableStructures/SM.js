/**
 * SM.js — table structure for the SM (System Security - Supplementary Fields) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SM").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SM
 */

/** @type {Object} */
const SM = {
    code: "SM",
    name: "System_Security_-_Supplementary_Fields",
    recordLength: null,
    helpRegistry: "hSM.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SMi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hsmd_mod_date"       : { canonical: "hSMd_Mod_Date"       , type: "DATE", tableCode: "SM" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hsmt_mod_time"       : { canonical: "hSMt_Mod_Time"       , type: "TIME", tableCode: "SM" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hsmz_deleted"        : { canonical: "hSMz_Deleted"        , type: "STRING", tableCode: "SM" },
        "hsmz_mod_user"       : { canonical: "hSMz_Mod_User"       , type: "STRING", tableCode: "SM" },
        "hsmz_security_key"   : { canonical: "hSMz_Security_Key"   , type: "STRING", tableCode: "SM" },

        // ── (y-prefix) ──────────────────────────────────────────────────
        "hsmy_supp_flds_sec01": { canonical: "hSMy_Supp_Flds_Sec01", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec02": { canonical: "hSMy_Supp_Flds_Sec02", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec03": { canonical: "hSMy_Supp_Flds_Sec03", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec04": { canonical: "hSMy_Supp_Flds_Sec04", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec05": { canonical: "hSMy_Supp_Flds_Sec05", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec06": { canonical: "hSMy_Supp_Flds_Sec06", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec07": { canonical: "hSMy_Supp_Flds_Sec07", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec08": { canonical: "hSMy_Supp_Flds_Sec08", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec09": { canonical: "hSMy_Supp_Flds_Sec09", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec10": { canonical: "hSMy_Supp_Flds_Sec10", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec11": { canonical: "hSMy_Supp_Flds_Sec11", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec12": { canonical: "hSMy_Supp_Flds_Sec12", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec13": { canonical: "hSMy_Supp_Flds_Sec13", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec14": { canonical: "hSMy_Supp_Flds_Sec14", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec15": { canonical: "hSMy_Supp_Flds_Sec15", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec16": { canonical: "hSMy_Supp_Flds_Sec16", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec17": { canonical: "hSMy_Supp_Flds_Sec17", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec18": { canonical: "hSMy_Supp_Flds_Sec18", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec19": { canonical: "hSMy_Supp_Flds_Sec19", type: "STRING", tableCode: "SM" },
        "hsmy_supp_flds_sec20": { canonical: "hSMy_Supp_Flds_Sec20", type: "STRING", tableCode: "SM" },
    }
};

export default SM;
