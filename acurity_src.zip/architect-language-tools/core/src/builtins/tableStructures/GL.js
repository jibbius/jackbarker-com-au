/**
 * GL.js — table structure for the GL (General Ledger) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "GL").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force GL
 */

/** @type {Object} */
const GL = {
    code: "GL",
    name: "General_Ledger",
    recordLength: null,
    helpRegistry: "hGL.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "GLi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hglc_archived"       : { canonical: "hGLc_Archived"       , type: "STRING", tableCode: "GL" },
        "hglc_leave_total"    : { canonical: "hGLc_Leave_Total"    , type: "STRING", tableCode: "GL" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hgld_effective"      : { canonical: "hGLd_Effective"      , type: "DATE", tableCode: "GL" },
        "hgld_interest"       : { canonical: "hGLd_Interest"       , type: "DATE", tableCode: "GL" },
        "hgld_mod_date"       : { canonical: "hGLd_Mod_Date"       , type: "DATE", tableCode: "GL" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hglf_amount"         : { canonical: "hGLf_Amount"         , type: "DOUBLE", tableCode: "GL" },
        "hglf_total_balance"  : { canonical: "hGLf_Total_Balance"  , type: "DOUBLE", tableCode: "GL" },
        "hglf_total_units"    : { canonical: "hGLf_Total_Units"    , type: "DOUBLE", tableCode: "GL" },
        "hglf_units"          : { canonical: "hGLf_Units"          , type: "DOUBLE", tableCode: "GL" },
        "hglf_ytd_balance"    : { canonical: "hGLf_YTD_Balance"    , type: "DOUBLE", tableCode: "GL" },
        "hglf_ytd_units"      : { canonical: "hGLf_YTD_Units"      , type: "DOUBLE", tableCode: "GL" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hgll_int_trans_ref"  : { canonical: "hGLl_Int_Trans_Ref"  , type: "INTEGER", tableCode: "GL" },
        "hgll_spare"          : { canonical: "hGLl_Spare"          , type: "INTEGER", tableCode: "GL" },
        "hgll_trans_ref"      : { canonical: "hGLl_Trans_Ref"      , type: "INTEGER", tableCode: "GL" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hglt_mod_time"       : { canonical: "hGLt_Mod_Time"       , type: "TIME", tableCode: "GL" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hglz_account"        : { canonical: "hGLz_Account"        , type: "STRING", tableCode: "GL" },
        "hglz_actual_fund"    : { canonical: "hGLz_Actual_Fund"    , type: "STRING", tableCode: "GL" },
        "hglz_actual_member"  : { canonical: "hGLz_Actual_Member"  , type: "STRING", tableCode: "GL" },
        "hglz_cont_acct"      : { canonical: "hGLz_Cont_Acct"      , type: "STRING", tableCode: "GL" },
        "hglz_debit_or_credit": { canonical: "hGLz_Debit_Or_Credit", type: "STRING", tableCode: "GL" },
        "hglz_division"       : { canonical: "hGLz_Division"       , type: "STRING", tableCode: "GL" },
        "hglz_fund"           : { canonical: "hGLz_Fund"           , type: "STRING", tableCode: "GL" },
        "hglz_member"         : { canonical: "hGLz_Member"         , type: "STRING", tableCode: "GL" },
        "hglz_mod_user"       : { canonical: "hGLz_Mod_User"       , type: "STRING", tableCode: "GL" },
        "hglz_preservation"   : { canonical: "hGLz_Preservation"   , type: "STRING", tableCode: "GL" },
        "hglz_spare"          : { canonical: "hGLz_Spare"          , type: "STRING", tableCode: "GL" },
        "hglz_sub_account"    : { canonical: "hGLz_Sub_Account"    , type: "STRING", tableCode: "GL" },
        "hglz_sub_sub_account": { canonical: "hGLz_Sub_Sub_Account", type: "STRING", tableCode: "GL" },
        "hglz_tran_type"      : { canonical: "hGLz_Tran_Type"      , type: "STRING", tableCode: "GL" },
    }
};

export default GL;
