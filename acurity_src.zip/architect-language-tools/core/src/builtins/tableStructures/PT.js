/**
 * PT.js — table structure for the PT (Member Periodical Payments) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PT").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PT
 */

/** @type {Object} */
const PT = {
    code: "PT",
    name: "Member_Periodical_Payments",
    recordLength: null,
    helpRegistry: "hPT.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PTi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hptd_effectove"      : { canonical: "hPTd_Effectove"      , type: "DATE", tableCode: "PT" },
        "hptd_mod_date"       : { canonical: "hPTd_Mod_Date"       , type: "DATE", tableCode: "PT" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hptf_gross_amt"      : { canonical: "hPTf_Gross_Amt"      , type: "DOUBLE", tableCode: "PT" },
        "hptf_net_amount"     : { canonical: "hPTf_Net_Amount"     , type: "DOUBLE", tableCode: "PT" },
        "hptf_paye_tax_amount": { canonical: "hPTf_PAYE_Tax_Amount", type: "DOUBLE", tableCode: "PT" },
        "hptf_rebate_amount"  : { canonical: "hPTf_Rebate_Amount"  , type: "DOUBLE", tableCode: "PT" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hptl_trans_ref"      : { canonical: "hPTl_Trans_Ref"      , type: "INTEGER", tableCode: "PT" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hptt_mod_time"       : { canonical: "hPTt_Mod_Time"       , type: "TIME", tableCode: "PT" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hptz_division"       : { canonical: "hPTz_Division"       , type: "STRING", tableCode: "PT" },
        "hptz_fund"           : { canonical: "hPTz_Fund"           , type: "STRING", tableCode: "PT" },
        "hptz_member"         : { canonical: "hPTz_Member"         , type: "STRING", tableCode: "PT" },
        "hptz_mod_user"       : { canonical: "hPTz_Mod_User"       , type: "STRING", tableCode: "PT" },
        "hptz_spare"          : { canonical: "hPTz_Spare"          , type: "STRING", tableCode: "PT" },
    }
};

export default PT;
