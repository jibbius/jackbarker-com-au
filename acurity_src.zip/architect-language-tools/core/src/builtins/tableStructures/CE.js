/**
 * CE.js — table structure for the CE (Client To Member Relationships) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CE").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CE
 */

/** @type {Object} */
const CE = {
    code: "CE",
    name: "Client_To_Member_Relationships",
    recordLength: null,
    helpRegistry: "hCE.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CEi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcez_client": { canonical: "hCEz_Client", type: "STRING", tableCode: "CE" },
        "hcez_fund"  : { canonical: "hCEz_Fund"  , type: "STRING", tableCode: "CE" },
        "hcez_member": { canonical: "hCEz_Member", type: "STRING", tableCode: "CE" },
        "hcez_spare" : { canonical: "hCEz_Spare" , type: "STRING", tableCode: "CE" },
        "hcez_type"  : { canonical: "hCEz_Type"  , type: "STRING", tableCode: "CE" },
    }
};

export default CE;
