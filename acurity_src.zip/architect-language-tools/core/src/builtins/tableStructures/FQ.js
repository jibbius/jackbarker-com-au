/**
 * FQ.js — table structure for the FQ (Transfer Request Lines) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FQ").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FQ
 */

/** @type {Object} */
const FQ = {
    code: "FQ",
    name: "Transfer_Request_Lines",
    recordLength: null,
    helpRegistry: "hFQ.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FQi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hfqc_context"         : { canonical: "hFQc_Context"         , type: "STRING", tableCode: "FQ" },
        "hfqc_deleted"         : { canonical: "hFQc_Deleted"         , type: "STRING", tableCode: "FQ" },
        "hfqc_payment_line"    : { canonical: "hFQc_Payment_Line"    , type: "STRING", tableCode: "FQ" },
        "hfqc_tfn_provided"    : { canonical: "hFQc_TFN_Provided"    , type: "STRING", tableCode: "FQ" },
        "hfqc_transfer_balance": { canonical: "hFQc_Transfer_Balance", type: "STRING", tableCode: "FQ" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfqd_birth"           : { canonical: "hFQd_Birth"           , type: "DATE", tableCode: "FQ" },
        "hfqd_exit"            : { canonical: "hFQd_Exit"            , type: "DATE", tableCode: "FQ" },
        "hfqd_mod_date"        : { canonical: "hFQd_Mod_Date"        , type: "DATE", tableCode: "FQ" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hfqf_requested_amount": { canonical: "hFQf_Requested_Amount", type: "DOUBLE", tableCode: "FQ" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hfql_batch_reference" : { canonical: "hFQl_Batch_Reference" , type: "INTEGER", tableCode: "FQ" },
        "hfql_file_reg_ref"    : { canonical: "hFQl_File_Reg_Ref"    , type: "INTEGER", tableCode: "FQ" },
        "hfql_line_no"         : { canonical: "hFQl_Line_No"         , type: "INTEGER", tableCode: "FQ" },
        "hfql_line_type"       : { canonical: "hFQl_Line_Type"       , type: "INTEGER", tableCode: "FQ" },
        "hfql_message_code"    : { canonical: "hFQl_Message_Code"    , type: "INTEGER", tableCode: "FQ" },
        "hfql_ms_record_no"    : { canonical: "hFQl_MS_Record_No"    , type: "INTEGER", tableCode: "FQ" },
        "hfql_spare"           : { canonical: "hFQl_Spare"           , type: "INTEGER", tableCode: "FQ" },
        "hfql_trans_ref"       : { canonical: "hFQl_Trans_Ref"       , type: "INTEGER", tableCode: "FQ" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfqt_mod_time"        : { canonical: "hFQt_Mod_Time"        , type: "TIME", tableCode: "FQ" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfqz_client"          : { canonical: "hFQz_Client"          , type: "STRING", tableCode: "FQ" },
        "hfqz_division"        : { canonical: "hFQz_Division"        , type: "STRING", tableCode: "FQ" },
        "hfqz_external_abn"    : { canonical: "hFQz_External_ABN"    , type: "STRING", tableCode: "FQ" },
        "hfqz_external_orgname": { canonical: "hFQz_External_OrgName", type: "STRING", tableCode: "FQ" },
        "hfqz_external_prodid" : { canonical: "hFQz_External_ProdId" , type: "STRING", tableCode: "FQ" },
        "hfqz_externalfundname": { canonical: "hFQz_ExternalFundName", type: "STRING", tableCode: "FQ" },
        "hfqz_externalmemberid": { canonical: "hFQz_ExternalMemberID", type: "STRING", tableCode: "FQ" },
        "hfqz_externalprodname": { canonical: "hFQz_ExternalProdName", type: "STRING", tableCode: "FQ" },
        "hfqz_fund"            : { canonical: "hFQz_Fund"            , type: "STRING", tableCode: "FQ" },
        "hfqz_given_names"     : { canonical: "hFQz_Given_Names"     , type: "STRING", tableCode: "FQ" },
        "hfqz_match_memberid"  : { canonical: "hFQz_Match_MemberID"  , type: "STRING", tableCode: "FQ" },
        "hfqz_matching_abn"    : { canonical: "hFQz_Matching_ABN"    , type: "STRING", tableCode: "FQ" },
        "hfqz_matching_prodid" : { canonical: "hFQz_Matching_ProdId" , type: "STRING", tableCode: "FQ" },
        "hfqz_member"          : { canonical: "hFQz_Member"          , type: "STRING", tableCode: "FQ" },
        "hfqz_mod_user"        : { canonical: "hFQz_Mod_User"        , type: "STRING", tableCode: "FQ" },
        "hfqz_payroll"         : { canonical: "hFQz_Payroll"         , type: "STRING", tableCode: "FQ" },
        "hfqz_payroll_name"    : { canonical: "hFQz_Payroll_Name"    , type: "STRING", tableCode: "FQ" },
        "hfqz_payroll_no"      : { canonical: "hFQz_Payroll_No"      , type: "STRING", tableCode: "FQ" },
        "hfqz_reject_reason"   : { canonical: "hFQz_Reject_Reason"   , type: "STRING", tableCode: "FQ" },
        "hfqz_sex"             : { canonical: "hFQz_Sex"             , type: "STRING", tableCode: "FQ" },
        "hfqz_spare"           : { canonical: "hFQz_Spare"           , type: "STRING", tableCode: "FQ" },
        "hfqz_status"          : { canonical: "hFQz_Status"          , type: "STRING", tableCode: "FQ" },
        "hfqz_supplied_acc_ref": { canonical: "hFQz_Supplied_Acc_Ref", type: "STRING", tableCode: "FQ" },
        "hfqz_surname"         : { canonical: "hFQz_Surname"         , type: "STRING", tableCode: "FQ" },
        "hfqz_tax_file_no"     : { canonical: "hFQz_Tax_File_No"     , type: "STRING", tableCode: "FQ" },
        "hfqz_title"           : { canonical: "hFQz_Title"           , type: "STRING", tableCode: "FQ" },
        "hfqz_user_def_flags01": { canonical: "hFQz_User_Def_Flags01", type: "STRING", tableCode: "FQ" },
        "hfqz_user_def_flags02": { canonical: "hFQz_User_Def_Flags02", type: "STRING", tableCode: "FQ" },
        "hfqz_user_def_flags03": { canonical: "hFQz_User_Def_Flags03", type: "STRING", tableCode: "FQ" },
        "hfqz_user_def_flags04": { canonical: "hFQz_User_Def_Flags04", type: "STRING", tableCode: "FQ" },

        // ── (v-prefix) ──────────────────────────────────────────────────
        "hfqv_contextmemberid" : { canonical: "hFQv_ContextMemberID" , type: "VARSTRING", tableCode: "FQ" },
        "hfqv_lost_member"     : { canonical: "hFQv_Lost_Member"     , type: "VARSTRING", tableCode: "FQ" },
        "hfqv_rlvrcontextid"   : { canonical: "hFQv_RlvrContextID"   , type: "VARSTRING", tableCode: "FQ" },
    }
};

export default FQ;
