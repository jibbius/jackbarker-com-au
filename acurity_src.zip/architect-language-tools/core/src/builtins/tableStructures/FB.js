/**
 * FB.js — table structure for the FB (Fee Calculation Bases) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FB").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FB
 */

/** @type {Object} */
const FB = {
    code: "FB",
    name: "Fee_Calculation_Bases",
    recordLength: null,
    helpRegistry: "hFB.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FBi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfbd_effective"      : { canonical: "hFBd_Effective"      , type: "DATE", tableCode: "FB" },
        "hfbd_mod_date"       : { canonical: "hFBd_Mod_Date"       , type: "DATE", tableCode: "FB" },
        "hfbd_spare"          : { canonical: "hFBd_Spare"          , type: "DATE", tableCode: "FB" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hfbf_nonded_premrate": { canonical: "hFBf_NonDed_PremRate", type: "DOUBLE", tableCode: "FB" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hfbs_formula_code"   : { canonical: "hFBs_Formula_Code"   , type: "INTEGER", tableCode: "FB" },
        "hfbs_spare01"        : { canonical: "hFBs_Spare01"        , type: "INTEGER", tableCode: "FB" },
        "hfbs_spare02"        : { canonical: "hFBs_Spare02"        , type: "INTEGER", tableCode: "FB" },
        "hfbs_spare03"        : { canonical: "hFBs_Spare03"        , type: "INTEGER", tableCode: "FB" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfbt_mod_time"       : { canonical: "hFBt_Mod_Time"       , type: "TIME", tableCode: "FB" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfbz_broker"         : { canonical: "hFBz_Broker"         , type: "STRING", tableCode: "FB" },
        "hfbz_category"       : { canonical: "hFBz_Category"       , type: "STRING", tableCode: "FB" },
        "hfbz_code"           : { canonical: "hFBz_Code"           , type: "STRING", tableCode: "FB" },
        "hfbz_deleted"        : { canonical: "hFBz_Deleted"        , type: "STRING", tableCode: "FB" },
        "hfbz_division"       : { canonical: "hFBz_Division"       , type: "STRING", tableCode: "FB" },
        "hfbz_fund"           : { canonical: "hFBz_Fund"           , type: "STRING", tableCode: "FB" },
        "hfbz_member"         : { canonical: "hFBz_Member"         , type: "STRING", tableCode: "FB" },
        "hfbz_mod_user"       : { canonical: "hFBz_Mod_User"       , type: "STRING", tableCode: "FB" },
        "hfbz_payroll"        : { canonical: "hFBz_Payroll"        , type: "STRING", tableCode: "FB" },
        "hfbz_spare"          : { canonical: "hFBz_Spare"          , type: "STRING", tableCode: "FB" },
    }
};

export default FB;
