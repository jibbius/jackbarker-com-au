/**
 * SR.js — table structure for the SR (Service Request Form) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SR").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SR
 */

/** @type {Object} */
const SR = {
    code: "SR",
    name: "Service_Request_Form",
    recordLength: null,
    helpRegistry: "hSR.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SRi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hsrc_nw_platform"     : { canonical: "hSRc_NW_Platform"     , type: "STRING", tableCode: "SR" },
        "hsrc_pc_platform"     : { canonical: "hSRc_PC_Platform"     , type: "STRING", tableCode: "SR" },
        "hsrc_printer"         : { canonical: "hSRc_Printer"         , type: "STRING", tableCode: "SR" },
        "hsrc_request"         : { canonical: "hSRc_Request"         , type: "STRING", tableCode: "SR" },
        "hsrc_severity"        : { canonical: "hSRc_Severity"        , type: "STRING", tableCode: "SR" },
        "hsrc_stage"           : { canonical: "hSRc_Stage"           , type: "STRING", tableCode: "SR" },
        "hsrc_status"          : { canonical: "hSRc_Status"          , type: "STRING", tableCode: "SR" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hsrd_mod_date"        : { canonical: "hSRd_Mod_Date"        , type: "DATE", tableCode: "SR" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hsrl_client_ref"      : { canonical: "hSRl_Client_Ref"      , type: "INTEGER", tableCode: "SR" },
        "hsrl_fin_syn_ref"     : { canonical: "hSRl_Fin_Syn_Ref"     , type: "INTEGER", tableCode: "SR" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hsrt_mod_time"        : { canonical: "hSRt_Mod_Time"        , type: "TIME", tableCode: "SR" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hsrz_accounting_tran" : { canonical: "hSRz_Accounting_Tran" , type: "STRING", tableCode: "SR" },
        "hsrz_acct_executive"  : { canonical: "hSRz_Acct_Executive"  , type: "STRING", tableCode: "SR" },
        "hsrz_c_name"          : { canonical: "hSRz_C_Name"          , type: "STRING", tableCode: "SR" },
        "hsrz_c_phone"         : { canonical: "hSRz_C_Phone"         , type: "STRING", tableCode: "SR" },
        "hsrz_company_name"    : { canonical: "hSRz_Company_Name"    , type: "STRING", tableCode: "SR" },
        "hsrz_division"        : { canonical: "hSRz_Division"        , type: "STRING", tableCode: "SR" },
        "hsrz_mod_user"        : { canonical: "hSRz_Mod_User"        , type: "STRING", tableCode: "SR" },
        "hsrz_old_home_phone"  : { canonical: "hSRz_Old_Home_Phone"  , type: "STRING", tableCode: "SR" },
        "hsrz_report_code"     : { canonical: "hSRz_Report_Code"     , type: "STRING", tableCode: "SR" },
        "hsrz_report_date_init": { canonical: "hSRz_Report_Date_Init", type: "STRING", tableCode: "SR" },
        "hsrz_report_group"    : { canonical: "hSRz_Report_Group"    , type: "STRING", tableCode: "SR" },
        "hsrz_screen_code"     : { canonical: "hSRz_Screen_Code"     , type: "STRING", tableCode: "SR" },
        "hsrz_short_desc"      : { canonical: "hSRz_Short_Desc"      , type: "STRING", tableCode: "SR" },
        "hsrz_spare"           : { canonical: "hSRz_Spare"           , type: "STRING", tableCode: "SR" },
        "hsrz_sr_number"       : { canonical: "hSRz_SR_Number"       , type: "STRING", tableCode: "SR" },
        "hsrz_state"           : { canonical: "hSRz_State"           , type: "STRING", tableCode: "SR" },
        "hsrz_version_datetime": { canonical: "hSRz_Version_DateTime", type: "STRING", tableCode: "SR" },
    }
};

export default SR;
