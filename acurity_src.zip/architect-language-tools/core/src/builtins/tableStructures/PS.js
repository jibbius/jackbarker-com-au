/**
 * PS.js — table structure for the PS (Publishing Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PS").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PS
 */

/** @type {Object} */
const PS = {
    code: "PS",
    name: "Publishing_Details",
    recordLength: null,
    helpRegistry: "hPS.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PSi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hpsc_division"      : { canonical: "hPSc_Division"      , type: "STRING", tableCode: "PS" },
        "hpsc_published"     : { canonical: "hPSc_Published"     , type: "STRING", tableCode: "PS" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hpsd_mod_date"      : { canonical: "hPSd_Mod_Date"      , type: "DATE", tableCode: "PS" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hpsl_documentid"    : { canonical: "hPSl_DocumentID"    , type: "INTEGER", tableCode: "PS" },
        "hpsl_spare"         : { canonical: "hPSl_Spare"         , type: "INTEGER", tableCode: "PS" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hpst_mod_time"      : { canonical: "hPSt_Mod_Time"      , type: "TIME", tableCode: "PS" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hpsz_adviser"       : { canonical: "hPSz_Adviser"       , type: "STRING", tableCode: "PS" },
        "hpsz_clientid"      : { canonical: "hPSz_ClientID"      , type: "STRING", tableCode: "PS" },
        "hpsz_company"       : { canonical: "hPSz_Company"       , type: "STRING", tableCode: "PS" },
        "hpsz_databasecode"  : { canonical: "hPSz_DatabaseCode"  , type: "STRING", tableCode: "PS" },
        "hpsz_docdescription": { canonical: "hPSz_DocDescription", type: "STRING", tableCode: "PS" },
        "hpsz_docextension"  : { canonical: "hPSz_DocExtension"  , type: "STRING", tableCode: "PS" },
        "hpsz_doctype"       : { canonical: "hPSz_DocType"       , type: "STRING", tableCode: "PS" },
        "hpsz_entitytype"    : { canonical: "hPSz_EntityType"    , type: "STRING", tableCode: "PS" },
        "hpsz_fund"          : { canonical: "hPSz_Fund"          , type: "STRING", tableCode: "PS" },
        "hpsz_insurer"       : { canonical: "hPSz_Insurer"       , type: "STRING", tableCode: "PS" },
        "hpsz_invmgr"        : { canonical: "hPSz_Invmgr"        , type: "STRING", tableCode: "PS" },
        "hpsz_member"        : { canonical: "hPSz_Member"        , type: "STRING", tableCode: "PS" },
        "hpsz_mod_user"      : { canonical: "hPSz_Mod_User"      , type: "STRING", tableCode: "PS" },
        "hpsz_payee"         : { canonical: "hPSz_Payee"         , type: "STRING", tableCode: "PS" },
        "hpsz_userid"        : { canonical: "hPSz_UserID"        , type: "STRING", tableCode: "PS" },
    }
};

export default PS;
