/**
 * MU.js — table structure for the MU (Multiple Cheques) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "MU").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force MU
 */

/** @type {Object} */
const MU = {
    code: "MU",
    name: "Multiple_Cheques",
    recordLength: null,
    helpRegistry: "hMU.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "MUi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hmud_mod_date"       : { canonical: "hMUd_Mod_Date"       , type: "DATE", tableCode: "MU" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hmuf_cheque_amount01": { canonical: "hMUf_Cheque_Amount01", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount02": { canonical: "hMUf_Cheque_Amount02", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount03": { canonical: "hMUf_Cheque_Amount03", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount04": { canonical: "hMUf_Cheque_Amount04", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount05": { canonical: "hMUf_Cheque_Amount05", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount06": { canonical: "hMUf_Cheque_Amount06", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount07": { canonical: "hMUf_Cheque_Amount07", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount08": { canonical: "hMUf_Cheque_Amount08", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount09": { canonical: "hMUf_Cheque_Amount09", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount10": { canonical: "hMUf_Cheque_Amount10", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount11": { canonical: "hMUf_Cheque_Amount11", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount12": { canonical: "hMUf_Cheque_Amount12", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount13": { canonical: "hMUf_Cheque_Amount13", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount14": { canonical: "hMUf_Cheque_Amount14", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount15": { canonical: "hMUf_Cheque_Amount15", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount16": { canonical: "hMUf_Cheque_Amount16", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount17": { canonical: "hMUf_Cheque_Amount17", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount18": { canonical: "hMUf_Cheque_Amount18", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount19": { canonical: "hMUf_Cheque_Amount19", type: "DOUBLE", tableCode: "MU" },
        "hmuf_cheque_amount20": { canonical: "hMUf_Cheque_Amount20", type: "DOUBLE", tableCode: "MU" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hmul_cheque_ref_no"  : { canonical: "hMUl_Cheque_Ref_No"  , type: "INTEGER", tableCode: "MU" },
        "hmul_trans_ref"      : { canonical: "hMUl_Trans_Ref"      , type: "INTEGER", tableCode: "MU" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hmus_record_no"      : { canonical: "hMUs_Record_No"      , type: "INTEGER", tableCode: "MU" },
        "hmus_spare01"        : { canonical: "hMUs_Spare01"        , type: "INTEGER", tableCode: "MU" },
        "hmus_spare02"        : { canonical: "hMUs_Spare02"        , type: "INTEGER", tableCode: "MU" },
        "hmus_spare03"        : { canonical: "hMUs_Spare03"        , type: "INTEGER", tableCode: "MU" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hmut_mod_time"       : { canonical: "hMUt_Mod_Time"       , type: "TIME", tableCode: "MU" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hmuz_cheque_no01"    : { canonical: "hMUz_Cheque_No01"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no02"    : { canonical: "hMUz_Cheque_No02"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no03"    : { canonical: "hMUz_Cheque_No03"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no04"    : { canonical: "hMUz_Cheque_No04"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no05"    : { canonical: "hMUz_Cheque_No05"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no06"    : { canonical: "hMUz_Cheque_No06"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no07"    : { canonical: "hMUz_Cheque_No07"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no08"    : { canonical: "hMUz_Cheque_No08"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no09"    : { canonical: "hMUz_Cheque_No09"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no10"    : { canonical: "hMUz_Cheque_No10"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no11"    : { canonical: "hMUz_Cheque_No11"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no12"    : { canonical: "hMUz_Cheque_No12"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no13"    : { canonical: "hMUz_Cheque_No13"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no14"    : { canonical: "hMUz_Cheque_No14"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no15"    : { canonical: "hMUz_Cheque_No15"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no16"    : { canonical: "hMUz_Cheque_No16"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no17"    : { canonical: "hMUz_Cheque_No17"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no18"    : { canonical: "hMUz_Cheque_No18"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no19"    : { canonical: "hMUz_Cheque_No19"    , type: "STRING", tableCode: "MU" },
        "hmuz_cheque_no20"    : { canonical: "hMUz_Cheque_No20"    , type: "STRING", tableCode: "MU" },
        "hmuz_division"       : { canonical: "hMUz_Division"       , type: "STRING", tableCode: "MU" },
        "hmuz_mod_user"       : { canonical: "hMUz_Mod_User"       , type: "STRING", tableCode: "MU" },
        "hmuz_spare"          : { canonical: "hMUz_Spare"          , type: "STRING", tableCode: "MU" },
    }
};

export default MU;
