/**
 * CS.js — table structure for the CS (Contribution Accounts) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CS").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CS
 */

/** @type {Object} */
const CS = {
    code: "CS",
    name: "Contribution_Accounts",
    recordLength: null,
    helpRegistry: "hCS.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CSi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hcsc_allow_wdls"      : { canonical: "hCSc_Allow_Wdls"      , type: "STRING", tableCode: "CS" },
        "hcsc_auto_invest"     : { canonical: "hCSc_Auto_Invest"     , type: "STRING", tableCode: "CS" },
        "hcsc_cont_tax"        : { canonical: "hCSc_Cont_Tax"        , type: "STRING", tableCode: "CS" },
        "hcsc_liability_level" : { canonical: "hCSc_Liability_Level" , type: "STRING", tableCode: "CS" },
        "hcsc_no_conts_dispd"  : { canonical: "hCSc_NO_Conts_Dispd"  , type: "STRING", tableCode: "CS" },
        "hcsc_protected_acct"  : { canonical: "hCSc_Protected_Acct"  , type: "STRING", tableCode: "CS" },
        "hcsc_surcharge"       : { canonical: "hCSc_Surcharge"       , type: "STRING", tableCode: "CS" },
        "hcsc_suspend"         : { canonical: "hCSc_Suspend"         , type: "STRING", tableCode: "CS" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hcsd_mod_date"        : { canonical: "hCSd_Mod_Date"        , type: "DATE", tableCode: "CS" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hcsf_cont_fld_a"      : { canonical: "hCSf_Cont_Fld_A"      , type: "DOUBLE", tableCode: "CS" },
        "hcsf_cont_fld_b"      : { canonical: "hCSf_Cont_Fld_B"      , type: "DOUBLE", tableCode: "CS" },
        "hcsf_cont_fld_c"      : { canonical: "hCSf_Cont_Fld_C"      , type: "DOUBLE", tableCode: "CS" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hcss_conts_based_den" : { canonical: "hCSs_Conts_Based_Den" , type: "INTEGER", tableCode: "CS" },
        "hcss_conts_based_no"  : { canonical: "hCSs_Conts_Based_No"  , type: "INTEGER", tableCode: "CS" },
        "hcss_process_order"   : { canonical: "hCSs_Process_Order"   , type: "INTEGER", tableCode: "CS" },
        "hcss_spare"           : { canonical: "hCSs_Spare"           , type: "INTEGER", tableCode: "CS" },
        "hcss_swimec_order"    : { canonical: "hCSs_SwimEC_Order"    , type: "INTEGER", tableCode: "CS" },
        "hcss_unpres_method"   : { canonical: "hCSs_Unpres_Method"   , type: "INTEGER", tableCode: "CS" },
        "hcss_vested_method"   : { canonical: "hCSs_Vested_Method"   , type: "INTEGER", tableCode: "CS" },
        "hcss_withdrawal_order": { canonical: "hCSs_Withdrawal_Order", type: "INTEGER", tableCode: "CS" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hcst_mod_time"        : { canonical: "hCSt_Mod_Time"        , type: "TIME", tableCode: "CS" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcsz_active"          : { canonical: "hCSz_Active"          , type: "STRING", tableCode: "CS" },
        "hcsz_cont_desc"       : { canonical: "hCSz_Cont_Desc"       , type: "STRING", tableCode: "CS" },
        "hcsz_cont_field_table": { canonical: "hCSz_Cont_Field_Table", type: "STRING", tableCode: "CS" },
        "hcsz_conts_based_acct": { canonical: "hCSz_Conts_Based_Acct", type: "STRING", tableCode: "CS" },
        "hcsz_fee_deduction"   : { canonical: "hCSz_Fee_Deduction"   , type: "STRING", tableCode: "CS" },
        "hcsz_formula_code"    : { canonical: "hCSz_Formula_Code"    , type: "STRING", tableCode: "CS" },
        "hcsz_glp_deduction"   : { canonical: "hCSz_GLP_Deduction"   , type: "STRING", tableCode: "CS" },
        "hcsz_heading1"        : { canonical: "hCSz_Heading1"        , type: "STRING", tableCode: "CS" },
        "hcsz_heading2"        : { canonical: "hCSz_Heading2"        , type: "STRING", tableCode: "CS" },
        "hcsz_heading3"        : { canonical: "hCSz_Heading3"        , type: "STRING", tableCode: "CS" },
        "hcsz_interest_method" : { canonical: "hCSz_Interest_Method" , type: "STRING", tableCode: "CS" },
        "hcsz_interest_type"   : { canonical: "hCSz_Interest_Type"   , type: "STRING", tableCode: "CS" },
        "hcsz_ledger_account"  : { canonical: "hCSz_Ledger_Account"  , type: "STRING", tableCode: "CS" },
        "hcsz_mbr_cont_accts"  : { canonical: "hCSz_Mbr_Cont_Accts"  , type: "STRING", tableCode: "CS" },
        "hcsz_mod_user"        : { canonical: "hCSz_Mod_User"        , type: "STRING", tableCode: "CS" },
        "hcsz_preserved"       : { canonical: "hCSz_Preserved"       , type: "STRING", tableCode: "CS" },
        "hcsz_set_no"          : { canonical: "hCSz_Set_No"          , type: "STRING", tableCode: "CS" },
        "hcsz_short_desc"      : { canonical: "hCSz_Short_Desc"      , type: "STRING", tableCode: "CS" },
        "hcsz_spare"           : { canonical: "hCSz_Spare"           , type: "STRING", tableCode: "CS" },
        "hcsz_taxable"         : { canonical: "hCSz_Taxable"         , type: "STRING", tableCode: "CS" },
        "hcsz_tran"            : { canonical: "hCSz_Tran"            , type: "STRING", tableCode: "CS" },
    }
};

export default CS;
