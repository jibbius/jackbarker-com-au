/**
 * CD.js — table structure for the CD (Codes and Descriptions) table.
 *
 * Indexes: sourced from authoritative schema data.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CD").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structure.js CD
 */

/** @type {Object} */
const CD = {
    code: "CD",
    name: "Description_Codes",
    recordLength: 168,
    helpRegistry: "hCD.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CDi_Identity", type: "BIGINT", length: 8 }
            ]
        },
        {
            name: "0",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CDz_Group",            type: "ZSTRING", length: 3 },
                { position: 1, field: "CDz_Description_Type", type: "ZSTRING", length: 3 }
            ]
        }
    ],
    fields: {
        "hcdc_cheque_book":      { canonical: "hCDc_Cheque_Book",      type: "STRING", tableCode: "CD" },
        "hcdc_deleted":          { canonical: "hCDc_Deleted",           type: "STRING", tableCode: "CD" },
        "hcdc_flag":             { canonical: "hCDc_Flag",              type: "STRING", tableCode: "CD" },
        "hcdc_hide_options01":   { canonical: "hCDc_Hide_Options01",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options02":   { canonical: "hCDc_Hide_Options02",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options03":   { canonical: "hCDc_Hide_Options03",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options04":   { canonical: "hCDc_Hide_Options04",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options05":   { canonical: "hCDc_Hide_Options05",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options06":   { canonical: "hCDc_Hide_Options06",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options07":   { canonical: "hCDc_Hide_Options07",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options08":   { canonical: "hCDc_Hide_Options08",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options09":   { canonical: "hCDc_Hide_Options09",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options10":   { canonical: "hCDc_Hide_Options10",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options11":   { canonical: "hCDc_Hide_Options11",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options12":   { canonical: "hCDc_Hide_Options12",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options13":   { canonical: "hCDc_Hide_Options13",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options14":   { canonical: "hCDc_Hide_Options14",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options15":   { canonical: "hCDc_Hide_Options15",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options16":   { canonical: "hCDc_Hide_Options16",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options17":   { canonical: "hCDc_Hide_Options17",    type: "STRING", tableCode: "CD" },
        "hcdc_hide_options18":   { canonical: "hCDc_Hide_Options18",    type: "STRING", tableCode: "CD" },
        "hcdc_receipting_tran":  { canonical: "hCDc_Receipting_Tran",   type: "STRING", tableCode: "CD" },
        "hcdc_wild_card_1":      { canonical: "hCDc_Wild_Card_1",       type: "STRING", tableCode: "CD" },
        "hcdc_wild_card_2":      { canonical: "hCDc_Wild_Card_2",       type: "STRING", tableCode: "CD" },
        "hcdc_wild_card_3":      { canonical: "hCDc_Wild_Card_3",       type: "STRING", tableCode: "CD" },
        "hcdz_description":      { canonical: "hCDz_Description",       type: "STRING", tableCode: "CD" },
        "hcdz_description_code": { canonical: "hCDz_Description_Code",  type: "STRING", tableCode: "CD" },
        "hcdz_description_type": { canonical: "hCDz_Description_Type",  type: "STRING", tableCode: "CD" },
        "hcdz_display_order":    { canonical: "hCDz_Display_Order",     type: "STRING", tableCode: "CD" },
        "hcdz_group":            { canonical: "hCDz_Group",             type: "STRING", tableCode: "CD" },
        "hcdz_security_levels":  { canonical: "hCDz_Security_Levels",   type: "STRING", tableCode: "CD" },
        "hcdz_spare":            { canonical: "hCDz_Spare",             type: "STRING", tableCode: "CD" }
    }
};

export default CD;
