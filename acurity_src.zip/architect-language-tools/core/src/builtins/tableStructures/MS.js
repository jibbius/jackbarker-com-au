/**
 * MS.js — table structure for the MS (Message History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "MS").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force MS
 */

/** @type {Object} */
const MS = {
    code: "MS",
    name: "Message_History",
    recordLength: null,
    helpRegistry: "hMS.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "MSi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hmsc_deleted"         : { canonical: "hMSc_Deleted"         , type: "STRING", tableCode: "MS" },
        "hmsc_payment_line"    : { canonical: "hMSc_Payment_Line"    , type: "STRING", tableCode: "MS" },
        "hmsc_transfer_balance": { canonical: "hMSc_Transfer_Balance", type: "STRING", tableCode: "MS" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hmsd_creation"        : { canonical: "hMSd_Creation"        , type: "DATE", tableCode: "MS" },
        "hmsd_exit"            : { canonical: "hMSd_Exit"            , type: "DATE", tableCode: "MS" },
        "hmsd_mod_date"        : { canonical: "hMSd_Mod_Date"        , type: "DATE", tableCode: "MS" },
        "hmsd_sent"            : { canonical: "hMSd_Sent"            , type: "DATE", tableCode: "MS" },
        "hmsd_spare"           : { canonical: "hMSd_Spare"           , type: "DATE", tableCode: "MS" },
        "hmsd_status_change"   : { canonical: "hMSd_Status_Change"   , type: "DATE", tableCode: "MS" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hmsf_total"           : { canonical: "hMSf_Total"           , type: "DOUBLE", tableCode: "MS" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hmsl_file_reg_ref"    : { canonical: "hMSl_File_Reg_Ref"    , type: "INTEGER", tableCode: "MS" },
        "hmsl_job_ref"         : { canonical: "hMSl_Job_Ref"         , type: "INTEGER", tableCode: "MS" },
        "hmsl_line_no"         : { canonical: "hMSl_Line_No"         , type: "INTEGER", tableCode: "MS" },
        "hmsl_message_code"    : { canonical: "hMSl_Message_Code"    , type: "INTEGER", tableCode: "MS" },
        "hmsl_record_no"       : { canonical: "hMSl_Record_No"       , type: "INTEGER", tableCode: "MS" },
        "hmsl_spare"           : { canonical: "hMSl_Spare"           , type: "INTEGER", tableCode: "MS" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hmss_sequence"        : { canonical: "hMSs_Sequence"        , type: "INTEGER", tableCode: "MS" },
        "hmss_spare01"         : { canonical: "hMSs_Spare01"         , type: "INTEGER", tableCode: "MS" },
        "hmss_spare02"         : { canonical: "hMSs_Spare02"         , type: "INTEGER", tableCode: "MS" },
        "hmss_spare03"         : { canonical: "hMSs_Spare03"         , type: "INTEGER", tableCode: "MS" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hmst_creation"        : { canonical: "hMSt_Creation"        , type: "TIME", tableCode: "MS" },
        "hmst_mod_time"        : { canonical: "hMSt_Mod_Time"        , type: "TIME", tableCode: "MS" },
        "hmst_sent"            : { canonical: "hMSt_Sent"            , type: "TIME", tableCode: "MS" },
        "hmst_status_change"   : { canonical: "hMSt_Status_Change"   , type: "TIME", tableCode: "MS" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hmsz_bank_st_ref"     : { canonical: "hMSz_Bank_St_Ref"     , type: "STRING", tableCode: "MS" },
        "hmsz_biller_code"     : { canonical: "hMSz_Biller_Code"     , type: "STRING", tableCode: "MS" },
        "hmsz_conversationid"  : { canonical: "hMSz_ConversationID"  , type: "STRING", tableCode: "MS" },
        "hmsz_elerrormessaging": { canonical: "hMSz_ElErrorMessaging", type: "STRING", tableCode: "MS" },
        "hmsz_fund"            : { canonical: "hMSz_Fund"            , type: "STRING", tableCode: "MS" },
        "hmsz_member"          : { canonical: "hMSz_Member"          , type: "STRING", tableCode: "MS" },
        "hmsz_memberid"        : { canonical: "hMSz_MemberID"        , type: "STRING", tableCode: "MS" },
        "hmsz_message_in_out"  : { canonical: "hMSz_Message_In_Out"  , type: "STRING", tableCode: "MS" },
        "hmsz_message_type"    : { canonical: "hMSz_Message_Type"    , type: "STRING", tableCode: "MS" },
        "hmsz_mod_user"        : { canonical: "hMSz_Mod_User"        , type: "STRING", tableCode: "MS" },
        "hmsz_orgname"         : { canonical: "hMSz_OrgName"         , type: "STRING", tableCode: "MS" },
        "hmsz_partid"          : { canonical: "hMSz_PartID"          , type: "STRING", tableCode: "MS" },
        "hmsz_paybankacctname" : { canonical: "hMSz_PayBankAcctName" , type: "STRING", tableCode: "MS" },
        "hmsz_paybankacctno"   : { canonical: "hMSz_PayBankAcctNo"   , type: "STRING", tableCode: "MS" },
        "hmsz_payeeaustbusno"  : { canonical: "hMSz_PayeeAustBusNo"  , type: "STRING", tableCode: "MS" },
        "hmsz_payeebankactname": { canonical: "hMSz_PayeeBankActName", type: "STRING", tableCode: "MS" },
        "hmsz_payeebankactno"  : { canonical: "hMSz_PayeeBankActNo"  , type: "STRING", tableCode: "MS" },
        "hmsz_payeebsb"        : { canonical: "hMSz_PayeeBSB"        , type: "STRING", tableCode: "MS" },
        "hmsz_payeeprodid"     : { canonical: "hMSz_PayeeProdID"     , type: "STRING", tableCode: "MS" },
        "hmsz_paymentaustbusno": { canonical: "hMSz_PaymentAustBusNo", type: "STRING", tableCode: "MS" },
        "hmsz_paymentbsb"      : { canonical: "hMSz_PaymentBSB"      , type: "STRING", tableCode: "MS" },
        "hmsz_paymentorgname"  : { canonical: "hMSz_PaymentOrgName"  , type: "STRING", tableCode: "MS" },
        "hmsz_product_name"    : { canonical: "hMSz_Product_Name"    , type: "STRING", tableCode: "MS" },
        "hmsz_rcvaustbusno"    : { canonical: "hMSz_RcvAustBusNo"    , type: "STRING", tableCode: "MS" },
        "hmsz_rcvprodid"       : { canonical: "hMSz_RcvProdID"       , type: "STRING", tableCode: "MS" },
        "hmsz_response"        : { canonical: "hMSz_Response"        , type: "STRING", tableCode: "MS" },
        "hmsz_sndaustbusno"    : { canonical: "hMSz_SndAustBusNo"    , type: "STRING", tableCode: "MS" },
        "hmsz_sndemail"        : { canonical: "hMSz_SndEmail"        , type: "STRING", tableCode: "MS" },
        "hmsz_sndgiven_names"  : { canonical: "hMSz_SndGiven_Names"  , type: "STRING", tableCode: "MS" },
        "hmsz_sndmobile_phone" : { canonical: "hMSz_SndMobile_Phone" , type: "STRING", tableCode: "MS" },
        "hmsz_sndphone"        : { canonical: "hMSz_SndPhone"        , type: "STRING", tableCode: "MS" },
        "hmsz_sndprodid"       : { canonical: "hMSz_SndProdID"       , type: "STRING", tableCode: "MS" },
        "hmsz_sndsurname"      : { canonical: "hMSz_SndSurname"      , type: "STRING", tableCode: "MS" },
        "hmsz_spare"           : { canonical: "hMSz_Spare"           , type: "STRING", tableCode: "MS" },
        "hmsz_status"          : { canonical: "hMSz_Status"          , type: "STRING", tableCode: "MS" },
        "hmsz_status_user"     : { canonical: "hMSz_Status_User"     , type: "STRING", tableCode: "MS" },
        "hmsz_supplied_trn_ref": { canonical: "hMSz_Supplied_Trn_Ref", type: "STRING", tableCode: "MS" },

        // ── (v-prefix) ──────────────────────────────────────────────────
        "hmsv_payeecontextid"  : { canonical: "hMSv_PayeeContextID"  , type: "VARSTRING", tableCode: "MS" },
        "hmsv_paymentcontextid": { canonical: "hMSv_PaymentContextID", type: "VARSTRING", tableCode: "MS" },
        "hmsv_receivecontextid": { canonical: "hMSv_ReceiveContextID", type: "VARSTRING", tableCode: "MS" },
        "hmsv_sendercontextid" : { canonical: "hMSv_SenderContextID" , type: "VARSTRING", tableCode: "MS" },
        "hmsv_srcelserviceaddr": { canonical: "hMSv_SrcElServiceAddr", type: "VARSTRING", tableCode: "MS" },
        "hmsv_tgtelserviceaddr": { canonical: "hMSv_TgtElServiceAddr", type: "VARSTRING", tableCode: "MS" },
    }
};

export default MS;
