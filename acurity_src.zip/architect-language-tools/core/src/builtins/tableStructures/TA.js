/**
 * TA.js — table structure for the TA (Tax Table History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "TA").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force TA
 */

/** @type {Object} */
const TA = {
    code: "TA",
    name: "Tax_Table_History",
    recordLength: null,
    helpRegistry: "hTA.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "TAi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "htac_table_no"   : { canonical: "hTAc_Table_No"   , type: "STRING", tableCode: "TA" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "htad_effective"  : { canonical: "hTAd_Effective"  , type: "DATE", tableCode: "TA" },
        "htad_mod_date"   : { canonical: "hTAd_Mod_Date"   , type: "DATE", tableCode: "TA" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "htaf_tax_table01": { canonical: "hTAf_Tax_Table01", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table02": { canonical: "hTAf_Tax_Table02", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table03": { canonical: "hTAf_Tax_Table03", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table04": { canonical: "hTAf_Tax_Table04", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table05": { canonical: "hTAf_Tax_Table05", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table06": { canonical: "hTAf_Tax_Table06", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table07": { canonical: "hTAf_Tax_Table07", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table08": { canonical: "hTAf_Tax_Table08", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table09": { canonical: "hTAf_Tax_Table09", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table10": { canonical: "hTAf_Tax_Table10", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table11": { canonical: "hTAf_Tax_Table11", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table12": { canonical: "hTAf_Tax_Table12", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table13": { canonical: "hTAf_Tax_Table13", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table14": { canonical: "hTAf_Tax_Table14", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table15": { canonical: "hTAf_Tax_Table15", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table16": { canonical: "hTAf_Tax_Table16", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table17": { canonical: "hTAf_Tax_Table17", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table18": { canonical: "hTAf_Tax_Table18", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table19": { canonical: "hTAf_Tax_Table19", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table20": { canonical: "hTAf_Tax_Table20", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table21": { canonical: "hTAf_Tax_Table21", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table22": { canonical: "hTAf_Tax_Table22", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table23": { canonical: "hTAf_Tax_Table23", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table24": { canonical: "hTAf_Tax_Table24", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table25": { canonical: "hTAf_Tax_Table25", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table26": { canonical: "hTAf_Tax_Table26", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table27": { canonical: "hTAf_Tax_Table27", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table28": { canonical: "hTAf_Tax_Table28", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table29": { canonical: "hTAf_Tax_Table29", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table30": { canonical: "hTAf_Tax_Table30", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table31": { canonical: "hTAf_Tax_Table31", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table32": { canonical: "hTAf_Tax_Table32", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table33": { canonical: "hTAf_Tax_Table33", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table34": { canonical: "hTAf_Tax_Table34", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table35": { canonical: "hTAf_Tax_Table35", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table36": { canonical: "hTAf_Tax_Table36", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table37": { canonical: "hTAf_Tax_Table37", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table38": { canonical: "hTAf_Tax_Table38", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table39": { canonical: "hTAf_Tax_Table39", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table40": { canonical: "hTAf_Tax_Table40", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table41": { canonical: "hTAf_Tax_Table41", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table42": { canonical: "hTAf_Tax_Table42", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table43": { canonical: "hTAf_Tax_Table43", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table44": { canonical: "hTAf_Tax_Table44", type: "DOUBLE", tableCode: "TA" },
        "htaf_tax_table45": { canonical: "hTAf_Tax_Table45", type: "DOUBLE", tableCode: "TA" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "htat_mod_time"   : { canonical: "hTAt_Mod_Time"   , type: "TIME", tableCode: "TA" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "htaz_mod_user"   : { canonical: "hTAz_Mod_User"   , type: "STRING", tableCode: "TA" },
        "htaz_spare"      : { canonical: "hTAz_Spare"      , type: "STRING", tableCode: "TA" },
    }
};

export default TA;
