/**
 * ES.js — table structure for the ES (Eligible Service Date History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "ES").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force ES
 */

/** @type {Object} */
const ES = {
    code: "ES",
    name: "Eligible_Service_Date_History",
    recordLength: null,
    helpRegistry: "hES.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ESi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hesc_pre_2007"        : { canonical: "hESc_Pre_2007"        , type: "STRING", tableCode: "ES" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hesd_effective"       : { canonical: "hESd_Effective"       , type: "DATE", tableCode: "ES" },
        "hesd_eligible_service": { canonical: "hESd_Eligible_Service", type: "DATE", tableCode: "ES" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hesl_spare"           : { canonical: "hESl_Spare"           , type: "INTEGER", tableCode: "ES" },
        "hesl_trans_ref"       : { canonical: "hESl_Trans_Ref"       , type: "INTEGER", tableCode: "ES" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hesz_deleted"         : { canonical: "hESz_Deleted"         , type: "STRING", tableCode: "ES" },
        "hesz_division"        : { canonical: "hESz_Division"        , type: "STRING", tableCode: "ES" },
        "hesz_fund"            : { canonical: "hESz_Fund"            , type: "STRING", tableCode: "ES" },
        "hesz_member"          : { canonical: "hESz_Member"          , type: "STRING", tableCode: "ES" },
        "hesz_spare"           : { canonical: "hESz_Spare"           , type: "STRING", tableCode: "ES" },
    }
};

export default ES;
