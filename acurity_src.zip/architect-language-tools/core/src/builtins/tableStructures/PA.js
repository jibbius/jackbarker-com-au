/**
 * PA.js — table structure for the PA (Password History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PA").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PA
 */

/** @type {Object} */
const PA = {
    code: "PA",
    name: "Password_History",
    recordLength: null,
    helpRegistry: "hPA.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PAi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hpad_effective"    : { canonical: "hPAd_Effective"    , type: "DATE", tableCode: "PA" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hpaz_spare"        : { canonical: "hPAz_Spare"        , type: "STRING", tableCode: "PA" },
        "hpaz_user_code"    : { canonical: "hPAz_User_Code"    , type: "STRING", tableCode: "PA" },
        "hpaz_user_password": { canonical: "hPAz_User_Password", type: "STRING", tableCode: "PA" },
    }
};

export default PA;
