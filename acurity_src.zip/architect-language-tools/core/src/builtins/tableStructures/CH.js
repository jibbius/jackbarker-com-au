/**
 * CH.js — table structure for the CH (Benefit Category History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CH
 */

/** @type {Object} */
const CH = {
    code: "CH",
    name: "Benefit_Category_History",
    recordLength: null,
    helpRegistry: "hCH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hchc_change_forced"  : { canonical: "hCHc_Change_Forced"  , type: "STRING", tableCode: "CH" },
        "hchc_cont_suspended" : { canonical: "hCHc_Cont_Suspended" , type: "STRING", tableCode: "CH" },
        "hchc_contributory"   : { canonical: "hCHc_Contributory"   , type: "STRING", tableCode: "CH" },
        "hchc_deleted"        : { canonical: "hCHc_Deleted"        , type: "STRING", tableCode: "CH" },
        "hchc_working_status" : { canonical: "hCHc_Working_Status" , type: "STRING", tableCode: "CH" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hchd_effective"      : { canonical: "hCHd_Effective"      , type: "DATE", tableCode: "CH" },
        "hchd_mod_date"       : { canonical: "hCHd_Mod_Date"       , type: "DATE", tableCode: "CH" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hchf_maximum_rate"   : { canonical: "hCHf_Maximum_Rate"   , type: "DOUBLE", tableCode: "CH" },
        "hchf_part_time_pcnt" : { canonical: "hCHf_Part_Time_Pcnt" , type: "DOUBLE", tableCode: "CH" },
        "hchf_prev_multiple"  : { canonical: "hCHf_Prev_Multiple"  , type: "DOUBLE", tableCode: "CH" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hchl_batchref_backup": { canonical: "hCHl_Batchref_Backup", type: "INTEGER", tableCode: "CH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hcht_mod_time"       : { canonical: "hCHt_Mod_Time"       , type: "TIME", tableCode: "CH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hchz_fund"           : { canonical: "hCHz_Fund"           , type: "STRING", tableCode: "CH" },
        "hchz_member"         : { canonical: "hCHz_Member"         , type: "STRING", tableCode: "CH" },
        "hchz_mod_user"       : { canonical: "hCHz_Mod_User"       , type: "STRING", tableCode: "CH" },
        "hchz_new_category"   : { canonical: "hCHz_New_Category"   , type: "STRING", tableCode: "CH" },
        "hchz_spare"          : { canonical: "hCHz_Spare"          , type: "STRING", tableCode: "CH" },
        "hchz_status"         : { canonical: "hCHz_Status"         , type: "STRING", tableCode: "CH" },
    }
};

export default CH;
