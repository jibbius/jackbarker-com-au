/**
 * CQ.js — table structure for the CQ (Cheque Reconciliation) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CQ").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CQ
 */

/** @type {Object} */
const CQ = {
    code: "CQ",
    name: "Cheque_Reconciliation",
    recordLength: null,
    helpRegistry: "hCQ.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CQi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hcqc_allocated"       : { canonical: "hCQc_Allocated"       , type: "STRING", tableCode: "CQ" },
        "hcqc_direct_debit"    : { canonical: "hCQc_Direct_Debit"    , type: "STRING", tableCode: "CQ" },
        "hcqc_payment_type"    : { canonical: "hCQc_Payment_Type"    , type: "STRING", tableCode: "CQ" },
        "hcqc_presented"       : { canonical: "hCQc_Presented"       , type: "STRING", tableCode: "CQ" },
        "hcqc_swimec_flag"     : { canonical: "hCQc_SwimEC_Flag"     , type: "STRING", tableCode: "CQ" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hcqd_effective"       : { canonical: "hCQd_Effective"       , type: "DATE", tableCode: "CQ" },
        "hcqd_mod_date"        : { canonical: "hCQd_Mod_Date"        , type: "DATE", tableCode: "CQ" },
        "hcqd_presentation"    : { canonical: "hCQd_Presentation"    , type: "DATE", tableCode: "CQ" },
        "hcqd_user_authorised" : { canonical: "hCQd_User_Authorised" , type: "DATE", tableCode: "CQ" },
        "hcqd_user_created"    : { canonical: "hCQd_User_Created"    , type: "DATE", tableCode: "CQ" },
        "hcqd_user_printed"    : { canonical: "hCQd_User_Printed"    , type: "DATE", tableCode: "CQ" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hcqf_cheque_amount"   : { canonical: "hCQf_Cheque_Amount"   , type: "DOUBLE", tableCode: "CQ" },
        "hcqf_spare"           : { canonical: "hCQf_Spare"           , type: "DOUBLE", tableCode: "CQ" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hcql_bank_ref"        : { canonical: "hCQl_Bank_Ref"        , type: "INTEGER", tableCode: "CQ" },
        "hcql_block_no"        : { canonical: "hCQl_Block_No"        , type: "INTEGER", tableCode: "CQ" },
        "hcql_chq_eft_batch_no": { canonical: "hCQl_Chq_EFT_Batch_No", type: "INTEGER", tableCode: "CQ" },
        "hcql_master_batch_ref": { canonical: "hCQl_Master_Batch_Ref", type: "INTEGER", tableCode: "CQ" },
        "hcql_trans_ref"       : { canonical: "hCQl_Trans_Ref"       , type: "INTEGER", tableCode: "CQ" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hcqt_mod_time"        : { canonical: "hCQt_Mod_Time"        , type: "TIME", tableCode: "CQ" },
        "hcqt_user_authorised" : { canonical: "hCQt_User_Authorised" , type: "TIME", tableCode: "CQ" },
        "hcqt_user_created"    : { canonical: "hCQt_User_Created"    , type: "TIME", tableCode: "CQ" },
        "hcqt_user_printed"    : { canonical: "hCQt_User_Printed"    , type: "TIME", tableCode: "CQ" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcqz_bank_account"    : { canonical: "hCQz_Bank_Account"    , type: "STRING", tableCode: "CQ" },
        "hcqz_cheque_no"       : { canonical: "hCQz_Cheque_No"       , type: "STRING", tableCode: "CQ" },
        "hcqz_chequerange_fund": { canonical: "hCQz_ChequeRange_Fund", type: "STRING", tableCode: "CQ" },
        "hcqz_division"        : { canonical: "hCQz_Division"        , type: "STRING", tableCode: "CQ" },
        "hcqz_fund"            : { canonical: "hCQz_Fund"            , type: "STRING", tableCode: "CQ" },
        "hcqz_issued_cheq_no"  : { canonical: "hCQz_Issued_Cheq_No"  , type: "STRING", tableCode: "CQ" },
        "hcqz_member"          : { canonical: "hCQz_Member"          , type: "STRING", tableCode: "CQ" },
        "hcqz_mod_user"        : { canonical: "hCQz_Mod_User"        , type: "STRING", tableCode: "CQ" },
        "hcqz_orig_swimec_id"  : { canonical: "hCQz_Orig_SwimEC_ID"  , type: "STRING", tableCode: "CQ" },
        "hcqz_reason"          : { canonical: "hCQz_Reason"          , type: "STRING", tableCode: "CQ" },
        "hcqz_reconciled"      : { canonical: "hCQz_Reconciled"      , type: "STRING", tableCode: "CQ" },
        "hcqz_repl_swimec_id"  : { canonical: "hCQz_Repl_SwimEC_ID"  , type: "STRING", tableCode: "CQ" },
        "hcqz_replaced_by"     : { canonical: "hCQz_Replaced_By"     , type: "STRING", tableCode: "CQ" },
        "hcqz_replacing"       : { canonical: "hCQz_Replacing"       , type: "STRING", tableCode: "CQ" },
        "hcqz_spare"           : { canonical: "hCQz_Spare"           , type: "STRING", tableCode: "CQ" },
        "hcqz_sub_account"     : { canonical: "hCQz_Sub_Account"     , type: "STRING", tableCode: "CQ" },
        "hcqz_sub_sub_account" : { canonical: "hCQz_Sub_Sub_Account" , type: "STRING", tableCode: "CQ" },
        "hcqz_transaction"     : { canonical: "hCQz_Transaction"     , type: "STRING", tableCode: "CQ" },
        "hcqz_user_authorised" : { canonical: "hCQz_User_Authorised" , type: "STRING", tableCode: "CQ" },
        "hcqz_user_created"    : { canonical: "hCQz_User_Created"    , type: "STRING", tableCode: "CQ" },
        "hcqz_user_printed"    : { canonical: "hCQz_User_Printed"    , type: "STRING", tableCode: "CQ" },
    }
};

export default CQ;
