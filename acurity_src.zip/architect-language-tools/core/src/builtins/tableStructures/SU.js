/**
 * SU.js — table structure for the SU (System Security - Transactions) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SU").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SU
 */

/** @type {Object} */
const SU = {
    code: "SU",
    name: "System_Security_-_Transactions",
    recordLength: null,
    helpRegistry: "hSU.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SUi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hsuc_security_level": { canonical: "hSUc_Security_Level", type: "STRING", tableCode: "SU" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hsud_mod_date"      : { canonical: "hSUd_Mod_Date"      , type: "DATE", tableCode: "SU" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hsut_mod_time"      : { canonical: "hSUt_Mod_Time"      , type: "TIME", tableCode: "SU" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hsuz_mod_user"      : { canonical: "hSUz_Mod_User"      , type: "STRING", tableCode: "SU" },
        "hsuz_spare"         : { canonical: "hSUz_Spare"         , type: "STRING", tableCode: "SU" },

        // ── (y-prefix) ──────────────────────────────────────────────────
        "hsuy_process_access": { canonical: "hSUy_Process_Access", type: "STRING", tableCode: "SU" },
        "hsuy_tran_access"   : { canonical: "hSUy_Tran_Access"   , type: "STRING", tableCode: "SU" },
    }
};

export default SU;
