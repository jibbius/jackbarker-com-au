/**
 * AX.js — table structure for the AX (Audit Header) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AX").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AX
 */

/** @type {Object} */
const AX = {
    code: "AX",
    name: "Audit_Header",
    recordLength: null,
    helpRegistry: "hAX.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "AXi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "haxc_auth_required": { canonical: "hAXc_Auth_Required", type: "STRING", tableCode: "AX" },
        "haxc_authorised"   : { canonical: "hAXc_Authorised"   , type: "STRING", tableCode: "AX" },
        "haxc_update_source": { canonical: "hAXc_Update_Source", type: "STRING", tableCode: "AX" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "haxd_auth_date"    : { canonical: "hAXd_Auth_Date"    , type: "DATE", tableCode: "AX" },
        "haxd_mod_date"     : { canonical: "hAXd_Mod_Date"     , type: "DATE", tableCode: "AX" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "haxl_audit_id"     : { canonical: "hAXl_Audit_ID"     , type: "INTEGER", tableCode: "AX" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "haxt_auth_time"    : { canonical: "hAXt_Auth_Time"    , type: "TIME", tableCode: "AX" },
        "haxt_mod_time"     : { canonical: "hAXt_Mod_Time"     , type: "TIME", tableCode: "AX" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "haxz_auth_user"    : { canonical: "hAXz_Auth_User"    , type: "STRING", tableCode: "AX" },
        "haxz_function_name": { canonical: "hAXz_Function_Name", type: "STRING", tableCode: "AX" },
        "haxz_mod_user"     : { canonical: "hAXz_Mod_User"     , type: "STRING", tableCode: "AX" },
        "haxz_spare"        : { canonical: "hAXz_Spare"        , type: "STRING", tableCode: "AX" },
    }
};

export default AX;
