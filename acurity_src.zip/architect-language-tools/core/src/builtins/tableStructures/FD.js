/**
 * FD.js — table structure for the FD (Fee Definitions) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FD").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FD
 */

/** @type {Object} */
const FD = {
    code: "FD",
    name: "Fee_Definitions",
    recordLength: null,
    helpRegistry: "hFD.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FDi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hfdc_advance"         : { canonical: "hFDc_Advance"         , type: "STRING", tableCode: "FD" },
        "hfdc_anniversary_exit": { canonical: "hFDc_Anniversary_Exit", type: "STRING", tableCode: "FD" },
        "hfdc_apra_fee_type"   : { canonical: "hFDc_APRA_Fee_Type"   , type: "STRING", tableCode: "FD" },
        "hfdc_conts_basis"     : { canonical: "hFDc_Conts_Basis"     , type: "STRING", tableCode: "FD" },
        "hfdc_entry_fee"       : { canonical: "hFDc_Entry_Fee"       , type: "STRING", tableCode: "FD" },
        "hfdc_expense_dedn"    : { canonical: "hFDc_Expense_Dedn"    , type: "STRING", tableCode: "FD" },
        "hfdc_fee_dollar_disc" : { canonical: "hFDc_Fee_Dollar_Disc" , type: "STRING", tableCode: "FD" },
        "hfdc_fee_liability"   : { canonical: "hFDc_Fee_Liability"   , type: "STRING", tableCode: "FD" },
        "hfdc_fund_prop_basis" : { canonical: "hFDc_Fund_Prop_Basis" , type: "STRING", tableCode: "FD" },
        "hfdc_gst_applies"     : { canonical: "hFDc_GST_Applies"     , type: "STRING", tableCode: "FD" },
        "hfdc_inact_fee_type"  : { canonical: "hFDc_Inact_Fee_Type"  , type: "STRING", tableCode: "FD" },
        "hfdc_invest_profile"  : { canonical: "hFDc_Invest_Profile"  , type: "STRING", tableCode: "FD" },
        "hfdc_liability_level" : { canonical: "hFDc_Liability_Level" , type: "STRING", tableCode: "FD" },
        "hfdc_min_acct_bal_app": { canonical: "hFDc_Min_Acct_Bal_App", type: "STRING", tableCode: "FD" },
        "hfdc_new_alloc_level" : { canonical: "hFDc_New_Alloc_Level" , type: "STRING", tableCode: "FD" },
        "hfdc_pro_rata"        : { canonical: "hFDc_Pro_Rata"        , type: "STRING", tableCode: "FD" },
        "hfdc_prorata_rnd_mthd": { canonical: "hFDc_ProRata_Rnd_Mthd", type: "STRING", tableCode: "FD" },
        "hfdc_rebateable"      : { canonical: "hFDc_Rebateable"      , type: "STRING", tableCode: "FD" },
        "hfdc_reserve_fee"     : { canonical: "hFDc_Reserve_Fee"     , type: "STRING", tableCode: "FD" },
        "hfdc_sal_cont_prem"   : { canonical: "hFDc_Sal_Cont_Prem"   , type: "STRING", tableCode: "FD" },
        "hfdc_split_commission": { canonical: "hFDc_Split_Commission", type: "STRING", tableCode: "FD" },
        "hfdc_transaction"     : { canonical: "hFDc_Transaction"     , type: "STRING", tableCode: "FD" },
        "hfdc_transfer_level"  : { canonical: "hFDc_Transfer_Level"  , type: "STRING", tableCode: "FD" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfdd_anniversary"     : { canonical: "hFDd_Anniversary"     , type: "DATE", tableCode: "FD" },
        "hfdd_mod_date"        : { canonical: "hFDd_Mod_Date"        , type: "DATE", tableCode: "FD" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hfdf_ritc_percent"    : { canonical: "hFDf_RITC_Percent"    , type: "DOUBLE", tableCode: "FD" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfdt_mod_time"        : { canonical: "hFDt_Mod_Time"        , type: "TIME", tableCode: "FD" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfdz_calc_level"      : { canonical: "hFDz_Calc_Level"      , type: "STRING", tableCode: "FD" },
        "hfdz_category"        : { canonical: "hFDz_Category"        , type: "STRING", tableCode: "FD" },
        "hfdz_class"           : { canonical: "hFDz_Class"           , type: "STRING", tableCode: "FD" },
        "hfdz_code"            : { canonical: "hFDz_Code"            , type: "STRING", tableCode: "FD" },
        "hfdz_deleted"         : { canonical: "hFDz_Deleted"         , type: "STRING", tableCode: "FD" },
        "hfdz_description"     : { canonical: "hFDz_Description"     , type: "STRING", tableCode: "FD" },
        "hfdz_event"           : { canonical: "hFDz_Event"           , type: "STRING", tableCode: "FD" },
        "hfdz_freqency"        : { canonical: "hFDz_Freqency"        , type: "STRING", tableCode: "FD" },
        "hfdz_group_fees"      : { canonical: "hFDz_Group_Fees"      , type: "STRING", tableCode: "FD" },
        "hfdz_inact_fee_code"  : { canonical: "hFDz_Inact_Fee_Code"  , type: "STRING", tableCode: "FD" },
        "hfdz_investment_group": { canonical: "hFDz_Investment_Group", type: "STRING", tableCode: "FD" },
        "hfdz_investment_mgr"  : { canonical: "hFDz_Investment_Mgr"  , type: "STRING", tableCode: "FD" },
        "hfdz_level"           : { canonical: "hFDz_Level"           , type: "STRING", tableCode: "FD" },
        "hfdz_mbr_cont_acct"   : { canonical: "hFDz_Mbr_Cont_Acct"   , type: "STRING", tableCode: "FD" },
        "hfdz_mbr_cont_pres"   : { canonical: "hFDz_Mbr_Cont_Pres"   , type: "STRING", tableCode: "FD" },
        "hfdz_mod_user"        : { canonical: "hFDz_Mod_User"        , type: "STRING", tableCode: "FD" },
        "hfdz_offset_tax"      : { canonical: "hFDz_Offset_Tax"      , type: "STRING", tableCode: "FD" },
        "hfdz_payee"           : { canonical: "hFDz_Payee"           , type: "STRING", tableCode: "FD" },
        "hfdz_prop_basis"      : { canonical: "hFDz_Prop_Basis"      , type: "STRING", tableCode: "FD" },
        "hfdz_spare"           : { canonical: "hFDz_Spare"           , type: "STRING", tableCode: "FD" },
    }
};

export default FD;
