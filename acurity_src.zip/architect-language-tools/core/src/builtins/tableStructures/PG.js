/**
 * PG.js — table structure for the PG (Client Groups) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PG").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PG
 */

/** @type {Object} */
const PG = {
    code: "PG",
    name: "Client_Groups",
    recordLength: null,
    helpRegistry: "hPG.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PGi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hpgc_deleted"      : { canonical: "hPGc_Deleted"      , type: "STRING", tableCode: "PG" },
        "hpgc_division"     : { canonical: "hPGc_Division"     , type: "STRING", tableCode: "PG" },
        "hpgc_spare"        : { canonical: "hPGc_Spare"        , type: "STRING", tableCode: "PG" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hpgd_mod_date"     : { canonical: "hPGd_Mod_Date"     , type: "DATE", tableCode: "PG" },
        "hpgd_operative"    : { canonical: "hPGd_Operative"    , type: "DATE", tableCode: "PG" },
        "hpgd_split"        : { canonical: "hPGd_Split"        , type: "DATE", tableCode: "PG" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hpgf_base_amount"  : { canonical: "hPGf_Base_Amount"  , type: "DOUBLE", tableCode: "PG" },
        "hpgf_split_amount" : { canonical: "hPGf_Split_Amount" , type: "DOUBLE", tableCode: "PG" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hpgl_batch_ref"    : { canonical: "hPGl_Batch_Ref"    , type: "INTEGER", tableCode: "PG" },
        "hpgl_spare"        : { canonical: "hPGl_Spare"        , type: "INTEGER", tableCode: "PG" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hpgs_record_number": { canonical: "hPGs_Record_Number", type: "INTEGER", tableCode: "PG" },
        "hpgs_spare01"      : { canonical: "hPGs_Spare01"      , type: "INTEGER", tableCode: "PG" },
        "hpgs_spare02"      : { canonical: "hPGs_Spare02"      , type: "INTEGER", tableCode: "PG" },
        "hpgs_spare03"      : { canonical: "hPGs_Spare03"      , type: "INTEGER", tableCode: "PG" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hpgt_mod_time"     : { canonical: "hPGt_Mod_Time"     , type: "TIME", tableCode: "PG" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hpgz_corr_client"  : { canonical: "hPGz_Corr_Client"  , type: "STRING", tableCode: "PG" },
        "hpgz_corr_fund"    : { canonical: "hPGz_Corr_Fund"    , type: "STRING", tableCode: "PG" },
        "hpgz_corr_member"  : { canonical: "hPGz_Corr_Member"  , type: "STRING", tableCode: "PG" },
        "hpgz_fund"         : { canonical: "hPGz_Fund"         , type: "STRING", tableCode: "PG" },
        "hpgz_member"       : { canonical: "hPGz_Member"       , type: "STRING", tableCode: "PG" },
        "hpgz_mod_user"     : { canonical: "hPGz_Mod_User"     , type: "STRING", tableCode: "PG" },
        "hpgz_notice_type"  : { canonical: "hPGz_Notice_Type"  , type: "STRING", tableCode: "PG" },
        "hpgz_prev_status"  : { canonical: "hPGz_Prev_Status"  , type: "STRING", tableCode: "PG" },
        "hpgz_record_type"  : { canonical: "hPGz_Record_Type"  , type: "STRING", tableCode: "PG" },
        "hpgz_split_type"   : { canonical: "hPGz_Split_Type"   , type: "STRING", tableCode: "PG" },
        "hpgz_status"       : { canonical: "hPGz_Status"       , type: "STRING", tableCode: "PG" },
    }
};

export default PG;
