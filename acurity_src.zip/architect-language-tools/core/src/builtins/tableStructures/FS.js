/**
 * FS.js — table structure for the FS (Static Data Lines) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FS").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FS
 */

/** @type {Object} */
const FS = {
    code: "FS",
    name: "Static_Data_Lines",
    recordLength: null,
    helpRegistry: "hFS.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FSi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hfsc_deleted"         : { canonical: "hFSc_Deleted"         , type: "STRING", tableCode: "FS" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfsd_effective"       : { canonical: "hFSd_Effective"       , type: "DATE", tableCode: "FS" },
        "hfsd_end"             : { canonical: "hFSd_End"             , type: "DATE", tableCode: "FS" },
        "hfsd_mod_date"        : { canonical: "hFSd_Mod_Date"        , type: "DATE", tableCode: "FS" },
        "hfsd_start"           : { canonical: "hFSd_Start"           , type: "DATE", tableCode: "FS" },
        "hfsd_user_updated"    : { canonical: "hFSd_User_Updated"    , type: "DATE", tableCode: "FS" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hfsl_bank_stmt_ref"   : { canonical: "hFSl_Bank_Stmt_Ref"   , type: "INTEGER", tableCode: "FS" },
        "hfsl_file_reg_ref"    : { canonical: "hFSl_File_Reg_Ref"    , type: "INTEGER", tableCode: "FS" },
        "hfsl_line_no"         : { canonical: "hFSl_Line_No"         , type: "INTEGER", tableCode: "FS" },
        "hfsl_message_code"    : { canonical: "hFSl_Message_Code"    , type: "INTEGER", tableCode: "FS" },
        "hfsl_receipt_ref"     : { canonical: "hFSl_Receipt_Ref"     , type: "INTEGER", tableCode: "FS" },
        "hfsl_spare"           : { canonical: "hFSl_Spare"           , type: "INTEGER", tableCode: "FS" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hfss_sequence"        : { canonical: "hFSs_Sequence"        , type: "INTEGER", tableCode: "FS" },
        "hfss_spare01"         : { canonical: "hFSs_Spare01"         , type: "INTEGER", tableCode: "FS" },
        "hfss_spare02"         : { canonical: "hFSs_Spare02"         , type: "INTEGER", tableCode: "FS" },
        "hfss_spare03"         : { canonical: "hFSs_Spare03"         , type: "INTEGER", tableCode: "FS" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfst_mod_time"        : { canonical: "hFSt_Mod_Time"        , type: "TIME", tableCode: "FS" },
        "hfst_spare"           : { canonical: "hFSt_Spare"           , type: "TIME", tableCode: "FS" },
        "hfst_user_updated"    : { canonical: "hFSt_User_Updated"    , type: "TIME", tableCode: "FS" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfsz_file_code"       : { canonical: "hFSz_File_Code"       , type: "STRING", tableCode: "FS" },
        "hfsz_fund"            : { canonical: "hFSz_Fund"            , type: "STRING", tableCode: "FS" },
        "hfsz_member"          : { canonical: "hFSz_Member"          , type: "STRING", tableCode: "FS" },
        "hfsz_mod_user"        : { canonical: "hFSz_Mod_User"        , type: "STRING", tableCode: "FS" },
        "hfsz_payroll"         : { canonical: "hFSz_Payroll"         , type: "STRING", tableCode: "FS" },
        "hfsz_reject_reason"   : { canonical: "hFSz_Reject_Reason"   , type: "STRING", tableCode: "FS" },
        "hfsz_spare"           : { canonical: "hFSz_Spare"           , type: "STRING", tableCode: "FS" },
        "hfsz_status"          : { canonical: "hFSz_Status"          , type: "STRING", tableCode: "FS" },
        "hfsz_user_def_flags01": { canonical: "hFSz_User_Def_Flags01", type: "STRING", tableCode: "FS" },
        "hfsz_user_def_flags02": { canonical: "hFSz_User_Def_Flags02", type: "STRING", tableCode: "FS" },
        "hfsz_user_def_flags03": { canonical: "hFSz_User_Def_Flags03", type: "STRING", tableCode: "FS" },
        "hfsz_user_def_flags04": { canonical: "hFSz_User_Def_Flags04", type: "STRING", tableCode: "FS" },
        "hfsz_user_updated"    : { canonical: "hFSz_User_Updated"    , type: "STRING", tableCode: "FS" },

        // ── (v-prefix) ──────────────────────────────────────────────────
        "hfsv_data_line"       : { canonical: "hFSv_Data_Line"       , type: "VARSTRING", tableCode: "FS" },
        "hfsv_header_line"     : { canonical: "hFSv_Header_Line"     , type: "VARSTRING", tableCode: "FS" },
    }
};

export default FS;
