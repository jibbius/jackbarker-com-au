/**
 * DX.js — table structure for the DX (Dependants Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "DX").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force DX
 */

/** @type {Object} */
const DX = {
    code: "DX",
    name: "Dependants_Details",
    recordLength: null,
    helpRegistry: "hDX.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "DXi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hdxc_bind_nomination" : { canonical: "hDXc_Bind_Nomination" , type: "STRING", tableCode: "DX" },
        "hdxc_first_spouse"    : { canonical: "hDXc_First_Spouse"    , type: "STRING", tableCode: "DX" },
        "hdxc_fulltime_student": { canonical: "hDXc_FullTime_Student", type: "STRING", tableCode: "DX" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hdxd_assessment_date" : { canonical: "hDXd_Assessment_Date" , type: "DATE", tableCode: "DX" },
        "hdxd_bind_expiry"     : { canonical: "hDXd_Bind_Expiry"     , type: "DATE", tableCode: "DX" },
        "hdxd_bind_last_notice": { canonical: "hDXd_Bind_Last_Notice", type: "DATE", tableCode: "DX" },
        "hdxd_date_of_birth"   : { canonical: "hDXd_Date_Of_Birth"   , type: "DATE", tableCode: "DX" },
        "hdxd_kyc_supplied"    : { canonical: "hDXd_KYC_Supplied"    , type: "DATE", tableCode: "DX" },
        "hdxd_mod_date"        : { canonical: "hDXd_Mod_Date"        , type: "DATE", tableCode: "DX" },
        "hdxd_spare"           : { canonical: "hDXd_Spare"           , type: "DATE", tableCode: "DX" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hdxf_dependant_pcnt"  : { canonical: "hDXf_Dependant_Pcnt"  , type: "DOUBLE", tableCode: "DX" },
        "hdxf_spare"           : { canonical: "hDXf_Spare"           , type: "DOUBLE", tableCode: "DX" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hdxt_mod_time"        : { canonical: "hDXt_Mod_Time"        , type: "TIME", tableCode: "DX" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hdxz_address_line_1"  : { canonical: "hDXz_Address_Line_1"  , type: "STRING", tableCode: "DX" },
        "hdxz_address_line_2"  : { canonical: "hDXz_Address_Line_2"  , type: "STRING", tableCode: "DX" },
        "hdxz_address_line01"  : { canonical: "hDXz_Address_Line01"  , type: "STRING", tableCode: "DX" },
        "hdxz_address_line02"  : { canonical: "hDXz_Address_Line02"  , type: "STRING", tableCode: "DX" },
        "hdxz_address_line03"  : { canonical: "hDXz_Address_Line03"  , type: "STRING", tableCode: "DX" },
        "hdxz_assessed"        : { canonical: "hDXz_Assessed"        , type: "STRING", tableCode: "DX" },
        "hdxz_bank_acct_name"  : { canonical: "hDXz_Bank_Acct_Name"  , type: "STRING", tableCode: "DX" },
        "hdxz_bank_acct_no"    : { canonical: "hDXz_Bank_Acct_No"    , type: "STRING", tableCode: "DX" },
        "hdxz_bsb"             : { canonical: "hDXz_BSB"             , type: "STRING", tableCode: "DX" },
        "hdxz_client"          : { canonical: "hDXz_Client"          , type: "STRING", tableCode: "DX" },
        "hdxz_country"         : { canonical: "hDXz_Country"         , type: "STRING", tableCode: "DX" },
        "hdxz_country_code"    : { canonical: "hDXz_Country_Code"    , type: "STRING", tableCode: "DX" },
        "hdxz_deleted"         : { canonical: "hDXz_Deleted"         , type: "STRING", tableCode: "DX" },
        "hdxz_dep_relationship": { canonical: "hDXz_Dep_Relationship", type: "STRING", tableCode: "DX" },
        "hdxz_dep_rltnshp_code": { canonical: "hDXz_Dep_Rltnshp_Code", type: "STRING", tableCode: "DX" },
        "hdxz_depend_name"     : { canonical: "hDXz_Depend_Name"     , type: "STRING", tableCode: "DX" },
        "hdxz_dependant_mbr"   : { canonical: "hDXz_Dependant_Mbr"   , type: "STRING", tableCode: "DX" },
        "hdxz_dependant_no"    : { canonical: "hDXz_Dependant_No"    , type: "STRING", tableCode: "DX" },
        "hdxz_dependant_type"  : { canonical: "hDXz_Dependant_Type"  , type: "STRING", tableCode: "DX" },
        "hdxz_estate"          : { canonical: "hDXz_Estate"          , type: "STRING", tableCode: "DX" },
        "hdxz_fund"            : { canonical: "hDXz_Fund"            , type: "STRING", tableCode: "DX" },
        "hdxz_given_names"     : { canonical: "hDXz_Given_Names"     , type: "STRING", tableCode: "DX" },
        "hdxz_kyc_status"      : { canonical: "hDXz_KYC_Status"      , type: "STRING", tableCode: "DX" },
        "hdxz_member"          : { canonical: "hDXz_Member"          , type: "STRING", tableCode: "DX" },
        "hdxz_mod_user"        : { canonical: "hDXz_Mod_User"        , type: "STRING", tableCode: "DX" },
        "hdxz_payment_type"    : { canonical: "hDXz_Payment_Type"    , type: "STRING", tableCode: "DX" },
        "hdxz_post_code"       : { canonical: "hDXz_Post_Code"       , type: "STRING", tableCode: "DX" },
        "hdxz_sex"             : { canonical: "hDXz_Sex"             , type: "STRING", tableCode: "DX" },
        "hdxz_spare"           : { canonical: "hDXz_Spare"           , type: "STRING", tableCode: "DX" },
        "hdxz_surname"         : { canonical: "hDXz_Surname"         , type: "STRING", tableCode: "DX" },
        "hdxz_tax_file_no"     : { canonical: "hDXz_Tax_File_No"     , type: "STRING", tableCode: "DX" },
        "hdxz_title"           : { canonical: "hDXz_Title"           , type: "STRING", tableCode: "DX" },
    }
};

export default DX;
