/**
 * EH.js — table structure for the EH (Exception History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "EH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force EH
 */

/** @type {Object} */
const EH = {
    code: "EH",
    name: "Exception_History",
    recordLength: null,
    helpRegistry: "hEH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "EHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hehc_basestype"       : { canonical: "hEHc_BasesType"       , type: "STRING", tableCode: "EH" },
        "hehc_deleted"         : { canonical: "hEHc_Deleted"         , type: "STRING", tableCode: "EH" },
        "hehc_published"       : { canonical: "hEHc_Published"       , type: "STRING", tableCode: "EH" },
        "hehc_spare"           : { canonical: "hEHc_Spare"           , type: "STRING", tableCode: "EH" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hehd_creation"        : { canonical: "hEHd_Creation"        , type: "DATE", tableCode: "EH" },
        "hehd_effective"       : { canonical: "hEHd_Effective"       , type: "DATE", tableCode: "EH" },
        "hehd_mod_date"        : { canonical: "hEHd_Mod_Date"        , type: "DATE", tableCode: "EH" },
        "hehd_spare"           : { canonical: "hEHd_Spare"           , type: "DATE", tableCode: "EH" },
        "hehd_status_change"   : { canonical: "hEHd_Status_Change"   , type: "DATE", tableCode: "EH" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hehl_batch_ref"       : { canonical: "hEHl_Batch_Ref"       , type: "INTEGER", tableCode: "EH" },
        "hehl_clob_id"         : { canonical: "hEHl_CLOB_ID"         , type: "INTEGER", tableCode: "EH" },
        "hehl_event_record_id" : { canonical: "hEHl_Event_Record_Id" , type: "INTEGER", tableCode: "EH" },
        "hehl_file_reg_ref"    : { canonical: "hEHl_File_Reg_Ref"    , type: "INTEGER", tableCode: "EH" },
        "hehl_job_number"      : { canonical: "hEHl_Job_Number"      , type: "INTEGER", tableCode: "EH" },
        "hehl_line_number"     : { canonical: "hEHl_Line_Number"     , type: "INTEGER", tableCode: "EH" },
        "hehl_message_code"    : { canonical: "hEHl_Message_Code"    , type: "INTEGER", tableCode: "EH" },
        "hehl_record_no"       : { canonical: "hEHl_Record_No"       , type: "INTEGER", tableCode: "EH" },
        "hehl_sequence"        : { canonical: "hEHl_Sequence"        , type: "INTEGER", tableCode: "EH" },
        "hehl_trans_ref"       : { canonical: "hEHl_Trans_Ref"       , type: "INTEGER", tableCode: "EH" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hehs_line_sequence"   : { canonical: "hEHs_Line_Sequence"   , type: "INTEGER", tableCode: "EH" },
        "hehs_record_no"       : { canonical: "hEHs_Record_No"       , type: "INTEGER", tableCode: "EH" },
        "hehs_spare01"         : { canonical: "hEHs_Spare01"         , type: "INTEGER", tableCode: "EH" },
        "hehs_spare02"         : { canonical: "hEHs_Spare02"         , type: "INTEGER", tableCode: "EH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "heht_creation"        : { canonical: "hEHt_Creation"        , type: "TIME", tableCode: "EH" },
        "heht_mod_time"        : { canonical: "hEHt_Mod_Time"        , type: "TIME", tableCode: "EH" },
        "heht_status_change"   : { canonical: "hEHt_Status_Change"   , type: "TIME", tableCode: "EH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hehz_adviser"         : { canonical: "hEHz_Adviser"         , type: "STRING", tableCode: "EH" },
        "hehz_client"          : { canonical: "hEHz_Client"          , type: "STRING", tableCode: "EH" },
        "hehz_description"     : { canonical: "hEHz_Description"     , type: "STRING", tableCode: "EH" },
        "hehz_division"        : { canonical: "hEHz_Division"        , type: "STRING", tableCode: "EH" },
        "hehz_employer"        : { canonical: "hEHz_Employer"        , type: "STRING", tableCode: "EH" },
        "hehz_exception_code"  : { canonical: "hEHz_Exception_Code"  , type: "STRING", tableCode: "EH" },
        "hehz_external_id"     : { canonical: "hEHz_External_Id"     , type: "STRING", tableCode: "EH" },
        "hehz_external_type"   : { canonical: "hEHz_External_Type"   , type: "STRING", tableCode: "EH" },
        "hehz_fund"            : { canonical: "hEHz_Fund"            , type: "STRING", tableCode: "EH" },
        "hehz_member"          : { canonical: "hEHz_Member"          , type: "STRING", tableCode: "EH" },
        "hehz_mod_user"        : { canonical: "hEHz_Mod_User"        , type: "STRING", tableCode: "EH" },
        "hehz_severity"        : { canonical: "hEHz_Severity"        , type: "STRING", tableCode: "EH" },
        "hehz_status"          : { canonical: "hEHz_Status"          , type: "STRING", tableCode: "EH" },
        "hehz_status_change"   : { canonical: "hEHz_Status_Change"   , type: "STRING", tableCode: "EH" },
        "hehz_status_reason"   : { canonical: "hEHz_Status_Reason"   , type: "STRING", tableCode: "EH" },
        "hehz_type"            : { canonical: "hEHz_Type"            , type: "STRING", tableCode: "EH" },
        "hehz_user_def_flags01": { canonical: "hEHz_User_Def_Flags01", type: "STRING", tableCode: "EH" },
        "hehz_user_def_flags02": { canonical: "hEHz_User_Def_Flags02", type: "STRING", tableCode: "EH" },

        // ── (v-prefix) ──────────────────────────────────────────────────
        "hehv_error_message"   : { canonical: "hEHv_Error_Message"   , type: "VARSTRING", tableCode: "EH" },
    }
};

export default EH;
