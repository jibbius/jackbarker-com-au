/**
 * UP.js — table structure for the UP (Unit Price History Records) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "UP").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force UP
 */

/** @type {Object} */
const UP = {
    code: "UP",
    name: "Unit_Price_History_Records",
    recordLength: null,
    helpRegistry: "hUP.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "UPi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hupc_confirmed"      : { canonical: "hUPc_Confirmed"      , type: "STRING", tableCode: "UP" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hupd_effective"      : { canonical: "hUPd_Effective"      , type: "DATE", tableCode: "UP" },
        "hupd_mod_date"       : { canonical: "hUPd_Mod_Date"       , type: "DATE", tableCode: "UP" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hupf_buy_price"      : { canonical: "hUPf_Buy_Price"      , type: "DOUBLE", tableCode: "UP" },
        "hupf_fee_factor"     : { canonical: "hUPf_Fee_Factor"     , type: "DOUBLE", tableCode: "UP" },
        "hupf_hard_buy_price" : { canonical: "hUPf_Hard_Buy_Price" , type: "DOUBLE", tableCode: "UP" },
        "hupf_hard_sell_price": { canonical: "hUPf_Hard_Sell_Price", type: "DOUBLE", tableCode: "UP" },
        "hupf_sell_price"     : { canonical: "hUPf_Sell_Price"     , type: "DOUBLE", tableCode: "UP" },
        "hupf_yield"          : { canonical: "hUPf_Yield"          , type: "DOUBLE", tableCode: "UP" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hupt_mod_time"       : { canonical: "hUPt_Mod_Time"       , type: "TIME", tableCode: "UP" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hupz_inv_mgr"        : { canonical: "hUPz_Inv_Mgr"        , type: "STRING", tableCode: "UP" },
        "hupz_mod_user"       : { canonical: "hUPz_Mod_User"       , type: "STRING", tableCode: "UP" },
        "hupz_spare"          : { canonical: "hUPz_Spare"          , type: "STRING", tableCode: "UP" },
    }
};

export default UP;
