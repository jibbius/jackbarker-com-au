/**
 * UL.js — table structure for the UL (Unpost General Ledger) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "UL").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force UL
 */

/** @type {Object} */
const UL = {
    code: "UL",
    name: "Unpost_General_Ledger",
    recordLength: null,
    helpRegistry: "hUL.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ULi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hulc_archived"       : { canonical: "hULc_Archived"       , type: "STRING", tableCode: "UL" },
        "hulc_leave_total"    : { canonical: "hULc_Leave_Total"    , type: "STRING", tableCode: "UL" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "huld_control"        : { canonical: "hULd_Control"        , type: "DATE", tableCode: "UL" },
        "huld_effective"      : { canonical: "hULd_Effective"      , type: "DATE", tableCode: "UL" },
        "huld_interest"       : { canonical: "hULd_Interest"       , type: "DATE", tableCode: "UL" },
        "huld_mod_date"       : { canonical: "hULd_Mod_Date"       , type: "DATE", tableCode: "UL" },
        "huld_paperwork_rcvd" : { canonical: "hULd_Paperwork_Rcvd" , type: "DATE", tableCode: "UL" },
        "huld_posted"         : { canonical: "hULd_Posted"         , type: "DATE", tableCode: "UL" },
        "huld_spare"          : { canonical: "hULd_Spare"          , type: "DATE", tableCode: "UL" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hulf_amount"         : { canonical: "hULf_Amount"         , type: "DOUBLE", tableCode: "UL" },
        "hulf_total_balance"  : { canonical: "hULf_Total_Balance"  , type: "DOUBLE", tableCode: "UL" },
        "hulf_total_units"    : { canonical: "hULf_Total_Units"    , type: "DOUBLE", tableCode: "UL" },
        "hulf_units"          : { canonical: "hULf_Units"          , type: "DOUBLE", tableCode: "UL" },
        "hulf_ytd_balance"    : { canonical: "hULf_YTD_Balance"    , type: "DOUBLE", tableCode: "UL" },
        "hulf_ytd_units"      : { canonical: "hULf_YTD_Units"      , type: "DOUBLE", tableCode: "UL" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hull_int_trans_ref"  : { canonical: "hULl_Int_Trans_Ref"  , type: "INTEGER", tableCode: "UL" },
        "hull_spare"          : { canonical: "hULl_Spare"          , type: "INTEGER", tableCode: "UL" },
        "hull_trans_ref"      : { canonical: "hULl_Trans_Ref"      , type: "INTEGER", tableCode: "UL" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hult_mod_time"       : { canonical: "hULt_Mod_Time"       , type: "TIME", tableCode: "UL" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hulz_account"        : { canonical: "hULz_Account"        , type: "STRING", tableCode: "UL" },
        "hulz_actual_fund"    : { canonical: "hULz_Actual_Fund"    , type: "STRING", tableCode: "UL" },
        "hulz_actual_member"  : { canonical: "hULz_Actual_Member"  , type: "STRING", tableCode: "UL" },
        "hulz_cont_acct"      : { canonical: "hULz_Cont_Acct"      , type: "STRING", tableCode: "UL" },
        "hulz_debit_or_credit": { canonical: "hULz_Debit_Or_Credit", type: "STRING", tableCode: "UL" },
        "hulz_division"       : { canonical: "hULz_Division"       , type: "STRING", tableCode: "UL" },
        "hulz_fund"           : { canonical: "hULz_Fund"           , type: "STRING", tableCode: "UL" },
        "hulz_member"         : { canonical: "hULz_Member"         , type: "STRING", tableCode: "UL" },
        "hulz_mod_user"       : { canonical: "hULz_Mod_User"       , type: "STRING", tableCode: "UL" },
        "hulz_preservation"   : { canonical: "hULz_Preservation"   , type: "STRING", tableCode: "UL" },
        "hulz_spare"          : { canonical: "hULz_Spare"          , type: "STRING", tableCode: "UL" },
        "hulz_sub_account"    : { canonical: "hULz_Sub_Account"    , type: "STRING", tableCode: "UL" },
        "hulz_sub_sub_account": { canonical: "hULz_Sub_Sub_Account", type: "STRING", tableCode: "UL" },
        "hulz_tran_type"      : { canonical: "hULz_Tran_Type"      , type: "STRING", tableCode: "UL" },
    }
};

export default UL;
