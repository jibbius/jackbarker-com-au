/**
 * FL.js — table structure for the FL (Locked Files and Caches) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FL").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FL
 */

/** @type {Object} */
const FL = {
    code: "FL",
    name: "Locked_Files_and_Caches",
    recordLength: null,
    helpRegistry: "hFL.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FLi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfld_edit"          : { canonical: "hFLd_Edit"          , type: "DATE", tableCode: "FL" },
        "hfld_mod_date"      : { canonical: "hFLd_Mod_Date"      , type: "DATE", tableCode: "FL" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hfll_spare"         : { canonical: "hFLl_Spare"         , type: "INTEGER", tableCode: "FL" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hflt_edit"          : { canonical: "hFLt_Edit"          , type: "TIME", tableCode: "FL" },
        "hflt_mod_time"      : { canonical: "hFLt_Mod_Time"      , type: "TIME", tableCode: "FL" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hflz_directory_path": { canonical: "hFLz_Directory_Path", type: "STRING", tableCode: "FL" },
        "hflz_filename"      : { canonical: "hFLz_Filename"      , type: "STRING", tableCode: "FL" },
        "hflz_mod_user"      : { canonical: "hFLz_Mod_User"      , type: "STRING", tableCode: "FL" },
        "hflz_payroll"       : { canonical: "hFLz_Payroll"       , type: "STRING", tableCode: "FL" },
        "hflz_spare"         : { canonical: "hFLz_Spare"         , type: "STRING", tableCode: "FL" },
    }
};

export default FL;
