/**
 * IR.js — table structure for the IR (Fund Interest Rate History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "IR").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force IR
 */

/** @type {Object} */
const IR = {
    code: "IR",
    name: "Fund_Interest_Rate_History",
    recordLength: null,
    helpRegistry: "hIR.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "IRi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hirc_confirmed"       : { canonical: "hIRc_Confirmed"       , type: "STRING", tableCode: "IR" },
        "hirc_deleted"         : { canonical: "hIRc_Deleted"         , type: "STRING", tableCode: "IR" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hird_interest_rate"   : { canonical: "hIRd_Interest_Rate"   , type: "DATE", tableCode: "IR" },
        "hird_mod_date"        : { canonical: "hIRd_Mod_Date"        , type: "DATE", tableCode: "IR" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hirf_actual_int_rate" : { canonical: "hIRf_Actual_Int_Rate" , type: "DOUBLE", tableCode: "IR" },
        "hirf_compound_rate"   : { canonical: "hIRf_Compound_Rate"   , type: "DOUBLE", tableCode: "IR" },
        "hirf_declared_int_rte": { canonical: "hIRf_Declared_Int_Rte", type: "DOUBLE", tableCode: "IR" },
        "hirf_fee_factor"      : { canonical: "hIRf_Fee_Factor"      , type: "DOUBLE", tableCode: "IR" },
        "hirf_indexation_rate" : { canonical: "hIRf_Indexation_Rate" , type: "DOUBLE", tableCode: "IR" },
        "hirf_interim_int_rate": { canonical: "hIRf_Interim_Int_Rate", type: "DOUBLE", tableCode: "IR" },
        "hirf_spare01"         : { canonical: "hIRf_Spare01"         , type: "DOUBLE", tableCode: "IR" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hirl_spare"           : { canonical: "hIRl_Spare"           , type: "INTEGER", tableCode: "IR" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hirt_mod_time"        : { canonical: "hIRt_Mod_Time"        , type: "TIME", tableCode: "IR" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hirz_division"        : { canonical: "hIRz_Division"        , type: "STRING", tableCode: "IR" },
        "hirz_fund"            : { canonical: "hIRz_Fund"            , type: "STRING", tableCode: "IR" },
        "hirz_interest_type"   : { canonical: "hIRz_Interest_Type"   , type: "STRING", tableCode: "IR" },
        "hirz_mod_user"        : { canonical: "hIRz_Mod_User"        , type: "STRING", tableCode: "IR" },
    }
};

export default IR;
