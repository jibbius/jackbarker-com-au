/**
 * BL.js — table structure for the BL (Balance History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BL").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BL
 */

/** @type {Object} */
const BL = {
    code: "BL",
    name: "Balance_History",
    recordLength: null,
    helpRegistry: "hBL.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BLi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hblc_deleted"         : { canonical: "hBLc_Deleted"         , type: "STRING", tableCode: "BL" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hbld_effective"       : { canonical: "hBLd_Effective"       , type: "DATE", tableCode: "BL" },
        "hbld_spare"           : { canonical: "hBLd_Spare"           , type: "DATE", tableCode: "BL" },
        "hbld_start"           : { canonical: "hBLd_Start"           , type: "DATE", tableCode: "BL" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hblf_cash"            : { canonical: "hBLf_Cash"            , type: "DOUBLE", tableCode: "BL" },
        "hblf_conts"           : { canonical: "hBLf_Conts"           , type: "DOUBLE", tableCode: "BL" },
        "hblf_conts_due"       : { canonical: "hBLf_Conts_Due"       , type: "DOUBLE", tableCode: "BL" },
        "hblf_conts_taken"     : { canonical: "hBLf_Conts_Taken"     , type: "DOUBLE", tableCode: "BL" },
        "hblf_fees"            : { canonical: "hBLf_Fees"            , type: "DOUBLE", tableCode: "BL" },
        "hblf_group_life_prem" : { canonical: "hBLf_Group_Life_Prem" , type: "DOUBLE", tableCode: "BL" },
        "hblf_interest"        : { canonical: "hBLf_Interest"        , type: "DOUBLE", tableCode: "BL" },
        "hblf_mbr_protect_rebt": { canonical: "hBLf_Mbr_Protect_Rebt", type: "DOUBLE", tableCode: "BL" },
        "hblf_misc_credit"     : { canonical: "hBLf_Misc_Credit"     , type: "DOUBLE", tableCode: "BL" },
        "hblf_misc_debit"      : { canonical: "hBLf_Misc_Debit"      , type: "DOUBLE", tableCode: "BL" },
        "hblf_opening"         : { canonical: "hBLf_Opening"         , type: "DOUBLE", tableCode: "BL" },
        "hblf_payments"        : { canonical: "hBLf_Payments"        , type: "DOUBLE", tableCode: "BL" },
        "hblf_surcharge"       : { canonical: "hBLf_Surcharge"       , type: "DOUBLE", tableCode: "BL" },
        "hblf_surcharge_adv"   : { canonical: "hBLf_Surcharge_Adv"   , type: "DOUBLE", tableCode: "BL" },
        "hblf_tax"             : { canonical: "hBLf_Tax"             , type: "DOUBLE", tableCode: "BL" },
        "hblf_total_conts"     : { canonical: "hBLf_Total_Conts"     , type: "DOUBLE", tableCode: "BL" },
        "hblf_unpr_vested_fact": { canonical: "hBLf_Unpr_Vested_Fact", type: "DOUBLE", tableCode: "BL" },
        "hblf_unpreserved"     : { canonical: "hBLf_Unpreserved"     , type: "DOUBLE", tableCode: "BL" },
        "hblf_vested"          : { canonical: "hBLf_Vested"          , type: "DOUBLE", tableCode: "BL" },
        "hblf_vested_factor"   : { canonical: "hBLf_Vested_Factor"   , type: "DOUBLE", tableCode: "BL" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hblz_cont_acct"       : { canonical: "hBLz_Cont_Acct"       , type: "STRING", tableCode: "BL" },
        "hblz_fund"            : { canonical: "hBLz_Fund"            , type: "STRING", tableCode: "BL" },
        "hblz_member"          : { canonical: "hBLz_Member"          , type: "STRING", tableCode: "BL" },
        "hblz_preservation"    : { canonical: "hBLz_Preservation"    , type: "STRING", tableCode: "BL" },
        "hblz_quote"           : { canonical: "hBLz_Quote"           , type: "STRING", tableCode: "BL" },
        "hblz_spare"           : { canonical: "hBLz_Spare"           , type: "STRING", tableCode: "BL" },
    }
};

export default BL;
