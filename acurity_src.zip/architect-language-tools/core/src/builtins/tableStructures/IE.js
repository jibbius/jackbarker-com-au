/**
 * IE.js — table structure for the IE (Income Election History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "IE").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force IE
 */

/** @type {Object} */
const IE = {
    code: "IE",
    name: "Income_Election_History",
    recordLength: null,
    helpRegistry: "hIE.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "IEi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hiec_deleted"        : { canonical: "hIEc_Deleted"        , type: "STRING", tableCode: "IE" },
        "hiec_income_election": { canonical: "hIEc_Income_Election", type: "STRING", tableCode: "IE" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hied_effective"      : { canonical: "hIEd_Effective"      , type: "DATE", tableCode: "IE" },
        "hied_mod_date"       : { canonical: "hIEd_Mod_Date"       , type: "DATE", tableCode: "IE" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hiet_mod_time"       : { canonical: "hIEt_Mod_Time"       , type: "TIME", tableCode: "IE" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hiez_fund"           : { canonical: "hIEz_Fund"           , type: "STRING", tableCode: "IE" },
        "hiez_invmgr"         : { canonical: "hIEz_InvMgr"         , type: "STRING", tableCode: "IE" },
        "hiez_member"         : { canonical: "hIEz_Member"         , type: "STRING", tableCode: "IE" },
        "hiez_mod_user"       : { canonical: "hIEz_Mod_User"       , type: "STRING", tableCode: "IE" },
        "hiez_spare"          : { canonical: "hIEz_Spare"          , type: "STRING", tableCode: "IE" },
    }
};

export default IE;
