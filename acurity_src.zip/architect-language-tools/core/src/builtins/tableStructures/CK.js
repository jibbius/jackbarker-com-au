/**
 * CK.js — table structure for the CK (Benefit Category - Member History Backup) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CK").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CK
 */

/** @type {Object} */
const CK = {
    code: "CK",
    name: "Benefit_Category_-_Member_History_Backup",
    recordLength: null,
    helpRegistry: "hCK.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CKi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hckc_change_forced"  : { canonical: "hCKc_Change_Forced"  , type: "STRING", tableCode: "CK" },
        "hckc_cont_suspended" : { canonical: "hCKc_Cont_Suspended" , type: "STRING", tableCode: "CK" },
        "hckc_contributory"   : { canonical: "hCKc_Contributory"   , type: "STRING", tableCode: "CK" },
        "hckc_deleted"        : { canonical: "hCKc_Deleted"        , type: "STRING", tableCode: "CK" },
        "hckc_working_status" : { canonical: "hCKc_Working_Status" , type: "STRING", tableCode: "CK" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hckd_effective"      : { canonical: "hCKd_Effective"      , type: "DATE", tableCode: "CK" },
        "hckd_mod_date"       : { canonical: "hCKd_Mod_Date"       , type: "DATE", tableCode: "CK" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hckf_maximum_rate"   : { canonical: "hCKf_Maximum_Rate"   , type: "DOUBLE", tableCode: "CK" },
        "hckf_part_time_pcnt" : { canonical: "hCKf_Part_Time_Pcnt" , type: "DOUBLE", tableCode: "CK" },
        "hckf_prev_multiple"  : { canonical: "hCKf_Prev_Multiple"  , type: "DOUBLE", tableCode: "CK" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hckl_batchref_backup": { canonical: "hCKl_Batchref_Backup", type: "INTEGER", tableCode: "CK" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hckt_mod_time"       : { canonical: "hCKt_Mod_Time"       , type: "TIME", tableCode: "CK" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hckz_fund"           : { canonical: "hCKz_Fund"           , type: "STRING", tableCode: "CK" },
        "hckz_member"         : { canonical: "hCKz_Member"         , type: "STRING", tableCode: "CK" },
        "hckz_mod_user"       : { canonical: "hCKz_Mod_User"       , type: "STRING", tableCode: "CK" },
        "hckz_new_category"   : { canonical: "hCKz_New_Category"   , type: "STRING", tableCode: "CK" },
        "hckz_spare"          : { canonical: "hCKz_Spare"          , type: "STRING", tableCode: "CK" },
        "hckz_status"         : { canonical: "hCKz_Status"         , type: "STRING", tableCode: "CK" },
    }
};

export default CK;
