/**
 * CB.js — table structure for the CB (Tax Flag History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CB").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CB
 */

/** @type {Object} */
const CB = {
    code: "CB",
    name: "Tax_Flag_History",
    recordLength: null,
    helpRegistry: "hCB.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CBi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hcbc_associated"      : { canonical: "hCBc_Associated"      , type: "STRING", tableCode: "CB" },
        "hcbc_deleted"         : { canonical: "hCBc_Deleted"         , type: "STRING", tableCode: "CB" },
        "hcbc_employer_support": { canonical: "hCBc_Employer_Support", type: "STRING", tableCode: "CB" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hcbd_effective"       : { canonical: "hCBd_Effective"       , type: "DATE", tableCode: "CB" },
        "hcbd_mod_date"        : { canonical: "hCBd_Mod_Date"        , type: "DATE", tableCode: "CB" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hcbf_claim_limit"     : { canonical: "hCBf_Claim_Limit"     , type: "DOUBLE", tableCode: "CB" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hcbl_spare"           : { canonical: "hCBl_Spare"           , type: "INTEGER", tableCode: "CB" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hcbt_mod_time"        : { canonical: "hCBt_Mod_Time"        , type: "TIME", tableCode: "CB" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcbz_fund"            : { canonical: "hCBz_Fund"            , type: "STRING", tableCode: "CB" },
        "hcbz_member"          : { canonical: "hCBz_Member"          , type: "STRING", tableCode: "CB" },
        "hcbz_mod_user"        : { canonical: "hCBz_Mod_User"        , type: "STRING", tableCode: "CB" },
        "hcbz_spare"           : { canonical: "hCBz_Spare"           , type: "STRING", tableCode: "CB" },
        "hcbz_tax_claim"       : { canonical: "hCBz_Tax_Claim"       , type: "STRING", tableCode: "CB" },
    }
};

export default CB;
