/**
 * DA.js — table structure for the DA (Data Register) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "DA").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force DA
 */

/** @type {Object} */
const DA = {
    code: "DA",
    name: "Data_Register",
    recordLength: null,
    helpRegistry: "hDA.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "DAi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hdac_spare"         : { canonical: "hDAc_Spare"         , type: "STRING", tableCode: "DA" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hdad_effective"     : { canonical: "hDAd_Effective"     , type: "DATE", tableCode: "DA" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hdal_data_no"       : { canonical: "hDAl_Data_No"       , type: "INTEGER", tableCode: "DA" },
        "hdal_spare"         : { canonical: "hDAl_Spare"         , type: "INTEGER", tableCode: "DA" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hdaz_data_type"     : { canonical: "hDAz_Data_Type"     , type: "STRING", tableCode: "DA" },
        "hdaz_division"      : { canonical: "hDAz_Division"      , type: "STRING", tableCode: "DA" },
        "hdaz_fund"          : { canonical: "hDAz_Fund"          , type: "STRING", tableCode: "DA" },
        "hdaz_header_flag"   : { canonical: "hDAz_Header_Flag"   , type: "STRING", tableCode: "DA" },
        "hdaz_interface_type": { canonical: "hDAz_Interface_Type", type: "STRING", tableCode: "DA" },
        "hdaz_payroll"       : { canonical: "hDAz_Payroll"       , type: "STRING", tableCode: "DA" },
        "hdaz_report_id"     : { canonical: "hDAz_Report_ID"     , type: "STRING", tableCode: "DA" },
    }
};

export default DA;
