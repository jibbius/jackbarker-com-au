/**
 * TR.js — table structure for the TR (Table Records) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "TR").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force TR
 */

/** @type {Object} */
const TR = {
    code: "TR",
    name: "Table_Records",
    recordLength: null,
    helpRegistry: "hTR.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "TRi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "htrd_effective"  : { canonical: "hTRd_Effective"  , type: "DATE", tableCode: "TR" },
        "htrd_mod_date"   : { canonical: "hTRd_Mod_Date"   , type: "DATE", tableCode: "TR" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "htrt_mod_time"   : { canonical: "hTRt_Mod_Time"   , type: "TIME", tableCode: "TR" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "htrz_code"       : { canonical: "hTRz_Code"       , type: "STRING", tableCode: "TR" },
        "htrz_deleted"    : { canonical: "hTRz_Deleted"    , type: "STRING", tableCode: "TR" },
        "htrz_description": { canonical: "hTRz_Description", type: "STRING", tableCode: "TR" },
        "htrz_insurer"    : { canonical: "hTRz_Insurer"    , type: "STRING", tableCode: "TR" },
        "htrz_mod_user"   : { canonical: "hTRz_Mod_User"   , type: "STRING", tableCode: "TR" },
        "htrz_spare"      : { canonical: "hTRz_Spare"      , type: "STRING", tableCode: "TR" },
        "htrz_string01"   : { canonical: "hTRz_String01"   , type: "STRING", tableCode: "TR" },
        "htrz_string02"   : { canonical: "hTRz_String02"   , type: "STRING", tableCode: "TR" },
        "htrz_string03"   : { canonical: "hTRz_String03"   , type: "STRING", tableCode: "TR" },
        "htrz_string04"   : { canonical: "hTRz_String04"   , type: "STRING", tableCode: "TR" },
        "htrz_string05"   : { canonical: "hTRz_String05"   , type: "STRING", tableCode: "TR" },
        "htrz_string06"   : { canonical: "hTRz_String06"   , type: "STRING", tableCode: "TR" },
        "htrz_string07"   : { canonical: "hTRz_String07"   , type: "STRING", tableCode: "TR" },
        "htrz_string08"   : { canonical: "hTRz_String08"   , type: "STRING", tableCode: "TR" },
        "htrz_string09"   : { canonical: "hTRz_String09"   , type: "STRING", tableCode: "TR" },
        "htrz_string10"   : { canonical: "hTRz_String10"   , type: "STRING", tableCode: "TR" },
        "htrz_string11"   : { canonical: "hTRz_String11"   , type: "STRING", tableCode: "TR" },
        "htrz_string12"   : { canonical: "hTRz_String12"   , type: "STRING", tableCode: "TR" },
        "htrz_string13"   : { canonical: "hTRz_String13"   , type: "STRING", tableCode: "TR" },
        "htrz_string14"   : { canonical: "hTRz_String14"   , type: "STRING", tableCode: "TR" },
        "htrz_string15"   : { canonical: "hTRz_String15"   , type: "STRING", tableCode: "TR" },
        "htrz_string16"   : { canonical: "hTRz_String16"   , type: "STRING", tableCode: "TR" },
        "htrz_string17"   : { canonical: "hTRz_String17"   , type: "STRING", tableCode: "TR" },
        "htrz_string18"   : { canonical: "hTRz_String18"   , type: "STRING", tableCode: "TR" },
        "htrz_string19"   : { canonical: "hTRz_String19"   , type: "STRING", tableCode: "TR" },
        "htrz_string20"   : { canonical: "hTRz_String20"   , type: "STRING", tableCode: "TR" },
        "htrz_string21"   : { canonical: "hTRz_String21"   , type: "STRING", tableCode: "TR" },
        "htrz_string22"   : { canonical: "hTRz_String22"   , type: "STRING", tableCode: "TR" },
        "htrz_string23"   : { canonical: "hTRz_String23"   , type: "STRING", tableCode: "TR" },
        "htrz_string24"   : { canonical: "hTRz_String24"   , type: "STRING", tableCode: "TR" },
        "htrz_string25"   : { canonical: "hTRz_String25"   , type: "STRING", tableCode: "TR" },
        "htrz_string26"   : { canonical: "hTRz_String26"   , type: "STRING", tableCode: "TR" },
        "htrz_string27"   : { canonical: "hTRz_String27"   , type: "STRING", tableCode: "TR" },
        "htrz_string28"   : { canonical: "hTRz_String28"   , type: "STRING", tableCode: "TR" },
        "htrz_string29"   : { canonical: "hTRz_String29"   , type: "STRING", tableCode: "TR" },
        "htrz_string30"   : { canonical: "hTRz_String30"   , type: "STRING", tableCode: "TR" },
        "htrz_string31"   : { canonical: "hTRz_String31"   , type: "STRING", tableCode: "TR" },
        "htrz_string32"   : { canonical: "hTRz_String32"   , type: "STRING", tableCode: "TR" },
        "htrz_string33"   : { canonical: "hTRz_String33"   , type: "STRING", tableCode: "TR" },
        "htrz_string34"   : { canonical: "hTRz_String34"   , type: "STRING", tableCode: "TR" },
        "htrz_string35"   : { canonical: "hTRz_String35"   , type: "STRING", tableCode: "TR" },
        "htrz_string36"   : { canonical: "hTRz_String36"   , type: "STRING", tableCode: "TR" },
        "htrz_string37"   : { canonical: "hTRz_String37"   , type: "STRING", tableCode: "TR" },
        "htrz_string38"   : { canonical: "hTRz_String38"   , type: "STRING", tableCode: "TR" },
        "htrz_string39"   : { canonical: "hTRz_String39"   , type: "STRING", tableCode: "TR" },
        "htrz_string40"   : { canonical: "hTRz_String40"   , type: "STRING", tableCode: "TR" },
        "htrz_string41"   : { canonical: "hTRz_String41"   , type: "STRING", tableCode: "TR" },
        "htrz_string42"   : { canonical: "hTRz_String42"   , type: "STRING", tableCode: "TR" },
        "htrz_string43"   : { canonical: "hTRz_String43"   , type: "STRING", tableCode: "TR" },
        "htrz_string44"   : { canonical: "hTRz_String44"   , type: "STRING", tableCode: "TR" },
        "htrz_string45"   : { canonical: "hTRz_String45"   , type: "STRING", tableCode: "TR" },
        "htrz_string46"   : { canonical: "hTRz_String46"   , type: "STRING", tableCode: "TR" },
        "htrz_string47"   : { canonical: "hTRz_String47"   , type: "STRING", tableCode: "TR" },
        "htrz_string48"   : { canonical: "hTRz_String48"   , type: "STRING", tableCode: "TR" },
        "htrz_string49"   : { canonical: "hTRz_String49"   , type: "STRING", tableCode: "TR" },
        "htrz_string50"   : { canonical: "hTRz_String50"   , type: "STRING", tableCode: "TR" },
        "htrz_string51"   : { canonical: "hTRz_String51"   , type: "STRING", tableCode: "TR" },
        "htrz_string52"   : { canonical: "hTRz_String52"   , type: "STRING", tableCode: "TR" },
        "htrz_string53"   : { canonical: "hTRz_String53"   , type: "STRING", tableCode: "TR" },
        "htrz_string54"   : { canonical: "hTRz_String54"   , type: "STRING", tableCode: "TR" },
        "htrz_string55"   : { canonical: "hTRz_String55"   , type: "STRING", tableCode: "TR" },
        "htrz_string56"   : { canonical: "hTRz_String56"   , type: "STRING", tableCode: "TR" },
        "htrz_string57"   : { canonical: "hTRz_String57"   , type: "STRING", tableCode: "TR" },
        "htrz_string58"   : { canonical: "hTRz_String58"   , type: "STRING", tableCode: "TR" },
        "htrz_string59"   : { canonical: "hTRz_String59"   , type: "STRING", tableCode: "TR" },
        "htrz_string60"   : { canonical: "hTRz_String60"   , type: "STRING", tableCode: "TR" },
        "htrz_type"       : { canonical: "hTRz_Type"       , type: "STRING", tableCode: "TR" },
    }
};

export default TR;
