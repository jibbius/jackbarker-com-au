/**
 * MH.js — table structure for the MH (Medical History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "MH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force MH
 */

/** @type {Object} */
const MH = {
    code: "MH",
    name: "Medical_History",
    recordLength: null,
    helpRegistry: "hMH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "MHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hmhc_load_whole_amt"  : { canonical: "hMHc_Load_Whole_Amt"  , type: "STRING", tableCode: "MH" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hmhd_assess_review"   : { canonical: "hMHd_Assess_Review"   , type: "DATE", tableCode: "MH" },
        "hmhd_effective"       : { canonical: "hMHd_Effective"       , type: "DATE", tableCode: "MH" },
        "hmhd_mod_date"        : { canonical: "hMHd_Mod_Date"        , type: "DATE", tableCode: "MH" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hmhf_dth_assessed"    : { canonical: "hMHf_DTH_Assessed"    , type: "DOUBLE", tableCode: "MH" },
        "hmhf_dth_assessed2"   : { canonical: "hMHf_DTH_Assessed2"   , type: "DOUBLE", tableCode: "MH" },
        "hmhf_dth_auto_cover"  : { canonical: "hMHf_Dth_Auto_Cover"  , type: "DOUBLE", tableCode: "MH" },
        "hmhf_dth_auto_units"  : { canonical: "hMHf_Dth_Auto_Units"  , type: "DOUBLE", tableCode: "MH" },
        "hmhf_dth_dollar_load" : { canonical: "hMHf_DTH_Dollar_Load" , type: "DOUBLE", tableCode: "MH" },
        "hmhf_dth_pcnt_load"   : { canonical: "hMHf_DTH_Pcnt_Load"   , type: "DOUBLE", tableCode: "MH" },
        "hmhf_dth_pcnt_load2"  : { canonical: "hMHf_DTH_Pcnt_Load2"  , type: "DOUBLE", tableCode: "MH" },
        "hmhf_ip_auto_cover"   : { canonical: "hMHf_IP_Auto_Cover"   , type: "DOUBLE", tableCode: "MH" },
        "hmhf_ip_auto_units"   : { canonical: "hMHf_IP_Auto_Units"   , type: "DOUBLE", tableCode: "MH" },
        "hmhf_sc_assessed"     : { canonical: "hMHf_SC_Assessed"     , type: "DOUBLE", tableCode: "MH" },
        "hmhf_sc_assessed2"    : { canonical: "hMHf_SC_Assessed2"    , type: "DOUBLE", tableCode: "MH" },
        "hmhf_sc_pcnt_load"    : { canonical: "hMHf_SC_Pcnt_Load"    , type: "DOUBLE", tableCode: "MH" },
        "hmhf_sc_pcnt_load2"   : { canonical: "hMHf_SC_Pcnt_Load2"   , type: "DOUBLE", tableCode: "MH" },
        "hmhf_tpd_assessed"    : { canonical: "hMHf_TPD_Assessed"    , type: "DOUBLE", tableCode: "MH" },
        "hmhf_tpd_assessed2"   : { canonical: "hMHf_TPD_Assessed2"   , type: "DOUBLE", tableCode: "MH" },
        "hmhf_tpd_auto_cover"  : { canonical: "hMHf_TPD_Auto_Cover"  , type: "DOUBLE", tableCode: "MH" },
        "hmhf_tpd_auto_units"  : { canonical: "hMHf_TPD_Auto_Units"  , type: "DOUBLE", tableCode: "MH" },
        "hmhf_tpd_dollar_load" : { canonical: "hMHf_TPD_Dollar_Load" , type: "DOUBLE", tableCode: "MH" },
        "hmhf_tpd_pcnt_load"   : { canonical: "hMHf_TPD_Pcnt_Load"   , type: "DOUBLE", tableCode: "MH" },
        "hmhf_tpd_pcnt_load2"  : { canonical: "hMHf_TPD_Pcnt_Load2"  , type: "DOUBLE", tableCode: "MH" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hmhl_assess_limit"    : { canonical: "hMHl_Assess_Limit"    , type: "INTEGER", tableCode: "MH" },
        "hmhl_policy_number"   : { canonical: "hMHl_Policy_Number"   , type: "INTEGER", tableCode: "MH" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hmhs_dth_age_rated"   : { canonical: "hMHs_DTH_Age_Rated"   , type: "INTEGER", tableCode: "MH" },
        "hmhs_spare01"         : { canonical: "hMHs_Spare01"         , type: "INTEGER", tableCode: "MH" },
        "hmhs_spare02"         : { canonical: "hMHs_Spare02"         , type: "INTEGER", tableCode: "MH" },
        "hmhs_tpd_age_rated"   : { canonical: "hMHs_TPD_Age_Rated"   , type: "INTEGER", tableCode: "MH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hmht_mod_time"        : { canonical: "hMHt_Mod_Time"        , type: "TIME", tableCode: "MH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hmhz_assess_rating"   : { canonical: "hMHz_Assess_Rating"   , type: "STRING", tableCode: "MH" },
        "hmhz_assess_rating01" : { canonical: "hMHz_Assess_Rating01" , type: "STRING", tableCode: "MH" },
        "hmhz_assess_rating02" : { canonical: "hMHz_Assess_Rating02" , type: "STRING", tableCode: "MH" },
        "hmhz_assess_rating03" : { canonical: "hMHz_Assess_Rating03" , type: "STRING", tableCode: "MH" },
        "hmhz_assess_rating04" : { canonical: "hMHz_Assess_Rating04" , type: "STRING", tableCode: "MH" },
        "hmhz_assess_rating05" : { canonical: "hMHz_Assess_Rating05" , type: "STRING", tableCode: "MH" },
        "hmhz_assess_ref_code" : { canonical: "hMHz_Assess_Ref_Code" , type: "STRING", tableCode: "MH" },
        "hmhz_client"          : { canonical: "hMHz_Client"          , type: "STRING", tableCode: "MH" },
        "hmhz_deleted"         : { canonical: "hMHz_Deleted"         , type: "STRING", tableCode: "MH" },
        "hmhz_fund"            : { canonical: "hMHz_Fund"            , type: "STRING", tableCode: "MH" },
        "hmhz_insurance_cat"   : { canonical: "hMHz_Insurance_Cat"   , type: "STRING", tableCode: "MH" },
        "hmhz_member_no"       : { canonical: "hMHz_Member_No"       , type: "STRING", tableCode: "MH" },
        "hmhz_mod_user"        : { canonical: "hMHz_Mod_User"        , type: "STRING", tableCode: "MH" },
        "hmhz_record_type"     : { canonical: "hMHz_Record_Type"     , type: "STRING", tableCode: "MH" },
        "hmhz_spare"           : { canonical: "hMHz_Spare"           , type: "STRING", tableCode: "MH" },
        "hmhz_supp_record_type": { canonical: "hMHz_Supp_Record_Type", type: "STRING", tableCode: "MH" },
    }
};

export default MH;
