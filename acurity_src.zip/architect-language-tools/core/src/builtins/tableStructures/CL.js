/**
 * CL.js — table structure for the CL (Employer Location) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CL").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CL
 */

/** @type {Object} */
const CL = {
    code: "CL",
    name: "Employer_Location",
    recordLength: null,
    helpRegistry: "hCL.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CLi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hclc_deleted"         : { canonical: "hCLc_Deleted"         , type: "STRING", tableCode: "CL" },
        "hclc_notes"           : { canonical: "hCLc_Notes"           , type: "STRING", tableCode: "CL" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hcld_date_elected"    : { canonical: "hCLd_Date_Elected"    , type: "DATE", tableCode: "CL" },
        "hcld_end_of_term"     : { canonical: "hCLd_End_Of_Term"     , type: "DATE", tableCode: "CL" },
        "hcld_mod_date"        : { canonical: "hCLd_Mod_Date"        , type: "DATE", tableCode: "CL" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hcll_trans_ref"       : { canonical: "hCLl_Trans_Ref"       , type: "INTEGER", tableCode: "CL" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hcls_contact_no"      : { canonical: "hCLs_Contact_No"      , type: "INTEGER", tableCode: "CL" },
        "hcls_spare01"         : { canonical: "hCLs_Spare01"         , type: "INTEGER", tableCode: "CL" },
        "hcls_spare02"         : { canonical: "hCLs_Spare02"         , type: "INTEGER", tableCode: "CL" },
        "hcls_spare03"         : { canonical: "hCLs_Spare03"         , type: "INTEGER", tableCode: "CL" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hclt_mod_time"        : { canonical: "hCLt_Mod_Time"        , type: "TIME", tableCode: "CL" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hclz_address_line_1"  : { canonical: "hCLz_Address_Line_1"  , type: "STRING", tableCode: "CL" },
        "hclz_address_line_2"  : { canonical: "hCLz_Address_Line_2"  , type: "STRING", tableCode: "CL" },
        "hclz_address_line_3"  : { canonical: "hCLz_Address_Line_3"  , type: "STRING", tableCode: "CL" },
        "hclz_address_state"   : { canonical: "hCLz_Address_State"   , type: "STRING", tableCode: "CL" },
        "hclz_address_suburb"  : { canonical: "hCLz_Address_Suburb"  , type: "STRING", tableCode: "CL" },
        "hclz_address_type"    : { canonical: "hCLz_Address_Type"    , type: "STRING", tableCode: "CL" },
        "hclz_annual_report"   : { canonical: "hCLz_Annual_Report"   , type: "STRING", tableCode: "CL" },
        "hclz_consult_commttee": { canonical: "hCLz_Consult_Commttee", type: "STRING", tableCode: "CL" },
        "hclz_contact_email"   : { canonical: "hCLz_contact_email"   , type: "STRING", tableCode: "CL" },
        "hclz_contact_fax"     : { canonical: "hCLz_Contact_Fax"     , type: "STRING", tableCode: "CL" },
        "hclz_contact_phone"   : { canonical: "hCLz_Contact_Phone"   , type: "STRING", tableCode: "CL" },
        "hclz_contact_type"    : { canonical: "hCLz_Contact_Type"    , type: "STRING", tableCode: "CL" },
        "hclz_country"         : { canonical: "hCLz_Country"         , type: "STRING", tableCode: "CL" },
        "hclz_country_code"    : { canonical: "hCLz_Country_Code"    , type: "STRING", tableCode: "CL" },
        "hclz_department"      : { canonical: "hCLz_Department"      , type: "STRING", tableCode: "CL" },
        "hclz_division"        : { canonical: "hCLz_Division"        , type: "STRING", tableCode: "CL" },
        "hclz_dpid_code"       : { canonical: "hCLz_DPID_Code"       , type: "STRING", tableCode: "CL" },
        "hclz_extra_addr_line1": { canonical: "hCLz_Extra_Addr_Line1", type: "STRING", tableCode: "CL" },
        "hclz_extra_addr_line2": { canonical: "hCLz_Extra_Addr_Line2", type: "STRING", tableCode: "CL" },
        "hclz_extra_postcode"  : { canonical: "hCLz_Extra_Postcode"  , type: "STRING", tableCode: "CL" },
        "hclz_extra_state"     : { canonical: "hCLz_Extra_State"     , type: "STRING", tableCode: "CL" },
        "hclz_extra_suburb"    : { canonical: "hCLz_Extra_Suburb"    , type: "STRING", tableCode: "CL" },
        "hclz_fund"            : { canonical: "hCLz_Fund"            , type: "STRING", tableCode: "CL" },
        "hclz_given_names"     : { canonical: "hCLz_Given_Names"     , type: "STRING", tableCode: "CL" },
        "hclz_job_title"       : { canonical: "hCLz_Job_Title"       , type: "STRING", tableCode: "CL" },
        "hclz_location"        : { canonical: "hCLz_Location"        , type: "STRING", tableCode: "CL" },
        "hclz_location_name"   : { canonical: "hCLz_Location_Name"   , type: "STRING", tableCode: "CL" },
        "hclz_long_location"   : { canonical: "hCLz_Long_Location"   , type: "STRING", tableCode: "CL" },
        "hclz_mobile_phone"    : { canonical: "hCLz_Mobile_Phone"    , type: "STRING", tableCode: "CL" },
        "hclz_mod_user"        : { canonical: "hCLz_Mod_User"        , type: "STRING", tableCode: "CL" },
        "hclz_payroll"         : { canonical: "hCLz_Payroll"         , type: "STRING", tableCode: "CL" },
        "hclz_post_code"       : { canonical: "hCLz_Post_Code"       , type: "STRING", tableCode: "CL" },
        "hclz_spare"           : { canonical: "hCLz_Spare"           , type: "STRING", tableCode: "CL" },
        "hclz_surname"         : { canonical: "hCLz_Surname"         , type: "STRING", tableCode: "CL" },
        "hclz_title"           : { canonical: "hCLz_Title"           , type: "STRING", tableCode: "CL" },
    }
};

export default CL;
