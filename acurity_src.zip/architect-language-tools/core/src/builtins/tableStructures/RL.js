/**
 * RL.js — table structure for the RL (Report Control) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "RL").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force RL
 */

/** @type {Object} */
const RL = {
    code: "RL",
    name: "Report_Control",
    recordLength: null,
    helpRegistry: "hRL.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "RLi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hrlc_action"          : { canonical: "hRLc_Action"          , type: "STRING", tableCode: "RL" },
        "hrlc_all_divisions"   : { canonical: "hRLc_All_Divisions"   , type: "STRING", tableCode: "RL" },
        "hrlc_append_report"   : { canonical: "hRLc_Append_Report"   , type: "STRING", tableCode: "RL" },
        "hrlc_direct_print"    : { canonical: "hRLc_Direct_Print"    , type: "STRING", tableCode: "RL" },
        "hrlc_email"           : { canonical: "hRLc_Email"           , type: "STRING", tableCode: "RL" },
        "hrlc_exits_included"  : { canonical: "hRLc_Exits_Included"  , type: "STRING", tableCode: "RL" },
        "hrlc_level_accounting": { canonical: "hRLc_Level_Accounting", type: "STRING", tableCode: "RL" },
        "hrlc_output_type"     : { canonical: "hRLc_Output_Type"     , type: "STRING", tableCode: "RL" },
        "hrlc_printer_code"    : { canonical: "hRLc_Printer_Code"    , type: "STRING", tableCode: "RL" },
        "hrlc_purge"           : { canonical: "hRLc_Purge"           , type: "STRING", tableCode: "RL" },
        "hrlc_report_per_mbr"  : { canonical: "hRLc_Report_Per_Mbr"  , type: "STRING", tableCode: "RL" },
        "hrlc_sort_order"      : { canonical: "hRLc_Sort_Order"      , type: "STRING", tableCode: "RL" },
        "hrlc_status"          : { canonical: "hRLc_Status"          , type: "STRING", tableCode: "RL" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hrld_end"             : { canonical: "hRLd_End"             , type: "DATE", tableCode: "RL" },
        "hrld_mod_date"        : { canonical: "hRLd_Mod_Date"        , type: "DATE", tableCode: "RL" },
        "hrld_start"           : { canonical: "hRLd_Start"           , type: "DATE", tableCode: "RL" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hrlf_order_price"     : { canonical: "hRLf_Order_Price"     , type: "DOUBLE", tableCode: "RL" },
        "hrlf_user_def_amt01"  : { canonical: "hRLf_User_Def_Amt01"  , type: "DOUBLE", tableCode: "RL" },
        "hrlf_user_def_amt02"  : { canonical: "hRLf_User_Def_Amt02"  , type: "DOUBLE", tableCode: "RL" },
        "hrlf_user_def_amt03"  : { canonical: "hRLf_User_Def_Amt03"  , type: "DOUBLE", tableCode: "RL" },
        "hrlf_user_def_amt04"  : { canonical: "hRLf_User_Def_Amt04"  , type: "DOUBLE", tableCode: "RL" },
        "hrlf_user_def_amt05"  : { canonical: "hRLf_User_Def_Amt05"  , type: "DOUBLE", tableCode: "RL" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hrll_batch_ref"       : { canonical: "hRLl_Batch_Ref"       , type: "INTEGER", tableCode: "RL" },
        "hrll_job_ref"         : { canonical: "hRLl_Job_Ref"         , type: "INTEGER", tableCode: "RL" },
        "hrll_spare"           : { canonical: "hRLl_Spare"           , type: "INTEGER", tableCode: "RL" },
        "hrll_trans_ref"       : { canonical: "hRLl_Trans_Ref"       , type: "INTEGER", tableCode: "RL" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hrls_sequence"        : { canonical: "hRLs_Sequence"        , type: "INTEGER", tableCode: "RL" },
        "hrls_spare01"         : { canonical: "hRLs_Spare01"         , type: "INTEGER", tableCode: "RL" },
        "hrls_spare02"         : { canonical: "hRLs_Spare02"         , type: "INTEGER", tableCode: "RL" },
        "hrls_spare03"         : { canonical: "hRLs_Spare03"         , type: "INTEGER", tableCode: "RL" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hrlt_mod_time"        : { canonical: "hRLt_Mod_Time"        , type: "TIME", tableCode: "RL" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hrlz_as400_job_name"  : { canonical: "hRLz_AS400_Job_Name"  , type: "STRING", tableCode: "RL" },
        "hrlz_as400_job_number": { canonical: "hRLz_AS400_Job_Number", type: "STRING", tableCode: "RL" },
        "hrlz_as400_userid"    : { canonical: "hRLz_AS400_Userid"    , type: "STRING", tableCode: "RL" },
        "hrlz_broker"          : { canonical: "hRLz_Broker"          , type: "STRING", tableCode: "RL" },
        "hrlz_division"        : { canonical: "hRLz_Division"        , type: "STRING", tableCode: "RL" },
        "hrlz_fund"            : { canonical: "hRLz_Fund"            , type: "STRING", tableCode: "RL" },
        "hrlz_info_string"     : { canonical: "hRLz_Info_String"     , type: "STRING", tableCode: "RL" },
        "hrlz_insurer"         : { canonical: "hRLz_Insurer"         , type: "STRING", tableCode: "RL" },
        "hrlz_investment_mgr"  : { canonical: "hRLz_Investment_Mgr"  , type: "STRING", tableCode: "RL" },
        "hrlz_member"          : { canonical: "hRLz_Member"          , type: "STRING", tableCode: "RL" },
        "hrlz_mod_user"        : { canonical: "hRLz_Mod_User"        , type: "STRING", tableCode: "RL" },
        "hrlz_payroll"         : { canonical: "hRLz_Payroll"         , type: "STRING", tableCode: "RL" },
        "hrlz_region_branch"   : { canonical: "hRLz_Region_Branch"   , type: "STRING", tableCode: "RL" },
        "hrlz_report_code"     : { canonical: "hRLz_Report_Code"     , type: "STRING", tableCode: "RL" },
        "hrlz_report_group"    : { canonical: "hRLz_Report_Group"    , type: "STRING", tableCode: "RL" },
        "hrlz_report_id"       : { canonical: "hRLz_Report_ID"       , type: "STRING", tableCode: "RL" },
        "hrlz_report_parms"    : { canonical: "hRLz_Report_Parms"    , type: "STRING", tableCode: "RL" },
        "hrlz_spare"           : { canonical: "hRLz_Spare"           , type: "STRING", tableCode: "RL" },
        "hrlz_user_id"         : { canonical: "hRLz_User_ID"         , type: "STRING", tableCode: "RL" },
    }
};

export default RL;
