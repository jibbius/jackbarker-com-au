/**
 * RE.js — table structure for the RE (Member Unit Refund Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "RE").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force RE
 */

/** @type {Object} */
const RE = {
    code: "RE",
    name: "Member_Unit_Refund_Details",
    recordLength: null,
    helpRegistry: "hRE.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "REi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hred_mod_date"        : { canonical: "hREd_Mod_Date"        , type: "DATE", tableCode: "RE" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "href_refunded_abandnd": { canonical: "hREf_Refunded_Abandnd", type: "DOUBLE", tableCode: "RE" },
        "href_refunded_held"   : { canonical: "hREf_Refunded_Held"   , type: "DOUBLE", tableCode: "RE" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hrel_corr_sequence_no": { canonical: "hREl_Corr_Sequence_No", type: "INTEGER", tableCode: "RE" },
        "hrel_sequence_no"     : { canonical: "hREl_Sequence_No"     , type: "INTEGER", tableCode: "RE" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hret_mod_time"        : { canonical: "hREt_Mod_Time"        , type: "TIME", tableCode: "RE" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hrez_fund"            : { canonical: "hREz_Fund"            , type: "STRING", tableCode: "RE" },
        "hrez_member"          : { canonical: "hREz_Member"          , type: "STRING", tableCode: "RE" },
        "hrez_mod_user"        : { canonical: "hREz_Mod_User"        , type: "STRING", tableCode: "RE" },
    }
};

export default RE;
