/**
 * BN.js — table structure for the BN (Bank Reconciliation History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BN").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BN
 */

/** @type {Object} */
const BN = {
    code: "BN",
    name: "Bank_Reconciliation_History",
    recordLength: null,
    helpRegistry: "hBN.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BNi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hbnc_deleted"         : { canonical: "hBNc_Deleted"         , type: "STRING", tableCode: "BN" },
        "hbnc_spare"           : { canonical: "hBNc_Spare"           , type: "STRING", tableCode: "BN" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hbnd_creation"        : { canonical: "hBNd_Creation"        , type: "DATE", tableCode: "BN" },
        "hbnd_effective"       : { canonical: "hBNd_Effective"       , type: "DATE", tableCode: "BN" },
        "hbnd_settlement"      : { canonical: "hBNd_Settlement"      , type: "DATE", tableCode: "BN" },
        "hbnd_spare"           : { canonical: "hBNd_Spare"           , type: "DATE", tableCode: "BN" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hbnf_amount"          : { canonical: "hBNf_Amount"          , type: "DOUBLE", tableCode: "BN" },
        "hbnf_settlement"      : { canonical: "hBNf_Settlement"      , type: "DOUBLE", tableCode: "BN" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hbnl_bank_ref"        : { canonical: "hBNl_Bank_Ref"        , type: "INTEGER", tableCode: "BN" },
        "hbnl_bank_stmt_ref"   : { canonical: "hBNl_Bank_Stmt_Ref"   , type: "INTEGER", tableCode: "BN" },
        "hbnl_link_ref"        : { canonical: "hBNl_Link_Ref"        , type: "INTEGER", tableCode: "BN" },
        "hbnl_trans_ref"       : { canonical: "hBNl_Trans_Ref"       , type: "INTEGER", tableCode: "BN" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hbnt_creation"        : { canonical: "hBNt_Creation"        , type: "TIME", tableCode: "BN" },
        "hbnt_effective"       : { canonical: "hBNt_Effective"       , type: "TIME", tableCode: "BN" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hbnz_bank_acct_no"    : { canonical: "hBNz_Bank_Acct_No"    , type: "STRING", tableCode: "BN" },
        "hbnz_biller_code"     : { canonical: "hBNz_Biller_Code"     , type: "STRING", tableCode: "BN" },
        "hbnz_crn"             : { canonical: "hBNz_CRN"             , type: "STRING", tableCode: "BN" },
        "hbnz_debit_or_credit" : { canonical: "hBNz_Debit_Or_Credit" , type: "STRING", tableCode: "BN" },
        "hbnz_division"        : { canonical: "hBNz_Division"        , type: "STRING", tableCode: "BN" },
        "hbnz_filename"        : { canonical: "hBNz_Filename"        , type: "STRING", tableCode: "BN" },
        "hbnz_originator_id"   : { canonical: "hBNz_Originator_Id"   , type: "STRING", tableCode: "BN" },
        "hbnz_payment_type"    : { canonical: "hBNz_Payment_Type"    , type: "STRING", tableCode: "BN" },
        "hbnz_receiver_id"     : { canonical: "hBNz_Receiver_Id"     , type: "STRING", tableCode: "BN" },
        "hbnz_reconciled"      : { canonical: "hBNz_Reconciled"      , type: "STRING", tableCode: "BN" },
        "hbnz_record_type"     : { canonical: "hBNz_Record_Type"     , type: "STRING", tableCode: "BN" },
        "hbnz_reference01"     : { canonical: "hBNz_Reference01"     , type: "STRING", tableCode: "BN" },
        "hbnz_reference02"     : { canonical: "hBNz_Reference02"     , type: "STRING", tableCode: "BN" },
        "hbnz_reference03"     : { canonical: "hBNz_Reference03"     , type: "STRING", tableCode: "BN" },
        "hbnz_text"            : { canonical: "hBNz_Text"            , type: "STRING", tableCode: "BN" },
        "hbnz_transaction_code": { canonical: "hBNz_Transaction_Code", type: "STRING", tableCode: "BN" },
        "hbnz_type01"          : { canonical: "hBNz_Type01"          , type: "STRING", tableCode: "BN" },
        "hbnz_type02"          : { canonical: "hBNz_Type02"          , type: "STRING", tableCode: "BN" },
        "hbnz_type03"          : { canonical: "hBNz_Type03"          , type: "STRING", tableCode: "BN" },
    }
};

export default BN;
