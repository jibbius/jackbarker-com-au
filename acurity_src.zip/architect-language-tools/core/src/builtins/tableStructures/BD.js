/**
 * BD.js — table structure for the BD (Broker) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BD").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BD
 */

/** @type {Object} */
const BD = {
    code: "BD",
    name: "Broker",
    recordLength: null,
    helpRegistry: "hBD.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BDi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hbdc_deleted"         : { canonical: "hBDc_Deleted"         , type: "STRING", tableCode: "BD" },
        "hbdc_halt_corres"     : { canonical: "hBDc_Halt_Corres"     , type: "STRING", tableCode: "BD" },
        "hbdc_model_portfolio" : { canonical: "hBDc_Model_Portfolio" , type: "STRING", tableCode: "BD" },
        "hbdc_rcti_agreement"  : { canonical: "hBDc_RCTI_Agreement"  , type: "STRING", tableCode: "BD" },
        "hbdc_spare"           : { canonical: "hBDc_Spare"           , type: "STRING", tableCode: "BD" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hbdd_c_date_of_birth" : { canonical: "hBDd_C_Date_Of_Birth" , type: "DATE", tableCode: "BD" },
        "hbdd_date01"          : { canonical: "hBDd_Date01"          , type: "DATE", tableCode: "BD" },
        "hbdd_date02"          : { canonical: "hBDd_Date02"          , type: "DATE", tableCode: "BD" },
        "hbdd_date03"          : { canonical: "hBDd_Date03"          , type: "DATE", tableCode: "BD" },
        "hbdd_date04"          : { canonical: "hBDd_Date04"          , type: "DATE", tableCode: "BD" },
        "hbdd_date05"          : { canonical: "hBDd_Date05"          , type: "DATE", tableCode: "BD" },
        "hbdd_fps_lastdate1"   : { canonical: "hBDd_FPS_LastDate1"   , type: "DATE", tableCode: "BD" },
        "hbdd_fps_lastdate2"   : { canonical: "hBDd_FPS_LastDate2"   , type: "DATE", tableCode: "BD" },
        "hbdd_fps_lastdate3"   : { canonical: "hBDd_FPS_LastDate3"   , type: "DATE", tableCode: "BD" },
        "hbdd_kyc_supplied"    : { canonical: "hBDd_KYC_Supplied"    , type: "DATE", tableCode: "BD" },
        "hbdd_last_contacted"  : { canonical: "hBDd_Last_Contacted"  , type: "DATE", tableCode: "BD" },
        "hbdd_mod_date"        : { canonical: "hBDd_Mod_Date"        , type: "DATE", tableCode: "BD" },
        "hbdd_next_to_contact" : { canonical: "hBDd_Next_To_Contact" , type: "DATE", tableCode: "BD" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hbdf_amount01"        : { canonical: "hBDf_Amount01"        , type: "DOUBLE", tableCode: "BD" },
        "hbdf_amount02"        : { canonical: "hBDf_Amount02"        , type: "DOUBLE", tableCode: "BD" },
        "hbdf_amount03"        : { canonical: "hBDf_Amount03"        , type: "DOUBLE", tableCode: "BD" },
        "hbdf_amount04"        : { canonical: "hBDf_Amount04"        , type: "DOUBLE", tableCode: "BD" },
        "hbdf_amount05"        : { canonical: "hBDf_Amount05"        , type: "DOUBLE", tableCode: "BD" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hbdl_fps_seq_no"      : { canonical: "hBDl_FPS_Seq_No"      , type: "INTEGER", tableCode: "BD" },
        "hbdl_spare"           : { canonical: "hBDl_Spare"           , type: "INTEGER", tableCode: "BD" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hbdt_mod_time"        : { canonical: "hBDt_Mod_Time"        , type: "TIME", tableCode: "BD" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hbdz_accounts_payable": { canonical: "hBDz_Accounts_Payable", type: "STRING", tableCode: "BD" },
        "hbdz_address_line_0"  : { canonical: "hBDz_Address_Line_0"  , type: "STRING", tableCode: "BD" },
        "hbdz_address01"       : { canonical: "hBDz_Address01"       , type: "STRING", tableCode: "BD" },
        "hbdz_address02"       : { canonical: "hBDz_Address02"       , type: "STRING", tableCode: "BD" },
        "hbdz_address03"       : { canonical: "hBDz_Address03"       , type: "STRING", tableCode: "BD" },
        "hbdz_adviser"         : { canonical: "hBDz_Adviser"         , type: "STRING", tableCode: "BD" },
        "hbdz_aust_business_no": { canonical: "hBDz_Aust_Business_No", type: "STRING", tableCode: "BD" },
        "hbdz_bank_account"    : { canonical: "hBDz_Bank_Account"    , type: "STRING", tableCode: "BD" },
        "hbdz_branch"          : { canonical: "hBDz_Branch"          , type: "STRING", tableCode: "BD" },
        "hbdz_bsb"             : { canonical: "hBDz_BSB"             , type: "STRING", tableCode: "BD" },
        "hbdz_business_name"   : { canonical: "hBDz_Business_Name"   , type: "STRING", tableCode: "BD" },
        "hbdz_c_address01"     : { canonical: "hBDz_C_Address01"     , type: "STRING", tableCode: "BD" },
        "hbdz_c_address02"     : { canonical: "hBDz_C_Address02"     , type: "STRING", tableCode: "BD" },
        "hbdz_c_address03"     : { canonical: "hBDz_C_Address03"     , type: "STRING", tableCode: "BD" },
        "hbdz_c_given_names"   : { canonical: "hBDz_C_Given_Names"   , type: "STRING", tableCode: "BD" },
        "hbdz_c_marital_stat"  : { canonical: "hBDz_C_Marital_Stat"  , type: "STRING", tableCode: "BD" },
        "hbdz_c_phone"         : { canonical: "hBDz_C_Phone"         , type: "STRING", tableCode: "BD" },
        "hbdz_c_position"      : { canonical: "hBDz_C_Position"      , type: "STRING", tableCode: "BD" },
        "hbdz_c_postcode"      : { canonical: "hBDz_C_Postcode"      , type: "STRING", tableCode: "BD" },
        "hbdz_c_sex"           : { canonical: "hBDz_C_Sex"           , type: "STRING", tableCode: "BD" },
        "hbdz_c_surname"       : { canonical: "hBDz_C_Surname"       , type: "STRING", tableCode: "BD" },
        "hbdz_c_work_phone"    : { canonical: "hBDz_C_Work_Phone"    , type: "STRING", tableCode: "BD" },
        "hbdz_country"         : { canonical: "hBDz_Country"         , type: "STRING", tableCode: "BD" },
        "hbdz_country_code"    : { canonical: "hBDz_Country_Code"    , type: "STRING", tableCode: "BD" },
        "hbdz_dealer"          : { canonical: "hBDz_Dealer"          , type: "STRING", tableCode: "BD" },
        "hbdz_email"           : { canonical: "hBDz_Email"           , type: "STRING", tableCode: "BD" },
        "hbdz_email2"          : { canonical: "hBDz_Email2"          , type: "STRING", tableCode: "BD" },
        "hbdz_fax_no"          : { canonical: "hBDz_Fax_No"          , type: "STRING", tableCode: "BD" },
        "hbdz_flags01"         : { canonical: "hBDz_Flags01"         , type: "STRING", tableCode: "BD" },
        "hbdz_flags02"         : { canonical: "hBDz_Flags02"         , type: "STRING", tableCode: "BD" },
        "hbdz_flags03"         : { canonical: "hBDz_Flags03"         , type: "STRING", tableCode: "BD" },
        "hbdz_flags04"         : { canonical: "hBDz_Flags04"         , type: "STRING", tableCode: "BD" },
        "hbdz_flags05"         : { canonical: "hBDz_Flags05"         , type: "STRING", tableCode: "BD" },
        "hbdz_fps_code"        : { canonical: "hBDz_FPS_Code"        , type: "STRING", tableCode: "BD" },
        "hbdz_fps_type"        : { canonical: "hBDz_FPS_Type"        , type: "STRING", tableCode: "BD" },
        "hbdz_kyc_status"      : { canonical: "hBDz_KYC_Status"      , type: "STRING", tableCode: "BD" },
        "hbdz_master"          : { canonical: "hBDz_Master"          , type: "STRING", tableCode: "BD" },
        "hbdz_mobile_phone"    : { canonical: "hBDz_Mobile_Phone"    , type: "STRING", tableCode: "BD" },
        "hbdz_mod_user"        : { canonical: "hBDz_Mod_User"        , type: "STRING", tableCode: "BD" },
        "hbdz_name"            : { canonical: "hBDz_Name"            , type: "STRING", tableCode: "BD" },
        "hbdz_postcode"        : { canonical: "hBDz_Postcode"        , type: "STRING", tableCode: "BD" },
        "hbdz_text01"          : { canonical: "hBDz_Text01"          , type: "STRING", tableCode: "BD" },
        "hbdz_text02"          : { canonical: "hBDz_Text02"          , type: "STRING", tableCode: "BD" },
        "hbdz_text03"          : { canonical: "hBDz_Text03"          , type: "STRING", tableCode: "BD" },
        "hbdz_text04"          : { canonical: "hBDz_Text04"          , type: "STRING", tableCode: "BD" },
        "hbdz_text05"          : { canonical: "hBDz_Text05"          , type: "STRING", tableCode: "BD" },
        "hbdz_title"           : { canonical: "hBDz_Title"           , type: "STRING", tableCode: "BD" },
        "hbdz_type"            : { canonical: "hBDz_Type"            , type: "STRING", tableCode: "BD" },
    }
};

export default BD;
