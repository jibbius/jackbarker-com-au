/**
 * TZ.js — table structure for the TZ (Sliding Scale Tables) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "TZ").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force TZ
 */

/** @type {Object} */
const TZ = {
    code: "TZ",
    name: "Sliding_Scale_Tables",
    recordLength: null,
    helpRegistry: "hTZ.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "TZi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "htzc_scale"      : { canonical: "hTZc_Scale"      , type: "STRING", tableCode: "TZ" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "htzd_effective"  : { canonical: "hTZd_Effective"  , type: "DATE", tableCode: "TZ" },
        "htzd_mod_date"   : { canonical: "hTZd_Mod_Date"   , type: "DATE", tableCode: "TZ" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "htzf_table01"    : { canonical: "hTZf_Table01"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table02"    : { canonical: "hTZf_Table02"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table03"    : { canonical: "hTZf_Table03"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table04"    : { canonical: "hTZf_Table04"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table05"    : { canonical: "hTZf_Table05"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table06"    : { canonical: "hTZf_Table06"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table07"    : { canonical: "hTZf_Table07"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table08"    : { canonical: "hTZf_Table08"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table09"    : { canonical: "hTZf_Table09"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table10"    : { canonical: "hTZf_Table10"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table11"    : { canonical: "hTZf_Table11"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table12"    : { canonical: "hTZf_Table12"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table13"    : { canonical: "hTZf_Table13"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table14"    : { canonical: "hTZf_Table14"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table15"    : { canonical: "hTZf_Table15"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table16"    : { canonical: "hTZf_Table16"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table17"    : { canonical: "hTZf_Table17"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table18"    : { canonical: "hTZf_Table18"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table19"    : { canonical: "hTZf_Table19"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_table20"    : { canonical: "hTZf_Table20"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value01"    : { canonical: "hTZf_Value01"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value02"    : { canonical: "hTZf_Value02"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value03"    : { canonical: "hTZf_Value03"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value04"    : { canonical: "hTZf_Value04"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value05"    : { canonical: "hTZf_Value05"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value06"    : { canonical: "hTZf_Value06"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value07"    : { canonical: "hTZf_Value07"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value08"    : { canonical: "hTZf_Value08"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value09"    : { canonical: "hTZf_Value09"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value10"    : { canonical: "hTZf_Value10"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value11"    : { canonical: "hTZf_Value11"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value12"    : { canonical: "hTZf_Value12"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value13"    : { canonical: "hTZf_Value13"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value14"    : { canonical: "hTZf_Value14"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value15"    : { canonical: "hTZf_Value15"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value16"    : { canonical: "hTZf_Value16"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value17"    : { canonical: "hTZf_Value17"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value18"    : { canonical: "hTZf_Value18"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value19"    : { canonical: "hTZf_Value19"    , type: "DOUBLE", tableCode: "TZ" },
        "htzf_value20"    : { canonical: "hTZf_Value20"    , type: "DOUBLE", tableCode: "TZ" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "htzs_rate_change": { canonical: "hTZs_Rate_Change", type: "INTEGER", tableCode: "TZ" },
        "htzs_spare01"    : { canonical: "hTZs_Spare01"    , type: "INTEGER", tableCode: "TZ" },
        "htzs_spare02"    : { canonical: "hTZs_Spare02"    , type: "INTEGER", tableCode: "TZ" },
        "htzs_spare03"    : { canonical: "hTZs_Spare03"    , type: "INTEGER", tableCode: "TZ" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "htzt_mod_time"   : { canonical: "hTZt_Mod_Time"   , type: "TIME", tableCode: "TZ" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "htzz_code"       : { canonical: "hTZz_Code"       , type: "STRING", tableCode: "TZ" },
        "htzz_deleted"    : { canonical: "hTZz_Deleted"    , type: "STRING", tableCode: "TZ" },
        "htzz_description": { canonical: "hTZz_Description", type: "STRING", tableCode: "TZ" },
        "htzz_insurer"    : { canonical: "hTZz_Insurer"    , type: "STRING", tableCode: "TZ" },
        "htzz_mod_user"   : { canonical: "hTZz_Mod_User"   , type: "STRING", tableCode: "TZ" },
        "htzz_spare"      : { canonical: "hTZz_Spare"      , type: "STRING", tableCode: "TZ" },
        "htzz_type"       : { canonical: "hTZz_Type"       , type: "STRING", tableCode: "TZ" },
    }
};

export default TZ;
