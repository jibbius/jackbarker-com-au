/**
 * AU.js — table structure for the AU (Audit Control) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AU").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AU
 */

/** @type {Object} */
const AU = {
    code: "AU",
    name: "Audit_Control",
    recordLength: null,
    helpRegistry: "hAU.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "AUi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hauc_audit"          : { canonical: "hAUc_Audit"          , type: "STRING", tableCode: "AU" },
        "hauc_authorise"      : { canonical: "hAUc_Authorise"      , type: "STRING", tableCode: "AU" },
        "hauc_type"           : { canonical: "hAUc_Type"           , type: "STRING", tableCode: "AU" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "haud_mod_date"       : { canonical: "hAUd_Mod_Date"       , type: "DATE", tableCode: "AU" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "haul_c_array_element": { canonical: "hAUl_C_Array_Element", type: "INTEGER", tableCode: "AU" },
        "haul_grouping_code"  : { canonical: "hAUl_Grouping_Code"  , type: "INTEGER", tableCode: "AU" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "haut_mod_time"       : { canonical: "hAUt_Mod_Time"       , type: "TIME", tableCode: "AU" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hauz_description"    : { canonical: "hAUz_Description"    , type: "STRING", tableCode: "AU" },
        "hauz_mod_user"       : { canonical: "hAUz_Mod_User"       , type: "STRING", tableCode: "AU" },
        "hauz_name"           : { canonical: "hAUz_Name"           , type: "STRING", tableCode: "AU" },
    }
};

export default AU;
