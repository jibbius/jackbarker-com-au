/**
 * AT.js — table structure for the AT (Audit Trail) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AT").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AT
 */

/** @type {Object} */
const AT = {
    code: "AT",
    name: "Audit_Trail",
    recordLength: null,
    helpRegistry: "hAT.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ATi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hatd_mod_date"  : { canonical: "hATd_Mod_Date"  , type: "DATE", tableCode: "AT" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hatl_job_ref"   : { canonical: "hATl_Job_Ref"   , type: "INTEGER", tableCode: "AT" },
        "hatl_spare"     : { canonical: "hATl_Spare"     , type: "INTEGER", tableCode: "AT" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hatt_mod_time"  : { canonical: "hATt_Mod_Time"  , type: "TIME", tableCode: "AT" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hatz_audit_type": { canonical: "hATz_Audit_Type", type: "STRING", tableCode: "AT" },
        "hatz_client"    : { canonical: "hATz_Client"    , type: "STRING", tableCode: "AT" },
        "hatz_field_name": { canonical: "hATz_Field_Name", type: "STRING", tableCode: "AT" },
        "hatz_key_field" : { canonical: "hATz_Key_Field" , type: "STRING", tableCode: "AT" },
        "hatz_mod_user"  : { canonical: "hATz_Mod_User"  , type: "STRING", tableCode: "AT" },
        "hatz_new_value" : { canonical: "hATz_New_Value" , type: "STRING", tableCode: "AT" },
        "hatz_old_value" : { canonical: "hATz_Old_Value" , type: "STRING", tableCode: "AT" },
        "hatz_spare"     : { canonical: "hATz_Spare"     , type: "STRING", tableCode: "AT" },
    }
};

export default AT;
