/**
 * CC.js — table structure for the CC (Corporate Action Election) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CC").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CC
 */

/** @type {Object} */
const CC = {
    code: "CC",
    name: "Corporate_Action_Election",
    recordLength: null,
    helpRegistry: "hCC.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CCi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hccd_election"        : { canonical: "hCCd_Election"        , type: "DATE", tableCode: "CC" },
        "hccd_mod_date"        : { canonical: "hCCd_Mod_Date"        , type: "DATE", tableCode: "CC" },
        "hccd_spare"           : { canonical: "hCCd_Spare"           , type: "DATE", tableCode: "CC" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hccf_amount"          : { canonical: "hCCf_Amount"          , type: "DOUBLE", tableCode: "CC" },
        "hccf_max_no_of_shares": { canonical: "hCCf_Max_No_Of_Shares", type: "DOUBLE", tableCode: "CC" },
        "hccf_no_of_shares"    : { canonical: "hCCf_No_Of_Shares"    , type: "DOUBLE", tableCode: "CC" },
        "hccf_unit_balance"    : { canonical: "hCCf_Unit_Balance"    , type: "DOUBLE", tableCode: "CC" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hccl_corpactionid"    : { canonical: "hCCl_CorpActionId"    , type: "INTEGER", tableCode: "CC" },
        "hccl_spare"           : { canonical: "hCCl_Spare"           , type: "INTEGER", tableCode: "CC" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hcct_mod_time"        : { canonical: "hCCt_Mod_Time"        , type: "TIME", tableCode: "CC" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hccz_fund"            : { canonical: "hCCz_Fund"            , type: "STRING", tableCode: "CC" },
        "hccz_invmgr"          : { canonical: "hCCz_InvMgr"          , type: "STRING", tableCode: "CC" },
        "hccz_member"          : { canonical: "hCCz_Member"          , type: "STRING", tableCode: "CC" },
        "hccz_mod_user"        : { canonical: "hCCz_Mod_User"        , type: "STRING", tableCode: "CC" },
        "hccz_participate"     : { canonical: "hCCz_Participate"     , type: "STRING", tableCode: "CC" },
        "hccz_spare"           : { canonical: "hCCz_Spare"           , type: "STRING", tableCode: "CC" },
    }
};

export default CC;
