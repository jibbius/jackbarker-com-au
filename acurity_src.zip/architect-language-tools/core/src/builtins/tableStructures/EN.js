/**
 * EN.js — table structure for the EN (Event Exception Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "EN").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force EN
 */

/** @type {Object} */
const EN = {
    code: "EN",
    name: "Event_Exception_Details",
    recordLength: null,
    helpRegistry: "hEN.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ENi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "henc_basestype"    : { canonical: "hENc_BasesType"    , type: "STRING", tableCode: "EN" },
        "henc_deleted"      : { canonical: "hENc_Deleted"      , type: "STRING", tableCode: "EN" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hend_mod_date"     : { canonical: "hENd_Mod_Date"     , type: "DATE", tableCode: "EN" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "henl_clob_id"      : { canonical: "hENl_CLOB_ID"      , type: "INTEGER", tableCode: "EN" },
        "henl_message_code" : { canonical: "hENl_Message_Code" , type: "INTEGER", tableCode: "EN" },
        "henl_record_id"    : { canonical: "hENl_Record_Id"    , type: "INTEGER", tableCode: "EN" },
        "henl_sequence"     : { canonical: "hENl_Sequence"     , type: "INTEGER", tableCode: "EN" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hent_mod_time"     : { canonical: "hENt_Mod_Time"     , type: "TIME", tableCode: "EN" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "henz_eventcode"    : { canonical: "hENz_EventCode"    , type: "STRING", tableCode: "EN" },
        "henz_exceptioncode": { canonical: "hENz_ExceptionCode", type: "STRING", tableCode: "EN" },
        "henz_functioncode" : { canonical: "hENz_FunctionCode" , type: "STRING", tableCode: "EN" },
        "henz_mod_user"     : { canonical: "hENz_Mod_User"     , type: "STRING", tableCode: "EN" },
        "henz_parameters"   : { canonical: "hENz_Parameters"   , type: "STRING", tableCode: "EN" },
        "henz_spare"        : { canonical: "hENz_Spare"        , type: "STRING", tableCode: "EN" },
    }
};

export default EN;
