/**
 * AZ.js — table structure for the AZ (Audit Character Large Objects) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AZ").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AZ
 */

/** @type {Object} */
const AZ = {
    code: "AZ",
    name: "Audit_Character_Large_Objects",
    recordLength: null,
    helpRegistry: "hAZ.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "AZi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── CLOB (b-prefix) ───────────────────────────────────────────────────
        "hazb_clob_audit_data": { canonical: "hAZb_CLOB_Audit_Data", type: "CLOB", tableCode: "AZ" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hazl_clob_id"        : { canonical: "hAZl_CLOB_ID"        , type: "AUTOINCREMENT", tableCode: "AZ" },
    }
};

export default AZ;
