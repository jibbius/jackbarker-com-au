/**
 * CP.js — table structure for the CP (Capital Gains Reporting) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CP").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CP
 */

/** @type {Object} */
const CP = {
    code: "CP",
    name: "Capital_Gains_Reporting",
    recordLength: null,
    helpRegistry: "hCP.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CPi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hcpc_deleted"         : { canonical: "hCPc_Deleted"         , type: "STRING", tableCode: "CP" },
        "hcpc_spare"           : { canonical: "hCPc_Spare"           , type: "STRING", tableCode: "CP" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hcpd_mod_date"        : { canonical: "hCPd_Mod_Date"        , type: "DATE", tableCode: "CP" },
        "hcpd_puchase"         : { canonical: "hCPd_Puchase"         , type: "DATE", tableCode: "CP" },
        "hcpd_purchase_qtr"    : { canonical: "hCPd_Purchase_Qtr"    , type: "DATE", tableCode: "CP" },
        "hcpd_sale"            : { canonical: "hCPd_Sale"            , type: "DATE", tableCode: "CP" },
        "hcpd_sale_qtr"        : { canonical: "hCPd_Sale_Qtr"        , type: "DATE", tableCode: "CP" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hcpf_base_reduction"  : { canonical: "hCPf_Base_Reduction"  , type: "DOUBLE", tableCode: "CP" },
        "hcpf_capital_gain"    : { canonical: "hCPf_Capital_Gain"    , type: "DOUBLE", tableCode: "CP" },
        "hcpf_capital_gain_tax": { canonical: "hCPf_Capital_Gain_Tax", type: "DOUBLE", tableCode: "CP" },
        "hcpf_entry_fee"       : { canonical: "hCPf_Entry_Fee"       , type: "DOUBLE", tableCode: "CP" },
        "hcpf_exit_fee"        : { canonical: "hCPf_Exit_Fee"        , type: "DOUBLE", tableCode: "CP" },
        "hcpf_indxd_market_val": { canonical: "hCPf_Indxd_Market_Val", type: "DOUBLE", tableCode: "CP" },
        "hcpf_indxd_orig_cost" : { canonical: "hCPf_Indxd_Orig_Cost" , type: "DOUBLE", tableCode: "CP" },
        "hcpf_market_value"    : { canonical: "hCPf_Market_Value"    , type: "DOUBLE", tableCode: "CP" },
        "hcpf_original_cost"   : { canonical: "hCPf_Original_Cost"   , type: "DOUBLE", tableCode: "CP" },
        "hcpf_purchase_index"  : { canonical: "hCPf_Purchase_Index"  , type: "DOUBLE", tableCode: "CP" },
        "hcpf_return_of_cap"   : { canonical: "hCPf_Return_of_Cap"   , type: "DOUBLE", tableCode: "CP" },
        "hcpf_sale_index"      : { canonical: "hCPf_Sale_Index"      , type: "DOUBLE", tableCode: "CP" },
        "hcpf_sale_price"      : { canonical: "hCPf_Sale_Price"      , type: "DOUBLE", tableCode: "CP" },
        "hcpf_spare"           : { canonical: "hCPf_Spare"           , type: "DOUBLE", tableCode: "CP" },
        "hcpf_units_to_redeem" : { canonical: "hCPf_Units_To_Redeem" , type: "DOUBLE", tableCode: "CP" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hcpl_share_cert"      : { canonical: "hCPl_Share_Cert"      , type: "INTEGER", tableCode: "CP" },
        "hcpl_trans_ref"       : { canonical: "hCPl_Trans_Ref"       , type: "INTEGER", tableCode: "CP" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hcpt_mod_time"        : { canonical: "hCPt_Mod_Time"        , type: "TIME", tableCode: "CP" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcpz_discount_factor" : { canonical: "hCPz_Discount_Factor" , type: "STRING", tableCode: "CP" },
        "hcpz_division"        : { canonical: "hCPz_Division"        , type: "STRING", tableCode: "CP" },
        "hcpz_fund"            : { canonical: "hCPz_Fund"            , type: "STRING", tableCode: "CP" },
        "hcpz_investment_mgr"  : { canonical: "hCPz_Investment_Mgr"  , type: "STRING", tableCode: "CP" },
        "hcpz_member"          : { canonical: "hCPz_Member"          , type: "STRING", tableCode: "CP" },
        "hcpz_mod_user"        : { canonical: "hCPz_Mod_User"        , type: "STRING", tableCode: "CP" },
        "hcpz_system_inv_mgr"  : { canonical: "hCPz_System_Inv_Mgr"  , type: "STRING", tableCode: "CP" },
    }
};

export default CP;
