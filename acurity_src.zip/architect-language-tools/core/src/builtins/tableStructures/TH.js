/**
 * TH.js — table structure for the TH (Transaction History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "TH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force TH
 */

/** @type {Object} */
const TH = {
    code: "TH",
    name: "Transaction_History",
    recordLength: null,
    helpRegistry: "hTH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "THi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hthc_archived"        : { canonical: "hTHc_Archived"        , type: "STRING", tableCode: "TH" },
        "hthc_batch_tran"      : { canonical: "hTHc_Batch_Tran"      , type: "STRING", tableCode: "TH" },
        "hthc_ben_01_74"       : { canonical: "hTHc_Ben_01_74"       , type: "STRING", tableCode: "TH" },
        "hthc_cheque_no"       : { canonical: "hTHc_Cheque_No"       , type: "STRING", tableCode: "TH" },
        "hthc_completed"       : { canonical: "hTHc_Completed"       , type: "STRING", tableCode: "TH" },
        "hthc_cont_type"       : { canonical: "hTHc_Cont_Type"       , type: "STRING", tableCode: "TH" },
        "hthc_create_conts"    : { canonical: "hTHc_Create_Conts"    , type: "STRING", tableCode: "TH" },
        "hthc_created_ledgers" : { canonical: "hTHc_Created_Ledgers" , type: "STRING", tableCode: "TH" },
        "hthc_edited_tran"     : { canonical: "hTHc_Edited_Tran"     , type: "STRING", tableCode: "TH" },
        "hthc_exit"            : { canonical: "hTHc_Exit"            , type: "STRING", tableCode: "TH" },
        "hthc_fid_applies"     : { canonical: "hTHc_FID_Applies"     , type: "STRING", tableCode: "TH" },
        "hthc_flag_1"          : { canonical: "hTHc_Flag_1"          , type: "STRING", tableCode: "TH" },
        "hthc_flag_2"          : { canonical: "hTHc_Flag_2"          , type: "STRING", tableCode: "TH" },
        "hthc_flag_3"          : { canonical: "hTHc_Flag_3"          , type: "STRING", tableCode: "TH" },
        "hthc_flag_4"          : { canonical: "hTHc_Flag_4"          , type: "STRING", tableCode: "TH" },
        "hthc_flag_5"          : { canonical: "hTHc_Flag_5"          , type: "STRING", tableCode: "TH" },
        "hthc_flag_6"          : { canonical: "hTHc_Flag_6"          , type: "STRING", tableCode: "TH" },
        "hthc_group"           : { canonical: "hTHc_Group"           , type: "STRING", tableCode: "TH" },
        "hthc_in_use"          : { canonical: "hTHc_In_Use"          , type: "STRING", tableCode: "TH" },
        "hthc_interfaced"      : { canonical: "hTHc_Interfaced"      , type: "STRING", tableCode: "TH" },
        "hthc_manual_alloc"    : { canonical: "hTHc_Manual_Alloc"    , type: "STRING", tableCode: "TH" },
        "hthc_multiple_chqs"   : { canonical: "hTHc_Multiple_Chqs"   , type: "STRING", tableCode: "TH" },
        "hthc_notes"           : { canonical: "hTHc_Notes"           , type: "STRING", tableCode: "TH" },
        "hthc_part_posted"     : { canonical: "hTHc_Part_Posted"     , type: "STRING", tableCode: "TH" },
        "hthc_partial_reverse" : { canonical: "hTHc_Partial_Reverse" , type: "STRING", tableCode: "TH" },
        "hthc_rcpt_allocation" : { canonical: "hTHc_Rcpt_Allocation" , type: "STRING", tableCode: "TH" },
        "hthc_rebalance"       : { canonical: "hTHc_Rebalance"       , type: "STRING", tableCode: "TH" },
        "hthc_receipt_tran"    : { canonical: "hTHc_Receipt_Tran"    , type: "STRING", tableCode: "TH" },
        "hthc_reverse_fid"     : { canonical: "hTHc_Reverse_FID"     , type: "STRING", tableCode: "TH" },
        "hthc_reversing_tran"  : { canonical: "hTHc_Reversing_Tran"  , type: "STRING", tableCode: "TH" },
        "hthc_tran_status"     : { canonical: "hTHc_Tran_Status"     , type: "STRING", tableCode: "TH" },
        "hthc_unit_price_meth" : { canonical: "hTHc_Unit_Price_Meth" , type: "STRING", tableCode: "TH" },
        "hthc_units_processed" : { canonical: "hTHc_Units_Processed" , type: "STRING", tableCode: "TH" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hthd_banked"          : { canonical: "hTHd_Banked"          , type: "DATE", tableCode: "TH" },
        "hthd_cont_end"        : { canonical: "hTHd_Cont_End"        , type: "DATE", tableCode: "TH" },
        "hthd_contribution"    : { canonical: "hTHd_Contribution"    , type: "DATE", tableCode: "TH" },
        "hthd_effective"       : { canonical: "hTHd_Effective"       , type: "DATE", tableCode: "TH" },
        "hthd_interest_calc"   : { canonical: "hTHd_Interest_Calc"   , type: "DATE", tableCode: "TH" },
        "hthd_journal_date"    : { canonical: "hTHd_Journal_Date"    , type: "DATE", tableCode: "TH" },
        "hthd_mod_date"        : { canonical: "hTHd_Mod_Date"        , type: "DATE", tableCode: "TH" },
        "hthd_paperwork_rcvd"  : { canonical: "hTHd_Paperwork_Rcvd"  , type: "DATE", tableCode: "TH" },
        "hthd_posted"          : { canonical: "hTHd_Posted"          , type: "DATE", tableCode: "TH" },
        "hthd_posted_report"   : { canonical: "hTHd_Posted_Report"   , type: "DATE", tableCode: "TH" },
        "hthd_spare"           : { canonical: "hTHd_Spare"           , type: "DATE", tableCode: "TH" },
        "hthd_tran"            : { canonical: "hTHd_Tran"            , type: "DATE", tableCode: "TH" },
        "hthd_unit_price_date" : { canonical: "hTHd_Unit_Price_Date" , type: "DATE", tableCode: "TH" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hthf_amount"          : { canonical: "hTHf_Amount"          , type: "DOUBLE", tableCode: "TH" },
        "hthf_bank_acct_tot"   : { canonical: "hTHf_Bank_Acct_Tot"   , type: "DOUBLE", tableCode: "TH" },
        "hthf_cheque_amt"      : { canonical: "hTHf_Cheque_Amt"      , type: "DOUBLE", tableCode: "TH" },
        "hthf_cheque_total"    : { canonical: "hTHf_Cheque_Total"    , type: "DOUBLE", tableCode: "TH" },
        "hthf_foreign_tax_cr"  : { canonical: "hTHf_Foreign_Tax_CR"  , type: "DOUBLE", tableCode: "TH" },
        "hthf_imputation_cr"   : { canonical: "hTHf_Imputation_CR"   , type: "DOUBLE", tableCode: "TH" },
        "hthf_inv_acct_total"  : { canonical: "hTHf_Inv_Acct_Total"  , type: "DOUBLE", tableCode: "TH" },
        "hthf_max_deductible"  : { canonical: "hTHf_Max_Deductible"  , type: "DOUBLE", tableCode: "TH" },
        "hthf_no_of_units"     : { canonical: "hTHf_No_Of_Units"     , type: "DOUBLE", tableCode: "TH" },
        "hthf_tax_amt"         : { canonical: "hTHf_Tax_Amt"         , type: "DOUBLE", tableCode: "TH" },
        "hthf_tran_run_tot"    : { canonical: "hTHf_Tran_Run_Tot"    , type: "DOUBLE", tableCode: "TH" },
        "hthf_tran_run_tot_2"  : { canonical: "hTHf_Tran_Run_Tot_2"  , type: "DOUBLE", tableCode: "TH" },
        "hthf_unalloc_tax_amt" : { canonical: "hTHf_Unalloc_Tax_Amt" , type: "DOUBLE", tableCode: "TH" },
        "hthf_unallocnontaxamt": { canonical: "hTHf_UnallocNonTaxAmt", type: "DOUBLE", tableCode: "TH" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hthl_bank_ref"        : { canonical: "hTHl_Bank_Ref"        , type: "INTEGER", tableCode: "TH" },
        "hthl_batch_ref"       : { canonical: "hTHl_Batch_Ref"       , type: "INTEGER", tableCode: "TH" },
        "hthl_cheque_ref"      : { canonical: "hTHl_Cheque_Ref"      , type: "INTEGER", tableCode: "TH" },
        "hthl_corr_noncost"    : { canonical: "hTHl_Corr_NonCost"    , type: "INTEGER", tableCode: "TH" },
        "hthl_corres_batch"    : { canonical: "hTHl_Corres_Batch"    , type: "INTEGER", tableCode: "TH" },
        "hthl_corres_batch_ref": { canonical: "hTHl_Corres_Batch_Ref", type: "INTEGER", tableCode: "TH" },
        "hthl_corres_receipt"  : { canonical: "hTHl_Corres_Receipt"  , type: "INTEGER", tableCode: "TH" },
        "hthl_corres_tran"     : { canonical: "hTHl_Corres_Tran"     , type: "INTEGER", tableCode: "TH" },
        "hthl_counter"         : { canonical: "hTHl_Counter"         , type: "INTEGER", tableCode: "TH" },
        "hthl_deposit_id"      : { canonical: "hTHl_Deposit_Id"      , type: "INTEGER", tableCode: "TH" },
        "hthl_elec_batch_ref"  : { canonical: "hTHl_Elec_Batch_Ref"  , type: "INTEGER", tableCode: "TH" },
        "hthl_file_reg_ref"    : { canonical: "hTHl_File_Reg_Ref"    , type: "INTEGER", tableCode: "TH" },
        "hthl_job_ref"         : { canonical: "hTHl_Job_Ref"         , type: "INTEGER", tableCode: "TH" },
        "hthl_master_batch_ref": { canonical: "hTHl_Master_Batch_Ref", type: "INTEGER", tableCode: "TH" },
        "hthl_no_batch_recs"   : { canonical: "hTHl_No_Batch_Recs"   , type: "INTEGER", tableCode: "TH" },
        "hthl_no_trans_recs"   : { canonical: "hTHl_No_Trans_Recs"   , type: "INTEGER", tableCode: "TH" },
        "hthl_receipt_ref"     : { canonical: "hTHl_Receipt_Ref"     , type: "INTEGER", tableCode: "TH" },
        "hthl_reversed_by"     : { canonical: "hTHl_Reversed_By"     , type: "INTEGER", tableCode: "TH" },
        "hthl_reversing_ref"   : { canonical: "hTHl_Reversing_Ref"   , type: "INTEGER", tableCode: "TH" },
        "hthl_spare"           : { canonical: "hTHl_Spare"           , type: "INTEGER", tableCode: "TH" },
        "hthl_trans_ref"       : { canonical: "hTHl_Trans_Ref"       , type: "INTEGER", tableCode: "TH" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hths_no_of_chqs"      : { canonical: "hTHs_No_Of_Chqs"      , type: "INTEGER", tableCode: "TH" },
        "hths_no_of_processes" : { canonical: "hTHs_No_Of_Processes" , type: "INTEGER", tableCode: "TH" },
        "hths_no_periods_conts": { canonical: "hTHs_No_Periods_Conts", type: "INTEGER", tableCode: "TH" },
        "hths_no_periodsfreq01": { canonical: "hTHs_No_PeriodsFreq01", type: "INTEGER", tableCode: "TH" },
        "hths_no_periodsfreq02": { canonical: "hTHs_No_PeriodsFreq02", type: "INTEGER", tableCode: "TH" },
        "hths_no_periodsfreq03": { canonical: "hTHs_No_PeriodsFreq03", type: "INTEGER", tableCode: "TH" },
        "hths_no_periodsfreq04": { canonical: "hTHs_No_PeriodsFreq04", type: "INTEGER", tableCode: "TH" },
        "hths_process_no"      : { canonical: "hTHs_Process_No"      , type: "INTEGER", tableCode: "TH" },
        "hths_sas_version"     : { canonical: "hTHs_SAS_Version"     , type: "INTEGER", tableCode: "TH" },
        "hths_sequence"        : { canonical: "hTHs_Sequence"        , type: "INTEGER", tableCode: "TH" },
        "hths_spare01"         : { canonical: "hTHs_Spare01"         , type: "INTEGER", tableCode: "TH" },
        "hths_spare02"         : { canonical: "hTHs_Spare02"         , type: "INTEGER", tableCode: "TH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "htht_mod_time"        : { canonical: "hTHt_Mod_Time"        , type: "TIME", tableCode: "TH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hthz_allocation_fname": { canonical: "hTHz_Allocation_Fname", type: "STRING", tableCode: "TH" },
        "hthz_bank_account"    : { canonical: "hTHz_Bank_Account"    , type: "STRING", tableCode: "TH" },
        "hthz_bank_st_ref"     : { canonical: "hTHz_Bank_St_Ref"     , type: "STRING", tableCode: "TH" },
        "hthz_batch_code"      : { canonical: "hTHz_Batch_Code"      , type: "STRING", tableCode: "TH" },
        "hthz_branch"          : { canonical: "hTHz_Branch"          , type: "STRING", tableCode: "TH" },
        "hthz_bsb"             : { canonical: "hTHz_BSB"             , type: "STRING", tableCode: "TH" },
        "hthz_calc_basis"      : { canonical: "hTHz_Calc_Basis"      , type: "STRING", tableCode: "TH" },
        "hthz_cheque_no"       : { canonical: "hTHz_Cheque_No"       , type: "STRING", tableCode: "TH" },
        "hthz_client"          : { canonical: "hTHz_Client"          , type: "STRING", tableCode: "TH" },
        "hthz_cont_status"     : { canonical: "hTHz_Cont_Status"     , type: "STRING", tableCode: "TH" },
        "hthz_deposit_id"      : { canonical: "hTHz_Deposit_ID"      , type: "STRING", tableCode: "TH" },
        "hthz_division"        : { canonical: "hTHz_Division"        , type: "STRING", tableCode: "TH" },
        "hthz_drawer"          : { canonical: "hTHz_Drawer"          , type: "STRING", tableCode: "TH" },
        "hthz_electronic_fname": { canonical: "hTHz_Electronic_Fname", type: "STRING", tableCode: "TH" },
        "hthz_exception_reason": { canonical: "hTHz_Exception_Reason", type: "STRING", tableCode: "TH" },
        "hthz_fund"            : { canonical: "hTHz_Fund"            , type: "STRING", tableCode: "TH" },
        "hthz_inv_mgr_code"    : { canonical: "hTHz_Inv_Mgr_Code"    , type: "STRING", tableCode: "TH" },
        "hthz_invalid_mbr_no"  : { canonical: "hTHz_Invalid_Mbr_No"  , type: "STRING", tableCode: "TH" },
        "hthz_kyc_status"      : { canonical: "hTHz_KYC_Status"      , type: "STRING", tableCode: "TH" },
        "hthz_member"          : { canonical: "hTHz_Member"          , type: "STRING", tableCode: "TH" },
        "hthz_mod_user"        : { canonical: "hTHz_Mod_User"        , type: "STRING", tableCode: "TH" },
        "hthz_partid"          : { canonical: "hTHz_PartID"          , type: "STRING", tableCode: "TH" },
        "hthz_payee"           : { canonical: "hTHz_Payee"           , type: "STRING", tableCode: "TH" },
        "hthz_payroll"         : { canonical: "hTHz_Payroll"         , type: "STRING", tableCode: "TH" },
        "hthz_posted"          : { canonical: "hTHz_Posted"          , type: "STRING", tableCode: "TH" },
        "hthz_receipt_method"  : { canonical: "hTHz_Receipt_Method"  , type: "STRING", tableCode: "TH" },
        "hthz_receipted"       : { canonical: "hTHz_Receipted"       , type: "STRING", tableCode: "TH" },
        "hthz_reconciled"      : { canonical: "hTHz_Reconciled"      , type: "STRING", tableCode: "TH" },
        "hthz_reference"       : { canonical: "hTHz_Reference"       , type: "STRING", tableCode: "TH" },
        "hthz_set_no"          : { canonical: "hTHz_Set_No"          , type: "STRING", tableCode: "TH" },
        "hthz_spare"           : { canonical: "hTHz_Spare"           , type: "STRING", tableCode: "TH" },
        "hthz_string"          : { canonical: "hTHz_String"          , type: "STRING", tableCode: "TH" },
        "hthz_subsidy_ctype"   : { canonical: "hTHz_Subsidy_CType"   , type: "STRING", tableCode: "TH" },
        "hthz_subsidy_fund"    : { canonical: "hTHz_Subsidy_Fund"    , type: "STRING", tableCode: "TH" },
        "hthz_subsidy_payroll" : { canonical: "hTHz_Subsidy_Payroll" , type: "STRING", tableCode: "TH" },
        "hthz_supplied_trn_ref": { canonical: "hTHz_Supplied_Trn_Ref", type: "STRING", tableCode: "TH" },
        "hthz_tran_created_by" : { canonical: "hTHz_Tran_Created_By" , type: "STRING", tableCode: "TH" },
        "hthz_tran_desc"       : { canonical: "hTHz_Tran_Desc"       , type: "STRING", tableCode: "TH" },
        "hthz_tran_requestd_by": { canonical: "hTHz_Tran_Requestd_By", type: "STRING", tableCode: "TH" },
        "hthz_transaction"     : { canonical: "hTHz_Transaction"     , type: "STRING", tableCode: "TH" },
    }
};

export default TH;
