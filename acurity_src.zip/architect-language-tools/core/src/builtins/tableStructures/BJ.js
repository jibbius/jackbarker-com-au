/**
 * BJ.js — table structure for the BJ (Background Jobs) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BJ").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BJ
 */

/** @type {Object} */
const BJ = {
    code: "BJ",
    name: "Background_Jobs",
    recordLength: null,
    helpRegistry: "hBJ.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BJi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hbjc_client_sys_flag" : { canonical: "hBJc_Client_Sys_Flag" , type: "STRING", tableCode: "BJ" },
        "hbjc_division"        : { canonical: "hBJc_Division"        , type: "STRING", tableCode: "BJ" },
        "hbjc_error_class"     : { canonical: "hBJc_Error_Class"     , type: "STRING", tableCode: "BJ" },
        "hbjc_exit_flag"       : { canonical: "hBJc_Exit_Flag"       , type: "STRING", tableCode: "BJ" },
        "hbjc_interactive"     : { canonical: "hBJc_Interactive"     , type: "STRING", tableCode: "BJ" },
        "hbjc_job_priority"    : { canonical: "hBJc_Job_Priority"    , type: "STRING", tableCode: "BJ" },
        "hbjc_job_status"      : { canonical: "hBJc_Job_Status"      , type: "STRING", tableCode: "BJ" },
        "hbjc_long_filename"   : { canonical: "hBJc_Long_Filename"   , type: "STRING", tableCode: "BJ" },
        "hbjc_output_priority" : { canonical: "hBJc_Output_Priority" , type: "STRING", tableCode: "BJ" },
        "hbjc_process_group"   : { canonical: "hBJc_Process_Group"   , type: "STRING", tableCode: "BJ" },
        "hbjc_process_level"   : { canonical: "hBJc_Process_Level"   , type: "STRING", tableCode: "BJ" },
        "hbjc_process_quantity": { canonical: "hBJc_Process_Quantity", type: "STRING", tableCode: "BJ" },
        "hbjc_restore"         : { canonical: "hBJc_Restore"         , type: "STRING", tableCode: "BJ" },
        "hbjc_routing"         : { canonical: "hBJc_Routing"         , type: "STRING", tableCode: "BJ" },
        "hbjc_spare"           : { canonical: "hBJc_Spare"           , type: "STRING", tableCode: "BJ" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hbjd_effective"       : { canonical: "hBJd_Effective"       , type: "DATE", tableCode: "BJ" },
        "hbjd_job_created"     : { canonical: "hBJd_Job_Created"     , type: "DATE", tableCode: "BJ" },
        "hbjd_job_finished"    : { canonical: "hBJd_Job_Finished"    , type: "DATE", tableCode: "BJ" },
        "hbjd_job_scheduled"   : { canonical: "hBJd_Job_Scheduled"   , type: "DATE", tableCode: "BJ" },
        "hbjd_job_started"     : { canonical: "hBJd_Job_Started"     , type: "DATE", tableCode: "BJ" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hbjl_batch_ref"       : { canonical: "hBJl_Batch_Ref"       , type: "INTEGER", tableCode: "BJ" },
        "hbjl_job_ref"         : { canonical: "hBJl_Job_Ref"         , type: "INTEGER", tableCode: "BJ" },
        "hbjl_lines_loaded"    : { canonical: "hBJl_Lines_Loaded"    , type: "INTEGER", tableCode: "BJ" },
        "hbjl_process_id"      : { canonical: "hBJl_Process_ID"      , type: "INTEGER", tableCode: "BJ" },
        "hbjl_spare"           : { canonical: "hBJl_Spare"           , type: "INTEGER", tableCode: "BJ" },
        "hbjl_total_lines"     : { canonical: "hBJl_Total_Lines"     , type: "INTEGER", tableCode: "BJ" },
        "hbjl_trans_ref"       : { canonical: "hBJl_Trans_Ref"       , type: "INTEGER", tableCode: "BJ" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hbjt_job_created"     : { canonical: "hBJt_Job_Created"     , type: "TIME", tableCode: "BJ" },
        "hbjt_job_finished"    : { canonical: "hBJt_Job_Finished"    , type: "TIME", tableCode: "BJ" },
        "hbjt_job_started"     : { canonical: "hBJt_Job_Started"     , type: "TIME", tableCode: "BJ" },
        "hbjt_scheduled"       : { canonical: "hBJt_Scheduled"       , type: "TIME", tableCode: "BJ" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hbjz_as400_job_name"  : { canonical: "hBJz_AS400_Job_Name"  , type: "STRING", tableCode: "BJ" },
        "hbjz_as400_job_number": { canonical: "hBJz_AS400_Job_Number", type: "STRING", tableCode: "BJ" },
        "hbjz_as400_job_queue" : { canonical: "hBJz_AS400_Job_Queue" , type: "STRING", tableCode: "BJ" },
        "hbjz_as400_queue_lib" : { canonical: "hBJz_AS400_Queue_Lib" , type: "STRING", tableCode: "BJ" },
        "hbjz_as400_userid"    : { canonical: "hBJz_AS400_Userid"    , type: "STRING", tableCode: "BJ" },
        "hbjz_batch_code"      : { canonical: "hBJz_Batch_Code"      , type: "STRING", tableCode: "BJ" },
        "hbjz_broker"          : { canonical: "hBJz_Broker"          , type: "STRING", tableCode: "BJ" },
        "hbjz_error_code"      : { canonical: "hBJz_Error_Code"      , type: "STRING", tableCode: "BJ" },
        "hbjz_error_type"      : { canonical: "hBJz_Error_Type"      , type: "STRING", tableCode: "BJ" },
        "hbjz_filename"        : { canonical: "hBJz_Filename"        , type: "STRING", tableCode: "BJ" },
        "hbjz_fund"            : { canonical: "hBJz_Fund"            , type: "STRING", tableCode: "BJ" },
        "hbjz_inv_mgr"         : { canonical: "hBJz_Inv_Mgr"         , type: "STRING", tableCode: "BJ" },
        "hbjz_job_queue"       : { canonical: "hBJz_Job_Queue"       , type: "STRING", tableCode: "BJ" },
        "hbjz_long_inv_mgr"    : { canonical: "hBJz_Long_Inv_Mgr"    , type: "STRING", tableCode: "BJ" },
        "hbjz_member"          : { canonical: "hBJz_Member"          , type: "STRING", tableCode: "BJ" },
        "hbjz_payroll"         : { canonical: "hBJz_Payroll"         , type: "STRING", tableCode: "BJ" },
        "hbjz_process"         : { canonical: "hBJz_Process"         , type: "STRING", tableCode: "BJ" },
        "hbjz_process_type"    : { canonical: "hBJz_Process_Type"    , type: "STRING", tableCode: "BJ" },
        "hbjz_report_code"     : { canonical: "hBJz_Report_Code"     , type: "STRING", tableCode: "BJ" },
        "hbjz_report_group"    : { canonical: "hBJz_Report_Group"    , type: "STRING", tableCode: "BJ" },
        "hbjz_report_id"       : { canonical: "hBJz_Report_Id"       , type: "STRING", tableCode: "BJ" },
        "hbjz_tran_type"       : { canonical: "hBJz_Tran_Type"       , type: "STRING", tableCode: "BJ" },
        "hbjz_user_id"         : { canonical: "hBJz_User_Id"         , type: "STRING", tableCode: "BJ" },
        "hbjz_web_user_id"     : { canonical: "hBJz_Web_User_ID"     , type: "STRING", tableCode: "BJ" },

        // ── (v-prefix) ──────────────────────────────────────────────────
        "hbjv_web_service_name": { canonical: "hBJv_Web_Service_Name", type: "VARSTRING", tableCode: "BJ" },
    }
};

export default BJ;
