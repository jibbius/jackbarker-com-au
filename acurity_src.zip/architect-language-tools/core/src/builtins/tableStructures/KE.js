/**
 * KE.js — table structure for the KE (Acurity Manager Keys) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "KE").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force KE
 */

/** @type {Object} */
const KE = {
    code: "KE",
    name: "Acurity_Manager_Keys",
    recordLength: null,
    helpRegistry: "hKE.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "KEi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hkez_currentkey" : { canonical: "hKEz_CurrentKey" , type: "STRING", tableCode: "KE" },
        "hkez_nextkey"    : { canonical: "hKEz_NextKey"    , type: "STRING", tableCode: "KE" },
        "hkez_previouskey": { canonical: "hKEz_PreviousKey", type: "STRING", tableCode: "KE" },
        "hkez_spare"      : { canonical: "hKEz_Spare"      , type: "STRING", tableCode: "KE" },
    }
};

export default KE;
