/**
 * SX.js — table structure for the SX (ATO Data History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SX").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SX
 */

/** @type {Object} */
const SX = {
    code: "SX",
    name: "ATO_Data_History",
    recordLength: null,
    helpRegistry: "hSX.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SXi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hsxc_adv_amt_code"    : { canonical: "hSXc_Adv_Amt_Code"    , type: "STRING", tableCode: "SX" },
        "hsxc_assess_amt_code" : { canonical: "hSXc_Assess_Amt_Code" , type: "STRING", tableCode: "SX" },
        "hsxc_assess_ledgers"  : { canonical: "hSXc_Assess_Ledgers"  , type: "STRING", tableCode: "SX" },
        "hsxc_cancelled"       : { canonical: "hSXc_Cancelled"       , type: "STRING", tableCode: "SX" },
        "hsxc_cont_rep_source" : { canonical: "hSXc_Cont_Rep_Source" , type: "STRING", tableCode: "SX" },
        "hsxc_db_interest"     : { canonical: "hSXc_DB_Interest"     , type: "STRING", tableCode: "SX" },
        "hsxc_dflt_assess_ind" : { canonical: "hSXc_Dflt_Assess_Ind" , type: "STRING", tableCode: "SX" },
        "hsxc_insurance"       : { canonical: "hSXc_Insurance"       , type: "STRING", tableCode: "SX" },
        "hsxc_inward_rollover" : { canonical: "hSXc_Inward_Rollover" , type: "STRING", tableCode: "SX" },
        "hsxc_outward_rollover": { canonical: "hSXc_Outward_Rollover", type: "STRING", tableCode: "SX" },
        "hsxc_payment_type"    : { canonical: "hSXc_Payment_Type"    , type: "STRING", tableCode: "SX" },
        "hsxc_record_type"     : { canonical: "hSXc_Record_Type"     , type: "STRING", tableCode: "SX" },
        "hsxc_resolved"        : { canonical: "hSXc_Resolved"        , type: "STRING", tableCode: "SX" },
        "hsxc_sex"             : { canonical: "hSXc_Sex"             , type: "STRING", tableCode: "SX" },
        "hsxc_warning"         : { canonical: "hSXc_Warning"         , type: "STRING", tableCode: "SX" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hsxd_advance_due"     : { canonical: "hSXd_Advance_Due"     , type: "DATE", tableCode: "SX" },
        "hsxd_assess_due"      : { canonical: "hSXd_Assess_Due"      , type: "DATE", tableCode: "SX" },
        "hsxd_assess_eff"      : { canonical: "hSXd_Assess_Eff"      , type: "DATE", tableCode: "SX" },
        "hsxd_birth"           : { canonical: "hSXd_Birth"           , type: "DATE", tableCode: "SX" },
        "hsxd_cont_reported"   : { canonical: "hSXd_Cont_Reported"   , type: "DATE", tableCode: "SX" },
        "hsxd_effective"       : { canonical: "hSXd_Effective"       , type: "DATE", tableCode: "SX" },
        "hsxd_exit"            : { canonical: "hSXd_Exit"            , type: "DATE", tableCode: "SX" },
        "hsxd_interest_due"    : { canonical: "hSXd_Interest_Due"    , type: "DATE", tableCode: "SX" },
        "hsxd_interest_end"    : { canonical: "hSXd_Interest_End"    , type: "DATE", tableCode: "SX" },
        "hsxd_interest_start"  : { canonical: "hSXd_Interest_Start"  , type: "DATE", tableCode: "SX" },
        "hsxd_issue"           : { canonical: "hSXd_Issue"           , type: "DATE", tableCode: "SX" },
        "hsxd_last_cont"       : { canonical: "hSXd_Last_Cont"       , type: "DATE", tableCode: "SX" },
        "hsxd_payment"         : { canonical: "hSXd_Payment"         , type: "DATE", tableCode: "SX" },
        "hsxd_start_acct_phase": { canonical: "hSXd_Start_Acct_Phase", type: "DATE", tableCode: "SX" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hsxf_acc_emp_amt"     : { canonical: "hSXf_Acc_Emp_Amt"     , type: "DOUBLE", tableCode: "SX" },
        "hsxf_adv_amount"      : { canonical: "hSXf_Adv_Amount"      , type: "DOUBLE", tableCode: "SX" },
        "hsxf_adv_offset_amt"  : { canonical: "hSXf_Adv_Offset_Amt"  , type: "DOUBLE", tableCode: "SX" },
        "hsxf_assess_amt"      : { canonical: "hSXf_Assess_Amt"      , type: "DOUBLE", tableCode: "SX" },
        "hsxf_cap_gains_cgt"   : { canonical: "hSXf_Cap_Gains_CGT"   , type: "DOUBLE", tableCode: "SX" },
        "hsxf_cap_gains_tax"   : { canonical: "hSXf_Cap_Gains_Tax"   , type: "DOUBLE", tableCode: "SX" },
        "hsxf_cocont_amt"      : { canonical: "hSXf_CoCont_Amt"      , type: "DOUBLE", tableCode: "SX" },
        "hsxf_db_emp_amt"      : { canonical: "hSXf_DB_Emp_Amt"      , type: "DOUBLE", tableCode: "SX" },
        "hsxf_injury_payment"  : { canonical: "hSXf_Injury_Payment"  , type: "DOUBLE", tableCode: "SX" },
        "hsxf_insufficient"    : { canonical: "hSXf_Insufficient"    , type: "DOUBLE", tableCode: "SX" },
        "hsxf_int_amount"      : { canonical: "hSXf_Int_Amount"      , type: "DOUBLE", tableCode: "SX" },
        "hsxf_int_base_amt"    : { canonical: "hSXf_Int_Base_Amt"    , type: "DOUBLE", tableCode: "SX" },
        "hsxf_kiwi_tax_free"   : { canonical: "hSXf_Kiwi_Tax_Free"   , type: "DOUBLE", tableCode: "SX" },
        "hsxf_mbr_deduct_amt"  : { canonical: "hSXf_Mbr_Deduct_Amt"  , type: "DOUBLE", tableCode: "SX" },
        "hsxf_non_assess_amt"  : { canonical: "hSXf_Non_Assess_Amt"  , type: "DOUBLE", tableCode: "SX" },
        "hsxf_notionaltaxedcnt": { canonical: "hSXf_NotionalTaxedCnt", type: "DOUBLE", tableCode: "SX" },
        "hsxf_post06_noncompl" : { canonical: "hSXf_Post06_NonCompl" , type: "DOUBLE", tableCode: "SX" },
        "hsxf_rollin_spec_amt" : { canonical: "hSXf_Rollin_Spec_Amt" , type: "DOUBLE", tableCode: "SX" },
        "hsxf_sg_amt"          : { canonical: "hSXf_SG_Amt"          , type: "DOUBLE", tableCode: "SX" },
        "hsxf_spec_rollover"   : { canonical: "hSXf_Spec_Rollover"   , type: "DOUBLE", tableCode: "SX" },
        "hsxf_spouse_cont_amt" : { canonical: "hSXf_Spouse_Cont_Amt" , type: "DOUBLE", tableCode: "SX" },
        "hsxf_surplus"         : { canonical: "hSXf_Surplus"         , type: "DOUBLE", tableCode: "SX" },
        "hsxf_tcont_nonassess" : { canonical: "hSXf_TCont_NonAssess" , type: "DOUBLE", tableCode: "SX" },
        "hsxf_tfree_foreign"   : { canonical: "hSXf_TFree_Foreign"   , type: "DOUBLE", tableCode: "SX" },
        "hsxf_tot_cont_amt"    : { canonical: "hSXf_Tot_Cont_Amt"    , type: "DOUBLE", tableCode: "SX" },
        "hsxf_toth_cont_amt"   : { canonical: "hSXf_TOth_Cont_Amt"   , type: "DOUBLE", tableCode: "SX" },
        "hsxf_tpers_cont_amt"  : { canonical: "hSXf_TPers_Cont_Amt"  , type: "DOUBLE", tableCode: "SX" },
        "hsxf_trans_ded_amt"   : { canonical: "hSXf_Trans_Ded_Amt"   , type: "DOUBLE", tableCode: "SX" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hsxl_dispute_transref": { canonical: "hSXl_Dispute_TransRef", type: "INTEGER", tableCode: "SX" },
        "hsxl_match_trans_ref" : { canonical: "hSXl_Match_Trans_Ref" , type: "INTEGER", tableCode: "SX" },
        "hsxl_pay_var_transref": { canonical: "hSXl_Pay_Var_TransRef", type: "INTEGER", tableCode: "SX" },
        "hsxl_reversing_ref"   : { canonical: "hSXl_Reversing_Ref"   , type: "INTEGER", tableCode: "SX" },
        "hsxl_spare"           : { canonical: "hSXl_Spare"           , type: "INTEGER", tableCode: "SX" },
        "hsxl_trans_ref"       : { canonical: "hSXl_Trans_Ref"       , type: "INTEGER", tableCode: "SX" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hsxs_assess_rec_no"   : { canonical: "hSXs_Assess_Rec_No"   , type: "INTEGER", tableCode: "SX" },
        "hsxs_record_number"   : { canonical: "hSXs_Record_Number"   , type: "INTEGER", tableCode: "SX" },
        "hsxs_spare01"         : { canonical: "hSXs_Spare01"         , type: "INTEGER", tableCode: "SX" },
        "hsxs_spare02"         : { canonical: "hSXs_Spare02"         , type: "INTEGER", tableCode: "SX" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hsxz_account_phase"   : { canonical: "hSXz_Account_Phase"   , type: "STRING", tableCode: "SX" },
        "hsxz_address_1_src"   : { canonical: "hSXz_Address_1_Src"   , type: "STRING", tableCode: "SX" },
        "hsxz_address_2_src"   : { canonical: "hSXz_Address_2_Src"   , type: "STRING", tableCode: "SX" },
        "hsxz_assess_id"       : { canonical: "hSXz_Assess_ID"       , type: "STRING", tableCode: "SX" },
        "hsxz_client"          : { canonical: "hSXz_Client"          , type: "STRING", tableCode: "SX" },
        "hsxz_comm_id"         : { canonical: "hSXz_Comm_ID"         , type: "STRING", tableCode: "SX" },
        "hsxz_cont_ref_nbr"    : { canonical: "hSXz_Cont_Ref_Nbr"    , type: "STRING", tableCode: "SX" },
        "hsxz_country_src"     : { canonical: "hSXz_Country_Src"     , type: "STRING", tableCode: "SX" },
        "hsxz_destination_type": { canonical: "hSXz_Destination_Type", type: "STRING", tableCode: "SX" },
        "hsxz_division"        : { canonical: "hSXz_Division"        , type: "STRING", tableCode: "SX" },
        "hsxz_fund"            : { canonical: "hSXz_Fund"            , type: "STRING", tableCode: "SX" },
        "hsxz_given_names_src" : { canonical: "hSXz_Given_Names_Src" , type: "STRING", tableCode: "SX" },
        "hsxz_int_reason"      : { canonical: "hSXz_Int_Reason"      , type: "STRING", tableCode: "SX" },
        "hsxz_member"          : { canonical: "hSXz_Member"          , type: "STRING", tableCode: "SX" },
        "hsxz_new_tax_file_no" : { canonical: "hSXz_New_Tax_File_No" , type: "STRING", tableCode: "SX" },
        "hsxz_original_fund"   : { canonical: "hSXz_Original_Fund"   , type: "STRING", tableCode: "SX" },
        "hsxz_original_member" : { canonical: "hSXz_Original_Member" , type: "STRING", tableCode: "SX" },
        "hsxz_payee"           : { canonical: "hSXz_Payee"           , type: "STRING", tableCode: "SX" },
        "hsxz_post_code_src"   : { canonical: "hSXz_Post_Code_Src"   , type: "STRING", tableCode: "SX" },
        "hsxz_prev_assess_id"  : { canonical: "hSXz_Prev_Assess_ID"  , type: "STRING", tableCode: "SX" },
        "hsxz_prev_prov_abn"   : { canonical: "hSXz_Prev_Prov_ABN"   , type: "STRING", tableCode: "SX" },
        "hsxz_prov_prod_id_nbr": { canonical: "hSXz_Prov_Prod_ID_Nbr", type: "STRING", tableCode: "SX" },
        "hsxz_ret_pay_eft"     : { canonical: "hSXz_Ret_Pay_EFT"     , type: "STRING", tableCode: "SX" },
        "hsxz_spare"           : { canonical: "hSXz_Spare"           , type: "STRING", tableCode: "SX" },
        "hsxz_state_src"       : { canonical: "hSXz_State_Src"       , type: "STRING", tableCode: "SX" },
        "hsxz_suburb_src"      : { canonical: "hSXz_Suburb_Src"      , type: "STRING", tableCode: "SX" },
        "hsxz_surname_src"     : { canonical: "hSXz_Surname_Src"     , type: "STRING", tableCode: "SX" },
        "hsxz_tax_file_no"     : { canonical: "hSXz_Tax_File_No"     , type: "STRING", tableCode: "SX" },
        "hsxz_variation_reason": { canonical: "hSXz_Variation_Reason", type: "STRING", tableCode: "SX" },
    }
};

export default SX;
