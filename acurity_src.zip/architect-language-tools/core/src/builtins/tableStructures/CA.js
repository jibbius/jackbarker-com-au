/**
 * CA.js — table structure for the CA (Chart of Accounts) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CA").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CA
 */

/** @type {Object} */
const CA = {
    code: "CA",
    name: "Chart_of_Accounts",
    recordLength: null,
    helpRegistry: "hCA.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CAi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hcac_deleted"        : { canonical: "hCAc_Deleted"        , type: "STRING", tableCode: "CA" },
        "hcac_distributed"    : { canonical: "hCAc_Distributed"    , type: "STRING", tableCode: "CA" },
        "hcac_excl_tran_list" : { canonical: "hCAc_Excl_Tran_List" , type: "STRING", tableCode: "CA" },
        "hcac_spare"          : { canonical: "hCAc_Spare"          , type: "STRING", tableCode: "CA" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcaz_account_code"   : { canonical: "hCAz_Account_Code"   , type: "STRING", tableCode: "CA" },
        "hcaz_account_type"   : { canonical: "hCAz_Account_Type"   , type: "STRING", tableCode: "CA" },
        "hcaz_bank_account"   : { canonical: "hCAz_Bank_Account"   , type: "STRING", tableCode: "CA" },
        "hcaz_description"    : { canonical: "hCAz_Description"    , type: "STRING", tableCode: "CA" },
        "hcaz_group"          : { canonical: "hCAz_Group"          , type: "STRING", tableCode: "CA" },
        "hcaz_net_cash_assets": { canonical: "hCAz_Net_Cash_Assets", type: "STRING", tableCode: "CA" },
        "hcaz_sub_group"      : { canonical: "hCAz_Sub_Group"      , type: "STRING", tableCode: "CA" },
    }
};

export default CA;
