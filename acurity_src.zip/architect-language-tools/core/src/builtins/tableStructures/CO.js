/**
 * CO.js — table structure for the CO (Employer Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CO").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CO
 */

/** @type {Object} */
const CO = {
    code: "CO",
    name: "Employer_Details",
    recordLength: null,
    helpRegistry: "hCO.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "COi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hcoc_adjust_cycle"    : { canonical: "hCOc_Adjust_Cycle"    , type: "STRING", tableCode: "CO" },
        "hcoc_comments"        : { canonical: "hCOc_Comments"        , type: "STRING", tableCode: "CO" },
        "hcoc_confirmed"       : { canonical: "hCOc_Confirmed"       , type: "STRING", tableCode: "CO" },
        "hcoc_cont_return_type": { canonical: "hCOc_Cont_Return_Type", type: "STRING", tableCode: "CO" },
        "hcoc_dummy_employer"  : { canonical: "hCOc_Dummy_Employer"  , type: "STRING", tableCode: "CO" },
        "hcoc_employer_std"    : { canonical: "hCOc_Employer_STD"    , type: "STRING", tableCode: "CO" },
        "hcoc_exception"       : { canonical: "hCOc_Exception"       , type: "STRING", tableCode: "CO" },
        "hcoc_fee_process_freq": { canonical: "hCOc_Fee_Process_Freq", type: "STRING", tableCode: "CO" },
        "hcoc_file_format"     : { canonical: "hCOc_File_Format"     , type: "STRING", tableCode: "CO" },
        "hcoc_group_processing": { canonical: "hCOc_Group_Processing", type: "STRING", tableCode: "CO" },
        "hcoc_individual_mbrs" : { canonical: "hCOc_Individual_Mbrs" , type: "STRING", tableCode: "CO" },
        "hcoc_overnight"       : { canonical: "hCOc_Overnight"       , type: "STRING", tableCode: "CO" },
        "hcoc_payroll_freq"    : { canonical: "hCOc_Payroll_Freq"    , type: "STRING", tableCode: "CO" },
        "hcoc_payroll_running" : { canonical: "hCOc_Payroll_Running" , type: "STRING", tableCode: "CO" },
        "hcoc_payroll_type"    : { canonical: "hCOc_Payroll_Type"    , type: "STRING", tableCode: "CO" },
        "hcoc_proc_frequency"  : { canonical: "hCOc_Proc_Frequency"  , type: "STRING", tableCode: "CO" },
        "hcoc_round_cont"      : { canonical: "hCOc_Round_Cont"      , type: "STRING", tableCode: "CO" },
        "hcoc_sal_cont_def"    : { canonical: "hCOc_Sal_Cont_Def"    , type: "STRING", tableCode: "CO" },
        "hcoc_scheme_part"     : { canonical: "hCOc_Scheme_Part"     , type: "STRING", tableCode: "CO" },
        "hcoc_treasury_funded" : { canonical: "hCOc_Treasury_Funded" , type: "STRING", tableCode: "CO" },
        "hcoc_units_processed" : { canonical: "hCOc_Units_Processed" , type: "STRING", tableCode: "CO" },
        "hcoc_web_cont_flag"   : { canonical: "hCOc_Web_Cont_Flag"   , type: "STRING", tableCode: "CO" },
        "hcoc_weekly_adjust"   : { canonical: "hCOc_Weekly_Adjust"   , type: "STRING", tableCode: "CO" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hcod_first_pay"       : { canonical: "hCOd_First_Pay"       , type: "DATE", tableCode: "CO" },
        "hcod_last_fee"        : { canonical: "hCOd_Last_Fee"        , type: "DATE", tableCode: "CO" },
        "hcod_last_pay"        : { canonical: "hCOd_Last_Pay"        , type: "DATE", tableCode: "CO" },
        "hcod_mod_date"        : { canonical: "hCOd_Mod_Date"        , type: "DATE", tableCode: "CO" },
        "hcod_paid_conts_to"   : { canonical: "hCOd_Paid_Conts_To"   , type: "DATE", tableCode: "CO" },
        "hcod_review"          : { canonical: "hCOd_Review"          , type: "DATE", tableCode: "CO" },
        "hcod_termination"     : { canonical: "hCOd_Termination"     , type: "DATE", tableCode: "CO" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hcof_brkr_pcnt01"     : { canonical: "hCOf_Brkr_Pcnt01"     , type: "DOUBLE", tableCode: "CO" },
        "hcof_brkr_pcnt02"     : { canonical: "hCOf_Brkr_Pcnt02"     , type: "DOUBLE", tableCode: "CO" },
        "hcof_brkr_pcnt03"     : { canonical: "hCOf_Brkr_Pcnt03"     , type: "DOUBLE", tableCode: "CO" },
        "hcof_brkr_trailpcnt01": { canonical: "hCOf_Brkr_TrailPcnt01", type: "DOUBLE", tableCode: "CO" },
        "hcof_brkr_trailpcnt02": { canonical: "hCOf_Brkr_TrailPcnt02", type: "DOUBLE", tableCode: "CO" },
        "hcof_brkr_trailpcnt03": { canonical: "hCOf_Brkr_TrailPcnt03", type: "DOUBLE", tableCode: "CO" },
        "hcof_cas_cont_ins_def": { canonical: "hCOf_Cas_Cont_Ins_Def", type: "DOUBLE", tableCode: "CO" },
        "hcof_cont_ins_def"    : { canonical: "hCOf_Cont_Ins_Def"    , type: "DOUBLE", tableCode: "CO" },
        "hcof_dth_auto_cover"  : { canonical: "hCOf_DTH_Auto_Cover"  , type: "DOUBLE", tableCode: "CO" },
        "hcof_dth_go_pcnt_load": { canonical: "hCOf_DTH_GO_Pcnt_Load", type: "DOUBLE", tableCode: "CO" },
        "hcof_non_cont_ins_def": { canonical: "hCOf_Non_Cont_Ins_Def", type: "DOUBLE", tableCode: "CO" },
        "hcof_sc_auto_cover"   : { canonical: "hCOf_SC_Auto_Cover"   , type: "DOUBLE", tableCode: "CO" },
        "hcof_sc_go_pcnt_load" : { canonical: "hCOf_SC_GO_Pcnt_Load" , type: "DOUBLE", tableCode: "CO" },
        "hcof_subsidy"         : { canonical: "hCOf_Subsidy"         , type: "DOUBLE", tableCode: "CO" },
        "hcof_tpd_auto_cover"  : { canonical: "hCOf_TPD_Auto_Cover"  , type: "DOUBLE", tableCode: "CO" },
        "hcof_tpd_go_pcnt_load": { canonical: "hCOf_TPD_GO_Pcnt_Load", type: "DOUBLE", tableCode: "CO" },
        "hcof_transfer_pending": { canonical: "hCOf_Transfer_Pending", type: "DOUBLE", tableCode: "CO" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hcol_merge_tran"      : { canonical: "hCOl_Merge_Tran"      , type: "INTEGER", tableCode: "CO" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hcos_cont_files"      : { canonical: "hCOs_Cont_Files"      , type: "INTEGER", tableCode: "CO" },
        "hcos_cycle_no"        : { canonical: "hCOs_Cycle_No"        , type: "INTEGER", tableCode: "CO" },
        "hcos_rounding_amt"    : { canonical: "hCOs_Rounding_Amt"    , type: "INTEGER", tableCode: "CO" },
        "hcos_spare_field"     : { canonical: "hCOs_Spare_Field"     , type: "INTEGER", tableCode: "CO" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hcot_mod_time"        : { canonical: "hCOt_Mod_Time"        , type: "TIME", tableCode: "CO" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcoz_add_c_given"     : { canonical: "hCOz_Add_C_Given"     , type: "STRING", tableCode: "CO" },
        "hcoz_add_c_phone"     : { canonical: "hCOz_Add_C_Phone"     , type: "STRING", tableCode: "CO" },
        "hcoz_add_c_position"  : { canonical: "hCOz_Add_C_Position"  , type: "STRING", tableCode: "CO" },
        "hcoz_add_c_surname"   : { canonical: "hCOz_Add_C_Surname"   , type: "STRING", tableCode: "CO" },
        "hcoz_add_c_title"     : { canonical: "hCOz_Add_C_Title"     , type: "STRING", tableCode: "CO" },
        "hcoz_address_line_101": { canonical: "hCOz_Address_Line_101", type: "STRING", tableCode: "CO" },
        "hcoz_address_line_102": { canonical: "hCOz_Address_Line_102", type: "STRING", tableCode: "CO" },
        "hcoz_address_line_103": { canonical: "hCOz_Address_Line_103", type: "STRING", tableCode: "CO" },
        "hcoz_association"     : { canonical: "hCOz_Association"     , type: "STRING", tableCode: "CO" },
        "hcoz_aust_company_no" : { canonical: "hCOz_Aust_Company_No" , type: "STRING", tableCode: "CO" },
        "hcoz_bank_acct_name"  : { canonical: "hCOz_Bank_Acct_Name"  , type: "STRING", tableCode: "CO" },
        "hcoz_bank_acct_name2" : { canonical: "hCOz_Bank_Acct_Name2" , type: "STRING", tableCode: "CO" },
        "hcoz_bank_acct_no"    : { canonical: "hCOz_Bank_Acct_No"    , type: "STRING", tableCode: "CO" },
        "hcoz_bank_acct_no2"   : { canonical: "hCOz_Bank_Acct_No2"   , type: "STRING", tableCode: "CO" },
        "hcoz_bpay_ref"        : { canonical: "hCOz_Bpay_Ref"        , type: "STRING", tableCode: "CO" },
        "hcoz_broker_codes01"  : { canonical: "hCOz_Broker_Codes01"  , type: "STRING", tableCode: "CO" },
        "hcoz_broker_codes02"  : { canonical: "hCOz_Broker_Codes02"  , type: "STRING", tableCode: "CO" },
        "hcoz_broker_codes03"  : { canonical: "hCOz_Broker_Codes03"  , type: "STRING", tableCode: "CO" },
        "hcoz_bsb_no"          : { canonical: "hCOz_BSB_No"          , type: "STRING", tableCode: "CO" },
        "hcoz_bsb_no2"         : { canonical: "hCOz_BSB_No2"         , type: "STRING", tableCode: "CO" },
        "hcoz_c_phone_no_bus"  : { canonical: "hCOz_C_Phone_No_Bus"  , type: "STRING", tableCode: "CO" },
        "hcoz_cemtex_change"   : { canonical: "hCOz_CEMTEX_Change"   , type: "STRING", tableCode: "CO" },
        "hcoz_contact_given"   : { canonical: "hCOz_Contact_Given"   , type: "STRING", tableCode: "CO" },
        "hcoz_contact_name"    : { canonical: "hCOz_Contact_Name"    , type: "STRING", tableCode: "CO" },
        "hcoz_contact_position": { canonical: "hCOz_Contact_Position", type: "STRING", tableCode: "CO" },
        "hcoz_contact_surname" : { canonical: "hCOz_Contact_Surname" , type: "STRING", tableCode: "CO" },
        "hcoz_contact_title"   : { canonical: "hCOz_Contact_Title"   , type: "STRING", tableCode: "CO" },
        "hcoz_corres_address01": { canonical: "hCOz_Corres_Address01", type: "STRING", tableCode: "CO" },
        "hcoz_corres_address02": { canonical: "hCOz_Corres_Address02", type: "STRING", tableCode: "CO" },
        "hcoz_corres_address03": { canonical: "hCOz_Corres_Address03", type: "STRING", tableCode: "CO" },
        "hcoz_corres_post_code": { canonical: "hCOz_Corres_Post_Code", type: "STRING", tableCode: "CO" },
        "hcoz_country"         : { canonical: "hCOz_Country"         , type: "STRING", tableCode: "CO" },
        "hcoz_country_code"    : { canonical: "hCOz_Country_Code"    , type: "STRING", tableCode: "CO" },
        "hcoz_date_joined_plan": { canonical: "hCOz_Date_Joined_Plan", type: "STRING", tableCode: "CO" },
        "hcoz_delegate"        : { canonical: "hCOz_Delegate"        , type: "STRING", tableCode: "CO" },
        "hcoz_deleted"         : { canonical: "hCOz_Deleted"         , type: "STRING", tableCode: "CO" },
        "hcoz_email"           : { canonical: "hCOz_Email"           , type: "STRING", tableCode: "CO" },
        "hcoz_extra_addr_line" : { canonical: "hCOz_Extra_Addr_Line" , type: "STRING", tableCode: "CO" },
        "hcoz_extra_addr_line2": { canonical: "hCOz_Extra_Addr_Line2", type: "STRING", tableCode: "CO" },
        "hcoz_fax_no"          : { canonical: "hCOz_Fax_No"          , type: "STRING", tableCode: "CO" },
        "hcoz_file_type_id"    : { canonical: "hCOz_File_Type_Id"    , type: "STRING", tableCode: "CO" },
        "hcoz_fund"            : { canonical: "hCOz_Fund"            , type: "STRING", tableCode: "CO" },
        "hcoz_given_names01"   : { canonical: "hCOz_Given_Names01"   , type: "STRING", tableCode: "CO" },
        "hcoz_given_names02"   : { canonical: "hCOz_Given_Names02"   , type: "STRING", tableCode: "CO" },
        "hcoz_given_names03"   : { canonical: "hCOz_Given_Names03"   , type: "STRING", tableCode: "CO" },
        "hcoz_given_names04"   : { canonical: "hCOz_Given_Names04"   , type: "STRING", tableCode: "CO" },
        "hcoz_given_names05"   : { canonical: "hCOz_Given_Names05"   , type: "STRING", tableCode: "CO" },
        "hcoz_given_names06"   : { canonical: "hCOz_Given_Names06"   , type: "STRING", tableCode: "CO" },
        "hcoz_group"           : { canonical: "hCOz_Group"           , type: "STRING", tableCode: "CO" },
        "hcoz_group_tax_no"    : { canonical: "hCOz_Group_Tax_No"    , type: "STRING", tableCode: "CO" },
        "hcoz_institution"     : { canonical: "hCOz_Institution"     , type: "STRING", tableCode: "CO" },
        "hcoz_long_payroll"    : { canonical: "hCOz_Long_Payroll"    , type: "STRING", tableCode: "CO" },
        "hcoz_merged_with"     : { canonical: "hCOz_Merged_With"     , type: "STRING", tableCode: "CO" },
        "hcoz_mobile_phone"    : { canonical: "hCOz_Mobile_Phone"    , type: "STRING", tableCode: "CO" },
        "hcoz_mod_user"        : { canonical: "hCOz_Mod_User"        , type: "STRING", tableCode: "CO" },
        "hcoz_old_home_phone"  : { canonical: "hCOz_Old_Home_Phone"  , type: "STRING", tableCode: "CO" },
        "hcoz_organiser"       : { canonical: "hCOz_Organiser"       , type: "STRING", tableCode: "CO" },
        "hcoz_payroll"         : { canonical: "hCOz_Payroll"         , type: "STRING", tableCode: "CO" },
        "hcoz_payroll_name"    : { canonical: "hCOz_Payroll_Name"    , type: "STRING", tableCode: "CO" },
        "hcoz_post_code"       : { canonical: "hCOz_Post_Code"       , type: "STRING", tableCode: "CO" },
        "hcoz_reg_address01"   : { canonical: "hCOz_Reg_Address01"   , type: "STRING", tableCode: "CO" },
        "hcoz_reg_address02"   : { canonical: "hCOz_Reg_Address02"   , type: "STRING", tableCode: "CO" },
        "hcoz_reg_address03"   : { canonical: "hCOz_Reg_Address03"   , type: "STRING", tableCode: "CO" },
        "hcoz_reg_post_code"   : { canonical: "hCOz_Reg_Post_Code"   , type: "STRING", tableCode: "CO" },
        "hcoz_reporting_centre": { canonical: "hCOz_Reporting_Centre", type: "STRING", tableCode: "CO" },
        "hcoz_sector"          : { canonical: "hCOz_Sector"          , type: "STRING", tableCode: "CO" },
        "hcoz_servicing_agent" : { canonical: "hCOz_Servicing_Agent" , type: "STRING", tableCode: "CO" },
        "hcoz_set_no"          : { canonical: "hCOz_Set_No"          , type: "STRING", tableCode: "CO" },
        "hcoz_sort_order"      : { canonical: "hCOz_Sort_Order"      , type: "STRING", tableCode: "CO" },
        "hcoz_spare"           : { canonical: "hCOz_Spare"           , type: "STRING", tableCode: "CO" },
        "hcoz_surname01"       : { canonical: "hCOz_Surname01"       , type: "STRING", tableCode: "CO" },
        "hcoz_surname02"       : { canonical: "hCOz_Surname02"       , type: "STRING", tableCode: "CO" },
        "hcoz_surname03"       : { canonical: "hCOz_Surname03"       , type: "STRING", tableCode: "CO" },
        "hcoz_surname04"       : { canonical: "hCOz_Surname04"       , type: "STRING", tableCode: "CO" },
        "hcoz_surname05"       : { canonical: "hCOz_Surname05"       , type: "STRING", tableCode: "CO" },
        "hcoz_surname06"       : { canonical: "hCOz_Surname06"       , type: "STRING", tableCode: "CO" },
        "hcoz_term_reason"     : { canonical: "hCOz_Term_Reason"     , type: "STRING", tableCode: "CO" },
        "hcoz_title01"         : { canonical: "hCOz_Title01"         , type: "STRING", tableCode: "CO" },
        "hcoz_title02"         : { canonical: "hCOz_Title02"         , type: "STRING", tableCode: "CO" },
        "hcoz_title03"         : { canonical: "hCOz_Title03"         , type: "STRING", tableCode: "CO" },
        "hcoz_title04"         : { canonical: "hCOz_Title04"         , type: "STRING", tableCode: "CO" },
        "hcoz_title05"         : { canonical: "hCOz_Title05"         , type: "STRING", tableCode: "CO" },
        "hcoz_title06"         : { canonical: "hCOz_Title06"         , type: "STRING", tableCode: "CO" },
        "hcoz_trade_name"      : { canonical: "hCOz_Trade_Name"      , type: "STRING", tableCode: "CO" },
        "hcoz_web_address"     : { canonical: "hCOz_Web_Address"     , type: "STRING", tableCode: "CO" },
    }
};

export default CO;
