/**
 * NZ.js — table structure for the NZ (New Zealand Exchange Rates) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "NZ").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force NZ
 */

/** @type {Object} */
const NZ = {
    code: "NZ",
    name: "New_Zealand_Exchange_Rates",
    recordLength: null,
    helpRegistry: "hNZ.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "NZi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hnzd_effective"    : { canonical: "hNZd_Effective"    , type: "DATE", tableCode: "NZ" },
        "hnzd_mod_date"     : { canonical: "hNZd_Mod_Date"     , type: "DATE", tableCode: "NZ" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hnzf_exchange_rate": { canonical: "hNZf_Exchange_Rate", type: "DOUBLE", tableCode: "NZ" },
        "hnzf_spare"        : { canonical: "hNZf_Spare"        , type: "DOUBLE", tableCode: "NZ" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hnzl_spare01"      : { canonical: "hNZl_Spare01"      , type: "INTEGER", tableCode: "NZ" },
        "hnzl_spare02"      : { canonical: "hNZl_Spare02"      , type: "INTEGER", tableCode: "NZ" },
        "hnzl_spare03"      : { canonical: "hNZl_Spare03"      , type: "INTEGER", tableCode: "NZ" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hnzt_mod_time"     : { canonical: "hNZt_Mod_Time"     , type: "TIME", tableCode: "NZ" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hnzz_deleted"      : { canonical: "hNZz_Deleted"      , type: "STRING", tableCode: "NZ" },
        "hnzz_mod_user"     : { canonical: "hNZz_Mod_User"     , type: "STRING", tableCode: "NZ" },
        "hnzz_spare"        : { canonical: "hNZz_Spare"        , type: "STRING", tableCode: "NZ" },
    }
};

export default NZ;
