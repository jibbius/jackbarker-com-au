/**
 * PO.js — table structure for the PO (Policy Committee) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PO").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PO
 */

/** @type {Object} */
const PO = {
    code: "PO",
    name: "Policy_Committee",
    recordLength: null,
    helpRegistry: "hPO.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "POi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hpod_appointed"   : { canonical: "hPOd_Appointed"   , type: "DATE", tableCode: "PO" },
        "hpod_mod_date"    : { canonical: "hPOd_Mod_Date"    , type: "DATE", tableCode: "PO" },
        "hpod_terminated"  : { canonical: "hPOd_Terminated"  , type: "DATE", tableCode: "PO" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hpos_committee_no": { canonical: "hPOs_Committee_No", type: "INTEGER", tableCode: "PO" },
        "hpos_spare01"     : { canonical: "hPOs_Spare01"     , type: "INTEGER", tableCode: "PO" },
        "hpos_spare02"     : { canonical: "hPOs_Spare02"     , type: "INTEGER", tableCode: "PO" },
        "hpos_spare03"     : { canonical: "hPOs_Spare03"     , type: "INTEGER", tableCode: "PO" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hpot_mod_time"    : { canonical: "hPOt_Mod_Time"    , type: "TIME", tableCode: "PO" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hpoz_address01"   : { canonical: "hPOz_Address01"   , type: "STRING", tableCode: "PO" },
        "hpoz_address02"   : { canonical: "hPOz_Address02"   , type: "STRING", tableCode: "PO" },
        "hpoz_address03"   : { canonical: "hPOz_Address03"   , type: "STRING", tableCode: "PO" },
        "hpoz_address04"   : { canonical: "hPOz_Address04"   , type: "STRING", tableCode: "PO" },
        "hpoz_deleted"     : { canonical: "hPOz_Deleted"     , type: "STRING", tableCode: "PO" },
        "hpoz_fax"         : { canonical: "hPOz_Fax"         , type: "STRING", tableCode: "PO" },
        "hpoz_fund"        : { canonical: "hPOz_Fund"        , type: "STRING", tableCode: "PO" },
        "hpoz_given_names" : { canonical: "hPOz_Given_Names" , type: "STRING", tableCode: "PO" },
        "hpoz_home_phone"  : { canonical: "hPOz_Home_Phone"  , type: "STRING", tableCode: "PO" },
        "hpoz_mod_user"    : { canonical: "hPOz_Mod_User"    , type: "STRING", tableCode: "PO" },
        "hpoz_post_code"   : { canonical: "hPOz_Post_Code"   , type: "STRING", tableCode: "PO" },
        "hpoz_spare"       : { canonical: "hPOz_Spare"       , type: "STRING", tableCode: "PO" },
        "hpoz_surname"     : { canonical: "hPOz_Surname"     , type: "STRING", tableCode: "PO" },
        "hpoz_title"       : { canonical: "hPOz_Title"       , type: "STRING", tableCode: "PO" },
        "hpoz_work_phone"  : { canonical: "hPOz_Work_Phone"  , type: "STRING", tableCode: "PO" },
    }
};

export default PO;
