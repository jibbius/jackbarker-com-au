/**
 * TU.js — table structure for the TU (User Defined Transaction (77)) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "TU").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force TU
 */

/** @type {Object} */
const TU = {
    code: "TU",
    name: "User_Defined_Transaction_(77)",
    recordLength: null,
    helpRegistry: "hTU.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "TUi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "htuc_deleted"        : { canonical: "hTUc_Deleted"        , type: "STRING", tableCode: "TU" },
        "htuc_level"          : { canonical: "hTUc_Level"          , type: "STRING", tableCode: "TU" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "htus_formula_code"   : { canonical: "hTUs_Formula_Code"   , type: "INTEGER", tableCode: "TU" },
        "htus_spare01"        : { canonical: "hTUs_Spare01"        , type: "INTEGER", tableCode: "TU" },
        "htus_spare02"        : { canonical: "hTUs_Spare02"        , type: "INTEGER", tableCode: "TU" },
        "htus_spare03"        : { canonical: "hTUs_Spare03"        , type: "INTEGER", tableCode: "TU" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "htuz_account"        : { canonical: "hTUz_Account"        , type: "STRING", tableCode: "TU" },
        "htuz_cont_accts"     : { canonical: "hTUz_Cont_Accts"     , type: "STRING", tableCode: "TU" },
        "htuz_division"       : { canonical: "hTUz_Division"       , type: "STRING", tableCode: "TU" },
        "htuz_dr_or_cr"       : { canonical: "hTUz_DR_or_CR"       , type: "STRING", tableCode: "TU" },
        "htuz_fund"           : { canonical: "hTUz_Fund"           , type: "STRING", tableCode: "TU" },
        "htuz_member"         : { canonical: "hTUz_Member"         , type: "STRING", tableCode: "TU" },
        "htuz_off_rev_account": { canonical: "hTUz_Off_Rev_Account", type: "STRING", tableCode: "TU" },
        "htuz_off_rev_sub"    : { canonical: "hTUz_Off_Rev_Sub"    , type: "STRING", tableCode: "TU" },
        "htuz_off_rev_sub_sub": { canonical: "hTUz_Off_Rev_Sub_Sub", type: "STRING", tableCode: "TU" },
        "htuz_offset_account" : { canonical: "hTUz_Offset_Account" , type: "STRING", tableCode: "TU" },
        "htuz_offset_sub"     : { canonical: "hTUz_Offset_Sub"     , type: "STRING", tableCode: "TU" },
        "htuz_offset_sub_sub" : { canonical: "hTUz_Offset_Sub_Sub" , type: "STRING", tableCode: "TU" },
        "htuz_preserved"      : { canonical: "hTUz_Preserved"      , type: "STRING", tableCode: "TU" },
        "htuz_spare"          : { canonical: "hTUz_Spare"          , type: "STRING", tableCode: "TU" },
        "htuz_sub_acct"       : { canonical: "hTUz_Sub_Acct"       , type: "STRING", tableCode: "TU" },
        "htuz_sub_sub_account": { canonical: "hTUz_Sub_Sub_Account", type: "STRING", tableCode: "TU" },
        "htuz_transaction"    : { canonical: "hTUz_Transaction"    , type: "STRING", tableCode: "TU" },
    }
};

export default TU;
