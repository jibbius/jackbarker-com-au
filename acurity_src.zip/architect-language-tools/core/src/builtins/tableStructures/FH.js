/**
 * FH.js — table structure for the FH (Fund Supplementary Labels 1) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FH
 */

/** @type {Object} */
const FH = {
    code: "FH",
    name: "Fund_Supplementary_Labels_1",
    recordLength: null,
    helpRegistry: "hFH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfhd_mod_date"       : { canonical: "hFHd_Mod_Date"       , type: "DATE", tableCode: "FH" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hfhs_record_no"      : { canonical: "hFHs_Record_No"      , type: "INTEGER", tableCode: "FH" },
        "hfhs_spare01"        : { canonical: "hFHs_Spare01"        , type: "INTEGER", tableCode: "FH" },
        "hfhs_spare02"        : { canonical: "hFHs_Spare02"        , type: "INTEGER", tableCode: "FH" },
        "hfhs_spare03"        : { canonical: "hFHs_Spare03"        , type: "INTEGER", tableCode: "FH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfht_mod_time"       : { canonical: "hFHt_Mod_Time"       , type: "TIME", tableCode: "FH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfhz_amount_labels01": { canonical: "hFHz_Amount_Labels01", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels02": { canonical: "hFHz_Amount_Labels02", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels03": { canonical: "hFHz_Amount_Labels03", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels04": { canonical: "hFHz_Amount_Labels04", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels05": { canonical: "hFHz_Amount_Labels05", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels06": { canonical: "hFHz_Amount_Labels06", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels07": { canonical: "hFHz_Amount_Labels07", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels08": { canonical: "hFHz_Amount_Labels08", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels09": { canonical: "hFHz_Amount_Labels09", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels10": { canonical: "hFHz_Amount_Labels10", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels11": { canonical: "hFHz_Amount_Labels11", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels12": { canonical: "hFHz_Amount_Labels12", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels13": { canonical: "hFHz_Amount_Labels13", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels14": { canonical: "hFHz_Amount_Labels14", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels15": { canonical: "hFHz_Amount_Labels15", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels16": { canonical: "hFHz_Amount_Labels16", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels17": { canonical: "hFHz_Amount_Labels17", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels18": { canonical: "hFHz_Amount_Labels18", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels19": { canonical: "hFHz_Amount_Labels19", type: "STRING", tableCode: "FH" },
        "hfhz_amount_labels20": { canonical: "hFHz_Amount_Labels20", type: "STRING", tableCode: "FH" },
        "hfhz_date_labels01"  : { canonical: "hFHz_Date_Labels01"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels02"  : { canonical: "hFHz_Date_Labels02"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels03"  : { canonical: "hFHz_Date_Labels03"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels04"  : { canonical: "hFHz_Date_Labels04"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels05"  : { canonical: "hFHz_Date_Labels05"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels06"  : { canonical: "hFHz_Date_Labels06"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels07"  : { canonical: "hFHz_Date_Labels07"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels08"  : { canonical: "hFHz_Date_Labels08"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels09"  : { canonical: "hFHz_Date_Labels09"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels10"  : { canonical: "hFHz_Date_Labels10"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels11"  : { canonical: "hFHz_Date_Labels11"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels12"  : { canonical: "hFHz_Date_Labels12"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels13"  : { canonical: "hFHz_Date_Labels13"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels14"  : { canonical: "hFHz_Date_Labels14"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels15"  : { canonical: "hFHz_Date_Labels15"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels16"  : { canonical: "hFHz_Date_Labels16"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels17"  : { canonical: "hFHz_Date_Labels17"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels18"  : { canonical: "hFHz_Date_Labels18"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels19"  : { canonical: "hFHz_Date_Labels19"  , type: "STRING", tableCode: "FH" },
        "hfhz_date_labels20"  : { canonical: "hFHz_Date_Labels20"  , type: "STRING", tableCode: "FH" },
        "hfhz_deleted"        : { canonical: "hFHz_Deleted"        , type: "STRING", tableCode: "FH" },
        "hfhz_division"       : { canonical: "hFHz_Division"       , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels01"  : { canonical: "hFHz_Flag_Labels01"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels02"  : { canonical: "hFHz_Flag_Labels02"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels03"  : { canonical: "hFHz_Flag_Labels03"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels04"  : { canonical: "hFHz_Flag_Labels04"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels05"  : { canonical: "hFHz_Flag_Labels05"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels06"  : { canonical: "hFHz_Flag_Labels06"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels07"  : { canonical: "hFHz_Flag_Labels07"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels08"  : { canonical: "hFHz_Flag_Labels08"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels09"  : { canonical: "hFHz_Flag_Labels09"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels10"  : { canonical: "hFHz_Flag_Labels10"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels11"  : { canonical: "hFHz_Flag_Labels11"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels12"  : { canonical: "hFHz_Flag_Labels12"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels13"  : { canonical: "hFHz_Flag_Labels13"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels14"  : { canonical: "hFHz_Flag_Labels14"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels15"  : { canonical: "hFHz_Flag_Labels15"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels16"  : { canonical: "hFHz_Flag_Labels16"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels17"  : { canonical: "hFHz_Flag_Labels17"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels18"  : { canonical: "hFHz_Flag_Labels18"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels19"  : { canonical: "hFHz_Flag_Labels19"  , type: "STRING", tableCode: "FH" },
        "hfhz_flag_labels20"  : { canonical: "hFHz_Flag_Labels20"  , type: "STRING", tableCode: "FH" },
        "hfhz_fund"           : { canonical: "hFHz_Fund"           , type: "STRING", tableCode: "FH" },
        "hfhz_mod_user"       : { canonical: "hFHz_Mod_User"       , type: "STRING", tableCode: "FH" },
        "hfhz_spare"          : { canonical: "hFHz_Spare"          , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels01"   : { canonical: "hFHz_Var_Labels01"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels02"   : { canonical: "hFHz_Var_Labels02"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels03"   : { canonical: "hFHz_Var_Labels03"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels04"   : { canonical: "hFHz_Var_Labels04"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels05"   : { canonical: "hFHz_Var_Labels05"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels06"   : { canonical: "hFHz_Var_Labels06"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels07"   : { canonical: "hFHz_Var_Labels07"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels08"   : { canonical: "hFHz_Var_Labels08"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels09"   : { canonical: "hFHz_Var_Labels09"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels10"   : { canonical: "hFHz_Var_Labels10"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels11"   : { canonical: "hFHz_Var_Labels11"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels12"   : { canonical: "hFHz_Var_Labels12"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels13"   : { canonical: "hFHz_Var_Labels13"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels14"   : { canonical: "hFHz_Var_Labels14"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels15"   : { canonical: "hFHz_Var_Labels15"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels16"   : { canonical: "hFHz_Var_Labels16"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels17"   : { canonical: "hFHz_Var_Labels17"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels18"   : { canonical: "hFHz_Var_Labels18"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels19"   : { canonical: "hFHz_Var_Labels19"   , type: "STRING", tableCode: "FH" },
        "hfhz_var_labels20"   : { canonical: "hFHz_Var_Labels20"   , type: "STRING", tableCode: "FH" },
    }
};

export default FH;
