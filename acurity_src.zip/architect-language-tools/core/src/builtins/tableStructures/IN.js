/**
 * IN.js — table structure for the IN (Insurer History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "IN").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force IN
 */

/** @type {Object} */
const IN = {
    code: "IN",
    name: "Insurer_History",
    recordLength: null,
    helpRegistry: "hIN.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "INi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hinc_death_choice"    : { canonical: "hINc_Death_Choice"    , type: "STRING", tableCode: "IN" },
        "hinc_record_type"     : { canonical: "hINc_Record_Type"     , type: "STRING", tableCode: "IN" },
        "hinc_sal_cont_choice" : { canonical: "hINc_Sal_Cont_Choice" , type: "STRING", tableCode: "IN" },
        "hinc_sal_cont_cover"  : { canonical: "hINc_Sal_Cont_Cover"  , type: "STRING", tableCode: "IN" },
        "hinc_tpd_choice"      : { canonical: "hINc_TPD_Choice"      , type: "STRING", tableCode: "IN" },
        "hinc_userdefndflags01": { canonical: "hINc_UserDefndFlags01", type: "STRING", tableCode: "IN" },
        "hinc_userdefndflags02": { canonical: "hINc_UserDefndFlags02", type: "STRING", tableCode: "IN" },
        "hinc_userdefndflags03": { canonical: "hINc_UserDefndFlags03", type: "STRING", tableCode: "IN" },
        "hinc_userdefndflags04": { canonical: "hINc_UserDefndFlags04", type: "STRING", tableCode: "IN" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hind_effective"       : { canonical: "hINd_Effective"       , type: "DATE", tableCode: "IN" },
        "hind_mod_date"        : { canonical: "hINd_Mod_Date"        , type: "DATE", tableCode: "IN" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hinf_amount"          : { canonical: "hINf_Amount"          , type: "DOUBLE", tableCode: "IN" },
        "hinf_death_cover"     : { canonical: "hINf_Death_Cover"     , type: "DOUBLE", tableCode: "IN" },
        "hinf_dth_cover_limit" : { canonical: "hINf_Dth_Cover_Limit" , type: "DOUBLE", tableCode: "IN" },
        "hinf_sal_cont_cover"  : { canonical: "hINf_Sal_Cont_Cover"  , type: "DOUBLE", tableCode: "IN" },
        "hinf_sal_cover_limit" : { canonical: "hINf_Sal_Cover_Limit" , type: "DOUBLE", tableCode: "IN" },
        "hinf_tpd_cover"       : { canonical: "hINf_TPD_Cover"       , type: "DOUBLE", tableCode: "IN" },
        "hinf_tpd_cover_limit" : { canonical: "hINf_TPD_Cover_Limit" , type: "DOUBLE", tableCode: "IN" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hint_mod_time"        : { canonical: "hINt_Mod_Time"        , type: "TIME", tableCode: "IN" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hinz_client"          : { canonical: "hINz_Client"          , type: "STRING", tableCode: "IN" },
        "hinz_deleted"         : { canonical: "hINz_Deleted"         , type: "STRING", tableCode: "IN" },
        "hinz_division"        : { canonical: "hINz_Division"        , type: "STRING", tableCode: "IN" },
        "hinz_fund"            : { canonical: "hINz_Fund"            , type: "STRING", tableCode: "IN" },
        "hinz_insurer"         : { canonical: "hINz_Insurer"         , type: "STRING", tableCode: "IN" },
        "hinz_mod_user"        : { canonical: "hINz_Mod_User"        , type: "STRING", tableCode: "IN" },
        "hinz_spare"           : { canonical: "hINz_Spare"           , type: "STRING", tableCode: "IN" },
    }
};

export default IN;
