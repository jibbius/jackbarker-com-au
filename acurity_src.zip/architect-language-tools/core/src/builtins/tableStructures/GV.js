/**
 * GV.js — table structure for the GV (Division Global Information) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "GV").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force GV
 */

/** @type {Object} */
const GV = {
    code: "GV",
    name: "Division_Global_Information",
    recordLength: null,
    helpRegistry: "hGV.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "GVi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hgvc_div1_old_rbm"    : { canonical: "hGVc_Div1_Old_RBM"    , type: "STRING", tableCode: "GV" },
        "hgvc_encryption_type" : { canonical: "hGVc_Encryption_Type" , type: "STRING", tableCode: "GV" },
        "hgvc_in_cash_flag"    : { canonical: "hGVc_In_Cash_Flag"    , type: "STRING", tableCode: "GV" },
        "hgvc_mobile_phone"    : { canonical: "hGVc_Mobile_Phone"    , type: "STRING", tableCode: "GV" },
        "hgvc_payer_type"      : { canonical: "hGVc_Payer_Type"      , type: "STRING", tableCode: "GV" },
        "hgvc_prov_gov_cocont" : { canonical: "hGVc_Prov_Gov_CoCont" , type: "STRING", tableCode: "GV" },
        "hgvc_reval_conversion": { canonical: "hGVc_Reval_Conversion", type: "STRING", tableCode: "GV" },
        "hgvc_surcharge_level" : { canonical: "hGVc_Surcharge_Level" , type: "STRING", tableCode: "GV" },
        "hgvc_surcharge_liab_l": { canonical: "hGVc_Surcharge_Liab_L", type: "STRING", tableCode: "GV" },
        "hgvc_tran87_conv"     : { canonical: "hGVc_Tran87_Conv"     , type: "STRING", tableCode: "GV" },
        "hgvc_web_cont_flag"   : { canonical: "hGVc_Web_Cont_Flag"   , type: "STRING", tableCode: "GV" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hgvd_bank_close_off"  : { canonical: "hGVd_Bank_Close_Off"  , type: "DATE", tableCode: "GV" },
        "hgvd_div_prev_review" : { canonical: "hGVd_Div_Prev_Review" , type: "DATE", tableCode: "GV" },
        "hgvd_first_eoy"       : { canonical: "hGVd_First_EOY"       , type: "DATE", tableCode: "GV" },
        "hgvd_latest_eoy"      : { canonical: "hGVd_Latest_EOY"      , type: "DATE", tableCode: "GV" },
        "hgvd_lost_member"     : { canonical: "hGVd_Lost_Member"     , type: "DATE", tableCode: "GV" },
        "hgvd_paper_work"      : { canonical: "hGVd_Paper_Work"      , type: "DATE", tableCode: "GV" },
        "hgvd_pres_increased"  : { canonical: "hGVd_Pres_Increased"  , type: "DATE", tableCode: "GV" },
        "hgvd_review_close_off": { canonical: "hGVd_Review_Close_Off", type: "DATE", tableCode: "GV" },
        "hgvd_spare"           : { canonical: "hGVd_Spare"           , type: "DATE", tableCode: "GV" },
        "hgvd_trust_end"       : { canonical: "hGVd_Trust_End"       , type: "DATE", tableCode: "GV" },
        "hgvd_trust_start"     : { canonical: "hGVd_Trust_Start"     , type: "DATE", tableCode: "GV" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hgvf_rebal_tolerance" : { canonical: "hGVf_Rebal_Tolerance" , type: "DOUBLE", tableCode: "GV" },
        "hgvf_retain_in_cash"  : { canonical: "hGVf_Retain_In_Cash"  , type: "DOUBLE", tableCode: "GV" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hgvl_afsl"            : { canonical: "hGVl_AFSL"            , type: "INTEGER", tableCode: "GV" },
        "hgvl_cemtex_userid"   : { canonical: "hGVl_Cemtex_Userid"   , type: "INTEGER", tableCode: "GV" },
        "hgvl_cheque_batch_no" : { canonical: "hGVl_Cheque_Batch_No" , type: "INTEGER", tableCode: "GV" },
        "hgvl_deposit_id"      : { canonical: "hGVl_Deposit_Id"      , type: "INTEGER", tableCode: "GV" },
        "hgvl_last_batch_ref"  : { canonical: "hGVl_Last_Batch_Ref"  , type: "INTEGER", tableCode: "GV" },
        "hgvl_last_eft_id"     : { canonical: "hGVl_Last_EFT_ID"     , type: "INTEGER", tableCode: "GV" },
        "hgvl_last_job_ref_no" : { canonical: "hGVl_Last_Job_Ref_No" , type: "INTEGER", tableCode: "GV" },
        "hgvl_last_logon_date" : { canonical: "hGVl_Last_Logon_Date" , type: "INTEGER", tableCode: "GV" },
        "hgvl_last_logon_time" : { canonical: "hGVl_Last_Logon_Time" , type: "INTEGER", tableCode: "GV" },
        "hgvl_last_rcpt_ref_no": { canonical: "hGVl_Last_Rcpt_Ref_No", type: "INTEGER", tableCode: "GV" },
        "hgvl_last_tmp_rep_no" : { canonical: "hGVl_Last_Tmp_Rep_No" , type: "INTEGER", tableCode: "GV" },
        "hgvl_last_trans_ref"  : { canonical: "hGVl_Last_Trans_Ref"  , type: "INTEGER", tableCode: "GV" },
        "hgvl_messageid"       : { canonical: "hGVl_MessageID"       , type: "INTEGER", tableCode: "GV" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hgvs_review_prd"      : { canonical: "hGVs_Review_Prd"      , type: "INTEGER", tableCode: "GV" },
        "hgvs_spare01"         : { canonical: "hGVs_Spare01"         , type: "INTEGER", tableCode: "GV" },
        "hgvs_spare02"         : { canonical: "hGVs_Spare02"         , type: "INTEGER", tableCode: "GV" },
        "hgvs_spare03"         : { canonical: "hGVs_Spare03"         , type: "INTEGER", tableCode: "GV" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hgvz_address_line_1"  : { canonical: "hGVz_Address_Line_1"  , type: "STRING", tableCode: "GV" },
        "hgvz_address_line_2"  : { canonical: "hGVz_Address_Line_2"  , type: "STRING", tableCode: "GV" },
        "hgvz_address_line_3"  : { canonical: "hGVz_Address_Line_3"  , type: "STRING", tableCode: "GV" },
        "hgvz_aust_company_no" : { canonical: "hGVz_Aust_Company_No" , type: "STRING", tableCode: "GV" },
        "hgvz_bank_acct_name"  : { canonical: "hGVz_Bank_Acct_Name"  , type: "STRING", tableCode: "GV" },
        "hgvz_bank_acct_no"    : { canonical: "hGVz_Bank_Acct_No"    , type: "STRING", tableCode: "GV" },
        "hgvz_bsb_no"          : { canonical: "hGVz_BSB_No"          , type: "STRING", tableCode: "GV" },
        "hgvz_category"        : { canonical: "hGVz_Category"        , type: "STRING", tableCode: "GV" },
        "hgvz_client_code"     : { canonical: "hGVz_Client_Code"     , type: "STRING", tableCode: "GV" },
        "hgvz_contact_email"   : { canonical: "hGVz_Contact_Email"   , type: "STRING", tableCode: "GV" },
        "hgvz_contact_fax"     : { canonical: "hGVz_Contact_Fax"     , type: "STRING", tableCode: "GV" },
        "hgvz_contact_name"    : { canonical: "hGVz_Contact_Name"    , type: "STRING", tableCode: "GV" },
        "hgvz_contact_phone"   : { canonical: "hGVz_Contact_Phone"   , type: "STRING", tableCode: "GV" },
        "hgvz_contact_surname" : { canonical: "hGVz_Contact_Surname" , type: "STRING", tableCode: "GV" },
        "hgvz_contact_title"   : { canonical: "hGVz_Contact_Title"   , type: "STRING", tableCode: "GV" },
        "hgvz_corp_ext_gway_id": { canonical: "hGVz_Corp_Ext_Gway_ID", type: "STRING", tableCode: "GV" },
        "hgvz_country"         : { canonical: "hGVz_Country"         , type: "STRING", tableCode: "GV" },
        "hgvz_default_broker"  : { canonical: "hGVz_Default_Broker"  , type: "STRING", tableCode: "GV" },
        "hgvz_default_payee"   : { canonical: "hGVz_Default_Payee"   , type: "STRING", tableCode: "GV" },
        "hgvz_dir_dbt_auth_no" : { canonical: "hGVz_Dir_Dbt_Auth_No" , type: "STRING", tableCode: "GV" },
        "hgvz_division"        : { canonical: "hGVz_Division"        , type: "STRING", tableCode: "GV" },
        "hgvz_footnote"        : { canonical: "hGVz_Footnote"        , type: "STRING", tableCode: "GV" },
        "hgvz_fund_group_tax"  : { canonical: "hGVz_Fund_Group_Tax"  , type: "STRING", tableCode: "GV" },
        "hgvz_fund_type"       : { canonical: "hGVz_Fund_Type"       , type: "STRING", tableCode: "GV" },
        "hgvz_group_tax_no"    : { canonical: "hGVz_Group_Tax_No"    , type: "STRING", tableCode: "GV" },
        "hgvz_ind_dummy_client": { canonical: "hGVz_Ind_Dummy_Client", type: "STRING", tableCode: "GV" },
        "hgvz_ind_last_dummy"  : { canonical: "hGVz_Ind_Last_Dummy"  , type: "STRING", tableCode: "GV" },
        "hgvz_last_client_no"  : { canonical: "hGVz_Last_Client_No"  , type: "STRING", tableCode: "GV" },
        "hgvz_last_emp_no"     : { canonical: "hGVz_Last_Emp_No"     , type: "STRING", tableCode: "GV" },
        "hgvz_last_fund"       : { canonical: "hGVz_Last_Fund"       , type: "STRING", tableCode: "GV" },
        "hgvz_last_location"   : { canonical: "hGVz_Last_Location"   , type: "STRING", tableCode: "GV" },
        "hgvz_last_report_no"  : { canonical: "hGVz_Last_Report_No"  , type: "STRING", tableCode: "GV" },
        "hgvz_logo_line_1"     : { canonical: "hGVz_Logo_Line_1"     , type: "STRING", tableCode: "GV" },
        "hgvz_logo_line_2"     : { canonical: "hGVz_Logo_Line_2"     , type: "STRING", tableCode: "GV" },
        "hgvz_paying_name"     : { canonical: "hGVz_Paying_name"     , type: "STRING", tableCode: "GV" },
        "hgvz_post_code"       : { canonical: "hGVz_Post_Code"       , type: "STRING", tableCode: "GV" },
        "hgvz_postal_add_1"    : { canonical: "hGVz_Postal_Add_1"    , type: "STRING", tableCode: "GV" },
        "hgvz_postal_add_2"    : { canonical: "hGVz_Postal_Add_2"    , type: "STRING", tableCode: "GV" },
        "hgvz_postal_add_3"    : { canonical: "hGVz_Postal_Add_3"    , type: "STRING", tableCode: "GV" },
        "hgvz_postal_post_code": { canonical: "hGVz_Postal_Post_Code", type: "STRING", tableCode: "GV" },
        "hgvz_postal_state"    : { canonical: "hGVz_Postal_State"    , type: "STRING", tableCode: "GV" },
        "hgvz_postal_suburb"   : { canonical: "hGVz_Postal_Suburb"   , type: "STRING", tableCode: "GV" },
        "hgvz_prodid"          : { canonical: "hGVz_ProdID"          , type: "STRING", tableCode: "GV" },
        "hgvz_prov_prod_id_nbr": { canonical: "hGVz_Prov_Prod_ID_Nbr", type: "STRING", tableCode: "GV" },
        "hgvz_regulated_no"    : { canonical: "hGVz_Regulated_No"    , type: "STRING", tableCode: "GV" },
        "hgvz_report_code"     : { canonical: "hGVz_Report_Code"     , type: "STRING", tableCode: "GV" },
        "hgvz_report_group"    : { canonical: "hGVz_Report_Group"    , type: "STRING", tableCode: "GV" },
        "hgvz_rse"             : { canonical: "hGVz_RSE"             , type: "STRING", tableCode: "GV" },
        "hgvz_set_no"          : { canonical: "hGVz_Set_No"          , type: "STRING", tableCode: "GV" },
        "hgvz_spare"           : { canonical: "hGVz_Spare"           , type: "STRING", tableCode: "GV" },
        "hgvz_ss_bonus_inv_mgr": { canonical: "hGVz_SS_Bonus_Inv_Mgr", type: "STRING", tableCode: "GV" },
        "hgvz_ss_pref_inv_mgr" : { canonical: "hGVz_SS_Pref_Inv_Mgr" , type: "STRING", tableCode: "GV" },
        "hgvz_ss_prefbonus_mgr": { canonical: "hGVz_SS_PrefBonus_Mgr", type: "STRING", tableCode: "GV" },
        "hgvz_state"           : { canonical: "hGVz_State"           , type: "STRING", tableCode: "GV" },
        "hgvz_suburb"          : { canonical: "hGVz_Suburb"          , type: "STRING", tableCode: "GV" },
        "hgvz_tax_file_no"     : { canonical: "hGVz_Tax_File_No"     , type: "STRING", tableCode: "GV" },
        "hgvz_trading_name"    : { canonical: "hGVz_Trading_Name"    , type: "STRING", tableCode: "GV" },
        "hgvz_trust_name"      : { canonical: "hGVz_Trust_name"      , type: "STRING", tableCode: "GV" },

        // ── (y-prefix) ──────────────────────────────────────────────────
        "hgvy_cont_accts01"    : { canonical: "hGVy_Cont_Accts01"    , type: "STRING", tableCode: "GV" },
        "hgvy_cont_accts02"    : { canonical: "hGVy_Cont_Accts02"    , type: "STRING", tableCode: "GV" },
        "hgvy_cont_accts03"    : { canonical: "hGVy_Cont_Accts03"    , type: "STRING", tableCode: "GV" },
        "hgvy_cont_accts04"    : { canonical: "hGVy_Cont_Accts04"    , type: "STRING", tableCode: "GV" },
        "hgvy_cont_accts05"    : { canonical: "hGVy_Cont_Accts05"    , type: "STRING", tableCode: "GV" },
        "hgvy_inv_group01"     : { canonical: "hGVy_Inv_Group01"     , type: "STRING", tableCode: "GV" },
        "hgvy_inv_group02"     : { canonical: "hGVy_Inv_Group02"     , type: "STRING", tableCode: "GV" },
        "hgvy_inv_group03"     : { canonical: "hGVy_Inv_Group03"     , type: "STRING", tableCode: "GV" },
        "hgvy_inv_group04"     : { canonical: "hGVy_Inv_Group04"     , type: "STRING", tableCode: "GV" },
        "hgvy_inv_group05"     : { canonical: "hGVy_Inv_Group05"     , type: "STRING", tableCode: "GV" },
        "hgvy_inv_group06"     : { canonical: "hGVy_Inv_Group06"     , type: "STRING", tableCode: "GV" },
    }
};

export default GV;
