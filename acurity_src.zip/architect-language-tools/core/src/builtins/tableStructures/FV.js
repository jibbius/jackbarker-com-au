/**
 * FV.js — table structure for the FV (Last Member Number) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FV").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FV
 */

/** @type {Object} */
const FV = {
    code: "FV",
    name: "Last_Member_Number",
    recordLength: null,
    helpRegistry: "hFV.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FVi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfvz_fund"       : { canonical: "hFVz_Fund"       , type: "STRING", tableCode: "FV" },
        "hfvz_last_emp_no": { canonical: "hFVz_Last_Emp_No", type: "STRING", tableCode: "FV" },
        "hfvz_last_mbr_no": { canonical: "hFVz_Last_Mbr_No", type: "STRING", tableCode: "FV" },
        "hfvz_spare"      : { canonical: "hFVz_Spare"      , type: "STRING", tableCode: "FV" },
    }
};

export default FV;
