/**
 * CG.js — table structure for the CG (Capital Gains Indexation Rates) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CG").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CG
 */

/** @type {Object} */
const CG = {
    code: "CG",
    name: "Capital_Gains_Indexation_Rates",
    recordLength: null,
    helpRegistry: "hCG.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CGi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hcgc_spare"         : { canonical: "hCGc_Spare"         , type: "STRING", tableCode: "CG" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hcgd_effective"     : { canonical: "hCGd_Effective"     , type: "DATE", tableCode: "CG" },
        "hcgd_mod_date"      : { canonical: "hCGd_Mod_Date"      , type: "DATE", tableCode: "CG" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hcgf_fid_maximum"   : { canonical: "hCGf_FID_Maximum"   , type: "DOUBLE", tableCode: "CG" },
        "hcgf_index_rate"    : { canonical: "hCGf_Index_Rate"    , type: "DOUBLE", tableCode: "CG" },
        "hcgf_interest_rate" : { canonical: "hCGf_Interest_Rate" , type: "DOUBLE", tableCode: "CG" },
        "hcgf_nz_index_rate" : { canonical: "hCGf_NZ_Index_Rate" , type: "DOUBLE", tableCode: "CG" },
        "hcgf_unfranked_rate": { canonical: "hCGf_Unfranked_Rate", type: "DOUBLE", tableCode: "CG" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hcgt_mod_time"      : { canonical: "hCGt_Mod_Time"      , type: "TIME", tableCode: "CG" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcgz_country_code"  : { canonical: "hCGz_Country_Code"  , type: "STRING", tableCode: "CG" },
        "hcgz_deleted"       : { canonical: "hCGz_Deleted"       , type: "STRING", tableCode: "CG" },
        "hcgz_mod_user"      : { canonical: "hCGz_Mod_User"      , type: "STRING", tableCode: "CG" },
        "hcgz_rec_type"      : { canonical: "hCGz_Rec_Type"      , type: "STRING", tableCode: "CG" },
    }
};

export default CG;
