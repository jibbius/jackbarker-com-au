/**
 * JQ.js — table structure for the JQ (Job Queuing Rules) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "JQ").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force JQ
 */

/** @type {Object} */
const JQ = {
    code: "JQ",
    name: "Job_Queuing_Rules",
    recordLength: null,
    helpRegistry: "hJQ.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "JQi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hjqc_deleted"         : { canonical: "hJQc_Deleted"         , type: "STRING", tableCode: "JQ" },
        "hjqc_division"        : { canonical: "hJQc_Division"        , type: "STRING", tableCode: "JQ" },
        "hjqc_interactive"     : { canonical: "hJQc_Interactive"     , type: "STRING", tableCode: "JQ" },
        "hjqc_job_priority"    : { canonical: "hJQc_Job_Priority"    , type: "STRING", tableCode: "JQ" },
        "hjqc_output_priority" : { canonical: "hJQc_Output_Priority" , type: "STRING", tableCode: "JQ" },
        "hjqc_process_group"   : { canonical: "hJQc_Process_Group"   , type: "STRING", tableCode: "JQ" },
        "hjqc_process_level"   : { canonical: "hJQc_Process_Level"   , type: "STRING", tableCode: "JQ" },
        "hjqc_process_quantity": { canonical: "hJQc_Process_Quantity", type: "STRING", tableCode: "JQ" },
        "hjqc_remote"          : { canonical: "hJQc_Remote"          , type: "STRING", tableCode: "JQ" },
        "hjqc_routing"         : { canonical: "hJQc_Routing"         , type: "STRING", tableCode: "JQ" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hjqd_mod_date"        : { canonical: "hJQd_Mod_Date"        , type: "DATE", tableCode: "JQ" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hjqs_rule_order"      : { canonical: "hJQs_Rule_Order"      , type: "INTEGER", tableCode: "JQ" },
        "hjqs_spare01"         : { canonical: "hJQs_Spare01"         , type: "INTEGER", tableCode: "JQ" },
        "hjqs_spare02"         : { canonical: "hJQs_Spare02"         , type: "INTEGER", tableCode: "JQ" },
        "hjqs_spare03"         : { canonical: "hJQs_Spare03"         , type: "INTEGER", tableCode: "JQ" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hjqt_mod_time"        : { canonical: "hJQt_Mod_Time"        , type: "TIME", tableCode: "JQ" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hjqz_batch_code"      : { canonical: "hJQz_Batch_Code"      , type: "STRING", tableCode: "JQ" },
        "hjqz_fund"            : { canonical: "hJQz_Fund"            , type: "STRING", tableCode: "JQ" },
        "hjqz_job_queue"       : { canonical: "hJQz_Job_Queue"       , type: "STRING", tableCode: "JQ" },
        "hjqz_mod_user"        : { canonical: "hJQz_Mod_User"        , type: "STRING", tableCode: "JQ" },
        "hjqz_payroll"         : { canonical: "hJQz_Payroll"         , type: "STRING", tableCode: "JQ" },
        "hjqz_process"         : { canonical: "hJQz_Process"         , type: "STRING", tableCode: "JQ" },
        "hjqz_process_type"    : { canonical: "hJQz_Process_Type"    , type: "STRING", tableCode: "JQ" },
        "hjqz_spare"           : { canonical: "hJQz_Spare"           , type: "STRING", tableCode: "JQ" },
        "hjqz_user_group"      : { canonical: "hJQz_User_Group"      , type: "STRING", tableCode: "JQ" },
        "hjqz_user_id"         : { canonical: "hJQz_User_Id"         , type: "STRING", tableCode: "JQ" },
    }
};

export default JQ;
