/**
 * RR.js — table structure for the RR (Report History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "RR").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force RR
 */

/** @type {Object} */
const RR = {
    code: "RR",
    name: "Report_History",
    recordLength: null,
    helpRegistry: "hRR.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "RRi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hrrc_group_cert"      : { canonical: "hRRc_Group_Cert"      , type: "STRING", tableCode: "RR" },
        "hrrc_return_to_sender": { canonical: "hRRc_Return_To_Sender", type: "STRING", tableCode: "RR" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hrrd_effective"       : { canonical: "hRRd_Effective"       , type: "DATE", tableCode: "RR" },
        "hrrd_mod_date"        : { canonical: "hRRd_Mod_Date"        , type: "DATE", tableCode: "RR" },
        "hrrd_returned"        : { canonical: "hRRd_Returned"        , type: "DATE", tableCode: "RR" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hrrf_bal_gc_recs"     : { canonical: "hRRf_Bal_GC_Recs"     , type: "DOUBLE", tableCode: "RR" },
        "hrrf_spare"           : { canonical: "hRRf_Spare"           , type: "DOUBLE", tableCode: "RR" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hrrl_block_no"        : { canonical: "hRRl_Block_No"        , type: "INTEGER", tableCode: "RR" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hrrt_mod_time"        : { canonical: "hRRt_Mod_Time"        , type: "TIME", tableCode: "RR" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hrrz_corres_method"   : { canonical: "hRRz_Corres_Method"   , type: "STRING", tableCode: "RR" },
        "hrrz_fund"            : { canonical: "hRRz_Fund"            , type: "STRING", tableCode: "RR" },
        "hrrz_group_cert_no"   : { canonical: "hRRz_Group_Cert_No"   , type: "STRING", tableCode: "RR" },
        "hrrz_member"          : { canonical: "hRRz_Member"          , type: "STRING", tableCode: "RR" },
        "hrrz_mod_user"        : { canonical: "hRRz_Mod_User"        , type: "STRING", tableCode: "RR" },
        "hrrz_report_id"       : { canonical: "hRRz_Report_Id"       , type: "STRING", tableCode: "RR" },
        "hrrz_report_type"     : { canonical: "hRRz_Report_Type"     , type: "STRING", tableCode: "RR" },
        "hrrz_spare"           : { canonical: "hRRz_Spare"           , type: "STRING", tableCode: "RR" },
    }
};

export default RR;
