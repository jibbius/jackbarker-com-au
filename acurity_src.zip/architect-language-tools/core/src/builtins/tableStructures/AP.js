/**
 * AP.js — table structure for the AP (Advisor Proportions History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AP").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AP
 */

/** @type {Object} */
const AP = {
    code: "AP",
    name: "Advisor_Proportions_History",
    recordLength: null,
    helpRegistry: "hAP.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "APi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hapd_effective"  : { canonical: "hAPd_Effective"  , type: "DATE", tableCode: "AP" },
        "hapd_mod_date"   : { canonical: "hAPd_Mod_Date"   , type: "DATE", tableCode: "AP" },
        "hapd_spare"      : { canonical: "hAPd_Spare"      , type: "DATE", tableCode: "AP" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hapf_comm_pcnt01": { canonical: "hAPf_Comm_Pcnt01", type: "DOUBLE", tableCode: "AP" },
        "hapf_comm_pcnt02": { canonical: "hAPf_Comm_Pcnt02", type: "DOUBLE", tableCode: "AP" },
        "hapf_comm_pcnt03": { canonical: "hAPf_Comm_Pcnt03", type: "DOUBLE", tableCode: "AP" },
        "hapf_comm_pcnt04": { canonical: "hAPf_Comm_Pcnt04", type: "DOUBLE", tableCode: "AP" },
        "hapf_comm_pcnt05": { canonical: "hAPf_Comm_Pcnt05", type: "DOUBLE", tableCode: "AP" },
        "hapf_comm_pcnt06": { canonical: "hAPf_Comm_Pcnt06", type: "DOUBLE", tableCode: "AP" },
        "hapf_comm_pcnt07": { canonical: "hAPf_Comm_Pcnt07", type: "DOUBLE", tableCode: "AP" },
        "hapf_comm_pcnt08": { canonical: "hAPf_Comm_Pcnt08", type: "DOUBLE", tableCode: "AP" },
        "hapf_comm_pcnt09": { canonical: "hAPf_Comm_Pcnt09", type: "DOUBLE", tableCode: "AP" },
        "hapf_comm_pcnt10": { canonical: "hAPf_Comm_Pcnt10", type: "DOUBLE", tableCode: "AP" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hapt_mod_time"   : { canonical: "hAPt_Mod_Time"   , type: "TIME", tableCode: "AP" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hapz_advisor01"  : { canonical: "hAPz_Advisor01"  , type: "STRING", tableCode: "AP" },
        "hapz_advisor02"  : { canonical: "hAPz_Advisor02"  , type: "STRING", tableCode: "AP" },
        "hapz_advisor03"  : { canonical: "hAPz_Advisor03"  , type: "STRING", tableCode: "AP" },
        "hapz_advisor04"  : { canonical: "hAPz_Advisor04"  , type: "STRING", tableCode: "AP" },
        "hapz_advisor05"  : { canonical: "hAPz_Advisor05"  , type: "STRING", tableCode: "AP" },
        "hapz_advisor06"  : { canonical: "hAPz_Advisor06"  , type: "STRING", tableCode: "AP" },
        "hapz_advisor07"  : { canonical: "hAPz_Advisor07"  , type: "STRING", tableCode: "AP" },
        "hapz_advisor08"  : { canonical: "hAPz_Advisor08"  , type: "STRING", tableCode: "AP" },
        "hapz_advisor09"  : { canonical: "hAPz_Advisor09"  , type: "STRING", tableCode: "AP" },
        "hapz_advisor10"  : { canonical: "hAPz_Advisor10"  , type: "STRING", tableCode: "AP" },
        "hapz_comm_type"  : { canonical: "hAPz_Comm_Type"  , type: "STRING", tableCode: "AP" },
        "hapz_fund"       : { canonical: "hAPz_Fund"       , type: "STRING", tableCode: "AP" },
        "hapz_member"     : { canonical: "hAPz_Member"     , type: "STRING", tableCode: "AP" },
        "hapz_mod_user"   : { canonical: "hAPz_Mod_User"   , type: "STRING", tableCode: "AP" },
        "hapz_payroll"    : { canonical: "hAPz_Payroll"    , type: "STRING", tableCode: "AP" },
        "hapz_record_type": { canonical: "hAPz_Record_Type", type: "STRING", tableCode: "AP" },
        "hapz_spare"      : { canonical: "hAPz_Spare"      , type: "STRING", tableCode: "AP" },
        "hapz_status"     : { canonical: "hAPz_Status"     , type: "STRING", tableCode: "AP" },
    }
};

export default AP;
