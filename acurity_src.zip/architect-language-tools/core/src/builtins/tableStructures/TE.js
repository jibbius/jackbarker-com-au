/**
 * TE.js — table structure for the TE (Member Exit Batch Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "TE").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force TE
 */

/** @type {Object} */
const TE = {
    code: "TE",
    name: "Member_Exit_Batch_Details",
    recordLength: null,
    helpRegistry: "hTE.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "TEi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "htec_benefit_payment" : { canonical: "hTEc_Benefit_Payment" , type: "STRING", tableCode: "TE" },
        "htec_benefit_taken"   : { canonical: "hTEc_Benefit_Taken"   , type: "STRING", tableCode: "TE" },
        "htec_benefit_type"    : { canonical: "hTEc_Benefit_Type"    , type: "STRING", tableCode: "TE" },
        "htec_division"        : { canonical: "hTEc_Division"        , type: "STRING", tableCode: "TE" },
        "htec_estate"          : { canonical: "hTEc_Estate"          , type: "STRING", tableCode: "TE" },
        "htec_marginal_rate"   : { canonical: "hTEc_Marginal_Rate"   , type: "STRING", tableCode: "TE" },
        "htec_misc_benefit"    : { canonical: "hTEc_Misc_Benefit"    , type: "STRING", tableCode: "TE" },
        "htec_os_or_hship"     : { canonical: "hTEc_OS_Or_Hship"     , type: "STRING", tableCode: "TE" },
        "htec_partial_wdl"     : { canonical: "hTEc_Partial_Wdl"     , type: "STRING", tableCode: "TE" },
        "htec_perm_retire"     : { canonical: "hTEc_Perm_Retire"     , type: "STRING", tableCode: "TE" },
        "htec_prev_status"     : { canonical: "hTEc_Prev_Status"     , type: "STRING", tableCode: "TE" },
        "htec_ro_portion"      : { canonical: "hTEc_RO_Portion"      , type: "STRING", tableCode: "TE" },
        "htec_surch_payment"   : { canonical: "hTEc_Surch_Payment"   , type: "STRING", tableCode: "TE" },
        "htec_tax_treatment"   : { canonical: "hTEc_Tax_Treatment"   , type: "STRING", tableCode: "TE" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hted_exit"            : { canonical: "hTEd_Exit"            , type: "DATE", tableCode: "TE" },
        "hted_ill_health_start": { canonical: "hTEd_Ill_Health_Start", type: "DATE", tableCode: "TE" },
        "hted_payment"         : { canonical: "hTEd_Payment"         , type: "DATE", tableCode: "TE" },
        "hted_spare"           : { canonical: "hTEd_Spare"           , type: "DATE", tableCode: "TE" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "htef_dth_dedn_actuary": { canonical: "hTEf_DTH_Dedn_Actuary", type: "DOUBLE", tableCode: "TE" },
        "htef_spare"           : { canonical: "hTEf_Spare"           , type: "DOUBLE", tableCode: "TE" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "htel_batch_ref"       : { canonical: "hTEl_Batch_Ref"       , type: "INTEGER", tableCode: "TE" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "htes_days_int_free"   : { canonical: "hTEs_Days_Int_Free"   , type: "INTEGER", tableCode: "TE" },
        "htes_spare01"         : { canonical: "hTEs_Spare01"         , type: "INTEGER", tableCode: "TE" },
        "htes_spare02"         : { canonical: "hTEs_Spare02"         , type: "INTEGER", tableCode: "TE" },
        "htes_spare03"         : { canonical: "hTEs_Spare03"         , type: "INTEGER", tableCode: "TE" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "htez_deleted"         : { canonical: "hTEz_Deleted"         , type: "STRING", tableCode: "TE" },
        "htez_exit_reason"     : { canonical: "hTEz_Exit_Reason"     , type: "STRING", tableCode: "TE" },
        "htez_exit_rolled_over": { canonical: "hTEz_Exit_Rolled_Over", type: "STRING", tableCode: "TE" },
        "htez_fund"            : { canonical: "hTEz_Fund"            , type: "STRING", tableCode: "TE" },
        "htez_group_cert"      : { canonical: "hTEz_Group_Cert"      , type: "STRING", tableCode: "TE" },
        "htez_member"          : { canonical: "hTEz_Member"          , type: "STRING", tableCode: "TE" },
        "htez_spare"           : { canonical: "hTEz_Spare"           , type: "STRING", tableCode: "TE" },
    }
};

export default TE;
