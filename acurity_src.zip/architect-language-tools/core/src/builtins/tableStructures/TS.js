/**
 * TS.js — table structure for the TS (Taxable Salary History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "TS").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force TS
 */

/** @type {Object} */
const TS = {
    code: "TS",
    name: "Taxable_Salary_History",
    recordLength: null,
    helpRegistry: "hTS.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "TSi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "htsd_effective"  : { canonical: "hTSd_Effective"  , type: "DATE", tableCode: "TS" },
        "htsd_mod_date"   : { canonical: "hTSd_Mod_Date"   , type: "DATE", tableCode: "TS" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "htsf_base_salary": { canonical: "hTSf_Base_Salary", type: "DOUBLE", tableCode: "TS" },
        "htsf_salary"     : { canonical: "hTSf_Salary"     , type: "DOUBLE", tableCode: "TS" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "htst_mod_time"   : { canonical: "hTSt_Mod_Time"   , type: "TIME", tableCode: "TS" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "htsz_deleted"    : { canonical: "hTSz_Deleted"    , type: "STRING", tableCode: "TS" },
        "htsz_fund"       : { canonical: "hTSz_Fund"       , type: "STRING", tableCode: "TS" },
        "htsz_member"     : { canonical: "hTSz_Member"     , type: "STRING", tableCode: "TS" },
        "htsz_mod_user"   : { canonical: "hTSz_Mod_User"   , type: "STRING", tableCode: "TS" },
        "htsz_payroll"    : { canonical: "hTSz_Payroll"    , type: "STRING", tableCode: "TS" },
        "htsz_spare"      : { canonical: "hTSz_Spare"      , type: "STRING", tableCode: "TS" },
    }
};

export default TS;
