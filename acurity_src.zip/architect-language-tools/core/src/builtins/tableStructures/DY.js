/**
 * DY.js — table structure for the DY (Auto Diary) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "DY").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force DY
 */

/** @type {Object} */
const DY = {
    code: "DY",
    name: "Auto_Diary",
    recordLength: null,
    helpRegistry: "hDY.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "DYi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hdyc_frequency": { canonical: "hDYc_Frequency", type: "STRING", tableCode: "DY" },
        "hdyc_projected": { canonical: "hDYc_Projected", type: "STRING", tableCode: "DY" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hdyd_effective": { canonical: "hDYd_Effective", type: "DATE", tableCode: "DY" },
        "hdyd_mod_date" : { canonical: "hDYd_Mod_Date" , type: "DATE", tableCode: "DY" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hdyt_mod_time" : { canonical: "hDYt_Mod_Time" , type: "TIME", tableCode: "DY" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hdyz_deleted"  : { canonical: "hDYz_Deleted"  , type: "STRING", tableCode: "DY" },
        "hdyz_message"  : { canonical: "hDYz_Message"  , type: "STRING", tableCode: "DY" },
        "hdyz_mod_user" : { canonical: "hDYz_Mod_User" , type: "STRING", tableCode: "DY" },
        "hdyz_spare"    : { canonical: "hDYz_Spare"    , type: "STRING", tableCode: "DY" },
        "hdyz_user"     : { canonical: "hDYz_User"     , type: "STRING", tableCode: "DY" },
    }
};

export default DY;
