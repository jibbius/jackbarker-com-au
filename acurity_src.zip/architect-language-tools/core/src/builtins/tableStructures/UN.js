/**
 * UN.js — table structure for the UN (Unit Entitlement History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "UN").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force UN
 */

/** @type {Object} */
const UN = {
    code: "UN",
    name: "Unit_Entitlement_History",
    recordLength: null,
    helpRegistry: "hUN.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "UNi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hunc_confirmed"       : { canonical: "hUNc_Confirmed"       , type: "STRING", tableCode: "UN" },
        "hunc_deleted"         : { canonical: "hUNc_Deleted"         , type: "STRING", tableCode: "UN" },
        "hunc_division"        : { canonical: "hUNc_Division"        , type: "STRING", tableCode: "UN" },
        "hunc_quote"           : { canonical: "hUNc_Quote"           , type: "STRING", tableCode: "UN" },
        "hunc_refund_or_approp": { canonical: "hUNc_Refund_Or_Approp", type: "STRING", tableCode: "UN" },
        "hunc_units_more_entit": { canonical: "hUNc_Units_More_Entit", type: "STRING", tableCode: "UN" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hund_effective"       : { canonical: "hUNd_Effective"       , type: "DATE", tableCode: "UN" },
        "hund_mod_date"        : { canonical: "hUNd_Mod_Date"        , type: "DATE", tableCode: "UN" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hunf_abandoned_calcd" : { canonical: "hUNf_Abandoned_Calcd" , type: "DOUBLE", tableCode: "UN" },
        "hunf_abandoned_confrm": { canonical: "hUNf_Abandoned_Confrm", type: "DOUBLE", tableCode: "UN" },
        "hunf_approp_calcd"    : { canonical: "hUNf_Approp_Calcd"    , type: "DOUBLE", tableCode: "UN" },
        "hunf_approp_confrmd"  : { canonical: "hUNf_Approp_Confrmd"  , type: "DOUBLE", tableCode: "UN" },
        "hunf_cnts_due_instal1": { canonical: "hUNf_Cnts_Due_Instal1", type: "DOUBLE", tableCode: "UN" },
        "hunf_cnts_due_instal2": { canonical: "hUNf_Cnts_Due_Instal2", type: "DOUBLE", tableCode: "UN" },
        "hunf_compulsory_calcd": { canonical: "hUNf_Compulsory_Calcd", type: "DOUBLE", tableCode: "UN" },
        "hunf_conts_ineffect"  : { canonical: "hUNf_Conts_Ineffect"  , type: "DOUBLE", tableCode: "UN" },
        "hunf_cost_fully_paid" : { canonical: "hUNf_Cost_Fully_Paid" , type: "DOUBLE", tableCode: "UN" },
        "hunf_cost_instalment" : { canonical: "hUNf_Cost_Instalment" , type: "DOUBLE", tableCode: "UN" },
        "hunf_cost_rate_age"   : { canonical: "hUNf_Cost_Rate_Age"   , type: "DOUBLE", tableCode: "UN" },
        "hunf_cost_reserve"    : { canonical: "hUNf_Cost_Reserve"    , type: "DOUBLE", tableCode: "UN" },
        "hunf_full_unit_cost"  : { canonical: "hUNf_Full_Unit_Cost"  , type: "DOUBLE", tableCode: "UN" },
        "hunf_optional_calcd"  : { canonical: "hUNf_Optional_Calcd"  , type: "DOUBLE", tableCode: "UN" },
        "hunf_optional_confrmd": { canonical: "hUNf_Optional_Confrmd", type: "DOUBLE", tableCode: "UN" },
        "hunf_out_bal_instal"  : { canonical: "hUNf_Out_Bal_Instal"  , type: "DOUBLE", tableCode: "UN" },
        "hunf_reduction_calcd" : { canonical: "hUNf_Reduction_Calcd" , type: "DOUBLE", tableCode: "UN" },
        "hunf_reduction_confrm": { canonical: "hUNf_Reduction_Confrm", type: "DOUBLE", tableCode: "UN" },
        "hunf_refund_instalmnt": { canonical: "hUNf_Refund_Instalmnt", type: "DOUBLE", tableCode: "UN" },
        "hunf_refund_rate_age" : { canonical: "hUNf_Refund_Rate_Age" , type: "DOUBLE", tableCode: "UN" },
        "hunf_refunded_abandon": { canonical: "hUNf_Refunded_Abandon", type: "DOUBLE", tableCode: "UN" },
        "hunf_refunded_held"   : { canonical: "hUNf_Refunded_Held"   , type: "DOUBLE", tableCode: "UN" },
        "hunf_reserve_confrmd" : { canonical: "hUNf_Reserve_Confrmd" , type: "DOUBLE", tableCode: "UN" },
        "hunf_spare01"         : { canonical: "hUNf_Spare01"         , type: "DOUBLE", tableCode: "UN" },
        "hunf_spare02"         : { canonical: "hUNf_Spare02"         , type: "DOUBLE", tableCode: "UN" },
        "hunf_tot_abandoned"   : { canonical: "hUNf_Tot_Abandoned"   , type: "DOUBLE", tableCode: "UN" },
        "hunf_tot_approp"      : { canonical: "hUNf_Tot_Approp"      , type: "DOUBLE", tableCode: "UN" },
        "hunf_tot_compulsory"  : { canonical: "hUNf_Tot_Compulsory"  , type: "DOUBLE", tableCode: "UN" },
        "hunf_tot_ded_factor"  : { canonical: "hUNf_Tot_Ded_Factor"  , type: "DOUBLE", tableCode: "UN" },
        "hunf_tot_fully_paid"  : { canonical: "hUNf_Tot_Fully_Paid"  , type: "DOUBLE", tableCode: "UN" },
        "hunf_tot_instalment"  : { canonical: "hUNf_Tot_Instalment"  , type: "DOUBLE", tableCode: "UN" },
        "hunf_tot_rate_for_age": { canonical: "hUNf_Tot_Rate_For_Age", type: "DOUBLE", tableCode: "UN" },
        "hunf_tot_reserve"     : { canonical: "hUNf_Tot_Reserve"     , type: "DOUBLE", tableCode: "UN" },
        "hunf_tot_unit_entit"  : { canonical: "hUNf_Tot_Unit_Entit"  , type: "DOUBLE", tableCode: "UN" },
        "hunf_tot_units_held"  : { canonical: "hUNf_Tot_Units_Held"  , type: "DOUBLE", tableCode: "UN" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hunl_sequence_no"     : { canonical: "hUNl_Sequence_No"     , type: "INTEGER", tableCode: "UN" },
        "hunl_trans_ref"       : { canonical: "hUNl_Trans_Ref"       , type: "INTEGER", tableCode: "UN" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hunt_mod_time"        : { canonical: "hUNt_Mod_Time"        , type: "TIME", tableCode: "UN" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hunz_approp_accts01"  : { canonical: "hUNz_Approp_Accts01"  , type: "STRING", tableCode: "UN" },
        "hunz_approp_accts02"  : { canonical: "hUNz_Approp_Accts02"  , type: "STRING", tableCode: "UN" },
        "hunz_approp_accts03"  : { canonical: "hUNz_Approp_Accts03"  , type: "STRING", tableCode: "UN" },
        "hunz_approp_accts04"  : { canonical: "hUNz_Approp_Accts04"  , type: "STRING", tableCode: "UN" },
        "hunz_approp_accts05"  : { canonical: "hUNz_Approp_Accts05"  , type: "STRING", tableCode: "UN" },
        "hunz_approp_accts06"  : { canonical: "hUNz_Approp_Accts06"  , type: "STRING", tableCode: "UN" },
        "hunz_approp_accts07"  : { canonical: "hUNz_Approp_Accts07"  , type: "STRING", tableCode: "UN" },
        "hunz_approp_accts08"  : { canonical: "hUNz_Approp_Accts08"  , type: "STRING", tableCode: "UN" },
        "hunz_description"     : { canonical: "hUNz_Description"     , type: "STRING", tableCode: "UN" },
        "hunz_fund"            : { canonical: "hUNz_Fund"            , type: "STRING", tableCode: "UN" },
        "hunz_member"          : { canonical: "hUNz_Member"          , type: "STRING", tableCode: "UN" },
        "hunz_mod_user"        : { canonical: "hUNz_Mod_User"        , type: "STRING", tableCode: "UN" },
        "hunz_reserve_accts01" : { canonical: "hUNz_Reserve_Accts01" , type: "STRING", tableCode: "UN" },
        "hunz_reserve_accts02" : { canonical: "hUNz_Reserve_Accts02" , type: "STRING", tableCode: "UN" },
        "hunz_reserve_accts03" : { canonical: "hUNz_Reserve_Accts03" , type: "STRING", tableCode: "UN" },
        "hunz_reserve_accts04" : { canonical: "hUNz_Reserve_Accts04" , type: "STRING", tableCode: "UN" },
        "hunz_reserve_accts05" : { canonical: "hUNz_Reserve_Accts05" , type: "STRING", tableCode: "UN" },
        "hunz_reserve_accts06" : { canonical: "hUNz_Reserve_Accts06" , type: "STRING", tableCode: "UN" },
        "hunz_reserve_accts07" : { canonical: "hUNz_Reserve_Accts07" , type: "STRING", tableCode: "UN" },
        "hunz_reserve_accts08" : { canonical: "hUNz_Reserve_Accts08" , type: "STRING", tableCode: "UN" },
        "hunz_sal_redctn_reasn": { canonical: "hUNz_Sal_Redctn_Reasn", type: "STRING", tableCode: "UN" },
        "hunz_spare"           : { canonical: "hUNz_Spare"           , type: "STRING", tableCode: "UN" },
    }
};

export default UN;
