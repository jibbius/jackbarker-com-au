/**
 * SC.js — table structure for the SC (System Security - Access) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SC").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SC
 */

/** @type {Object} */
const SC = {
    code: "SC",
    name: "System_Security_-_Access",
    recordLength: null,
    helpRegistry: "hSC.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SCi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hscd_mod_date"       : { canonical: "hSCd_Mod_Date"       , type: "DATE", tableCode: "SC" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hsct_mod_time"       : { canonical: "hSCt_Mod_Time"       , type: "TIME", tableCode: "SC" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hscz_deleted"        : { canonical: "hSCz_Deleted"        , type: "STRING", tableCode: "SC" },
        "hscz_mod_user"       : { canonical: "hSCz_Mod_User"       , type: "STRING", tableCode: "SC" },
        "hscz_security_key"   : { canonical: "hSCz_Security_Key"   , type: "STRING", tableCode: "SC" },

        // ── (y-prefix) ──────────────────────────────────────────────────
        "hscy_screen_access01": { canonical: "hSCy_Screen_Access01", type: "STRING", tableCode: "SC" },
        "hscy_screen_access02": { canonical: "hSCy_Screen_Access02", type: "STRING", tableCode: "SC" },
        "hscy_screen_access03": { canonical: "hSCy_Screen_Access03", type: "STRING", tableCode: "SC" },
        "hscy_screen_access04": { canonical: "hSCy_Screen_Access04", type: "STRING", tableCode: "SC" },
        "hscy_screen_access05": { canonical: "hSCy_Screen_Access05", type: "STRING", tableCode: "SC" },
        "hscy_screen_access06": { canonical: "hSCy_Screen_Access06", type: "STRING", tableCode: "SC" },
        "hscy_screen_access07": { canonical: "hSCy_Screen_Access07", type: "STRING", tableCode: "SC" },
        "hscy_screen_access08": { canonical: "hSCy_Screen_Access08", type: "STRING", tableCode: "SC" },
        "hscy_screen_access09": { canonical: "hSCy_Screen_Access09", type: "STRING", tableCode: "SC" },
        "hscy_screen_access10": { canonical: "hSCy_Screen_Access10", type: "STRING", tableCode: "SC" },
        "hscy_screen_access11": { canonical: "hSCy_Screen_Access11", type: "STRING", tableCode: "SC" },
        "hscy_screen_access12": { canonical: "hSCy_Screen_Access12", type: "STRING", tableCode: "SC" },
        "hscy_screen_access13": { canonical: "hSCy_Screen_Access13", type: "STRING", tableCode: "SC" },
        "hscy_screen_access14": { canonical: "hSCy_Screen_Access14", type: "STRING", tableCode: "SC" },
        "hscy_screen_access15": { canonical: "hSCy_Screen_Access15", type: "STRING", tableCode: "SC" },
        "hscy_screen_access16": { canonical: "hSCy_Screen_Access16", type: "STRING", tableCode: "SC" },
        "hscy_screen_access17": { canonical: "hSCy_Screen_Access17", type: "STRING", tableCode: "SC" },
        "hscy_screen_access18": { canonical: "hSCy_Screen_Access18", type: "STRING", tableCode: "SC" },
        "hscy_screen_access19": { canonical: "hSCy_Screen_Access19", type: "STRING", tableCode: "SC" },
        "hscy_screen_access20": { canonical: "hSCy_Screen_Access20", type: "STRING", tableCode: "SC" },
    }
};

export default SC;
