/**
 * AB.js — table structure for the AB (API CLOB) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AB").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AB
 */

/** @type {Object} */
const AB = {
    code: "AB",
    name: "API_CLOB",
    recordLength: null,
    helpRegistry: "hAB.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ABi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "habl_clob_id": { canonical: "hABl_CLOB_ID", type: "INTEGER", tableCode: "AB" },
        "habl_job_ref": { canonical: "hABl_Job_Ref", type: "INTEGER", tableCode: "AB" },
    }
};

export default AB;
