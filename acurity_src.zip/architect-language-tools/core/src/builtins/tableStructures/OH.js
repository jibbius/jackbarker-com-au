/**
 * OH.js — table structure for the OH (Member Past Benefit History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "OH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force OH
 */

/** @type {Object} */
const OH = {
    code: "OH",
    name: "Member_Past_Benefit_History",
    recordLength: null,
    helpRegistry: "hOH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "OHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hohc_spare"           : { canonical: "hOHc_Spare"           , type: "STRING", tableCode: "OH" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hohd_mod_date"        : { canonical: "hOHd_Mod_Date"        , type: "DATE", tableCode: "OH" },
        "hohd_spare"           : { canonical: "hOHd_Spare"           , type: "DATE", tableCode: "OH" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hohf_benefit_paid"    : { canonical: "hOHf_Benefit_Paid"    , type: "DOUBLE", tableCode: "OH" },
        "hohf_concess_ls_tax"  : { canonical: "hOHf_Concess_LS_Tax"  , type: "DOUBLE", tableCode: "OH" },
        "hohf_golden_handshake": { canonical: "hOHf_Golden_Handshake", type: "DOUBLE", tableCode: "OH" },
        "hohf_preserved_comp"  : { canonical: "hOHf_Preserved_Comp"  , type: "DOUBLE", tableCode: "OH" },
        "hohf_rbm_25_05_88"    : { canonical: "hOHf_RBM_25_05_88"    , type: "DOUBLE", tableCode: "OH" },
        "hohf_spare"           : { canonical: "hOHf_Spare"           , type: "DOUBLE", tableCode: "OH" },
        "hohf_undeduct_conts"  : { canonical: "hOHf_Undeduct_Conts"  , type: "DOUBLE", tableCode: "OH" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hohl_spare"           : { canonical: "hOHl_Spare"           , type: "INTEGER", tableCode: "OH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hoht_mod_time"        : { canonical: "hOHt_Mod_Time"        , type: "TIME", tableCode: "OH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hohz_date_ro"         : { canonical: "hOHz_Date_RO"         , type: "STRING", tableCode: "OH" },
        "hohz_deleted"         : { canonical: "hOHz_Deleted"         , type: "STRING", tableCode: "OH" },
        "hohz_fund"            : { canonical: "hOHz_Fund"            , type: "STRING", tableCode: "OH" },
        "hohz_member"          : { canonical: "hOHz_Member"          , type: "STRING", tableCode: "OH" },
        "hohz_mod_user"        : { canonical: "hOHz_Mod_User"        , type: "STRING", tableCode: "OH" },
        "hohz_other_fund_name" : { canonical: "hOHz_Other_Fund_Name" , type: "STRING", tableCode: "OH" },
        "hohz_rbm_date"        : { canonical: "hOHz_RBM_Date"        , type: "STRING", tableCode: "OH" },
        "hohz_spare"           : { canonical: "hOHz_Spare"           , type: "STRING", tableCode: "OH" },
    }
};

export default OH;
