/**
 * FG.js — table structure for the FG (Fee Group) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FG").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FG
 */

/** @type {Object} */
const FG = {
    code: "FG",
    name: "Fee_Group",
    recordLength: null,
    helpRegistry: "hFG.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FGi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfgd_effective": { canonical: "hFGd_Effective", type: "DATE", tableCode: "FG" },
        "hfgd_mod_date" : { canonical: "hFGd_Mod_Date" , type: "DATE", tableCode: "FG" },
        "hfgd_spare"    : { canonical: "hFGd_Spare"    , type: "DATE", tableCode: "FG" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfgt_mod_time" : { canonical: "hFGt_Mod_Time" , type: "TIME", tableCode: "FG" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfgz_deleted"  : { canonical: "hFGz_Deleted"  , type: "STRING", tableCode: "FG" },
        "hfgz_fee_code" : { canonical: "hFGz_Fee_Code" , type: "STRING", tableCode: "FG" },
        "hfgz_fee_group": { canonical: "hFGz_Fee_Group", type: "STRING", tableCode: "FG" },
        "hfgz_fund"     : { canonical: "hFGz_Fund"     , type: "STRING", tableCode: "FG" },
        "hfgz_member"   : { canonical: "hFGz_Member"   , type: "STRING", tableCode: "FG" },
        "hfgz_mod_user" : { canonical: "hFGz_Mod_User" , type: "STRING", tableCode: "FG" },
        "hfgz_spare"    : { canonical: "hFGz_Spare"    , type: "STRING", tableCode: "FG" },
    }
};

export default FG;
