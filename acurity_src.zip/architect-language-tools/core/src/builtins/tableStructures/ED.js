/**
 * ED.js — table structure for the ED (Member Exit History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "ED").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force ED
 */

/** @type {Object} */
const ED = {
    code: "ED",
    name: "Member_Exit_History",
    recordLength: null,
    helpRegistry: "hED.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "EDi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hedc_benefit_taken"   : { canonical: "hEDc_Benefit_Taken"   , type: "STRING", tableCode: "ED" },
        "hedc_deleted"         : { canonical: "hEDc_Deleted"         , type: "STRING", tableCode: "ED" },
        "hedc_exit_flag"       : { canonical: "hEDc_Exit_Flag"       , type: "STRING", tableCode: "ED" },
        "hedc_is_alloc_pens"   : { canonical: "hEDc_Is_Alloc_Pens"   , type: "STRING", tableCode: "ED" },
        "hedc_lapse_periods"   : { canonical: "hEDc_Lapse_Periods"   , type: "STRING", tableCode: "ED" },
        "hedc_marginal_tax_rte": { canonical: "hEDc_Marginal_Tax_Rte", type: "STRING", tableCode: "ED" },
        "hedc_posted"          : { canonical: "hEDc_Posted"          , type: "STRING", tableCode: "ED" },
        "hedc_pres_released"   : { canonical: "hEDc_Pres_Released"   , type: "STRING", tableCode: "ED" },
        "hedc_rbl_amend"       : { canonical: "hEDc_RBL_Amend"       , type: "STRING", tableCode: "ED" },
        "hedc_restore_surch"   : { canonical: "hEDc_Restore_Surch"   , type: "STRING", tableCode: "ED" },
        "hedc_rolled_over"     : { canonical: "hEDc_Rolled_Over"     , type: "STRING", tableCode: "ED" },
        "hedc_tfn_supplied"    : { canonical: "hEDc_TFN_Supplied"    , type: "STRING", tableCode: "ED" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hedd_benefit_payment" : { canonical: "hEDd_Benefit_Payment" , type: "DATE", tableCode: "ED" },
        "hedd_etp_start"       : { canonical: "hEDd_ETP_Start"       , type: "DATE", tableCode: "ED" },
        "hedd_exit"            : { canonical: "hEDd_Exit"            , type: "DATE", tableCode: "ED" },
        "hedd_glc_notified"    : { canonical: "hEDd_GLC_Notified"    , type: "DATE", tableCode: "ED" },
        "hedd_glc_settlement"  : { canonical: "hEDd_GLC_Settlement"  , type: "DATE", tableCode: "ED" },
        "hedd_mod_date"        : { canonical: "hEDd_Mod_Date"        , type: "DATE", tableCode: "ED" },
        "hedd_processing"      : { canonical: "hEDd_Processing"      , type: "DATE", tableCode: "ED" },
        "hedd_restore"         : { canonical: "hEDd_Restore"         , type: "DATE", tableCode: "ED" },
        "hedd_second_start"    : { canonical: "hEDd_Second_Start"    , type: "DATE", tableCode: "ED" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hedf_basic_ben"       : { canonical: "hEDf_Basic_Ben"       , type: "DOUBLE", tableCode: "ED" },
        "hedf_ben_due_exit"    : { canonical: "hEDf_Ben_Due_Exit"    , type: "DOUBLE", tableCode: "ED" },
        "hedf_cf_etp_comp"     : { canonical: "hEDf_CF_ETP_Comp"     , type: "DOUBLE", tableCode: "ED" },
        "hedf_cfb"             : { canonical: "hEDf_CFB"             , type: "DOUBLE", tableCode: "ED" },
        "hedf_cgt_exempt_amt"  : { canonical: "hEDf_CGT_Exempt_Amt"  , type: "DOUBLE", tableCode: "ED" },
        "hedf_cgt_exempt_tot"  : { canonical: "hEDf_CGT_Exempt_Tot"  , type: "DOUBLE", tableCode: "ED" },
        "hedf_coconts"         : { canonical: "hEDf_CoConts"         , type: "DOUBLE", tableCode: "ED" },
        "hedf_concess_comp"    : { canonical: "hEDf_Concess_Comp"    , type: "DOUBLE", tableCode: "ED" },
        "hedf_concess_total"   : { canonical: "hEDf_Concess_Total"   , type: "DOUBLE", tableCode: "ED" },
        "hedf_conts_due"       : { canonical: "hEDf_Conts_Due"       , type: "DOUBLE", tableCode: "ED" },
        "hedf_defer_basic_ben" : { canonical: "hEDf_Defer_Basic_Ben" , type: "DOUBLE", tableCode: "ED" },
        "hedf_defer_coconts"   : { canonical: "hEDf_Defer_CoConts"   , type: "DOUBLE", tableCode: "ED" },
        "hedf_defer_shortfall" : { canonical: "hEDf_Defer_Shortfall" , type: "DOUBLE", tableCode: "ED" },
        "hedf_dth_deduct"      : { canonical: "hEDf_DTH_Deduct"      , type: "DOUBLE", tableCode: "ED" },
        "hedf_efb"             : { canonical: "hEDf_EFB"             , type: "DOUBLE", tableCode: "ED" },
        "hedf_excess_ben"      : { canonical: "hEDf_Excess_Ben"      , type: "DOUBLE", tableCode: "ED" },
        "hedf_first_amt"       : { canonical: "hEDf_First_Amt"       , type: "DOUBLE", tableCode: "ED" },
        "hedf_first_amt_tot"   : { canonical: "hEDf_First_Amt_Tot"   , type: "DOUBLE", tableCode: "ED" },
        "hedf_foregone_ben"    : { canonical: "hEDf_Foregone_Ben"    , type: "DOUBLE", tableCode: "ED" },
        "hedf_fund_etp_comp"   : { canonical: "hEDf_Fund_ETP_Comp"   , type: "DOUBLE", tableCode: "ED" },
        "hedf_glc_amount"      : { canonical: "hEDf_GLC_Amount"      , type: "DOUBLE", tableCode: "ED" },
        "hedf_gross_benefit"   : { canonical: "hEDf_Gross_Benefit"   , type: "DOUBLE", tableCode: "ED" },
        "hedf_guaranteed_amt"  : { canonical: "hEDf_Guaranteed_Amt"  , type: "DOUBLE", tableCode: "ED" },
        "hedf_invalidity_comp" : { canonical: "hEDf_Invalidity_Comp" , type: "DOUBLE", tableCode: "ED" },
        "hedf_late_interest"   : { canonical: "hEDf_Late_Interest"   , type: "DOUBLE", tableCode: "ED" },
        "hedf_net_assets"      : { canonical: "hEDf_Net_Assets"      , type: "DOUBLE", tableCode: "ED" },
        "hedf_net_benefit"     : { canonical: "hEDf_Net_Benefit"     , type: "DOUBLE", tableCode: "ED" },
        "hedf_post_83_days"    : { canonical: "hEDf_Post_83_Days"    , type: "DOUBLE", tableCode: "ED" },
        "hedf_post_83_taxed"   : { canonical: "hEDf_Post_83_Taxed"   , type: "DOUBLE", tableCode: "ED" },
        "hedf_post_83_untaxed" : { canonical: "hEDf_Post_83_Untaxed" , type: "DOUBLE", tableCode: "ED" },
        "hedf_pre_83_comp"     : { canonical: "hEDf_Pre_83_Comp"     , type: "DOUBLE", tableCode: "ED" },
        "hedf_pre_83_comp_tot" : { canonical: "hEDf_Pre_83_Comp_Tot" , type: "DOUBLE", tableCode: "ED" },
        "hedf_pre_83_days"     : { canonical: "hEDf_Pre_83_Days"     , type: "DOUBLE", tableCode: "ED" },
        "hedf_pre_post_taxed"  : { canonical: "hEDf_Pre_Post_Taxed"  , type: "DOUBLE", tableCode: "ED" },
        "hedf_preserved_comp"  : { canonical: "hEDf_Preserved_Comp"  , type: "DOUBLE", tableCode: "ED" },
        "hedf_rebate_prop_pens": { canonical: "hEDf_Rebate_Prop_Pens", type: "DOUBLE", tableCode: "ED" },
        "hedf_res_unt_late_int": { canonical: "hEDf_Res_Unt_Late_Int", type: "DOUBLE", tableCode: "ED" },
        "hedf_reserve_unit_bal": { canonical: "hEDf_Reserve_Unit_Bal", type: "DOUBLE", tableCode: "ED" },
        "hedf_restr_unpres"    : { canonical: "hEDf_Restr_Unpres"    , type: "DOUBLE", tableCode: "ED" },
        "hedf_retained_ben"    : { canonical: "hEDf_Retained_Ben"    , type: "DOUBLE", tableCode: "ED" },
        "hedf_ro_amt"          : { canonical: "hEDf_RO_Amt"          , type: "DOUBLE", tableCode: "ED" },
        "hedf_ro_post_tax"     : { canonical: "hEDf_RO_Post_Tax"     , type: "DOUBLE", tableCode: "ED" },
        "hedf_ro_preserved"    : { canonical: "hEDf_RO_Preserved"    , type: "DOUBLE", tableCode: "ED" },
        "hedf_roll_bal_15_2_90": { canonical: "hEDf_Roll_Bal_15_2_90", type: "DOUBLE", tableCode: "ED" },
        "hedf_sancs_late_int"  : { canonical: "hEDf_SANCS_Late_Int"  , type: "DOUBLE", tableCode: "ED" },
        "hedf_second_amt"      : { canonical: "hEDf_Second_Amt"      , type: "DOUBLE", tableCode: "ED" },
        "hedf_second_amt_tot"  : { canonical: "hEDf_Second_Amt_Tot"  , type: "DOUBLE", tableCode: "ED" },
        "hedf_shortfall"       : { canonical: "hEDf_Shortfall"       , type: "DOUBLE", tableCode: "ED" },
        "hedf_sss_defer_ls"    : { canonical: "hEDf_SSS_Defer_LS"    , type: "DOUBLE", tableCode: "ED" },
        "hedf_sss_ls_ben"      : { canonical: "hEDf_SSS_LS_Ben"      , type: "DOUBLE", tableCode: "ED" },
        "hedf_surch_cap"       : { canonical: "hEDf_Surch_Cap"       , type: "DOUBLE", tableCode: "ED" },
        "hedf_surch_efb"       : { canonical: "hEDf_Surch_EFB"       , type: "DOUBLE", tableCode: "ED" },
        "hedf_tax_payable"     : { canonical: "hEDf_Tax_Payable"     , type: "DOUBLE", tableCode: "ED" },
        "hedf_tot_rbal_15_2_90": { canonical: "hEDf_Tot_RBal_15_2_90", type: "DOUBLE", tableCode: "ED" },
        "hedf_total_conts"     : { canonical: "hEDf_Total_Conts"     , type: "DOUBLE", tableCode: "ED" },
        "hedf_undeduct_cont"   : { canonical: "hEDf_Undeduct_Cont"   , type: "DOUBLE", tableCode: "ED" },
        "hedf_undeduct_res"    : { canonical: "hEDf_Undeduct_Res"    , type: "DOUBLE", tableCode: "ED" },
        "hedf_undeduct_total"  : { canonical: "hEDf_Undeduct_Total"  , type: "DOUBLE", tableCode: "ED" },
        "hedf_undeducted_pres" : { canonical: "hEDf_Undeducted_Pres" , type: "DOUBLE", tableCode: "ED" },
        "hedf_unrestr_unpres"  : { canonical: "hEDf_Unrestr_Unpres"  , type: "DOUBLE", tableCode: "ED" },
        "hedf_untaxed_27ab4"   : { canonical: "hEDf_Untaxed_27AB4"   , type: "DOUBLE", tableCode: "ED" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hedl_batch_reference" : { canonical: "hEDl_Batch_Reference" , type: "INTEGER", tableCode: "ED" },
        "hedl_block_no"        : { canonical: "hEDl_Block_No"        , type: "INTEGER", tableCode: "ED" },
        "hedl_trans_ref_35"    : { canonical: "hEDl_Trans_Ref_35"    , type: "INTEGER", tableCode: "ED" },
        "hedl_trans_ref_disput": { canonical: "hEDl_Trans_Ref_Disput", type: "INTEGER", tableCode: "ED" },
        "hedl_trans_ref_erf"   : { canonical: "hEDl_Trans_Ref_ERF"   , type: "INTEGER", tableCode: "ED" },
        "hedl_trans_ref_rbl"   : { canonical: "hEDl_Trans_Ref_RBL"   , type: "INTEGER", tableCode: "ED" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hedt_mod_time"        : { canonical: "hEDt_Mod_Time"        , type: "TIME", tableCode: "ED" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hedz_ben_paid"        : { canonical: "hEDz_Ben_Paid"        , type: "STRING", tableCode: "ED" },
        "hedz_division"        : { canonical: "hEDz_Division"        , type: "STRING", tableCode: "ED" },
        "hedz_estate"          : { canonical: "hEDz_Estate"          , type: "STRING", tableCode: "ED" },
        "hedz_exit_reason"     : { canonical: "hEDz_Exit_Reason"     , type: "STRING", tableCode: "ED" },
        "hedz_fund"            : { canonical: "hEDz_Fund"            , type: "STRING", tableCode: "ED" },
        "hedz_gl_claim"        : { canonical: "hEDz_GL_Claim"        , type: "STRING", tableCode: "ED" },
        "hedz_glc_insurer"     : { canonical: "hEDz_GLC_Insurer"     , type: "STRING", tableCode: "ED" },
        "hedz_group_cert_no"   : { canonical: "hEDz_Group_Cert_No"   , type: "STRING", tableCode: "ED" },
        "hedz_member"          : { canonical: "hEDz_Member"          , type: "STRING", tableCode: "ED" },
        "hedz_mod_user"        : { canonical: "hEDz_Mod_User"        , type: "STRING", tableCode: "ED" },
        "hedz_spare_1"         : { canonical: "hEDz_Spare_1"         , type: "STRING", tableCode: "ED" },
    }
};

export default ED;
