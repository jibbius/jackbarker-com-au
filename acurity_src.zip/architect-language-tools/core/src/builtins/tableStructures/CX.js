/**
 * CX.js — table structure for the CX (Commissions) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CX").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CX
 */

/** @type {Object} */
const CX = {
    code: "CX",
    name: "Commissions",
    recordLength: null,
    helpRegistry: "hCX.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CXi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hcxc_spare"           : { canonical: "hCXc_Spare"           , type: "STRING", tableCode: "CX" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hcxd_effective"       : { canonical: "hCXd_Effective"       , type: "DATE", tableCode: "CX" },
        "hcxd_mod_date"        : { canonical: "hCXd_Mod_Date"        , type: "DATE", tableCode: "CX" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hcxf_cont_amount"     : { canonical: "hCXf_Cont_Amount"     , type: "DOUBLE", tableCode: "CX" },
        "hcxf_cont_overall"    : { canonical: "hCXf_Cont_Overall"    , type: "DOUBLE", tableCode: "CX" },
        "hcxf_cont_ytd"        : { canonical: "hCXf_Cont_YTD"        , type: "DOUBLE", tableCode: "CX" },
        "hcxf_exp_init_ytd_inc": { canonical: "hCXf_Exp_Init_YTD_Inc", type: "DOUBLE", tableCode: "CX" },
        "hcxf_exp_renewal_ytd" : { canonical: "hCXf_Exp_Renewal_YTD" , type: "DOUBLE", tableCode: "CX" },
        "hcxf_expec_ytd_increm": { canonical: "hCXf_Expec_YTD_Increm", type: "DOUBLE", tableCode: "CX" },
        "hcxf_expectd_ann_cont": { canonical: "hCXf_Expectd_Ann_Cont", type: "DOUBLE", tableCode: "CX" },
        "hcxf_first_year_ytd"  : { canonical: "hCXf_First_Year_YTD"  , type: "DOUBLE", tableCode: "CX" },
        "hcxf_highst_prev_cont": { canonical: "hCXf_Highst_Prev_Cont", type: "DOUBLE", tableCode: "CX" },
        "hcxf_init_or_inc_comm": { canonical: "hCXf_Init_Or_Inc_Comm", type: "DOUBLE", tableCode: "CX" },
        "hcxf_init_or_inc_fee" : { canonical: "hCXf_Init_Or_Inc_Fee" , type: "DOUBLE", tableCode: "CX" },
        "hcxf_renewal_amt"     : { canonical: "hCXf_Renewal_Amt"     , type: "DOUBLE", tableCode: "CX" },
        "hcxf_renewal_comm"    : { canonical: "hCXf_Renewal_Comm"    , type: "DOUBLE", tableCode: "CX" },
        "hcxf_renewal_fee"     : { canonical: "hCXf_Renewal_Fee"     , type: "DOUBLE", tableCode: "CX" },
        "hcxf_renewal_ytd"     : { canonical: "hCXf_Renewal_YTD"     , type: "DOUBLE", tableCode: "CX" },
        "hcxf_spare"           : { canonical: "hCXf_Spare"           , type: "DOUBLE", tableCode: "CX" },
        "hcxf_tot_initorincfee": { canonical: "hCXf_Tot_InitOrIncFee", type: "DOUBLE", tableCode: "CX" },
        "hcxf_tot_renewal_comm": { canonical: "hCXf_Tot_Renewal_Comm", type: "DOUBLE", tableCode: "CX" },
        "hcxf_tot_renewal_fee" : { canonical: "hCXf_Tot_Renewal_Fee" , type: "DOUBLE", tableCode: "CX" },
        "hcxf_totinitorinccomm": { canonical: "hCXf_TotInitOrIncComm", type: "DOUBLE", tableCode: "CX" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hcxl_spare"           : { canonical: "hCXl_Spare"           , type: "INTEGER", tableCode: "CX" },
        "hcxl_trans_ref"       : { canonical: "hCXl_Trans_Ref"       , type: "INTEGER", tableCode: "CX" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hcxt_mod_time"        : { canonical: "hCXt_Mod_Time"        , type: "TIME", tableCode: "CX" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcxz_cont_type"       : { canonical: "hCXz_Cont_Type"       , type: "STRING", tableCode: "CX" },
        "hcxz_division"        : { canonical: "hCXz_Division"        , type: "STRING", tableCode: "CX" },
        "hcxz_fund"            : { canonical: "hCXz_Fund"            , type: "STRING", tableCode: "CX" },
        "hcxz_member"          : { canonical: "hCXz_Member"          , type: "STRING", tableCode: "CX" },
        "hcxz_mod_user"        : { canonical: "hCXz_Mod_User"        , type: "STRING", tableCode: "CX" },
        "hcxz_spare"           : { canonical: "hCXz_Spare"           , type: "STRING", tableCode: "CX" },
    }
};

export default CX;
