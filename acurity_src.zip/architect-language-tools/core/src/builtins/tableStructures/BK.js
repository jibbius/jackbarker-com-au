/**
 * BK.js — table structure for the BK (Member Balance History Backup) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BK").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BK
 */

/** @type {Object} */
const BK = {
    code: "BK",
    name: "Member_Balance_History_Backup",
    recordLength: null,
    helpRegistry: "hBK.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BKi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hbkc_deleted"         : { canonical: "hBKc_Deleted"         , type: "STRING", tableCode: "BK" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hbkd_effective"       : { canonical: "hBKd_Effective"       , type: "DATE", tableCode: "BK" },
        "hbkd_spare"           : { canonical: "hBKd_Spare"           , type: "DATE", tableCode: "BK" },
        "hbkd_start"           : { canonical: "hBKd_Start"           , type: "DATE", tableCode: "BK" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hbkf_cash"            : { canonical: "hBKf_Cash"            , type: "DOUBLE", tableCode: "BK" },
        "hbkf_conts"           : { canonical: "hBKf_Conts"           , type: "DOUBLE", tableCode: "BK" },
        "hbkf_conts_due"       : { canonical: "hBKf_Conts_Due"       , type: "DOUBLE", tableCode: "BK" },
        "hbkf_conts_taken"     : { canonical: "hBKf_Conts_Taken"     , type: "DOUBLE", tableCode: "BK" },
        "hbkf_fees"            : { canonical: "hBKf_Fees"            , type: "DOUBLE", tableCode: "BK" },
        "hbkf_group_life_prem" : { canonical: "hBKf_Group_Life_Prem" , type: "DOUBLE", tableCode: "BK" },
        "hbkf_interest"        : { canonical: "hBKf_Interest"        , type: "DOUBLE", tableCode: "BK" },
        "hbkf_mbr_protect_rebt": { canonical: "hBKf_Mbr_Protect_Rebt", type: "DOUBLE", tableCode: "BK" },
        "hbkf_misc_credit"     : { canonical: "hBKf_Misc_Credit"     , type: "DOUBLE", tableCode: "BK" },
        "hbkf_misc_debit"      : { canonical: "hBKf_Misc_Debit"      , type: "DOUBLE", tableCode: "BK" },
        "hbkf_opening"         : { canonical: "hBKf_Opening"         , type: "DOUBLE", tableCode: "BK" },
        "hbkf_payments"        : { canonical: "hBKf_Payments"        , type: "DOUBLE", tableCode: "BK" },
        "hbkf_surcharge"       : { canonical: "hBKf_Surcharge"       , type: "DOUBLE", tableCode: "BK" },
        "hbkf_surcharge_adv"   : { canonical: "hBKf_Surcharge_Adv"   , type: "DOUBLE", tableCode: "BK" },
        "hbkf_tax"             : { canonical: "hBKf_Tax"             , type: "DOUBLE", tableCode: "BK" },
        "hbkf_total_conts"     : { canonical: "hBKf_Total_Conts"     , type: "DOUBLE", tableCode: "BK" },
        "hbkf_unpr_vested_fact": { canonical: "hBKf_Unpr_Vested_Fact", type: "DOUBLE", tableCode: "BK" },
        "hbkf_unpreserved"     : { canonical: "hBKf_Unpreserved"     , type: "DOUBLE", tableCode: "BK" },
        "hbkf_vested"          : { canonical: "hBKf_Vested"          , type: "DOUBLE", tableCode: "BK" },
        "hbkf_vested_factor"   : { canonical: "hBKf_Vested_Factor"   , type: "DOUBLE", tableCode: "BK" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hbkz_cont_acct"       : { canonical: "hBKz_Cont_Acct"       , type: "STRING", tableCode: "BK" },
        "hbkz_fund"            : { canonical: "hBKz_Fund"            , type: "STRING", tableCode: "BK" },
        "hbkz_member"          : { canonical: "hBKz_Member"          , type: "STRING", tableCode: "BK" },
        "hbkz_preservation"    : { canonical: "hBKz_Preservation"    , type: "STRING", tableCode: "BK" },
        "hbkz_quote"           : { canonical: "hBKz_Quote"           , type: "STRING", tableCode: "BK" },
        "hbkz_spare"           : { canonical: "hBKz_Spare"           , type: "STRING", tableCode: "BK" },
    }
};

export default BK;
