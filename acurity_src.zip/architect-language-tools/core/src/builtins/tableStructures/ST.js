/**
 * ST.js — table structure for the ST (Share Scheme - Temporary Records) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "ST").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force ST
 */

/** @type {Object} */
const ST = {
    code: "ST",
    name: "Share_Scheme_-_Temporary_Records",
    recordLength: null,
    helpRegistry: "hST.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "STi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hstf_shared_alloc"    : { canonical: "hSTf_Shared_Alloc"    , type: "DOUBLE", tableCode: "ST" },
        "hstf_shared_requested": { canonical: "hSTf_Shared_Requested", type: "DOUBLE", tableCode: "ST" },
        "hstf_sort"            : { canonical: "hSTf_Sort"            , type: "DOUBLE", tableCode: "ST" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hsts_round_up"        : { canonical: "hSTs_Round_Up"        , type: "INTEGER", tableCode: "ST" },
        "hsts_spare"           : { canonical: "hSTs_Spare"           , type: "INTEGER", tableCode: "ST" },
        "hsts_spare_1"         : { canonical: "hSTs_Spare_1"         , type: "INTEGER", tableCode: "ST" },
        "hsts_spare_2"         : { canonical: "hSTs_Spare_2"         , type: "INTEGER", tableCode: "ST" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hstz_fund"            : { canonical: "hSTz_Fund"            , type: "STRING", tableCode: "ST" },
        "hstz_mbr_surname"     : { canonical: "hSTz_Mbr_Surname"     , type: "STRING", tableCode: "ST" },
        "hstz_member"          : { canonical: "hSTz_Member"          , type: "STRING", tableCode: "ST" },
        "hstz_spare"           : { canonical: "hSTz_Spare"           , type: "STRING", tableCode: "ST" },
    }
};

export default ST;
