/**
 * VH.js — table structure for the VH (Data Version History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "VH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force VH
 */

/** @type {Object} */
const VH = {
    code: "VH",
    name: "Data_Version_History",
    recordLength: null,
    helpRegistry: "hVH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "VHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hvhd_mod_date"    : { canonical: "hVHd_Mod_Date"    , type: "DATE", tableCode: "VH" },
        "hvhd_spare"       : { canonical: "hVHd_Spare"       , type: "DATE", tableCode: "VH" },
        "hvhd_version_date": { canonical: "hVHd_Version_Date", type: "DATE", tableCode: "VH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hvht_mod_time"    : { canonical: "hVHt_Mod_Time"    , type: "TIME", tableCode: "VH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hvhz_mod_user"    : { canonical: "hVHz_Mod_User"    , type: "STRING", tableCode: "VH" },
        "hvhz_schema"      : { canonical: "hVHz_Schema"      , type: "STRING", tableCode: "VH" },
        "hvhz_software"    : { canonical: "hVHz_Software"    , type: "STRING", tableCode: "VH" },
    }
};

export default VH;
