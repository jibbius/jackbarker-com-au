/**
 * AY.js — table structure for the AY (Audit Child) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AY").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AY
 */

/** @type {Object} */
const AY = {
    code: "AY",
    name: "Audit_Child",
    recordLength: null,
    helpRegistry: "hAY.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "AYi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hayl_audit_id"   : { canonical: "hAYl_Audit_ID"   , type: "INTEGER", tableCode: "AY" },
        "hayl_batch_ref"  : { canonical: "hAYl_Batch_Ref"  , type: "INTEGER", tableCode: "AY" },
        "hayl_clob_id"    : { canonical: "hAYl_CLOB_ID"    , type: "INTEGER", tableCode: "AY" },
        "hayl_spare"      : { canonical: "hAYl_Spare"      , type: "INTEGER", tableCode: "AY" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hayz_action_type": { canonical: "hAYz_Action_Type", type: "STRING", tableCode: "AY" },
        "hayz_adviser"    : { canonical: "hAYz_Adviser"    , type: "STRING", tableCode: "AY" },
        "hayz_client"     : { canonical: "hAYz_Client"     , type: "STRING", tableCode: "AY" },
        "hayz_element"    : { canonical: "hAYz_Element"    , type: "STRING", tableCode: "AY" },
        "hayz_employer"   : { canonical: "hAYz_Employer"   , type: "STRING", tableCode: "AY" },
        "hayz_fund"       : { canonical: "hAYz_Fund"       , type: "STRING", tableCode: "AY" },
        "hayz_member"     : { canonical: "hAYz_Member"     , type: "STRING", tableCode: "AY" },
        "hayz_record_type": { canonical: "hAYz_Record_Type", type: "STRING", tableCode: "AY" },
    }
};

export default AY;
