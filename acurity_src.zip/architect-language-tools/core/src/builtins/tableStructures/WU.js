/**
 * WU.js — table structure for the WU (Web User Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "WU").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force WU
 */

/** @type {Object} */
const WU = {
    code: "WU",
    name: "Web_User_Details",
    recordLength: null,
    helpRegistry: "hWU.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "WUi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hwuc_active"       : { canonical: "hWUc_Active"       , type: "STRING", tableCode: "WU" },
        "hwuc_adviser_view" : { canonical: "hWUc_Adviser_View" , type: "STRING", tableCode: "WU" },
        "hwuc_failed_logins": { canonical: "hWUc_Failed_Logins", type: "STRING", tableCode: "WU" },
        "hwuc_force_new_pwd": { canonical: "hWUc_Force_New_Pwd", type: "STRING", tableCode: "WU" },
        "hwuc_id_altered"   : { canonical: "hWUc_ID_Altered"   , type: "STRING", tableCode: "WU" },
        "hwuc_pwd_hash_type": { canonical: "hWUc_Pwd_Hash_Type", type: "STRING", tableCode: "WU" },
        "hwuc_type"         : { canonical: "hWUc_Type"         , type: "STRING", tableCode: "WU" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hwuz_broker"       : { canonical: "hWUz_Broker"       , type: "STRING", tableCode: "WU" },
        "hwuz_client"       : { canonical: "hWUz_Client"       , type: "STRING", tableCode: "WU" },
        "hwuz_email"        : { canonical: "hWUz_Email"        , type: "STRING", tableCode: "WU" },
        "hwuz_fund"         : { canonical: "hWUz_Fund"         , type: "STRING", tableCode: "WU" },
        "hwuz_given_names"  : { canonical: "hWUz_Given_Names"  , type: "STRING", tableCode: "WU" },
        "hwuz_member"       : { canonical: "hWUz_Member"       , type: "STRING", tableCode: "WU" },
        "hwuz_password"     : { canonical: "hWUz_Password"     , type: "STRING", tableCode: "WU" },
        "hwuz_password_id1" : { canonical: "hWUz_Password_ID1" , type: "STRING", tableCode: "WU" },
        "hwuz_password_id2" : { canonical: "hWUz_Password_ID2" , type: "STRING", tableCode: "WU" },
        "hwuz_payrol_code"  : { canonical: "hWUz_Payrol_Code"  , type: "STRING", tableCode: "WU" },
        "hwuz_payroll"      : { canonical: "hWUz_Payroll"      , type: "STRING", tableCode: "WU" },
        "hwuz_salt_id"      : { canonical: "hWUz_Salt_ID"      , type: "STRING", tableCode: "WU" },
        "hwuz_security_role": { canonical: "hWUz_Security_Role", type: "STRING", tableCode: "WU" },
        "hwuz_spare"        : { canonical: "hWUz_Spare"        , type: "STRING", tableCode: "WU" },
        "hwuz_surname"      : { canonical: "hWUz_Surname"      , type: "STRING", tableCode: "WU" },
        "hwuz_user"         : { canonical: "hWUz_User"         , type: "STRING", tableCode: "WU" },
        "hwuz_user_id"      : { canonical: "hWUz_User_ID"      , type: "STRING", tableCode: "WU" },
    }
};

export default WU;
