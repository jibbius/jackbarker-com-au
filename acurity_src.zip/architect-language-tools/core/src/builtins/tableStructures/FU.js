/**
 * FU.js — table structure for the FU (Fund History Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FU").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FU
 */

/** @type {Object} */
const FU = {
    code: "FU",
    name: "Fund_History_Details",
    recordLength: null,
    helpRegistry: "hFU.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FUi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hfuc_cont_tax"       : { canonical: "hFUc_Cont_Tax"       , type: "STRING", tableCode: "FU" },
        "hfuc_deleted"        : { canonical: "hFUc_Deleted"        , type: "STRING", tableCode: "FU" },
        "hfuc_discount_factor": { canonical: "hFUc_Discount_Factor", type: "STRING", tableCode: "FU" },
        "hfuc_nconc_cap"      : { canonical: "hFUc_NConc_Cap"      , type: "STRING", tableCode: "FU" },
        "hfuc_tfn_req"        : { canonical: "hFUc_TFN_Req"        , type: "STRING", tableCode: "FU" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfud_effective"      : { canonical: "hFUd_Effective"      , type: "DATE", tableCode: "FU" },
        "hfud_mod_date"       : { canonical: "hFUd_Mod_Date"       , type: "DATE", tableCode: "FU" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hfuf_cont_tax_rate"  : { canonical: "hFUf_Cont_Tax_Rate"  , type: "DOUBLE", tableCode: "FU" },
        "hfuf_disc_fact_o12"  : { canonical: "hFUf_Disc_Fact_O12"  , type: "DOUBLE", tableCode: "FU" },
        "hfuf_disc_fact_u12"  : { canonical: "hFUf_Disc_Fact_U12"  , type: "DOUBLE", tableCode: "FU" },
        "hfuf_nconc_cap_o65"  : { canonical: "hFUf_NConc_Cap_O65"  , type: "DOUBLE", tableCode: "FU" },
        "hfuf_nconc_cap_u65"  : { canonical: "hFUf_NConc_Cap_U65"  , type: "DOUBLE", tableCode: "FU" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfut_mod_time"       : { canonical: "hFUt_Mod_Time"       , type: "TIME", tableCode: "FU" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfuz_fund"           : { canonical: "hFUz_Fund"           , type: "STRING", tableCode: "FU" },
        "hfuz_mod_user"       : { canonical: "hFUz_Mod_User"       , type: "STRING", tableCode: "FU" },
        "hfuz_spare"          : { canonical: "hFUz_Spare"          , type: "STRING", tableCode: "FU" },
    }
};

export default FU;
