/**
 * EI.js — table structure for the EI (Event and Exception Information) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "EI").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force EI
 */

/** @type {Object} */
const EI = {
    code: "EI",
    name: "Event_and_Exception_Information",
    recordLength: null,
    helpRegistry: "hEI.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "EIi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "heic_deleted"        : { canonical: "hEIc_Deleted"        , type: "STRING", tableCode: "EI" },
        "heic_elec_processing": { canonical: "hEIc_Elec_Processing", type: "STRING", tableCode: "EI" },
        "heic_web_service"    : { canonical: "hEIc_Web_Service"    , type: "STRING", tableCode: "EI" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "heid_mod_date"       : { canonical: "hEId_Mod_Date"       , type: "DATE", tableCode: "EI" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "heit_mod_time"       : { canonical: "hEIt_Mod_Time"       , type: "TIME", tableCode: "EI" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "heiz_description"    : { canonical: "hEIz_Description"    , type: "STRING", tableCode: "EI" },
        "heiz_function_name"  : { canonical: "hEIz_Function_Name"  , type: "STRING", tableCode: "EI" },
        "heiz_functioncode"   : { canonical: "hEIz_FunctionCode"   , type: "STRING", tableCode: "EI" },
        "heiz_mod_user"       : { canonical: "hEIz_Mod_User"       , type: "STRING", tableCode: "EI" },
        "heiz_report_code"    : { canonical: "hEIz_Report_Code"    , type: "STRING", tableCode: "EI" },
        "heiz_report_group"   : { canonical: "hEIz_Report_Group"   , type: "STRING", tableCode: "EI" },
        "heiz_spare"          : { canonical: "hEIz_Spare"          , type: "STRING", tableCode: "EI" },
    }
};

export default EI;
