/**
 * DU.js — table structure for the DU (User Codes and Descriptions) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "DU").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force DU
 */

/** @type {Object} */
const DU = {
    code: "DU",
    name: "User_Codes_and_Descriptions",
    recordLength: null,
    helpRegistry: "hDU.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "DUi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hduc_deleted"         : { canonical: "hDUc_Deleted"         , type: "STRING", tableCode: "DU" },
        "hduc_flag"            : { canonical: "hDUc_Flag"            , type: "STRING", tableCode: "DU" },
        "hduc_wild_card_1"     : { canonical: "hDUc_Wild_Card_1"     , type: "STRING", tableCode: "DU" },
        "hduc_wild_card_2"     : { canonical: "hDUc_Wild_Card_2"     , type: "STRING", tableCode: "DU" },
        "hduc_wild_card_3"     : { canonical: "hDUc_Wild_Card_3"     , type: "STRING", tableCode: "DU" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hduz_code"            : { canonical: "hDUz_Code"            , type: "STRING", tableCode: "DU" },
        "hduz_corres_fld_value": { canonical: "hDUz_Corres_Fld_Value", type: "STRING", tableCode: "DU" },
        "hduz_description"     : { canonical: "hDUz_Description"     , type: "STRING", tableCode: "DU" },
        "hduz_help_file"       : { canonical: "hDUz_Help_File"       , type: "STRING", tableCode: "DU" },
        "hduz_task_type"       : { canonical: "hDUz_Task_Type"       , type: "STRING", tableCode: "DU" },
    }
};

export default DU;
