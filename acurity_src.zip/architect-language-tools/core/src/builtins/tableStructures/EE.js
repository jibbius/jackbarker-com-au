/**
 * EE.js — table structure for the EE (Employer Enquiry) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "EE").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force EE
 */

/** @type {Object} */
const EE = {
    code: "EE",
    name: "Employer_Enquiry",
    recordLength: null,
    helpRegistry: "hEE.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "EEi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "heed_effective"    : { canonical: "hEEd_Effective"    , type: "DATE", tableCode: "EE" },
        "heed_paid"         : { canonical: "hEEd_Paid"         , type: "DATE", tableCode: "EE" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "heef_cheque_amount": { canonical: "hEEf_Cheque_Amount", type: "DOUBLE", tableCode: "EE" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "heel_no_of_members": { canonical: "hEEl_No_Of_Members", type: "INTEGER", tableCode: "EE" },
        "heel_trans_ref"    : { canonical: "hEEl_Trans_Ref"    , type: "INTEGER", tableCode: "EE" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "heez_fund"         : { canonical: "hEEz_Fund"         , type: "STRING", tableCode: "EE" },
        "heez_long_payroll" : { canonical: "hEEz_Long_Payroll" , type: "STRING", tableCode: "EE" },
        "heez_payroll"      : { canonical: "hEEz_Payroll"      , type: "STRING", tableCode: "EE" },
        "heez_spare"        : { canonical: "hEEz_Spare"        , type: "STRING", tableCode: "EE" },
        "heez_spare_1"      : { canonical: "hEEz_Spare_1"      , type: "STRING", tableCode: "EE" },
        "heez_status"       : { canonical: "hEEz_Status"       , type: "STRING", tableCode: "EE" },
    }
};

export default EE;
