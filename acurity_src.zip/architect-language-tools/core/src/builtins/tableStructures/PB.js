/**
 * PB.js — table structure for the PB (Daily Portfolio Balances) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PB").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PB
 */

/** @type {Object} */
const PB = {
    code: "PB",
    name: "Daily_Portfolio_Balances",
    recordLength: null,
    helpRegistry: "hPB.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PBi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hpbc_archived"       : { canonical: "hPBc_Archived"       , type: "STRING", tableCode: "PB" },
        "hpbc_leave_total"    : { canonical: "hPBc_Leave_Total"    , type: "STRING", tableCode: "PB" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hpbd_effective"      : { canonical: "hPBd_Effective"      , type: "DATE", tableCode: "PB" },
        "hpbd_interest"       : { canonical: "hPBd_Interest"       , type: "DATE", tableCode: "PB" },
        "hpbd_mod_date"       : { canonical: "hPBd_Mod_Date"       , type: "DATE", tableCode: "PB" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hpbf_amount"         : { canonical: "hPBf_Amount"         , type: "DOUBLE", tableCode: "PB" },
        "hpbf_total_balance"  : { canonical: "hPBf_Total_Balance"  , type: "DOUBLE", tableCode: "PB" },
        "hpbf_total_units"    : { canonical: "hPBf_Total_Units"    , type: "DOUBLE", tableCode: "PB" },
        "hpbf_units"          : { canonical: "hPBf_Units"          , type: "DOUBLE", tableCode: "PB" },
        "hpbf_ytd_balance"    : { canonical: "hPBf_YTD_Balance"    , type: "DOUBLE", tableCode: "PB" },
        "hpbf_ytd_units"      : { canonical: "hPBf_YTD_Units"      , type: "DOUBLE", tableCode: "PB" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hpbl_int_trans_ref"  : { canonical: "hPBl_Int_Trans_Ref"  , type: "INTEGER", tableCode: "PB" },
        "hpbl_spare"          : { canonical: "hPBl_Spare"          , type: "INTEGER", tableCode: "PB" },
        "hpbl_trans_ref"      : { canonical: "hPBl_Trans_Ref"      , type: "INTEGER", tableCode: "PB" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hpbt_mod_time"       : { canonical: "hPBt_Mod_Time"       , type: "TIME", tableCode: "PB" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hpbz_account"        : { canonical: "hPBz_Account"        , type: "STRING", tableCode: "PB" },
        "hpbz_actual_fund"    : { canonical: "hPBz_Actual_Fund"    , type: "STRING", tableCode: "PB" },
        "hpbz_actual_member"  : { canonical: "hPBz_Actual_Member"  , type: "STRING", tableCode: "PB" },
        "hpbz_cont_acct"      : { canonical: "hPBz_Cont_Acct"      , type: "STRING", tableCode: "PB" },
        "hpbz_debit_or_credit": { canonical: "hPBz_Debit_Or_Credit", type: "STRING", tableCode: "PB" },
        "hpbz_division"       : { canonical: "hPBz_Division"       , type: "STRING", tableCode: "PB" },
        "hpbz_fund"           : { canonical: "hPBz_Fund"           , type: "STRING", tableCode: "PB" },
        "hpbz_member"         : { canonical: "hPBz_Member"         , type: "STRING", tableCode: "PB" },
        "hpbz_mod_user"       : { canonical: "hPBz_Mod_User"       , type: "STRING", tableCode: "PB" },
        "hpbz_preservation"   : { canonical: "hPBz_Preservation"   , type: "STRING", tableCode: "PB" },
        "hpbz_spare"          : { canonical: "hPBz_Spare"          , type: "STRING", tableCode: "PB" },
        "hpbz_sub_account"    : { canonical: "hPBz_Sub_Account"    , type: "STRING", tableCode: "PB" },
        "hpbz_sub_sub_account": { canonical: "hPBz_Sub_Sub_Account", type: "STRING", tableCode: "PB" },
        "hpbz_tran_type"      : { canonical: "hPBz_Tran_Type"      , type: "STRING", tableCode: "PB" },
    }
};

export default PB;
