/**
 * BH.js — table structure for the BH (Broker History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BH
 */

/** @type {Object} */
const BH = {
    code: "BH",
    name: "Broker_History",
    recordLength: null,
    helpRegistry: "hBH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hbhd_effective"  : { canonical: "hBHd_Effective"  , type: "DATE", tableCode: "BH" },
        "hbhd_termination": { canonical: "hBHd_Termination", type: "DATE", tableCode: "BH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hbhz_deleted"    : { canonical: "hBHz_Deleted"    , type: "STRING", tableCode: "BH" },
        "hbhz_master"     : { canonical: "hBHz_Master"     , type: "STRING", tableCode: "BH" },
        "hbhz_number"     : { canonical: "hBHz_Number"     , type: "STRING", tableCode: "BH" },
        "hbhz_spare"      : { canonical: "hBHz_Spare"      , type: "STRING", tableCode: "BH" },
    }
};

export default BH;
