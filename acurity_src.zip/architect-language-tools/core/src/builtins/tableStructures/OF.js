/**
 * OF.js — table structure for the OF (Member Transfer History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "OF").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force OF
 */

/** @type {Object} */
const OF = {
    code: "OF",
    name: "Member_Transfer_History",
    recordLength: null,
    helpRegistry: "hOF.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "OFi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hofc_division"        : { canonical: "hOFc_Division"        , type: "STRING", tableCode: "OF" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hofd_effective"       : { canonical: "hOFd_Effective"       , type: "DATE", tableCode: "OF" },
        "hofd_els"             : { canonical: "hOFd_ELS"             , type: "DATE", tableCode: "OF" },
        "hofd_joined_prev_fund": { canonical: "hOFd_Joined_Prev_Fund", type: "DATE", tableCode: "OF" },
        "hofd_preservation_dte": { canonical: "hOFd_Preservation_Dte", type: "DATE", tableCode: "OF" },
        "hofd_rollin_date"     : { canonical: "hOFd_Rollin_Date"     , type: "DATE", tableCode: "OF" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hoff_acc_emp_amt"     : { canonical: "hOFf_Acc_Emp_Amt"     , type: "DOUBLE", tableCode: "OF" },
        "hoff_cap_gains_cgt"   : { canonical: "hOFf_Cap_Gains_CGT"   , type: "DOUBLE", tableCode: "OF" },
        "hoff_cap_gains_tax"   : { canonical: "hOFf_Cap_Gains_Tax"   , type: "DOUBLE", tableCode: "OF" },
        "hoff_db_emp_amt"      : { canonical: "hOFf_DB_Emp_Amt"      , type: "DOUBLE", tableCode: "OF" },
        "hoff_emp_tfr_ct"      : { canonical: "hOFf_Emp_Tfr_CT"      , type: "DOUBLE", tableCode: "OF" },
        "hoff_employer_tfr"    : { canonical: "hOFf_Employer_Tfr"    , type: "DOUBLE", tableCode: "OF" },
        "hoff_eu_unrstr_tfr_cs": { canonical: "hOFf_EU_Unrstr_Tfr_CS", type: "DOUBLE", tableCode: "OF" },
        "hoff_eu_unrstr_tfr_ct": { canonical: "hOFf_EU_Unrstr_Tfr_CT", type: "DOUBLE", tableCode: "OF" },
        "hoff_injury_payment"  : { canonical: "hOFf_Injury_Payment"  , type: "DOUBLE", tableCode: "OF" },
        "hoff_kiwi_preserved"  : { canonical: "hOFf_Kiwi_Preserved"  , type: "DOUBLE", tableCode: "OF" },
        "hoff_kiwi_tax_free"   : { canonical: "hOFf_Kiwi_Tax_Free"   , type: "DOUBLE", tableCode: "OF" },
        "hoff_mbrrestrundedtfr": { canonical: "hOFf_MbrRestrUndedTfr", type: "DOUBLE", tableCode: "OF" },
        "hoff_mbrunrstrundtfr" : { canonical: "hOFf_MbrUnrstrUndTfr" , type: "DOUBLE", tableCode: "OF" },
        "hoff_member_tfr"      : { canonical: "hOFf_Member_Tfr"      , type: "DOUBLE", tableCode: "OF" },
        "hoff_mu_restr_tfr"    : { canonical: "hOFf_MU_Restr_Tfr"    , type: "DOUBLE", tableCode: "OF" },
        "hoff_mu_unrstr_tfr"   : { canonical: "hOFf_MU_Unrstr_Tfr"   , type: "DOUBLE", tableCode: "OF" },
        "hoff_non_assess_amt"  : { canonical: "hOFf_Non_Assess_Amt"  , type: "DOUBLE", tableCode: "OF" },
        "hoff_oth_cont_amt"    : { canonical: "hOFf_Oth_Cont_Amt"    , type: "DOUBLE", tableCode: "OF" },
        "hoff_pers_cont_amt"   : { canonical: "hOFf_Pers_Cont_Amt"   , type: "DOUBLE", tableCode: "OF" },
        "hoff_post06_noncompl" : { canonical: "hOFf_Post06_NonCompl" , type: "DOUBLE", tableCode: "OF" },
        "hoff_restr_unpres"    : { canonical: "hOFf_Restr_Unpres"    , type: "DOUBLE", tableCode: "OF" },
        "hoff_spec_rollover"   : { canonical: "hOFf_Spec_Rollover"   , type: "DOUBLE", tableCode: "OF" },
        "hoff_spouse_cont_amt" : { canonical: "hOFf_Spouse_Cont_Amt" , type: "DOUBLE", tableCode: "OF" },
        "hoff_surplus"         : { canonical: "hOFf_Surplus"         , type: "DOUBLE", tableCode: "OF" },
        "hoff_tcont_nonassess" : { canonical: "hOFf_TCont_NonAssess" , type: "DOUBLE", tableCode: "OF" },
        "hoff_tfree_foreign"   : { canonical: "hOFf_TFree_Foreign"   , type: "DOUBLE", tableCode: "OF" },
        "hoff_tot_cont_amt"    : { canonical: "hOFf_Tot_Cont_Amt"    , type: "DOUBLE", tableCode: "OF" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hofl_trans_ref"       : { canonical: "hOFl_Trans_Ref"       , type: "INTEGER", tableCode: "OF" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hofz_fund"            : { canonical: "hOFz_Fund"            , type: "STRING", tableCode: "OF" },
        "hofz_member"          : { canonical: "hOFz_Member"          , type: "STRING", tableCode: "OF" },
        "hofz_spare"           : { canonical: "hOFz_Spare"           , type: "STRING", tableCode: "OF" },
    }
};

export default OF;
