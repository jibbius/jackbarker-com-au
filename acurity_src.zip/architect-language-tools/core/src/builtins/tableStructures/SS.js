/**
 * SS.js — table structure for the SS (Jobs System - Global Variables) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SS").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SS
 */

/** @type {Object} */
const SS = {
    code: "SS",
    name: "Jobs_System_-_Global_Variables",
    recordLength: null,
    helpRegistry: "hSS.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SSi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hssc_account"         : { canonical: "hSSc_Account"         , type: "STRING", tableCode: "SS" },
        "hssc_allow_receipt"   : { canonical: "hSSc_Allow_Receipt"   , type: "STRING", tableCode: "SS" },
        "hssc_batch_proc"      : { canonical: "hSSc_Batch_Proc"      , type: "STRING", tableCode: "SS" },
        "hssc_batch_type"      : { canonical: "hSSc_Batch_Type"      , type: "STRING", tableCode: "SS" },
        "hssc_confirm_rvw"     : { canonical: "hSSc_Confirm_Rvw"     , type: "STRING", tableCode: "SS" },
        "hssc_detail_mben_calc": { canonical: "hSSc_Detail_MBen_Calc", type: "STRING", tableCode: "SS" },
        "hssc_full_restore"    : { canonical: "hSSc_Full_Restore"    , type: "STRING", tableCode: "SS" },
        "hssc_gen_rebal_report": { canonical: "hSSc_Gen_Rebal_Report", type: "STRING", tableCode: "SS" },
        "hssc_global"          : { canonical: "hSSc_Global"          , type: "STRING", tableCode: "SS" },
        "hssc_inc_alloc_pens"  : { canonical: "hSSc_Inc_Alloc_Pens"  , type: "STRING", tableCode: "SS" },
        "hssc_interim_rvw"     : { canonical: "hSSc_Interim_Rvw"     , type: "STRING", tableCode: "SS" },
        "hssc_leave_rec"       : { canonical: "hSSc_Leave_Rec"       , type: "STRING", tableCode: "SS" },
        "hssc_maxtax_use_asal" : { canonical: "hSSc_MaxTax_Use_ASAL" , type: "STRING", tableCode: "SS" },
        "hssc_no_show"         : { canonical: "hSSc_No_Show"         , type: "STRING", tableCode: "SS" },
        "hssc_process_desc"    : { canonical: "hSSc_Process_Desc"    , type: "STRING", tableCode: "SS" },
        "hssc_rebalance_at_end": { canonical: "hSSc_Rebalance_At_End", type: "STRING", tableCode: "SS" },
        "hssc_reversal_tran"   : { canonical: "hSSc_Reversal_Tran"   , type: "STRING", tableCode: "SS" },
        "hssc_review_type"     : { canonical: "hSSc_Review_Type"     , type: "STRING", tableCode: "SS" },
        "hssc_skip_prev_rvw"   : { canonical: "hSSc_Skip_Prev_Rvw"   , type: "STRING", tableCode: "SS" },
        "hssc_spare"           : { canonical: "hSSc_Spare"           , type: "STRING", tableCode: "SS" },
        "hssc_tran80"          : { canonical: "hSSc_Tran80"          , type: "STRING", tableCode: "SS" },
        "hssc_use_archve_files": { canonical: "hSSc_Use_Archve_Files", type: "STRING", tableCode: "SS" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hssd_end"             : { canonical: "hSSd_End"             , type: "DATE", tableCode: "SS" },
        "hssd_exiting"         : { canonical: "hSSd_Exiting"         , type: "DATE", tableCode: "SS" },
        "hssd_mod_date"        : { canonical: "hSSd_Mod_Date"        , type: "DATE", tableCode: "SS" },
        "hssd_start"           : { canonical: "hSSd_Start"           , type: "DATE", tableCode: "SS" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hssf_amount01"        : { canonical: "hSSf_Amount01"        , type: "DOUBLE", tableCode: "SS" },
        "hssf_amount02"        : { canonical: "hSSf_Amount02"        , type: "DOUBLE", tableCode: "SS" },
        "hssf_amount03"        : { canonical: "hSSf_Amount03"        , type: "DOUBLE", tableCode: "SS" },
        "hssf_amount04"        : { canonical: "hSSf_Amount04"        , type: "DOUBLE", tableCode: "SS" },
        "hssf_amount05"        : { canonical: "hSSf_Amount05"        , type: "DOUBLE", tableCode: "SS" },
        "hssf_amount06"        : { canonical: "hSSf_Amount06"        , type: "DOUBLE", tableCode: "SS" },
        "hssf_amount07"        : { canonical: "hSSf_Amount07"        , type: "DOUBLE", tableCode: "SS" },
        "hssf_amount08"        : { canonical: "hSSf_Amount08"        , type: "DOUBLE", tableCode: "SS" },
        "hssf_amount09"        : { canonical: "hSSf_Amount09"        , type: "DOUBLE", tableCode: "SS" },
        "hssf_amount10"        : { canonical: "hSSf_Amount10"        , type: "DOUBLE", tableCode: "SS" },
        "hssf_tax_unalloc_fld" : { canonical: "hSSf_Tax_Unalloc_Fld" , type: "DOUBLE", tableCode: "SS" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hssl_batch_ref"       : { canonical: "hSSl_Batch_Ref"       , type: "INTEGER", tableCode: "SS" },
        "hssl_job_ref"         : { canonical: "hSSl_Job_Ref"         , type: "INTEGER", tableCode: "SS" },
        "hssl_last_audit_id"   : { canonical: "hSSl_Last_Audit_ID"   , type: "INTEGER", tableCode: "SS" },
        "hssl_saved_unit_link" : { canonical: "hSSl_Saved_Unit_Link" , type: "INTEGER", tableCode: "SS" },
        "hssl_trans_ref"       : { canonical: "hSSl_Trans_Ref"       , type: "INTEGER", tableCode: "SS" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hsss_accounting_step" : { canonical: "hSSs_Accounting_Step" , type: "INTEGER", tableCode: "SS" },
        "hsss_as400"           : { canonical: "hSSs_AS400"           , type: "INTEGER", tableCode: "SS" },
        "hsss_current_printer" : { canonical: "hSSs_Current_Printer" , type: "INTEGER", tableCode: "SS" },
        "hsss_int_free_days"   : { canonical: "hSSs_Int_Free_Days"   , type: "INTEGER", tableCode: "SS" },
        "hsss_leave_statwn"    : { canonical: "hSSs_Leave_Statwn"    , type: "INTEGER", tableCode: "SS" },
        "hsss_new_entrant"     : { canonical: "hSSs_New_Entrant"     , type: "INTEGER", tableCode: "SS" },
        "hsss_proll_in_ledger" : { canonical: "hSSs_Proll_In_Ledger" , type: "INTEGER", tableCode: "SS" },
        "hsss_receipt_batches" : { canonical: "hSSs_Receipt_Batches" , type: "INTEGER", tableCode: "SS" },
        "hsss_report_level"    : { canonical: "hSSs_Report_Level"    , type: "INTEGER", tableCode: "SS" },
        "hsss_sas_testing"     : { canonical: "hSSs_SAS_Testing"     , type: "INTEGER", tableCode: "SS" },
        "hsss_spare"           : { canonical: "hSSs_Spare"           , type: "INTEGER", tableCode: "SS" },
        "hsss_testing_batch"   : { canonical: "hSSs_Testing_Batch"   , type: "INTEGER", tableCode: "SS" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hsst_mod_time"        : { canonical: "hSSt_Mod_Time"        , type: "TIME", tableCode: "SS" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hssz_acct_location"   : { canonical: "hSSz_Acct_Location"   , type: "STRING", tableCode: "SS" },
        "hssz_acct_no"         : { canonical: "hSSz_Acct_No"         , type: "STRING", tableCode: "SS" },
        "hssz_append_report"   : { canonical: "hSSz_Append_Report"   , type: "STRING", tableCode: "SS" },
        "hssz_archive_no"      : { canonical: "hSSz_Archive_No"      , type: "STRING", tableCode: "SS" },
        "hssz_calc_date"       : { canonical: "hSSz_Calc_Date"       , type: "STRING", tableCode: "SS" },
        "hssz_caller"          : { canonical: "hSSz_Caller"          , type: "STRING", tableCode: "SS" },
        "hssz_category"        : { canonical: "hSSz_Category"        , type: "STRING", tableCode: "SS" },
        "hssz_client"          : { canonical: "hSSz_Client"          , type: "STRING", tableCode: "SS" },
        "hssz_client_sys"      : { canonical: "hSSz_Client_Sys"      , type: "STRING", tableCode: "SS" },
        "hssz_client_sys_flag" : { canonical: "hSSz_Client_Sys_Flag" , type: "STRING", tableCode: "SS" },
        "hssz_client_systems"  : { canonical: "hSSz_Client_Systems"  , type: "STRING", tableCode: "SS" },
        "hssz_config_filename" : { canonical: "hSSz_Config_Filename" , type: "STRING", tableCode: "SS" },
        "hssz_data_form"       : { canonical: "hSSz_Data_Form"       , type: "STRING", tableCode: "SS" },
        "hssz_direct"          : { canonical: "hSSz_Direct"          , type: "STRING", tableCode: "SS" },
        "hssz_division"        : { canonical: "hSSz_Division"        , type: "STRING", tableCode: "SS" },
        "hssz_electronic_fname": { canonical: "hSSz_Electronic_Fname", type: "STRING", tableCode: "SS" },
        "hssz_exiting"         : { canonical: "hSSz_Exiting"         , type: "STRING", tableCode: "SS" },
        "hssz_form_ext"        : { canonical: "hSSz_Form_Ext"        , type: "STRING", tableCode: "SS" },
        "hssz_form_name"       : { canonical: "hSSz_Form_Name"       , type: "STRING", tableCode: "SS" },
        "hssz_form_options"    : { canonical: "hSSz_Form_Options"    , type: "STRING", tableCode: "SS" },
        "hssz_fund"            : { canonical: "hSSz_Fund"            , type: "STRING", tableCode: "SS" },
        "hssz_inv_mgr_lst"     : { canonical: "hSSz_Inv_Mgr_Lst"     , type: "STRING", tableCode: "SS" },
        "hssz_inv_mgr_no"      : { canonical: "hSSz_Inv_Mgr_No"      , type: "STRING", tableCode: "SS" },
        "hssz_investment"      : { canonical: "hSSz_Investment"      , type: "STRING", tableCode: "SS" },
        "hssz_last_update"     : { canonical: "hSSz_Last_Update"     , type: "STRING", tableCode: "SS" },
        "hssz_member_no"       : { canonical: "hSSz_Member_No"       , type: "STRING", tableCode: "SS" },
        "hssz_mod_user"        : { canonical: "hSSz_Mod_User"        , type: "STRING", tableCode: "SS" },
        "hssz_order"           : { canonical: "hSSz_Order"           , type: "STRING", tableCode: "SS" },
        "hssz_payroll_no"      : { canonical: "hSSz_Payroll_No"      , type: "STRING", tableCode: "SS" },
        "hssz_recalc_mult"     : { canonical: "hSSz_Recalc_Mult"     , type: "STRING", tableCode: "SS" },
        "hssz_record_type"     : { canonical: "hSSz_Record_Type"     , type: "STRING", tableCode: "SS" },
        "hssz_redemption"      : { canonical: "hSSz_Redemption"      , type: "STRING", tableCode: "SS" },
        "hssz_region"          : { canonical: "hSSz_Region"          , type: "STRING", tableCode: "SS" },
        "hssz_sas_version"     : { canonical: "hSSz_SAS_Version"     , type: "STRING", tableCode: "SS" },
        "hssz_show_file"       : { canonical: "hSSz_Show_File"       , type: "STRING", tableCode: "SS" },
        "hssz_sort"            : { canonical: "hSSz_Sort"            , type: "STRING", tableCode: "SS" },
        "hssz_spare_1"         : { canonical: "hSSz_Spare_1"         , type: "STRING", tableCode: "SS" },
        "hssz_sub_system"      : { canonical: "hSSz_Sub_System"      , type: "STRING", tableCode: "SS" },
        "hssz_unit_link_str"   : { canonical: "hSSz_Unit_Link_Str"   , type: "STRING", tableCode: "SS" },
    }
};

export default SS;
