/**
 * PY.js — table structure for the PY (Member Payment History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PY").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PY
 */

/** @type {Object} */
const PY = {
    code: "PY",
    name: "Member_Payment_History",
    recordLength: null,
    helpRegistry: "hPY.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PYi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hpyc_direct_debit"    : { canonical: "hPYc_Direct_Debit"    , type: "STRING", tableCode: "PY" },
        "hpyc_electronic_input": { canonical: "hPYc_Electronic_Input", type: "STRING", tableCode: "PY" },
        "hpyc_in_out"          : { canonical: "hPYc_In_Out"          , type: "STRING", tableCode: "PY" },
        "hpyc_line"            : { canonical: "hPYc_Line"            , type: "STRING", tableCode: "PY" },
        "hpyc_posted"          : { canonical: "hPYc_Posted"          , type: "STRING", tableCode: "PY" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hpyd_effective"       : { canonical: "hPYd_Effective"       , type: "DATE", tableCode: "PY" },
        "hpyd_mod_date"        : { canonical: "hPYd_Mod_Date"        , type: "DATE", tableCode: "PY" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hpyf_alloc_surplus"   : { canonical: "hPYf_Alloc_Surplus"   , type: "DOUBLE", tableCode: "PY" },
        "hpyf_cap_gains_cgt"   : { canonical: "hPYf_Cap_Gains_CGT"   , type: "DOUBLE", tableCode: "PY" },
        "hpyf_cap_gains_tax"   : { canonical: "hPYf_Cap_Gains_Tax"   , type: "DOUBLE", tableCode: "PY" },
        "hpyf_cf_etp_comp"     : { canonical: "hPYf_CF_ETP_Comp"     , type: "DOUBLE", tableCode: "PY" },
        "hpyf_cgt_exempt_amt"  : { canonical: "hPYf_CGT_Exempt_Amt"  , type: "DOUBLE", tableCode: "PY" },
        "hpyf_death_amt"       : { canonical: "hPYf_Death_Amt"       , type: "DOUBLE", tableCode: "PY" },
        "hpyf_disablement_amt" : { canonical: "hPYf_Disablement_Amt" , type: "DOUBLE", tableCode: "PY" },
        "hpyf_emp_cont_amt"    : { canonical: "hPYf_Emp_Cont_Amt"    , type: "DOUBLE", tableCode: "PY" },
        "hpyf_empl_db_cont_amt": { canonical: "hPYf_Empl_DB_Cont_Amt", type: "DOUBLE", tableCode: "PY" },
        "hpyf_fund_etp_comp"   : { canonical: "hPYf_Fund_ETP_Comp"   , type: "DOUBLE", tableCode: "PY" },
        "hpyf_income_protn_amt": { canonical: "hPYf_Income_Protn_Amt", type: "DOUBLE", tableCode: "PY" },
        "hpyf_injury_payment"  : { canonical: "hPYf_Injury_Payment"  , type: "DOUBLE", tableCode: "PY" },
        "hpyf_kiwi_preserved"  : { canonical: "hPYf_Kiwi_Preserved"  , type: "DOUBLE", tableCode: "PY" },
        "hpyf_kiwi_tax_free"   : { canonical: "hPYf_Kiwi_Tax_Free"   , type: "DOUBLE", tableCode: "PY" },
        "hpyf_non_assess_amt"  : { canonical: "hPYf_Non_Assess_Amt"  , type: "DOUBLE", tableCode: "PY" },
        "hpyf_post_83_days"    : { canonical: "hPYf_Post_83_Days"    , type: "DOUBLE", tableCode: "PY" },
        "hpyf_post06_noncompl" : { canonical: "hPYf_Post06_NonCompl" , type: "DOUBLE", tableCode: "PY" },
        "hpyf_pre_83_days"     : { canonical: "hPYf_Pre_83_Days"     , type: "DOUBLE", tableCode: "PY" },
        "hpyf_restr_unpres"    : { canonical: "hPYf_Restr_Unpres"    , type: "DOUBLE", tableCode: "PY" },
        "hpyf_returned_etp"    : { canonical: "hPYf_Returned_ETP"    , type: "DOUBLE", tableCode: "PY" },
        "hpyf_returned_post_t" : { canonical: "hPYf_Returned_Post_t" , type: "DOUBLE", tableCode: "PY" },
        "hpyf_ro_concessional" : { canonical: "hPYf_RO_Concessional" , type: "DOUBLE", tableCode: "PY" },
        "hpyf_ro_etp"          : { canonical: "hPYf_RO_ETP"          , type: "DOUBLE", tableCode: "PY" },
        "hpyf_ro_invalidity"   : { canonical: "hPYf_RO_Invalidity"   , type: "DOUBLE", tableCode: "PY" },
        "hpyf_ro_post_taxed"   : { canonical: "hPYf_RO_Post_Taxed"   , type: "DOUBLE", tableCode: "PY" },
        "hpyf_ro_post_untaxed" : { canonical: "hPYf_RO_Post_Untaxed" , type: "DOUBLE", tableCode: "PY" },
        "hpyf_ro_pre_83"       : { canonical: "hPYf_RO_Pre_83"       , type: "DOUBLE", tableCode: "PY" },
        "hpyf_ro_pre_post_tax" : { canonical: "hPYf_RO_Pre_Post_Tax" , type: "DOUBLE", tableCode: "PY" },
        "hpyf_ro_preserved"    : { canonical: "hPYf_RO_Preserved"    , type: "DOUBLE", tableCode: "PY" },
        "hpyf_ro_unded"        : { canonical: "hPYf_RO_Unded"        , type: "DOUBLE", tableCode: "PY" },
        "hpyf_roll_bal_15_2_90": { canonical: "hPYf_Roll_Bal_15_2_90", type: "DOUBLE", tableCode: "PY" },
        "hpyf_spec_ro_amt"     : { canonical: "hPYf_Spec_RO_Amt"     , type: "DOUBLE", tableCode: "PY" },
        "hpyf_spouse_cont_amt" : { canonical: "hPYf_Spouse_Cont_Amt" , type: "DOUBLE", tableCode: "PY" },
        "hpyf_start_date_amt_1": { canonical: "hPYf_Start_Date_Amt_1", type: "DOUBLE", tableCode: "PY" },
        "hpyf_start_date_amt_2": { canonical: "hPYf_Start_Date_Amt_2", type: "DOUBLE", tableCode: "PY" },
        "hpyf_tax_to_be_deduct": { canonical: "hPYf_Tax_To_Be_Deduct", type: "DOUBLE", tableCode: "PY" },
        "hpyf_tcont_nonassess" : { canonical: "hPYf_TCont_NonAssess" , type: "DOUBLE", tableCode: "PY" },
        "hpyf_tfree_foreign"   : { canonical: "hPYf_TFree_Foreign"   , type: "DOUBLE", tableCode: "PY" },
        "hpyf_tot_cont_amt"    : { canonical: "hPYf_Tot_Cont_Amt"    , type: "DOUBLE", tableCode: "PY" },
        "hpyf_toth_cont_amt"   : { canonical: "hPYf_TOth_Cont_Amt"   , type: "DOUBLE", tableCode: "PY" },
        "hpyf_tpers_cont_amt"  : { canonical: "hPYf_TPers_Cont_Amt"  , type: "DOUBLE", tableCode: "PY" },
        "hpyf_unrestr_unpres"  : { canonical: "hPYf_Unrestr_Unpres"  , type: "DOUBLE", tableCode: "PY" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hpyl_chq_eft_batch_no": { canonical: "hPYl_Chq_EFT_Batch_No", type: "INTEGER", tableCode: "PY" },
        "hpyl_policy_term"     : { canonical: "hPYl_Policy_Term"     , type: "INTEGER", tableCode: "PY" },
        "hpyl_trans_ref"       : { canonical: "hPYl_Trans_Ref"       , type: "INTEGER", tableCode: "PY" },
        "hpyl_trans_ref_surch" : { canonical: "hPYl_Trans_Ref_Surch" , type: "INTEGER", tableCode: "PY" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hpyt_mod_time"        : { canonical: "hPYt_Mod_Time"        , type: "TIME", tableCode: "PY" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hpyz_abn_status"      : { canonical: "hPYz_ABN_Status"      , type: "STRING", tableCode: "PY" },
        "hpyz_address_line01"  : { canonical: "hPYz_Address_Line01"  , type: "STRING", tableCode: "PY" },
        "hpyz_address_line02"  : { canonical: "hPYz_Address_Line02"  , type: "STRING", tableCode: "PY" },
        "hpyz_address_line03"  : { canonical: "hPYz_Address_Line03"  , type: "STRING", tableCode: "PY" },
        "hpyz_aust_business_no": { canonical: "hPYz_Aust_Business_No", type: "STRING", tableCode: "PY" },
        "hpyz_bank_acct_name"  : { canonical: "hPYz_Bank_Acct_Name"  , type: "STRING", tableCode: "PY" },
        "hpyz_bank_acct_no"    : { canonical: "hPYz_Bank_Acct_No"    , type: "STRING", tableCode: "PY" },
        "hpyz_bsb"             : { canonical: "hPYz_BSB"             , type: "STRING", tableCode: "PY" },
        "hpyz_cheque_no"       : { canonical: "hPYz_Cheque_No"       , type: "STRING", tableCode: "PY" },
        "hpyz_conversationid"  : { canonical: "hPYz_ConversationID"  , type: "STRING", tableCode: "PY" },
        "hpyz_country"         : { canonical: "hPYz_Country"         , type: "STRING", tableCode: "PY" },
        "hpyz_country_code"    : { canonical: "hPYz_Country_Code"    , type: "STRING", tableCode: "PY" },
        "hpyz_deleted"         : { canonical: "hPYz_Deleted"         , type: "STRING", tableCode: "PY" },
        "hpyz_dep_reference"   : { canonical: "hPYz_Dep_Reference"   , type: "STRING", tableCode: "PY" },
        "hpyz_dest_client_id"  : { canonical: "hPYz_Dest_Client_ID"  , type: "STRING", tableCode: "PY" },
        "hpyz_dest_mbr_acc_no" : { canonical: "hPYz_Dest_Mbr_Acc_No" , type: "STRING", tableCode: "PY" },
        "hpyz_division"        : { canonical: "hPYz_Division"        , type: "STRING", tableCode: "PY" },
        "hpyz_fund"            : { canonical: "hPYz_Fund"            , type: "STRING", tableCode: "PY" },
        "hpyz_hmrc_reference"  : { canonical: "hPYz_HMRC_Reference"  , type: "STRING", tableCode: "PY" },
        "hpyz_initiate_convid" : { canonical: "hPYz_Initiate_ConvID" , type: "STRING", tableCode: "PY" },
        "hpyz_member"          : { canonical: "hPYz_Member"          , type: "STRING", tableCode: "PY" },
        "hpyz_memberid"        : { canonical: "hPYz_MemberID"        , type: "STRING", tableCode: "PY" },
        "hpyz_mod_user"        : { canonical: "hPYz_Mod_User"        , type: "STRING", tableCode: "PY" },
        "hpyz_orgname"         : { canonical: "hPYz_OrgName"         , type: "STRING", tableCode: "PY" },
        "hpyz_payee"           : { canonical: "hPYz_Payee"           , type: "STRING", tableCode: "PY" },
        "hpyz_paymentreference": { canonical: "hPYz_PaymentReference", type: "STRING", tableCode: "PY" },
        "hpyz_post_code"       : { canonical: "hPYz_Post_Code"       , type: "STRING", tableCode: "PY" },
        "hpyz_prodid"          : { canonical: "hPYz_ProdID"          , type: "STRING", tableCode: "PY" },
        "hpyz_product_name"    : { canonical: "hPYz_Product_Name"    , type: "STRING", tableCode: "PY" },
        "hpyz_reconciled"      : { canonical: "hPYz_Reconciled"      , type: "STRING", tableCode: "PY" },
        "hpyz_reference"       : { canonical: "hPYz_Reference"       , type: "STRING", tableCode: "PY" },
        "hpyz_reversion_client": { canonical: "hPYz_Reversion_Client", type: "STRING", tableCode: "PY" },
        "hpyz_spare"           : { canonical: "hPYz_Spare"           , type: "STRING", tableCode: "PY" },
        "hpyz_state"           : { canonical: "hPYz_State"           , type: "STRING", tableCode: "PY" },
        "hpyz_suburb"          : { canonical: "hPYz_Suburb"          , type: "STRING", tableCode: "PY" },
        "hpyz_transaction"     : { canonical: "hPYz_Transaction"     , type: "STRING", tableCode: "PY" },
        "hpyz_transfer_type"   : { canonical: "hPYz_Transfer_Type"   , type: "STRING", tableCode: "PY" },
    }
};

export default PY;
