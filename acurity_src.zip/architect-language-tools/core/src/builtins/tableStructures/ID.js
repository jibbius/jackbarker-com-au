/**
 * ID.js — table structure for the ID (Insurer) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "ID").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force ID
 */

/** @type {Object} */
const ID = {
    code: "ID",
    name: "Insurer",
    recordLength: null,
    helpRegistry: "hID.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "IDi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hidc_prorata_premiums": { canonical: "hIDc_ProRata_Premiums", type: "STRING", tableCode: "ID" },
        "hidc_stamp_duty"      : { canonical: "hIDc_Stamp_Duty"      , type: "STRING", tableCode: "ID" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hidd_anniversary"     : { canonical: "hIDd_Anniversary"     , type: "DATE", tableCode: "ID" },
        "hidd_mod_date"        : { canonical: "hIDd_Mod_Date"        , type: "DATE", tableCode: "ID" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hidf_dth_auto_cover"  : { canonical: "hIDf_Dth_Auto_Cover"  , type: "DOUBLE", tableCode: "ID" },
        "hidf_dth_auto_units"  : { canonical: "hIDf_Dth_Auto_Units"  , type: "DOUBLE", tableCode: "ID" },
        "hidf_dth_max_cover"   : { canonical: "hIDf_Dth_Max_Cover"   , type: "DOUBLE", tableCode: "ID" },
        "hidf_dth_min_cover"   : { canonical: "hIDf_Dth_Min_Cover"   , type: "DOUBLE", tableCode: "ID" },
        "hidf_fin_uwrite_limit": { canonical: "hIDf_Fin_Uwrite_Limit", type: "DOUBLE", tableCode: "ID" },
        "hidf_ip_auto_cover"   : { canonical: "hIDf_IP_Auto_Cover"   , type: "DOUBLE", tableCode: "ID" },
        "hidf_ip_auto_units"   : { canonical: "hIDf_IP_Auto_Units"   , type: "DOUBLE", tableCode: "ID" },
        "hidf_ip_max_cover"    : { canonical: "hIDf_IP_Max_Cover"    , type: "DOUBLE", tableCode: "ID" },
        "hidf_ip_min_cover"    : { canonical: "hIDf_IP_Min_Cover"    , type: "DOUBLE", tableCode: "ID" },
        "hidf_tpd_auto_cover"  : { canonical: "hIDf_TPD_Auto_Cover"  , type: "DOUBLE", tableCode: "ID" },
        "hidf_tpd_auto_units"  : { canonical: "hIDf_TPD_Auto_Units"  , type: "DOUBLE", tableCode: "ID" },
        "hidf_tpd_max_cover"   : { canonical: "hIDf_TPD_Max_Cover"   , type: "DOUBLE", tableCode: "ID" },
        "hidf_tpd_min_cover"   : { canonical: "hIDf_TPD_Min_Cover"   , type: "DOUBLE", tableCode: "ID" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hidl_spare01"         : { canonical: "hIDl_Spare01"         , type: "INTEGER", tableCode: "ID" },
        "hidl_spare02"         : { canonical: "hIDl_Spare02"         , type: "INTEGER", tableCode: "ID" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hidt_mod_time"        : { canonical: "hIDt_Mod_Time"        , type: "TIME", tableCode: "ID" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hidz_aust_business_no": { canonical: "hIDz_Aust_Business_No", type: "STRING", tableCode: "ID" },
        "hidz_business_name"   : { canonical: "hIDz_Business_Name"   , type: "STRING", tableCode: "ID" },
        "hidz_c_add_line01"    : { canonical: "hIDz_C_Add_Line01"    , type: "STRING", tableCode: "ID" },
        "hidz_c_add_line02"    : { canonical: "hIDz_C_Add_Line02"    , type: "STRING", tableCode: "ID" },
        "hidz_c_add_line03"    : { canonical: "hIDz_C_Add_Line03"    , type: "STRING", tableCode: "ID" },
        "hidz_c_add_line04"    : { canonical: "hIDz_C_Add_Line04"    , type: "STRING", tableCode: "ID" },
        "hidz_c_email"         : { canonical: "hIDz_C_Email"         , type: "STRING", tableCode: "ID" },
        "hidz_c_fax"           : { canonical: "hIDz_C_Fax"           , type: "STRING", tableCode: "ID" },
        "hidz_c_given_name"    : { canonical: "hIDz_C_Given_Name"    , type: "STRING", tableCode: "ID" },
        "hidz_c_home_phone"    : { canonical: "hIDz_C_Home_Phone"    , type: "STRING", tableCode: "ID" },
        "hidz_c_post_code"     : { canonical: "hIDz_C_Post_Code"     , type: "STRING", tableCode: "ID" },
        "hidz_c_surname"       : { canonical: "hIDz_C_Surname"       , type: "STRING", tableCode: "ID" },
        "hidz_c_title"         : { canonical: "hIDz_C_Title"         , type: "STRING", tableCode: "ID" },
        "hidz_c_work_phone"    : { canonical: "hIDz_C_Work_Phone"    , type: "STRING", tableCode: "ID" },
        "hidz_c2_business_name": { canonical: "hIDz_C2_Business_Name", type: "STRING", tableCode: "ID" },
        "hidz_c2_email"        : { canonical: "hIDz_C2_Email"        , type: "STRING", tableCode: "ID" },
        "hidz_c2_fax"          : { canonical: "hIDz_C2_Fax"          , type: "STRING", tableCode: "ID" },
        "hidz_c2_given_name"   : { canonical: "hIDz_C2_Given_Name"   , type: "STRING", tableCode: "ID" },
        "hidz_c2_home_phone"   : { canonical: "hIDz_C2_Home_Phone"   , type: "STRING", tableCode: "ID" },
        "hidz_c2_surname"      : { canonical: "hIDz_C2_Surname"      , type: "STRING", tableCode: "ID" },
        "hidz_c2_title"        : { canonical: "hIDz_C2_Title"        , type: "STRING", tableCode: "ID" },
        "hidz_c2_work_phone"   : { canonical: "hIDz_C2_Work_Phone"   , type: "STRING", tableCode: "ID" },
        "hidz_deleted"         : { canonical: "hIDz_Deleted"         , type: "STRING", tableCode: "ID" },
        "hidz_fee_record_type" : { canonical: "hIDz_Fee_Record_Type" , type: "STRING", tableCode: "ID" },
        "hidz_fin_uwrite_limit": { canonical: "hIDz_Fin_Uwrite_Limit", type: "STRING", tableCode: "ID" },
        "hidz_fin_uwrite_mult" : { canonical: "hIDz_Fin_Uwrite_Mult" , type: "STRING", tableCode: "ID" },
        "hidz_ins_bank_acct_no": { canonical: "hIDz_Ins_Bank_Acct_No", type: "STRING", tableCode: "ID" },
        "hidz_insurer"         : { canonical: "hIDz_Insurer"         , type: "STRING", tableCode: "ID" },
        "hidz_insurer_bsb"     : { canonical: "hIDz_Insurer_BSB"     , type: "STRING", tableCode: "ID" },
        "hidz_mail_add_line01" : { canonical: "hIDz_Mail_Add_Line01" , type: "STRING", tableCode: "ID" },
        "hidz_mail_add_line02" : { canonical: "hIDz_Mail_Add_Line02" , type: "STRING", tableCode: "ID" },
        "hidz_mail_add_line03" : { canonical: "hIDz_Mail_Add_Line03" , type: "STRING", tableCode: "ID" },
        "hidz_mail_add_line04" : { canonical: "hIDz_Mail_Add_Line04" , type: "STRING", tableCode: "ID" },
        "hidz_mail_post_code"  : { canonical: "hIDz_Mail_Post_Code"  , type: "STRING", tableCode: "ID" },
        "hidz_mod_user"        : { canonical: "hIDz_Mod_User"        , type: "STRING", tableCode: "ID" },
        "hidz_old_home_phone"  : { canonical: "hIDz_Old_Home_Phone"  , type: "STRING", tableCode: "ID" },
        "hidz_old_work_phone"  : { canonical: "hIDz_Old_Work_Phone"  , type: "STRING", tableCode: "ID" },
        "hidz_spare"           : { canonical: "hIDz_Spare"           , type: "STRING", tableCode: "ID" },
        "hidz_supp_record_type": { canonical: "hIDz_Supp_Record_Type", type: "STRING", tableCode: "ID" },
        "hidz_tab_prefix_fnsmk": { canonical: "hIDz_Tab_Prefix_FNSmk", type: "STRING", tableCode: "ID" },
        "hidz_tab_prefix_fsmk" : { canonical: "hIDz_Tab_Prefix_FSmk" , type: "STRING", tableCode: "ID" },
        "hidz_tab_prefix_mnsmk": { canonical: "hIDz_Tab_Prefix_MNSmk", type: "STRING", tableCode: "ID" },
        "hidz_tab_prefix_msmk" : { canonical: "hIDz_Tab_Prefix_MSmk" , type: "STRING", tableCode: "ID" },
        "hidz_table_prefix"    : { canonical: "hIDz_Table_Prefix"    , type: "STRING", tableCode: "ID" },
    }
};

export default ID;
