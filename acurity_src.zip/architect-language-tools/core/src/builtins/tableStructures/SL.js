/**
 * SL.js — table structure for the SL (SAML Artifacts) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SL").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SL
 */

/** @type {Object} */
const SL = {
    code: "SL",
    name: "SAML_Artifacts",
    recordLength: null,
    helpRegistry: "hSL.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SLi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hslz_spare"           : { canonical: "hSLz_Spare"           , type: "STRING", tableCode: "SL" },

        // ── (v-prefix) ──────────────────────────────────────────────────
        "hslv_artifact_id"     : { canonical: "hSLv_Artifact_Id"     , type: "VARSTRING", tableCode: "SL" },
        "hslv_identity_profile": { canonical: "hSLv_Identity_Profile", type: "VARSTRING", tableCode: "SL" },
    }
};

export default SL;
