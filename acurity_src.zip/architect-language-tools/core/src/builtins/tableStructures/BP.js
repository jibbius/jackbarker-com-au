/**
 * BP.js — table structure for the BP (Batch Processing Steps) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BP").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BP
 */

/** @type {Object} */
const BP = {
    code: "BP",
    name: "Batch_Processing_Steps",
    recordLength: null,
    helpRegistry: "hBP.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BPi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hbpc_acct_tran_edit"  : { canonical: "hBPc_Acct_Tran_Edit"  , type: "STRING", tableCode: "BP" },
        "hbpc_allocated_pens"  : { canonical: "hBPc_Allocated_Pens"  , type: "STRING", tableCode: "BP" },
        "hbpc_auth_step"       : { canonical: "hBPc_Auth_Step"       , type: "STRING", tableCode: "BP" },
        "hbpc_cont_calc_only"  : { canonical: "hBPc_Cont_Calc_Only"  , type: "STRING", tableCode: "BP" },
        "hbpc_deleted"         : { canonical: "hBPc_Deleted"         , type: "STRING", tableCode: "BP" },
        "hbpc_detail_print"    : { canonical: "hBPc_Detail_Print"    , type: "STRING", tableCode: "BP" },
        "hbpc_disp_unit_entit" : { canonical: "hBPc_Disp_Unit_Entit" , type: "STRING", tableCode: "BP" },
        "hbpc_interim_review"  : { canonical: "hBPc_Interim_Review"  , type: "STRING", tableCode: "BP" },
        "hbpc_recalc_ben_mult" : { canonical: "hBPc_Recalc_Ben_Mult" , type: "STRING", tableCode: "BP" },
        "hbpc_reverse_electrnc": { canonical: "hBPc_Reverse_Electrnc", type: "STRING", tableCode: "BP" },
        "hbpc_review_type"     : { canonical: "hBPc_Review_Type"     , type: "STRING", tableCode: "BP" },
        "hbpc_spare"           : { canonical: "hBPc_Spare"           , type: "STRING", tableCode: "BP" },
        "hbpc_split_process"   : { canonical: "hBPc_Split_Process"   , type: "STRING", tableCode: "BP" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hbpd_mod_date"        : { canonical: "hBPd_Mod_Date"        , type: "DATE", tableCode: "BP" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hbps_sequence"        : { canonical: "hBPs_Sequence"        , type: "INTEGER", tableCode: "BP" },
        "hbps_sequence_no"     : { canonical: "hBPs_Sequence_No"     , type: "INTEGER", tableCode: "BP" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hbpt_mod_time"        : { canonical: "hBPt_Mod_Time"        , type: "TIME", tableCode: "BP" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hbpz_calc_for_review" : { canonical: "hBPz_Calc_For_Review" , type: "STRING", tableCode: "BP" },
        "hbpz_code"            : { canonical: "hBPz_Code"            , type: "STRING", tableCode: "BP" },
        "hbpz_description"     : { canonical: "hBPz_Description"     , type: "STRING", tableCode: "BP" },
        "hbpz_end_date"        : { canonical: "hBPz_End_Date"        , type: "STRING", tableCode: "BP" },
        "hbpz_interest_date"   : { canonical: "hBPz_Interest_Date"   , type: "STRING", tableCode: "BP" },
        "hbpz_mod_user"        : { canonical: "hBPz_Mod_User"        , type: "STRING", tableCode: "BP" },
        "hbpz_paperwork_date"  : { canonical: "hBPz_Paperwork_Date"  , type: "STRING", tableCode: "BP" },
        "hbpz_report_code"     : { canonical: "hBPz_Report_Code"     , type: "STRING", tableCode: "BP" },
        "hbpz_report_group"    : { canonical: "hBPz_Report_Group"    , type: "STRING", tableCode: "BP" },
        "hbpz_start_date"      : { canonical: "hBPz_Start_Date"      , type: "STRING", tableCode: "BP" },
        "hbpz_tran_desc"       : { canonical: "hBPz_Tran_Desc"       , type: "STRING", tableCode: "BP" },
        "hbpz_transaction"     : { canonical: "hBPz_Transaction"     , type: "STRING", tableCode: "BP" },
        "hbpz_type"            : { canonical: "hBPz_Type"            , type: "STRING", tableCode: "BP" },
        "hbpz_user_tran"       : { canonical: "hBPz_User_Tran"       , type: "STRING", tableCode: "BP" },
    }
};

export default BP;
