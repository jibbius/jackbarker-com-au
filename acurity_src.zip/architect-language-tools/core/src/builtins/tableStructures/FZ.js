/**
 * FZ.js — table structure for the FZ (Fund Information 3 (Trustee Details)) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FZ").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FZ
 */

/** @type {Object} */
const FZ = {
    code: "FZ",
    name: "Fund_Information_3_(Trustee_Details)",
    recordLength: null,
    helpRegistry: "hFZ.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FZi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hfzf_max_admin"       : { canonical: "hFZf_Max_Admin"       , type: "DOUBLE", tableCode: "FZ" },
        "hfzf_prov_comm_amt"   : { canonical: "hFZf_Prov_Comm_Amt"   , type: "DOUBLE", tableCode: "FZ" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hfzl_afsl"            : { canonical: "hFZl_AFSL"            , type: "INTEGER", tableCode: "FZ" },
        "hfzl_spare"           : { canonical: "hFZl_Spare"           , type: "INTEGER", tableCode: "FZ" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hfzs_no_of_auth_sign" : { canonical: "hFZs_No_Of_Auth_Sign" , type: "INTEGER", tableCode: "FZ" },
        "hfzs_spare01"         : { canonical: "hFZs_Spare01"         , type: "INTEGER", tableCode: "FZ" },
        "hfzs_spare02"         : { canonical: "hFZs_Spare02"         , type: "INTEGER", tableCode: "FZ" },
        "hfzs_spare03"         : { canonical: "hFZs_Spare03"         , type: "INTEGER", tableCode: "FZ" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfzz_address01"       : { canonical: "hFZz_Address01"       , type: "STRING", tableCode: "FZ" },
        "hfzz_address02"       : { canonical: "hFZz_Address02"       , type: "STRING", tableCode: "FZ" },
        "hfzz_address03"       : { canonical: "hFZz_Address03"       , type: "STRING", tableCode: "FZ" },
        "hfzz_aust_company_no" : { canonical: "hFZz_Aust_Company_No" , type: "STRING", tableCode: "FZ" },
        "hfzz_auth_signatory_1": { canonical: "hFZz_Auth_Signatory_1", type: "STRING", tableCode: "FZ" },
        "hfzz_auth_signatory_2": { canonical: "hFZz_Auth_Signatory_2", type: "STRING", tableCode: "FZ" },
        "hfzz_auth_signatory_3": { canonical: "hFZz_Auth_Signatory_3", type: "STRING", tableCode: "FZ" },
        "hfzz_auth_signatory_4": { canonical: "hFZz_Auth_Signatory_4", type: "STRING", tableCode: "FZ" },
        "hfzz_auth_signatory_5": { canonical: "hFZz_Auth_Signatory_5", type: "STRING", tableCode: "FZ" },
        "hfzz_contact_fax_no"  : { canonical: "hFZz_Contact_Fax_No"  , type: "STRING", tableCode: "FZ" },
        "hfzz_contact_mobile_n": { canonical: "hFZz_Contact_Mobile_N", type: "STRING", tableCode: "FZ" },
        "hfzz_contact_phone_no": { canonical: "hFZz_Contact_Phone_No", type: "STRING", tableCode: "FZ" },
        "hfzz_extra_address"   : { canonical: "hFZz_Extra_Address"   , type: "STRING", tableCode: "FZ" },
        "hfzz_fund"            : { canonical: "hFZz_Fund"            , type: "STRING", tableCode: "FZ" },
        "hfzz_govt_actuary_reg": { canonical: "hFZz_Govt_Actuary_Reg", type: "STRING", tableCode: "FZ" },
        "hfzz_intro_intrmdry"  : { canonical: "hFZz_Intro_Intrmdry"  , type: "STRING", tableCode: "FZ" },
        "hfzz_post_code"       : { canonical: "hFZz_Post_Code"       , type: "STRING", tableCode: "FZ" },
        "hfzz_region"          : { canonical: "hFZz_Region"          , type: "STRING", tableCode: "FZ" },
        "hfzz_rse"             : { canonical: "hFZz_RSE"             , type: "STRING", tableCode: "FZ" },
        "hfzz_spare"           : { canonical: "hFZz_Spare"           , type: "STRING", tableCode: "FZ" },
        "hfzz_trustee_name"    : { canonical: "hFZz_Trustee_Name"    , type: "STRING", tableCode: "FZ" },
    }
};

export default FZ;
