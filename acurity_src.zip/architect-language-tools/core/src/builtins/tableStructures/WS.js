/**
 * WS.js — table structure for the WS (Working Status History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "WS").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force WS
 */

/** @type {Object} */
const WS = {
    code: "WS",
    name: "Working_Status_History",
    recordLength: null,
    helpRegistry: "hWS.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "WSi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hwsc_conv_record"   : { canonical: "hWSc_Conv_Record"   , type: "STRING", tableCode: "WS" },
        "hwsc_deleted"       : { canonical: "hWSc_Deleted"       , type: "STRING", tableCode: "WS" },
        "hwsc_reduce_entit"  : { canonical: "hWSc_Reduce_Entit"  , type: "STRING", tableCode: "WS" },
        "hwsc_spare"         : { canonical: "hWSc_Spare"         , type: "STRING", tableCode: "WS" },
        "hwsc_working_status": { canonical: "hWSc_Working_Status", type: "STRING", tableCode: "WS" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hwsd_effective"     : { canonical: "hWSd_Effective"     , type: "DATE", tableCode: "WS" },
        "hwsd_end"           : { canonical: "hWSd_End"           , type: "DATE", tableCode: "WS" },
        "hwsd_mod_date"      : { canonical: "hWSd_Mod_Date"      , type: "DATE", tableCode: "WS" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hwst_mod_time"      : { canonical: "hWSt_Mod_Time"      , type: "TIME", tableCode: "WS" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hwsz_fund"          : { canonical: "hWSz_Fund"          , type: "STRING", tableCode: "WS" },
        "hwsz_half_conts"    : { canonical: "hWSz_Half_Conts"    , type: "STRING", tableCode: "WS" },
        "hwsz_member"        : { canonical: "hWSz_Member"        , type: "STRING", tableCode: "WS" },
        "hwsz_mod_user"      : { canonical: "hWSz_Mod_User"      , type: "STRING", tableCode: "WS" },
    }
};

export default WS;
