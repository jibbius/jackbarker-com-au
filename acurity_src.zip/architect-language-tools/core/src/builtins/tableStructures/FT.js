/**
 * FT.js — table structure for the FT (File Type Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FT").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FT
 */

/** @type {Object} */
const FT = {
    code: "FT",
    name: "File_Type_Details",
    recordLength: null,
    helpRegistry: "hFT.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FTi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hftc_deleted"         : { canonical: "hFTc_Deleted"         , type: "STRING", tableCode: "FT" },
        "hftc_period_req"      : { canonical: "hFTc_Period_Req"      , type: "STRING", tableCode: "FT" },
        "hftc_reference_req"   : { canonical: "hFTc_Reference_Req"   , type: "STRING", tableCode: "FT" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hftd_mod_date"        : { canonical: "hFTd_Mod_Date"        , type: "DATE", tableCode: "FT" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hftf_error_threshold" : { canonical: "hFTf_Error_Threshold" , type: "DOUBLE", tableCode: "FT" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hftl_headerline"      : { canonical: "hFTl_HeaderLine"      , type: "INTEGER", tableCode: "FT" },
        "hftl_max_error_lines" : { canonical: "hFTl_Max_Error_Lines" , type: "INTEGER", tableCode: "FT" },
        "hftl_max_tot_errors"  : { canonical: "hFTl_Max_Tot_Errors"  , type: "INTEGER", tableCode: "FT" },
        "hftl_min_lines"       : { canonical: "hFTl_Min_Lines"       , type: "INTEGER", tableCode: "FT" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hftt_mod_time"        : { canonical: "hFTt_Mod_Time"        , type: "TIME", tableCode: "FT" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hftz_datapattern"     : { canonical: "hFTz_DataPattern"     , type: "STRING", tableCode: "FT" },
        "hftz_file_type_id"    : { canonical: "hFTz_File_Type_Id"    , type: "STRING", tableCode: "FT" },
        "hftz_filenamepattern" : { canonical: "hFTz_FilenamePattern" , type: "STRING", tableCode: "FT" },
        "hftz_headerpattern"   : { canonical: "hFTz_HeaderPattern"   , type: "STRING", tableCode: "FT" },
        "hftz_match"           : { canonical: "hFTz_Match"           , type: "STRING", tableCode: "FT" },
        "hftz_match_code"      : { canonical: "hFTz_Match_Code"      , type: "STRING", tableCode: "FT" },
        "hftz_match_group"     : { canonical: "hFTz_Match_Group"     , type: "STRING", tableCode: "FT" },
        "hftz_match_parameters": { canonical: "hFTz_Match_Parameters", type: "STRING", tableCode: "FT" },
        "hftz_mod_user"        : { canonical: "hFTz_Mod_User"        , type: "STRING", tableCode: "FT" },
        "hftz_rejadv_code"     : { canonical: "hFTz_RejAdv_Code"     , type: "STRING", tableCode: "FT" },
        "hftz_rejadv_function" : { canonical: "hFTz_RejAdv_Function" , type: "STRING", tableCode: "FT" },
        "hftz_rejadv_group"    : { canonical: "hFTz_RejAdv_Group"    , type: "STRING", tableCode: "FT" },
        "hftz_rejadv_params"   : { canonical: "hFTz_RejAdv_Params"   , type: "STRING", tableCode: "FT" },
        "hftz_spare"           : { canonical: "hFTz_Spare"           , type: "STRING", tableCode: "FT" },
        "hftz_trans_parameters": { canonical: "hFTz_Trans_Parameters", type: "STRING", tableCode: "FT" },
        "hftz_transl_group"    : { canonical: "hFTz_Transl_Group"    , type: "STRING", tableCode: "FT" },
        "hftz_translation_code": { canonical: "hFTz_Translation_Code", type: "STRING", tableCode: "FT" },
        "hftz_translation_name": { canonical: "hFTz_Translation_Name", type: "STRING", tableCode: "FT" },
        "hftz_user_def_flags01": { canonical: "hFTz_User_Def_Flags01", type: "STRING", tableCode: "FT" },
        "hftz_user_def_flags02": { canonical: "hFTz_User_Def_Flags02", type: "STRING", tableCode: "FT" },
        "hftz_user_def_flags03": { canonical: "hFTz_User_Def_Flags03", type: "STRING", tableCode: "FT" },
        "hftz_user_def_flags04": { canonical: "hFTz_User_Def_Flags04", type: "STRING", tableCode: "FT" },
    }
};

export default FT;
