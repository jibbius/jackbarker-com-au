/**
 * OG.js — table structure for the OG (Member - Other Fund Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "OG").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force OG
 */

/** @type {Object} */
const OG = {
    code: "OG",
    name: "Member_-_Other_Fund_Details",
    recordLength: null,
    helpRegistry: "hOG.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "OGi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hogc_spare"         : { canonical: "hOGc_Spare"         , type: "STRING", tableCode: "OG" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hogd_mod_date"      : { canonical: "hOGd_Mod_Date"      , type: "DATE", tableCode: "OG" },
        "hogd_spare"         : { canonical: "hOGd_Spare"         , type: "DATE", tableCode: "OG" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hogf_amt_other_fund": { canonical: "hOGf_Amt_Other_Fund", type: "DOUBLE", tableCode: "OG" },
        "hogf_current_cont"  : { canonical: "hOGf_Current_Cont"  , type: "DOUBLE", tableCode: "OG" },
        "hogf_dth_ben_other" : { canonical: "hOGf_DTH_Ben_Other" , type: "DOUBLE", tableCode: "OG" },
        "hogf_other_salary"  : { canonical: "hOGf_Other_Salary"  , type: "DOUBLE", tableCode: "OG" },
        "hogf_spare"         : { canonical: "hOGf_Spare"         , type: "DOUBLE", tableCode: "OG" },
        "hogf_tpd_ben_other" : { canonical: "hOGf_TPD_Ben_Other" , type: "DOUBLE", tableCode: "OG" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hogl_spare"         : { canonical: "hOGl_Spare"         , type: "INTEGER", tableCode: "OG" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hogt_mod_time"      : { canonical: "hOGt_Mod_Time"      , type: "TIME", tableCode: "OG" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hogz_deleted"       : { canonical: "hOGz_Deleted"       , type: "STRING", tableCode: "OG" },
        "hogz_fund"          : { canonical: "hOGz_Fund"          , type: "STRING", tableCode: "OG" },
        "hogz_fund_name"     : { canonical: "hOGz_Fund_Name"     , type: "STRING", tableCode: "OG" },
        "hogz_member"        : { canonical: "hOGz_Member"        , type: "STRING", tableCode: "OG" },
        "hogz_mod_user"      : { canonical: "hOGz_Mod_User"      , type: "STRING", tableCode: "OG" },
        "hogz_spare"         : { canonical: "hOGz_Spare"         , type: "STRING", tableCode: "OG" },
    }
};

export default OG;
