/**
 * SP.js — table structure for the SP (Posting Transaction Control) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SP").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SP
 */

/** @type {Object} */
const SP = {
    code: "SP",
    name: "Posting_Transaction_Control",
    recordLength: null,
    helpRegistry: "hSP.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SPi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hspd_mod_date" : { canonical: "hSPd_Mod_Date" , type: "DATE", tableCode: "SP" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hspl_trans_ref": { canonical: "hSPl_Trans_Ref", type: "INTEGER", tableCode: "SP" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hspt_mod_time" : { canonical: "hSPt_Mod_Time" , type: "TIME", tableCode: "SP" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hspz_division" : { canonical: "hSPz_Division" , type: "STRING", tableCode: "SP" },
        "hspz_fund"     : { canonical: "hSPz_Fund"     , type: "STRING", tableCode: "SP" },
        "hspz_mod_user" : { canonical: "hSPz_Mod_User" , type: "STRING", tableCode: "SP" },
        "hspz_spare"    : { canonical: "hSPz_Spare"    , type: "STRING", tableCode: "SP" },
    }
};

export default SP;
