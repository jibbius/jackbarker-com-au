/**
 * MC.js — table structure for the MC (Member Contribution Rate History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "MC").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force MC
 */

/** @type {Object} */
const MC = {
    code: "MC",
    name: "Member_Contribution_Rate_History",
    recordLength: null,
    helpRegistry: "hMC.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "MCi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hmcc_adjusting_record": { canonical: "hMCc_Adjusting_Record", type: "STRING", tableCode: "MC" },
        "hmcc_deleted"         : { canonical: "hMCc_Deleted"         , type: "STRING", tableCode: "MC" },
        "hmcc_frequency"       : { canonical: "hMCc_Frequency"       , type: "STRING", tableCode: "MC" },
        "hmcc_quote"           : { canonical: "hMCc_Quote"           , type: "STRING", tableCode: "MC" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hmcd_anniversary"     : { canonical: "hMCd_Anniversary"     , type: "DATE", tableCode: "MC" },
        "hmcd_created"         : { canonical: "hMCd_Created"         , type: "DATE", tableCode: "MC" },
        "hmcd_effective"       : { canonical: "hMCd_Effective"       , type: "DATE", tableCode: "MC" },
        "hmcd_mod_date"        : { canonical: "hMCd_Mod_Date"        , type: "DATE", tableCode: "MC" },
        "hmcd_termination"     : { canonical: "hMCd_Termination"     , type: "DATE", tableCode: "MC" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hmcf_coy_award_amt"   : { canonical: "hMCf_Coy_Award_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_award_pcnt"  : { canonical: "hMCf_Coy_Award_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_reg_p_amt"   : { canonical: "hMCf_Coy_Reg_P_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_reg_p_pcnt"  : { canonical: "hMCf_Coy_Reg_P_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_reg_u_amt"   : { canonical: "hMCf_Coy_Reg_U_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_reg_u_pcnt"  : { canonical: "hMCf_Coy_Reg_U_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_sgl_p_amt"   : { canonical: "hMCf_Coy_Sgl_P_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_sgl_p_pcnt"  : { canonical: "hMCf_Coy_Sgl_P_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_sgl_u_amt"   : { canonical: "hMCf_Coy_Sgl_U_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_sgl_u_pcnt"  : { canonical: "hMCf_Coy_Sgl_U_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_vol_p_amt"   : { canonical: "hMCf_Coy_Vol_P_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_vol_p_pcnt"  : { canonical: "hMCf_Coy_Vol_P_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_vol_u_amt"   : { canonical: "hMCf_Coy_Vol_U_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_coy_vol_u_pcnt"  : { canonical: "hMCf_Coy_Vol_U_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_deductible_conts": { canonical: "hMCf_Deductible_Conts", type: "DOUBLE", tableCode: "MC" },
        "hmcf_maximum_cont"    : { canonical: "hMCf_Maximum_Cont"    , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_deem_p_amt"  : { canonical: "hMCf_Mbr_Deem_P_Amt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_deem_p_pcnt" : { canonical: "hMCf_Mbr_Deem_P_Pcnt" , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_deem_u_amt"  : { canonical: "hMCf_Mbr_Deem_U_Amt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_deem_u_pcnt" : { canonical: "hMCf_Mbr_Deem_U_Pcnt" , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_reg_p_amt"   : { canonical: "hMCf_Mbr_Reg_P_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_reg_p_pcnt"  : { canonical: "hMCf_Mbr_Reg_P_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_reg_u_amt"   : { canonical: "hMCf_Mbr_Reg_U_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_reg_u_pcnt"  : { canonical: "hMCf_Mbr_Reg_U_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_sgl_p_amt"   : { canonical: "hMCf_Mbr_Sgl_P_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_sgl_p_pcnt"  : { canonical: "hMCf_Mbr_Sgl_P_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_sgl_u_amt"   : { canonical: "hMCf_Mbr_Sgl_U_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_sgl_u_pcnt"  : { canonical: "hMCf_Mbr_Sgl_U_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_vol_p_amt"   : { canonical: "hMCf_Mbr_Vol_P_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_vol_p_pcnt"  : { canonical: "hMCf_Mbr_Vol_P_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_vol_u_amt"   : { canonical: "hMCf_Mbr_Vol_U_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_mbr_vol_u_pcnt"  : { canonical: "hMCf_Mbr_Vol_U_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res1_pres_amt"   : { canonical: "hMCf_Res1_Pres_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res1_pres_pcnt"  : { canonical: "hMCf_Res1_Pres_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res1_unpr_amt"   : { canonical: "hMCf_Res1_Unpr_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res1_unpr_pcnt"  : { canonical: "hMCf_Res1_Unpr_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res2_pres_amt"   : { canonical: "hMCf_Res2_Pres_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res2_pres_pcnt"  : { canonical: "hMCf_Res2_Pres_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res2_unpr_amt"   : { canonical: "hMCf_Res2_Unpr_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res2_unpr_pcnt"  : { canonical: "hMCf_Res2_Unpr_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res3_pres_amt"   : { canonical: "hMCf_Res3_Pres_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res3_pres_pcnt"  : { canonical: "hMCf_Res3_Pres_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res3_unpr_amt"   : { canonical: "hMCf_Res3_Unpr_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res3_unpr_pcnt"  : { canonical: "hMCf_Res3_Unpr_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res4_pres_amt"   : { canonical: "hMCf_Res4_Pres_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res4_pres_pcnt"  : { canonical: "hMCf_Res4_Pres_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res4_unpr_amt"   : { canonical: "hMCf_Res4_Unpr_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res4_unpr_pcnt"  : { canonical: "hMCf_Res4_Unpr_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res5_pres_amt"   : { canonical: "hMCf_Res5_Pres_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res5_pres_pcnt"  : { canonical: "hMCf_Res5_Pres_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res5_unpr_amt"   : { canonical: "hMCf_Res5_Unpr_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res5_unpr_pcnt"  : { canonical: "hMCf_Res5_Unpr_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res6_pres_amt"   : { canonical: "hMCf_Res6_Pres_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res6_pres_pcnt"  : { canonical: "hMCf_Res6_Pres_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res6_unpr_amt"   : { canonical: "hMCf_Res6_Unpr_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res6_unpr_pcnt"  : { canonical: "hMCf_Res6_Unpr_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res7_pres_amt"   : { canonical: "hMCf_Res7_Pres_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res7_pres_pcnt"  : { canonical: "hMCf_Res7_Pres_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res7_unpr_amt"   : { canonical: "hMCf_Res7_Unpr_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res7_unpr_pcnt"  : { canonical: "hMCf_Res7_Unpr_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res8_pres_amt"   : { canonical: "hMCf_Res8_Pres_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res8_pres_pcnt"  : { canonical: "hMCf_Res8_Pres_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res8_unpr_amt"   : { canonical: "hMCf_Res8_Unpr_Amt"   , type: "DOUBLE", tableCode: "MC" },
        "hmcf_res8_unpr_pcnt"  : { canonical: "hMCf_Res8_Unpr_Pcnt"  , type: "DOUBLE", tableCode: "MC" },
        "hmcf_sg_pres_amt"     : { canonical: "hMCf_SG_Pres_Amt"     , type: "DOUBLE", tableCode: "MC" },
        "hmcf_sg_pres_pcnt"    : { canonical: "hMCf_SG_Pres_Pcnt"    , type: "DOUBLE", tableCode: "MC" },
        "hmcf_sg_unpr_amt"     : { canonical: "hMCf_SG_Unpr_Amt"     , type: "DOUBLE", tableCode: "MC" },
        "hmcf_sg_unpr_pcnt"    : { canonical: "hMCf_SG_Unpr_Pcnt"    , type: "DOUBLE", tableCode: "MC" },
        "hmcf_spsecntpres_amt" : { canonical: "hMCf_SpseCntPres_Amt" , type: "DOUBLE", tableCode: "MC" },
        "hmcf_spsecntpres_pcnt": { canonical: "hMCf_SpseCntPres_Pcnt", type: "DOUBLE", tableCode: "MC" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hmcl_spare"           : { canonical: "hMCl_Spare"           , type: "INTEGER", tableCode: "MC" },
        "hmcl_trans_ref"       : { canonical: "hMCl_Trans_Ref"       , type: "INTEGER", tableCode: "MC" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hmct_mod_time"        : { canonical: "hMCt_Mod_Time"        , type: "TIME", tableCode: "MC" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hmcz_division"        : { canonical: "hMCz_Division"        , type: "STRING", tableCode: "MC" },
        "hmcz_fund"            : { canonical: "hMCz_Fund"            , type: "STRING", tableCode: "MC" },
        "hmcz_member"          : { canonical: "hMCz_Member"          , type: "STRING", tableCode: "MC" },
        "hmcz_mod_user"        : { canonical: "hMCz_Mod_User"        , type: "STRING", tableCode: "MC" },
        "hmcz_payroll"         : { canonical: "hMCz_Payroll"         , type: "STRING", tableCode: "MC" },
        "hmcz_spare"           : { canonical: "hMCz_Spare"           , type: "STRING", tableCode: "MC" },
    }
};

export default MC;
