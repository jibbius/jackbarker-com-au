/**
 * PP.js — table structure for the PP (Temporary P04 and P05 Totals) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PP").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PP
 */

/** @type {Object} */
const PP = {
    code: "PP",
    name: "Temporary_P04_and_P05_Totals",
    recordLength: null,
    helpRegistry: "hPP.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PPi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hppc_spare"          : { canonical: "hPPc_Spare"          , type: "STRING", tableCode: "PP" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hppf_p04_tot_amt_mbr": { canonical: "hPPf_P04_Tot_Amt_Mbr", type: "DOUBLE", tableCode: "PP" },
        "hppf_p05_tot_amt_mbr": { canonical: "hPPf_P05_Tot_Amt_Mbr", type: "DOUBLE", tableCode: "PP" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hppl_spare"          : { canonical: "hPPl_Spare"          , type: "INTEGER", tableCode: "PP" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hppz_fund"           : { canonical: "hPPz_Fund"           , type: "STRING", tableCode: "PP" },
        "hppz_member"         : { canonical: "hPPz_Member"         , type: "STRING", tableCode: "PP" },
        "hppz_spare"          : { canonical: "hPPz_Spare"          , type: "STRING", tableCode: "PP" },
    }
};

export default PP;
