/**
 * EX.js — table structure for the EX (Extensions) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "EX").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force EX
 */

/** @type {Object} */
const EX = {
    code: "EX",
    name: "Extensions",
    recordLength: null,
    helpRegistry: "hEX.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "EXi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hexc_deleted"     : { canonical: "hEXc_Deleted"     , type: "STRING", tableCode: "EX" },
        "hexc_spare01"     : { canonical: "hEXc_Spare01"     , type: "STRING", tableCode: "EX" },
        "hexc_spare02"     : { canonical: "hEXc_Spare02"     , type: "STRING", tableCode: "EX" },
        "hexc_spare03"     : { canonical: "hEXc_Spare03"     , type: "STRING", tableCode: "EX" },
        "hexc_spare04"     : { canonical: "hEXc_Spare04"     , type: "STRING", tableCode: "EX" },
        "hexc_spare05"     : { canonical: "hEXc_Spare05"     , type: "STRING", tableCode: "EX" },
        "hexc_spare06"     : { canonical: "hEXc_Spare06"     , type: "STRING", tableCode: "EX" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hexd_mod_date"    : { canonical: "hEXd_Mod_Date"    , type: "DATE", tableCode: "EX" },
        "hexd_spare"       : { canonical: "hEXd_Spare"       , type: "DATE", tableCode: "EX" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hext_mod_time"    : { canonical: "hEXt_Mod_Time"    , type: "TIME", tableCode: "EX" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hexz_description" : { canonical: "hEXz_Description" , type: "STRING", tableCode: "EX" },
        "hexz_mod_user"    : { canonical: "hEXz_Mod_User"    , type: "STRING", tableCode: "EX" },
        "hexz_name"        : { canonical: "hEXz_Name"        , type: "STRING", tableCode: "EX" },
        "hexz_report_code" : { canonical: "hEXz_Report_Code" , type: "STRING", tableCode: "EX" },
        "hexz_report_group": { canonical: "hEXz_Report_Group", type: "STRING", tableCode: "EX" },
    }
};

export default EX;
