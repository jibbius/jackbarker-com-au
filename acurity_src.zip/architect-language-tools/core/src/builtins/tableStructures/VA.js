/**
 * VA.js — table structure for the VA (Contribution Variance History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "VA").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force VA
 */

/** @type {Object} */
const VA = {
    code: "VA",
    name: "Contribution_Variance_History",
    recordLength: null,
    helpRegistry: "hVA.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "VAi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hvac_deleted"       : { canonical: "hVAc_Deleted"       , type: "STRING", tableCode: "VA" },
        "hvac_url_template"  : { canonical: "hVAc_Url_Template"  , type: "STRING", tableCode: "VA" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hvad_effective"     : { canonical: "hVAd_Effective"     , type: "DATE", tableCode: "VA" },
        "hvad_expected_to01" : { canonical: "hVAd_Expected_To01" , type: "DATE", tableCode: "VA" },
        "hvad_expected_to02" : { canonical: "hVAd_Expected_To02" , type: "DATE", tableCode: "VA" },
        "hvad_mod_date"      : { canonical: "hVAd_Mod_Date"      , type: "DATE", tableCode: "VA" },
        "hvad_paid_to"       : { canonical: "hVAd_Paid_To"       , type: "DATE", tableCode: "VA" },
        "hvad_spare"         : { canonical: "hVAd_Spare"         , type: "DATE", tableCode: "VA" },
        "hvad_variance"      : { canonical: "hVAd_Variance"      , type: "DATE", tableCode: "VA" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hvaf_expected_emp01": { canonical: "hVAf_Expected_Emp01", type: "DOUBLE", tableCode: "VA" },
        "hvaf_expected_emp02": { canonical: "hVAf_Expected_Emp02", type: "DOUBLE", tableCode: "VA" },
        "hvaf_expected_mbr01": { canonical: "hVAf_Expected_Mbr01", type: "DOUBLE", tableCode: "VA" },
        "hvaf_expected_mbr02": { canonical: "hVAf_Expected_Mbr02", type: "DOUBLE", tableCode: "VA" },
        "hvaf_expected_mbr03": { canonical: "hVAf_Expected_Mbr03", type: "DOUBLE", tableCode: "VA" },
        "hvaf_expected_mbr04": { canonical: "hVAf_Expected_Mbr04", type: "DOUBLE", tableCode: "VA" },
        "hvaf_variance_emp01": { canonical: "hVAf_Variance_Emp01", type: "DOUBLE", tableCode: "VA" },
        "hvaf_variance_emp02": { canonical: "hVAf_Variance_Emp02", type: "DOUBLE", tableCode: "VA" },
        "hvaf_variance_mbr01": { canonical: "hVAf_Variance_Mbr01", type: "DOUBLE", tableCode: "VA" },
        "hvaf_variance_mbr02": { canonical: "hVAf_Variance_Mbr02", type: "DOUBLE", tableCode: "VA" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hvat_mod_time"      : { canonical: "hVAt_Mod_Time"      , type: "TIME", tableCode: "VA" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hvaz_division"      : { canonical: "hVAz_Division"      , type: "STRING", tableCode: "VA" },
        "hvaz_fund"          : { canonical: "hVAz_Fund"          , type: "STRING", tableCode: "VA" },
        "hvaz_member"        : { canonical: "hVAz_Member"        , type: "STRING", tableCode: "VA" },
        "hvaz_mod_user"      : { canonical: "hVAz_Mod_User"      , type: "STRING", tableCode: "VA" },
        "hvaz_payroll"       : { canonical: "hVAz_Payroll"       , type: "STRING", tableCode: "VA" },
        "hvaz_record_type"   : { canonical: "hVAz_Record_Type"   , type: "STRING", tableCode: "VA" },
        "hvaz_spare"         : { canonical: "hVAz_Spare"         , type: "STRING", tableCode: "VA" },
        "hvaz_url_general01" : { canonical: "hVAz_Url_General01" , type: "STRING", tableCode: "VA" },
        "hvaz_url_general02" : { canonical: "hVAz_Url_General02" , type: "STRING", tableCode: "VA" },
        "hvaz_url_general03" : { canonical: "hVAz_Url_General03" , type: "STRING", tableCode: "VA" },
    }
};

export default VA;
