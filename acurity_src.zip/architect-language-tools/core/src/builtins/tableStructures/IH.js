/**
 * IH.js — table structure for the IH (Investment Manager History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "IH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force IH
 */

/** @type {Object} */
const IH = {
    code: "IH",
    name: "Investment_Manager_History",
    recordLength: null,
    helpRegistry: "hIH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "IHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hihc_notes"           : { canonical: "hIHc_Notes"           , type: "STRING", tableCode: "IH" },
        "hihc_spare"           : { canonical: "hIHc_Spare"           , type: "STRING", tableCode: "IH" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hihd_effective"       : { canonical: "hIHd_Effective"       , type: "DATE", tableCode: "IH" },
        "hihd_mod_date"        : { canonical: "hIHd_Mod_Date"        , type: "DATE", tableCode: "IH" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hihf_actual_return"   : { canonical: "hIHf_Actual_Return"   , type: "DOUBLE", tableCode: "IH" },
        "hihf_ass_alloc_aus_fi": { canonical: "hIHf_Ass_Alloc_Aus_FI", type: "DOUBLE", tableCode: "IH" },
        "hihf_ass_alloc_aus_sh": { canonical: "hIHf_Ass_Alloc_Aus_SH", type: "DOUBLE", tableCode: "IH" },
        "hihf_ass_alloc_int_fi": { canonical: "hIHf_Ass_Alloc_Int_FI", type: "DOUBLE", tableCode: "IH" },
        "hihf_ass_alloc_int_sh": { canonical: "hIHf_Ass_Alloc_Int_SH", type: "DOUBLE", tableCode: "IH" },
        "hihf_ass_alloc_other" : { canonical: "hIHf_Ass_Alloc_Other" , type: "DOUBLE", tableCode: "IH" },
        "hihf_ass_alloc_prop"  : { canonical: "hIHf_Ass_Alloc_Prop"  , type: "DOUBLE", tableCode: "IH" },
        "hihf_asset_alloc_cash": { canonical: "hIHf_Asset_Alloc_Cash", type: "DOUBLE", tableCode: "IH" },
        "hihf_asset_list_prop" : { canonical: "hIHf_Asset_List_Prop" , type: "DOUBLE", tableCode: "IH" },
        "hihf_asset_mortgage"  : { canonical: "hIHf_Asset_Mortgage"  , type: "DOUBLE", tableCode: "IH" },
        "hihf_fees_costs"      : { canonical: "hIHf_Fees_Costs"      , type: "DOUBLE", tableCode: "IH" },
        "hihf_mov_avg_ret_targ": { canonical: "hIHf_Mov_Avg_Ret_Targ", type: "DOUBLE", tableCode: "IH" },
        "hihf_moving_avg_ret"  : { canonical: "hIHf_Moving_Avg_Ret"  , type: "DOUBLE", tableCode: "IH" },
        "hihf_past_perform_10y": { canonical: "hIHf_Past_Perform_10y", type: "DOUBLE", tableCode: "IH" },
        "hihf_past_perform_1y" : { canonical: "hIHf_Past_Perform_1y" , type: "DOUBLE", tableCode: "IH" },
        "hihf_past_perform_2y" : { canonical: "hIHf_Past_Perform_2y" , type: "DOUBLE", tableCode: "IH" },
        "hihf_past_perform_3m" : { canonical: "hIHf_Past_Perform_3m" , type: "DOUBLE", tableCode: "IH" },
        "hihf_past_perform_3y" : { canonical: "hIHf_Past_Perform_3y" , type: "DOUBLE", tableCode: "IH" },
        "hihf_past_perform_5y" : { canonical: "hIHf_Past_Perform_5y" , type: "DOUBLE", tableCode: "IH" },
        "hihf_past_perform_6m" : { canonical: "hIHf_Past_Perform_6m" , type: "DOUBLE", tableCode: "IH" },
        "hihf_past_perform_7y" : { canonical: "hIHf_Past_Perform_7y" , type: "DOUBLE", tableCode: "IH" },
        "hihf_return_target"   : { canonical: "hIHf_Return_Target"   , type: "DOUBLE", tableCode: "IH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hiht_mod_time"        : { canonical: "hIHt_Mod_Time"        , type: "TIME", tableCode: "IH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hihz_code"            : { canonical: "hIHz_Code"            , type: "STRING", tableCode: "IH" },
        "hihz_inv_risk"        : { canonical: "hIHz_Inv_Risk"        , type: "STRING", tableCode: "IH" },
        "hihz_mod_user"        : { canonical: "hIHz_Mod_User"        , type: "STRING", tableCode: "IH" },
    }
};

export default IH;
