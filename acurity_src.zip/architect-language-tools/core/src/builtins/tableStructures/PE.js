/**
 * PE.js — table structure for the PE (Member Pension History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PE").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PE
 */

/** @type {Object} */
const PE = {
    code: "PE",
    name: "Member_Pension_History",
    recordLength: null,
    helpRegistry: "hPE.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PEi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hpec_cpi"             : { canonical: "hPEc_CPI"             , type: "STRING", tableCode: "PE" },
        "hpec_deleted"         : { canonical: "hPEc_Deleted"         , type: "STRING", tableCode: "PE" },
        "hpec_freq_pens_pay"   : { canonical: "hPEc_Freq_Pens_Pay"   , type: "STRING", tableCode: "PE" },
        "hpec_min_max_nom_amt" : { canonical: "hPEc_Min_Max_Nom_Amt" , type: "STRING", tableCode: "PE" },
        "hpec_min_std_met"     : { canonical: "hPEc_Min_Std_Met"     , type: "STRING", tableCode: "PE" },
        "hpec_one_off_payment" : { canonical: "hPEc_One_Off_Payment" , type: "STRING", tableCode: "PE" },
        "hpec_pens_amt_confirm": { canonical: "hPEc_Pens_Amt_Confirm", type: "STRING", tableCode: "PE" },
        "hpec_pens_gross_amt"  : { canonical: "hPEc_Pens_Gross_Amt"  , type: "STRING", tableCode: "PE" },
        "hpec_spare"           : { canonical: "hPEc_Spare"           , type: "STRING", tableCode: "PE" },
        "hpec_tax_specified"   : { canonical: "hPEc_Tax_Specified"   , type: "STRING", tableCode: "PE" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hped_cessation"       : { canonical: "hPEd_Cessation"       , type: "DATE", tableCode: "PE" },
        "hped_defer_cessation" : { canonical: "hPEd_Defer_Cessation" , type: "DATE", tableCode: "PE" },
        "hped_effective"       : { canonical: "hPEd_Effective"       , type: "DATE", tableCode: "PE" },
        "hped_guar_cessation"  : { canonical: "hPEd_Guar_Cessation"  , type: "DATE", tableCode: "PE" },
        "hped_mod_date"        : { canonical: "hPEd_Mod_Date"        , type: "DATE", tableCode: "PE" },
        "hped_payment"         : { canonical: "hPEd_Payment"         , type: "DATE", tableCode: "PE" },
        "hped_pres_cessation"  : { canonical: "hPEd_Pres_Cessation"  , type: "DATE", tableCode: "PE" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hpef_concess_comp"    : { canonical: "hPEf_Concess_Comp"    , type: "DOUBLE", tableCode: "PE" },
        "hpef_deduct_amt_yr"   : { canonical: "hPEf_Deduct_Amt_Yr"   , type: "DOUBLE", tableCode: "PE" },
        "hpef_deduct_std_met"  : { canonical: "hPEf_Deduct_Std_Met"  , type: "DOUBLE", tableCode: "PE" },
        "hpef_deferred_pens"   : { canonical: "hPEf_Deferred_Pens"   , type: "DOUBLE", tableCode: "PE" },
        "hpef_dependant_pens"  : { canonical: "hPEf_Dependant_Pens"  , type: "DOUBLE", tableCode: "PE" },
        "hpef_excessive_comp"  : { canonical: "hPEf_Excessive_Comp"  , type: "DOUBLE", tableCode: "PE" },
        "hpef_indexation"      : { canonical: "hPEf_Indexation"      , type: "DOUBLE", tableCode: "PE" },
        "hpef_life_factor"     : { canonical: "hPEf_Life_Factor"     , type: "DOUBLE", tableCode: "PE" },
        "hpef_life_factor_rev" : { canonical: "hPEf_Life_Factor_Rev" , type: "DOUBLE", tableCode: "PE" },
        "hpef_max_factor"      : { canonical: "hPEf_Max_Factor"      , type: "DOUBLE", tableCode: "PE" },
        "hpef_max_pens_yr"     : { canonical: "hPEf_Max_Pens_Yr"     , type: "DOUBLE", tableCode: "PE" },
        "hpef_min_factor"      : { canonical: "hPEf_Min_Factor"      , type: "DOUBLE", tableCode: "PE" },
        "hpef_min_pens_yr"     : { canonical: "hPEf_Min_Pens_Yr"     , type: "DOUBLE", tableCode: "PE" },
        "hpef_net_pension_amt" : { canonical: "hPEf_Net_Pension_Amt" , type: "DOUBLE", tableCode: "PE" },
        "hpef_original_pens"   : { canonical: "hPEf_Original_Pens"   , type: "DOUBLE", tableCode: "PE" },
        "hpef_pay_factor_amt"  : { canonical: "hPEf_Pay_Factor_Amt"  , type: "DOUBLE", tableCode: "PE" },
        "hpef_pension_amt"     : { canonical: "hPEf_Pension_Amt"     , type: "DOUBLE", tableCode: "PE" },
        "hpef_post_83_taxed"   : { canonical: "hPEf_Post_83_Taxed"   , type: "DOUBLE", tableCode: "PE" },
        "hpef_post_83_untaxed" : { canonical: "hPEf_Post_83_Untaxed" , type: "DOUBLE", tableCode: "PE" },
        "hpef_pre_83_comp"     : { canonical: "hPEf_Pre_83_Comp"     , type: "DOUBLE", tableCode: "PE" },
        "hpef_preserved_pens"  : { canonical: "hPEf_Preserved_Pens"  , type: "DOUBLE", tableCode: "PE" },
        "hpef_purchase_price"  : { canonical: "hPEf_Purchase_Price"  , type: "DOUBLE", tableCode: "PE" },
        "hpef_rebate_pcnt"     : { canonical: "hPEf_Rebate_Pcnt"     , type: "DOUBLE", tableCode: "PE" },
        "hpef_reduction_amount": { canonical: "hPEf_Reduction_Amount", type: "DOUBLE", tableCode: "PE" },
        "hpef_res_cap_val_ann" : { canonical: "hPEf_Res_Cap_Val_Ann" , type: "DOUBLE", tableCode: "PE" },
        "hpef_spouse_pension"  : { canonical: "hPEf_Spouse_Pension"  , type: "DOUBLE", tableCode: "PE" },
        "hpef_tax_payable"     : { canonical: "hPEf_Tax_Payable"     , type: "DOUBLE", tableCode: "PE" },
        "hpef_tax_payable_pcnt": { canonical: "hPEf_Tax_Payable_Pcnt", type: "DOUBLE", tableCode: "PE" },
        "hpef_unded_conts"     : { canonical: "hPEf_Unded_Conts"     , type: "DOUBLE", tableCode: "PE" },
        "hpef_unused_unded_pp" : { canonical: "hPEf_Unused_Unded_PP" , type: "DOUBLE", tableCode: "PE" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hpet_mod_time"        : { canonical: "hPEt_Mod_Time"        , type: "TIME", tableCode: "PE" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hpez_fund"            : { canonical: "hPEz_Fund"            , type: "STRING", tableCode: "PE" },
        "hpez_member"          : { canonical: "hPEz_Member"          , type: "STRING", tableCode: "PE" },
        "hpez_mod_user"        : { canonical: "hPEz_Mod_User"        , type: "STRING", tableCode: "PE" },
        "hpez_policy_term"     : { canonical: "hPEz_Policy_Term"     , type: "STRING", tableCode: "PE" },
        "hpez_reason"          : { canonical: "hPEz_Reason"          , type: "STRING", tableCode: "PE" },
    }
};

export default PE;
