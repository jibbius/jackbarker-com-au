/**
 * GR.js — table structure for the GR (Group Certificate) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "GR").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force GR
 */

/** @type {Object} */
const GR = {
    code: "GR",
    name: "Group_Certificate",
    recordLength: null,
    helpRegistry: "hGR.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "GRi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hgrd_mod_date"       : { canonical: "hGRd_Mod_Date"       , type: "DATE", tableCode: "GR" },
        "hgrd_spare"          : { canonical: "hGRd_Spare"          , type: "DATE", tableCode: "GR" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hgrf_spare"          : { canonical: "hGRf_Spare"          , type: "DOUBLE", tableCode: "GR" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hgrl_block_no"       : { canonical: "hGRl_Block_No"       , type: "INTEGER", tableCode: "GR" },
        "hgrl_spare"          : { canonical: "hGRl_Spare"          , type: "INTEGER", tableCode: "GR" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hgrs_total_allocated": { canonical: "hGRs_Total_Allocated", type: "INTEGER", tableCode: "GR" },
        "hgrs_total_cancelled": { canonical: "hGRs_Total_Cancelled", type: "INTEGER", tableCode: "GR" },
        "hgrs_total_no_block" : { canonical: "hGRs_Total_No_Block" , type: "INTEGER", tableCode: "GR" },
        "hgrs_total_used"     : { canonical: "hGRs_Total_Used"     , type: "INTEGER", tableCode: "GR" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hgrt_mod_time"       : { canonical: "hGRt_Mod_Time"       , type: "TIME", tableCode: "GR" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hgrz_division"       : { canonical: "hGRz_Division"       , type: "STRING", tableCode: "GR" },
        "hgrz_finish_no"      : { canonical: "hGRz_Finish_No"      , type: "STRING", tableCode: "GR" },
        "hgrz_fund"           : { canonical: "hGRz_Fund"           , type: "STRING", tableCode: "GR" },
        "hgrz_last_given_no"  : { canonical: "hGRz_Last_Given_No"  , type: "STRING", tableCode: "GR" },
        "hgrz_mod_user"       : { canonical: "hGRz_Mod_User"       , type: "STRING", tableCode: "GR" },
        "hgrz_record_type"    : { canonical: "hGRz_Record_Type"    , type: "STRING", tableCode: "GR" },
        "hgrz_spare"          : { canonical: "hGRz_Spare"          , type: "STRING", tableCode: "GR" },
        "hgrz_start_no"       : { canonical: "hGRz_Start_No"       , type: "STRING", tableCode: "GR" },
        "hgrz_status"         : { canonical: "hGRz_Status"         , type: "STRING", tableCode: "GR" },
        "hgrz_transactions01" : { canonical: "hGRz_Transactions01" , type: "STRING", tableCode: "GR" },
        "hgrz_transactions02" : { canonical: "hGRz_Transactions02" , type: "STRING", tableCode: "GR" },
        "hgrz_transactions03" : { canonical: "hGRz_Transactions03" , type: "STRING", tableCode: "GR" },
        "hgrz_transactions04" : { canonical: "hGRz_Transactions04" , type: "STRING", tableCode: "GR" },
        "hgrz_transactions05" : { canonical: "hGRz_Transactions05" , type: "STRING", tableCode: "GR" },
        "hgrz_type"           : { canonical: "hGRz_Type"           , type: "STRING", tableCode: "GR" },
    }
};

export default GR;
