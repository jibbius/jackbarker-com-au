/**
 * DV.js — table structure for the DV (Global Information) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "DV").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force DV
 */

/** @type {Object} */
const DV = {
    code: "DV",
    name: "Global_Information",
    recordLength: null,
    helpRegistry: "hDV.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "DVi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hdvc_allow_alloc_pens": { canonical: "hDVc_Allow_Alloc_Pens", type: "STRING", tableCode: "DV" },
        "hdvc_conts_splitting" : { canonical: "hDVc_Conts_Splitting" , type: "STRING", tableCode: "DV" },
        "hdvc_event_handling"  : { canonical: "hDVc_Event_Handling"  , type: "STRING", tableCode: "DV" },
        "hdvc_extension_code"  : { canonical: "hDVc_Extension_Code"  , type: "STRING", tableCode: "DV" },
        "hdvc_invest_system"   : { canonical: "hDVc_Invest_System"   , type: "STRING", tableCode: "DV" },
        "hdvc_model_portfolio" : { canonical: "hDVc_Model_Portfolio" , type: "STRING", tableCode: "DV" },
        "hdvc_mult_employers"  : { canonical: "hDVc_Mult_Employers"  , type: "STRING", tableCode: "DV" },
        "hdvc_pensions"        : { canonical: "hDVc_Pensions"        , type: "STRING", tableCode: "DV" },
        "hdvc_qrops"           : { canonical: "hDVc_QROPS"           , type: "STRING", tableCode: "DV" },
        "hdvc_receipting"      : { canonical: "hDVc_Receipting"      , type: "STRING", tableCode: "DV" },
        "hdvc_term_alloc_pens" : { canonical: "hDVc_Term_Alloc_Pens" , type: "STRING", tableCode: "DV" },
        "hdvc_tiered_interest" : { canonical: "hDVc_Tiered_Interest" , type: "STRING", tableCode: "DV" },
        "hdvc_trans_to_retire" : { canonical: "hDVc_Trans_to_Retire" , type: "STRING", tableCode: "DV" },
        "hdvc_webuser"         : { canonical: "hDVc_WebUser"         , type: "STRING", tableCode: "DV" },
        "hdvc_word_integration": { canonical: "hDVc_Word_Integration", type: "STRING", tableCode: "DV" },
        "hdvc_workbench"       : { canonical: "hDVc_Workbench"       , type: "STRING", tableCode: "DV" },
        "hdvc_xci"             : { canonical: "hDVc_XCI"             , type: "STRING", tableCode: "DV" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hdvz_division"        : { canonical: "hDVz_Division"        , type: "STRING", tableCode: "DV" },
        "hdvz_report_list"     : { canonical: "hDVz_Report_List"     , type: "STRING", tableCode: "DV" },
        "hdvz_spare"           : { canonical: "hDVz_Spare"           , type: "STRING", tableCode: "DV" },
    }
};

export default DV;
