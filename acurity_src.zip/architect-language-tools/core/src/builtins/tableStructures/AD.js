/**
 * AD.js — table structure for the AD (Member Contribution Adjustment History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AD").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AD
 */

/** @type {Object} */
const AD = {
    code: "AD",
    name: "Member_Contribution_Adjustment_History",
    recordLength: null,
    helpRegistry: "hAD.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ADi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hadc_new_work_status": { canonical: "hADc_New_Work_Status", type: "STRING", tableCode: "AD" },
        "hadc_old_work_status": { canonical: "hADc_Old_Work_Status", type: "STRING", tableCode: "AD" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hadd_effective"      : { canonical: "hADd_Effective"      , type: "DATE", tableCode: "AD" },
        "hadd_mod_date"       : { canonical: "hADd_Mod_Date"       , type: "DATE", tableCode: "AD" },
        "hadd_new_end"        : { canonical: "hADd_New_End"        , type: "DATE", tableCode: "AD" },
        "hadd_old_effective"  : { canonical: "hADd_Old_Effective"  , type: "DATE", tableCode: "AD" },
        "hadd_old_end"        : { canonical: "hADd_Old_End"        , type: "DATE", tableCode: "AD" },
        "hadd_processed"      : { canonical: "hADd_Processed"      , type: "DATE", tableCode: "AD" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hadf_backdated_adj"  : { canonical: "hADf_Backdated_Adj"  , type: "DOUBLE", tableCode: "AD" },
        "hadf_new_ptime_sal"  : { canonical: "hADf_New_Ptime_Sal"  , type: "DOUBLE", tableCode: "AD" },
        "hadf_new_salary"     : { canonical: "hADf_New_Salary"     , type: "DOUBLE", tableCode: "AD" },
        "hadf_old_ptime_sal"  : { canonical: "hADf_Old_Ptime_Sal"  , type: "DOUBLE", tableCode: "AD" },
        "hadf_old_salary"     : { canonical: "hADf_Old_Salary"     , type: "DOUBLE", tableCode: "AD" },
        "hadf_regular_adj"    : { canonical: "hADf_Regular_Adj"    , type: "DOUBLE", tableCode: "AD" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hadl_reversing_ref"  : { canonical: "hADl_Reversing_Ref"  , type: "INTEGER", tableCode: "AD" },
        "hadl_trans_ref"      : { canonical: "hADl_Trans_Ref"      , type: "INTEGER", tableCode: "AD" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hadt_mod_time"       : { canonical: "hADt_Mod_Time"       , type: "TIME", tableCode: "AD" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hadz_division"       : { canonical: "hADz_Division"       , type: "STRING", tableCode: "AD" },
        "hadz_fund"           : { canonical: "hADz_Fund"           , type: "STRING", tableCode: "AD" },
        "hadz_member"         : { canonical: "hADz_Member"         , type: "STRING", tableCode: "AD" },
        "hadz_mod_user"       : { canonical: "hADz_Mod_User"       , type: "STRING", tableCode: "AD" },
        "hadz_payroll"        : { canonical: "hADz_Payroll"        , type: "STRING", tableCode: "AD" },
        "hadz_reason"         : { canonical: "hADz_Reason"         , type: "STRING", tableCode: "AD" },
        "hadz_spare"          : { canonical: "hADz_Spare"          , type: "STRING", tableCode: "AD" },
    }
};

export default AD;
