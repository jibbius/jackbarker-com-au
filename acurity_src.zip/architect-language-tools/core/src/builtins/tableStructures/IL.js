/**
 * IL.js — table structure for the IL (Insurance Category Defaults) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "IL").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force IL
 */

/** @type {Object} */
const IL = {
    code: "IL",
    name: "Insurance_Category_Defaults",
    recordLength: null,
    helpRegistry: "hIL.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ILi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hilc_deleted"         : { canonical: "hILc_Deleted"         , type: "STRING", tableCode: "IL" },
        "hilc_tapering_applies": { canonical: "hILc_Tapering_Applies", type: "STRING", tableCode: "IL" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hild_effective"       : { canonical: "hILd_Effective"       , type: "DATE", tableCode: "IL" },
        "hild_mod_date"        : { canonical: "hILd_Mod_Date"        , type: "DATE", tableCode: "IL" },
        "hild_spare"           : { canonical: "hILd_Spare"           , type: "DATE", tableCode: "IL" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hilf_crb"             : { canonical: "hILf_CRB"             , type: "DOUBLE", tableCode: "IL" },
        "hilf_dollar_default"  : { canonical: "hILf_Dollar_Default"  , type: "DOUBLE", tableCode: "IL" },
        "hilf_dollar_maximum"  : { canonical: "hILf_Dollar_Maximum"  , type: "DOUBLE", tableCode: "IL" },
        "hilf_dollar_minimum"  : { canonical: "hILf_Dollar_Minimum"  , type: "DOUBLE", tableCode: "IL" },
        "hilf_percent_maximum" : { canonical: "hILf_Percent_Maximum" , type: "DOUBLE", tableCode: "IL" },
        "hilf_percent_minimum" : { canonical: "hILf_Percent_Minimum" , type: "DOUBLE", tableCode: "IL" },
        "hilf_percent_salary"  : { canonical: "hILf_Percent_Salary"  , type: "DOUBLE", tableCode: "IL" },
        "hilf_units_default"   : { canonical: "hILf_Units_Default"   , type: "DOUBLE", tableCode: "IL" },
        "hilf_units_maximum"   : { canonical: "hILf_Units_Maximum"   , type: "DOUBLE", tableCode: "IL" },
        "hilf_units_minimum"   : { canonical: "hILf_Units_Minimum"   , type: "DOUBLE", tableCode: "IL" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hils_max_inc_age"     : { canonical: "hILs_Max_Inc_Age"     , type: "INTEGER", tableCode: "IL" },
        "hils_max_joining_age" : { canonical: "hILs_Max_Joining_Age" , type: "INTEGER", tableCode: "IL" },
        "hils_maximum_age"     : { canonical: "hILs_Maximum_Age"     , type: "INTEGER", tableCode: "IL" },
        "hils_minimum_age"     : { canonical: "hILs_Minimum_Age"     , type: "INTEGER", tableCode: "IL" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hilt_mod_time"        : { canonical: "hILt_Mod_Time"        , type: "TIME", tableCode: "IL" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hilz_benefit_period"  : { canonical: "hILz_Benefit_Period"  , type: "STRING", tableCode: "IL" },
        "hilz_benefit_type"    : { canonical: "hILz_Benefit_Type"    , type: "STRING", tableCode: "IL" },
        "hilz_defaults_table"  : { canonical: "hILz_Defaults_Table"  , type: "STRING", tableCode: "IL" },
        "hilz_dollar_max_table": { canonical: "hILz_Dollar_Max_Table", type: "STRING", tableCode: "IL" },
        "hilz_insurance_cat"   : { canonical: "hILz_Insurance_Cat"   , type: "STRING", tableCode: "IL" },
        "hilz_insurer"         : { canonical: "hILz_Insurer"         , type: "STRING", tableCode: "IL" },
        "hilz_mod_user"        : { canonical: "hILz_Mod_User"        , type: "STRING", tableCode: "IL" },
        "hilz_percentmax_table": { canonical: "hILz_PercentMax_Table", type: "STRING", tableCode: "IL" },
        "hilz_supp_record_type": { canonical: "hILz_Supp_Record_Type", type: "STRING", tableCode: "IL" },
        "hilz_units_max_table" : { canonical: "hILz_Units_Max_Table" , type: "STRING", tableCode: "IL" },
        "hilz_waiting_period"  : { canonical: "hILz_Waiting_Period"  , type: "STRING", tableCode: "IL" },
    }
};

export default IL;
