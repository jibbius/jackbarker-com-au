/**
 * CN.js — table structure for the CN (Corporate Actions) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CN").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CN
 */

/** @type {Object} */
const CN = {
    code: "CN",
    name: "Corporate_Actions",
    recordLength: null,
    helpRegistry: "hCN.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CNi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hcnc_invbalnotreq"    : { canonical: "hCNc_InvBalNotReq"    , type: "STRING", tableCode: "CN" },
        "hcnc_notes"           : { canonical: "hCNc_Notes"           , type: "STRING", tableCode: "CN" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hcnd_announcement"    : { canonical: "hCNd_Announcement"    , type: "DATE", tableCode: "CN" },
        "hcnd_electionend"     : { canonical: "hCNd_ElectionEnd"     , type: "DATE", tableCode: "CN" },
        "hcnd_issue"           : { canonical: "hCNd_Issue"           , type: "DATE", tableCode: "CN" },
        "hcnd_mod_date"        : { canonical: "hCNd_Mod_Date"        , type: "DATE", tableCode: "CN" },
        "hcnd_record"          : { canonical: "hCNd_Record"          , type: "DATE", tableCode: "CN" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hcnf_from_ratio"      : { canonical: "hCNf_From_Ratio"      , type: "DOUBLE", tableCode: "CN" },
        "hcnf_max_amount"      : { canonical: "hCNf_Max_Amount"      , type: "DOUBLE", tableCode: "CN" },
        "hcnf_min_amount"      : { canonical: "hCNf_Min_Amount"      , type: "DOUBLE", tableCode: "CN" },
        "hcnf_no_of_shares"    : { canonical: "hCNf_No_Of_Shares"    , type: "DOUBLE", tableCode: "CN" },
        "hcnf_reserve_cash_amt": { canonical: "hCNf_Reserve_Cash_Amt", type: "DOUBLE", tableCode: "CN" },
        "hcnf_spp_bandamount01": { canonical: "hCNf_SPP_BandAmount01", type: "DOUBLE", tableCode: "CN" },
        "hcnf_spp_bandamount02": { canonical: "hCNf_SPP_BandAmount02", type: "DOUBLE", tableCode: "CN" },
        "hcnf_spp_bandamount03": { canonical: "hCNf_SPP_BandAmount03", type: "DOUBLE", tableCode: "CN" },
        "hcnf_spp_bandamount04": { canonical: "hCNf_SPP_BandAmount04", type: "DOUBLE", tableCode: "CN" },
        "hcnf_spp_bandamount05": { canonical: "hCNf_SPP_BandAmount05", type: "DOUBLE", tableCode: "CN" },
        "hcnf_to_ratio"        : { canonical: "hCNf_To_Ratio"        , type: "DOUBLE", tableCode: "CN" },
        "hcnf_unit_balance"    : { canonical: "hCNf_Unit_Balance"    , type: "DOUBLE", tableCode: "CN" },
        "hcnf_unit_price"      : { canonical: "hCNf_Unit_Price"      , type: "DOUBLE", tableCode: "CN" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hcnl_corpactionid"    : { canonical: "hCNl_CorpActionId"    , type: "INTEGER", tableCode: "CN" },
        "hcnl_electiontransref": { canonical: "hCNl_ElectionTransRef", type: "INTEGER", tableCode: "CN" },
        "hcnl_exercisetransref": { canonical: "hCNl_ExerciseTransRef", type: "INTEGER", tableCode: "CN" },
        "hcnl_issue_trans_ref" : { canonical: "hCNl_Issue_Trans_Ref" , type: "INTEGER", tableCode: "CN" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hcnt_mod_time"        : { canonical: "hCNt_Mod_Time"        , type: "TIME", tableCode: "CN" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcnz_corpactionref"   : { canonical: "hCNz_CorpActionRef"   , type: "STRING", tableCode: "CN" },
        "hcnz_division"        : { canonical: "hCNz_Division"        , type: "STRING", tableCode: "CN" },
        "hcnz_electiondivision": { canonical: "hCNz_ElectionDivision", type: "STRING", tableCode: "CN" },
        "hcnz_electionrequired": { canonical: "hCNz_ElectionRequired", type: "STRING", tableCode: "CN" },
        "hcnz_eventtype"       : { canonical: "hCNz_EventType"       , type: "STRING", tableCode: "CN" },
        "hcnz_exercisedivision": { canonical: "hCNz_ExerciseDivision", type: "STRING", tableCode: "CN" },
        "hcnz_fund"            : { canonical: "hCNz_Fund"            , type: "STRING", tableCode: "CN" },
        "hcnz_invmgr"          : { canonical: "hCNz_InvMgr"          , type: "STRING", tableCode: "CN" },
        "hcnz_issue_division"  : { canonical: "hCNz_Issue_Division"  , type: "STRING", tableCode: "CN" },
        "hcnz_mod_user"        : { canonical: "hCNz_Mod_User"        , type: "STRING", tableCode: "CN" },
        "hcnz_participate"     : { canonical: "hCNz_Participate"     , type: "STRING", tableCode: "CN" },
        "hcnz_spare"           : { canonical: "hCNz_Spare"           , type: "STRING", tableCode: "CN" },
        "hcnz_status"          : { canonical: "hCNz_Status"          , type: "STRING", tableCode: "CN" },
        "hcnz_tablecode"       : { canonical: "hCNz_TableCode"       , type: "STRING", tableCode: "CN" },
        "hcnz_to_invmgr"       : { canonical: "hCNz_To_InvMgr"       , type: "STRING", tableCode: "CN" },
    }
};

export default CN;
