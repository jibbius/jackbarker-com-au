/**
 * CM.js — table structure for the CM (Client Match) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "CM").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force CM
 */

/** @type {Object} */
const CM = {
    code: "CM",
    name: "Client_Match",
    recordLength: null,
    helpRegistry: "hCM.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "CMi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hcmz_client"         : { canonical: "hCMz_Client"         , type: "STRING", tableCode: "CM" },
        "hcmz_search_fragment": { canonical: "hCMz_Search_Fragment", type: "STRING", tableCode: "CM" },
        "hcmz_spare"          : { canonical: "hCMz_Spare"          , type: "STRING", tableCode: "CM" },
    }
};

export default CM;
