/**
 * AN.js — table structure for the AN (Address Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AN").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AN
 */

/** @type {Object} */
const AN = {
    code: "AN",
    name: "Address_Details",
    recordLength: null,
    helpRegistry: "hAN.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ANi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hanc_deleted"       : { canonical: "hANc_Deleted"       , type: "STRING", tableCode: "AN" },
        "hanc_valid_address" : { canonical: "hANc_Valid_Address" , type: "STRING", tableCode: "AN" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hand_mod_date"      : { canonical: "hANd_Mod_Date"      , type: "DATE", tableCode: "AN" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hanl_file_reg_ref"  : { canonical: "hANl_File_Reg_Ref"  , type: "INTEGER", tableCode: "AN" },
        "hanl_line_no"       : { canonical: "hANl_Line_No"       , type: "INTEGER", tableCode: "AN" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hant_mod_time"      : { canonical: "hANt_Mod_Time"      , type: "TIME", tableCode: "AN" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hanz_address_line01": { canonical: "hANz_Address_Line01", type: "STRING", tableCode: "AN" },
        "hanz_address_line02": { canonical: "hANz_Address_Line02", type: "STRING", tableCode: "AN" },
        "hanz_address_line03": { canonical: "hANz_Address_Line03", type: "STRING", tableCode: "AN" },
        "hanz_address_line04": { canonical: "hANz_Address_Line04", type: "STRING", tableCode: "AN" },
        "hanz_address_type"  : { canonical: "hANz_Address_Type"  , type: "STRING", tableCode: "AN" },
        "hanz_country"       : { canonical: "hANz_Country"       , type: "STRING", tableCode: "AN" },
        "hanz_country_code"  : { canonical: "hANz_Country_Code"  , type: "STRING", tableCode: "AN" },
        "hanz_dpid_code"     : { canonical: "hANz_DPID_Code"     , type: "STRING", tableCode: "AN" },
        "hanz_file_code"     : { canonical: "hANz_File_Code"     , type: "STRING", tableCode: "AN" },
        "hanz_key_field"     : { canonical: "hANz_Key_Field"     , type: "STRING", tableCode: "AN" },
        "hanz_mod_user"      : { canonical: "hANz_Mod_User"      , type: "STRING", tableCode: "AN" },
        "hanz_postcode"      : { canonical: "hANz_Postcode"      , type: "STRING", tableCode: "AN" },
        "hanz_record_type"   : { canonical: "hANz_Record_Type"   , type: "STRING", tableCode: "AN" },
        "hanz_spare"         : { canonical: "hANz_Spare"         , type: "STRING", tableCode: "AN" },
        "hanz_state"         : { canonical: "hANz_State"         , type: "STRING", tableCode: "AN" },
        "hanz_suburb"        : { canonical: "hANz_Suburb"        , type: "STRING", tableCode: "AN" },
    }
};

export default AN;
