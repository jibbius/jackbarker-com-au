/**
 * AC.js — table structure for the AC (Archive) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "AC").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force AC
 */

/** @type {Object} */
const AC = {
    code: "AC",
    name: "Archive",
    recordLength: null,
    helpRegistry: "hAC.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "ACi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hacc_clean_output" : { canonical: "hACc_Clean_Output" , type: "STRING", tableCode: "AC" },
        "hacc_status"       : { canonical: "hACc_Status"       , type: "STRING", tableCode: "AC" },
        "hacc_type"         : { canonical: "hACc_Type"         , type: "STRING", tableCode: "AC" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hacd_applies"      : { canonical: "hACd_Applies"      , type: "DATE", tableCode: "AC" },
        "hacd_mod_date"     : { canonical: "hACd_Mod_Date"     , type: "DATE", tableCode: "AC" },
        "hacd_spare"        : { canonical: "hACd_Spare"        , type: "DATE", tableCode: "AC" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hacf_spare"        : { canonical: "hACf_Spare"        , type: "DOUBLE", tableCode: "AC" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hact_mod_time"     : { canonical: "hACt_Mod_Time"     , type: "TIME", tableCode: "AC" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hacz_division"     : { canonical: "hACz_Division"     , type: "STRING", tableCode: "AC" },
        "hacz_file01"       : { canonical: "hACz_File01"       , type: "STRING", tableCode: "AC" },
        "hacz_file02"       : { canonical: "hACz_File02"       , type: "STRING", tableCode: "AC" },
        "hacz_file03"       : { canonical: "hACz_File03"       , type: "STRING", tableCode: "AC" },
        "hacz_file04"       : { canonical: "hACz_File04"       , type: "STRING", tableCode: "AC" },
        "hacz_file05"       : { canonical: "hACz_File05"       , type: "STRING", tableCode: "AC" },
        "hacz_file06"       : { canonical: "hACz_File06"       , type: "STRING", tableCode: "AC" },
        "hacz_file07"       : { canonical: "hACz_File07"       , type: "STRING", tableCode: "AC" },
        "hacz_file08"       : { canonical: "hACz_File08"       , type: "STRING", tableCode: "AC" },
        "hacz_file09"       : { canonical: "hACz_File09"       , type: "STRING", tableCode: "AC" },
        "hacz_file10"       : { canonical: "hACz_File10"       , type: "STRING", tableCode: "AC" },
        "hacz_file11"       : { canonical: "hACz_File11"       , type: "STRING", tableCode: "AC" },
        "hacz_file12"       : { canonical: "hACz_File12"       , type: "STRING", tableCode: "AC" },
        "hacz_file13"       : { canonical: "hACz_File13"       , type: "STRING", tableCode: "AC" },
        "hacz_file14"       : { canonical: "hACz_File14"       , type: "STRING", tableCode: "AC" },
        "hacz_file15"       : { canonical: "hACz_File15"       , type: "STRING", tableCode: "AC" },
        "hacz_file16"       : { canonical: "hACz_File16"       , type: "STRING", tableCode: "AC" },
        "hacz_file17"       : { canonical: "hACz_File17"       , type: "STRING", tableCode: "AC" },
        "hacz_file18"       : { canonical: "hACz_File18"       , type: "STRING", tableCode: "AC" },
        "hacz_file19"       : { canonical: "hACz_File19"       , type: "STRING", tableCode: "AC" },
        "hacz_file20"       : { canonical: "hACz_File20"       , type: "STRING", tableCode: "AC" },
        "hacz_file21"       : { canonical: "hACz_File21"       , type: "STRING", tableCode: "AC" },
        "hacz_file22"       : { canonical: "hACz_File22"       , type: "STRING", tableCode: "AC" },
        "hacz_file23"       : { canonical: "hACz_File23"       , type: "STRING", tableCode: "AC" },
        "hacz_file24"       : { canonical: "hACz_File24"       , type: "STRING", tableCode: "AC" },
        "hacz_file25"       : { canonical: "hACz_File25"       , type: "STRING", tableCode: "AC" },
        "hacz_file26"       : { canonical: "hACz_File26"       , type: "STRING", tableCode: "AC" },
        "hacz_file27"       : { canonical: "hACz_File27"       , type: "STRING", tableCode: "AC" },
        "hacz_file28"       : { canonical: "hACz_File28"       , type: "STRING", tableCode: "AC" },
        "hacz_file29"       : { canonical: "hACz_File29"       , type: "STRING", tableCode: "AC" },
        "hacz_file30"       : { canonical: "hACz_File30"       , type: "STRING", tableCode: "AC" },
        "hacz_file31"       : { canonical: "hACz_File31"       , type: "STRING", tableCode: "AC" },
        "hacz_file32"       : { canonical: "hACz_File32"       , type: "STRING", tableCode: "AC" },
        "hacz_file33"       : { canonical: "hACz_File33"       , type: "STRING", tableCode: "AC" },
        "hacz_file34"       : { canonical: "hACz_File34"       , type: "STRING", tableCode: "AC" },
        "hacz_file35"       : { canonical: "hACz_File35"       , type: "STRING", tableCode: "AC" },
        "hacz_file36"       : { canonical: "hACz_File36"       , type: "STRING", tableCode: "AC" },
        "hacz_file37"       : { canonical: "hACz_File37"       , type: "STRING", tableCode: "AC" },
        "hacz_file38"       : { canonical: "hACz_File38"       , type: "STRING", tableCode: "AC" },
        "hacz_file39"       : { canonical: "hACz_File39"       , type: "STRING", tableCode: "AC" },
        "hacz_file40"       : { canonical: "hACz_File40"       , type: "STRING", tableCode: "AC" },
        "hacz_file41"       : { canonical: "hACz_File41"       , type: "STRING", tableCode: "AC" },
        "hacz_file42"       : { canonical: "hACz_File42"       , type: "STRING", tableCode: "AC" },
        "hacz_file43"       : { canonical: "hACz_File43"       , type: "STRING", tableCode: "AC" },
        "hacz_file44"       : { canonical: "hACz_File44"       , type: "STRING", tableCode: "AC" },
        "hacz_file45"       : { canonical: "hACz_File45"       , type: "STRING", tableCode: "AC" },
        "hacz_file46"       : { canonical: "hACz_File46"       , type: "STRING", tableCode: "AC" },
        "hacz_file47"       : { canonical: "hACz_File47"       , type: "STRING", tableCode: "AC" },
        "hacz_file48"       : { canonical: "hACz_File48"       , type: "STRING", tableCode: "AC" },
        "hacz_file49"       : { canonical: "hACz_File49"       , type: "STRING", tableCode: "AC" },
        "hacz_file50"       : { canonical: "hACz_File50"       , type: "STRING", tableCode: "AC" },
        "hacz_file51"       : { canonical: "hACz_File51"       , type: "STRING", tableCode: "AC" },
        "hacz_file52"       : { canonical: "hACz_File52"       , type: "STRING", tableCode: "AC" },
        "hacz_file53"       : { canonical: "hACz_File53"       , type: "STRING", tableCode: "AC" },
        "hacz_file54"       : { canonical: "hACz_File54"       , type: "STRING", tableCode: "AC" },
        "hacz_file55"       : { canonical: "hACz_File55"       , type: "STRING", tableCode: "AC" },
        "hacz_file56"       : { canonical: "hACz_File56"       , type: "STRING", tableCode: "AC" },
        "hacz_file57"       : { canonical: "hACz_File57"       , type: "STRING", tableCode: "AC" },
        "hacz_file58"       : { canonical: "hACz_File58"       , type: "STRING", tableCode: "AC" },
        "hacz_file59"       : { canonical: "hACz_File59"       , type: "STRING", tableCode: "AC" },
        "hacz_file60"       : { canonical: "hACz_File60"       , type: "STRING", tableCode: "AC" },
        "hacz_function_name": { canonical: "hACz_Function_Name", type: "STRING", tableCode: "AC" },
        "hacz_fund"         : { canonical: "hACz_Fund"         , type: "STRING", tableCode: "AC" },
        "hacz_mod_user"     : { canonical: "hACz_Mod_User"     , type: "STRING", tableCode: "AC" },
        "hacz_number"       : { canonical: "hACz_Number"       , type: "STRING", tableCode: "AC" },
        "hacz_spare"        : { canonical: "hACz_Spare"        , type: "STRING", tableCode: "AC" },
        "hacz_version"      : { canonical: "hACz_Version"      , type: "STRING", tableCode: "AC" },
    }
};

export default AC;
