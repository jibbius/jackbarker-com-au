/**
 * NT.js — table structure for the NT (New Zealand - Insurance Records) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "NT").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force NT
 */

/** @type {Object} */
const NT = {
    code: "NT",
    name: "New_Zealand_-_Insurance_Records",
    recordLength: null,
    helpRegistry: "hNT.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "NTi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hntc_spare"           : { canonical: "hNTc_Spare"           , type: "STRING", tableCode: "NT" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hntf_cont_amt_rcvd"   : { canonical: "hNTf_Cont_Amt_Rcvd"   , type: "DOUBLE", tableCode: "NT" },
        "hntf_cont_overall"    : { canonical: "hNTf_Cont_Overall"    , type: "DOUBLE", tableCode: "NT" },
        "hntf_cont_ytd"        : { canonical: "hNTf_Cont_YTD"        , type: "DOUBLE", tableCode: "NT" },
        "hntf_exp_ann_cont"    : { canonical: "hNTf_Exp_Ann_Cont"    , type: "DOUBLE", tableCode: "NT" },
        "hntf_exp_renewal_ytd" : { canonical: "hNTf_Exp_Renewal_YTD" , type: "DOUBLE", tableCode: "NT" },
        "hntf_first_year_ytd"  : { canonical: "hNTf_First_Year_YTD"  , type: "DOUBLE", tableCode: "NT" },
        "hntf_highst_prev_cont": { canonical: "hNTf_Highst_Prev_Cont", type: "DOUBLE", tableCode: "NT" },
        "hntf_inc_exp_init_ytd": { canonical: "hNTf_Inc_Exp_Init_YTD", type: "DOUBLE", tableCode: "NT" },
        "hntf_inc_exp_ren_ytd" : { canonical: "hNTf_Inc_Exp_Ren_YTD" , type: "DOUBLE", tableCode: "NT" },
        "hntf_init_or_inc_comm": { canonical: "hNTf_Init_Or_Inc_Comm", type: "DOUBLE", tableCode: "NT" },
        "hntf_init_or_inc_fee" : { canonical: "hNTf_Init_Or_Inc_Fee" , type: "DOUBLE", tableCode: "NT" },
        "hntf_renewal_amt"     : { canonical: "hNTf_Renewal_Amt"     , type: "DOUBLE", tableCode: "NT" },
        "hntf_renewal_comm"    : { canonical: "hNTf_Renewal_Comm"    , type: "DOUBLE", tableCode: "NT" },
        "hntf_renewal_fee"     : { canonical: "hNTf_Renewal_Fee"     , type: "DOUBLE", tableCode: "NT" },
        "hntf_renewal_ytd"     : { canonical: "hNTf_Renewal_YTD"     , type: "DOUBLE", tableCode: "NT" },
        "hntf_tot_init_inc_com": { canonical: "hNTf_Tot_Init_Inc_Com", type: "DOUBLE", tableCode: "NT" },
        "hntf_tot_init_inc_fee": { canonical: "hNTf_Tot_Init_Inc_Fee", type: "DOUBLE", tableCode: "NT" },
        "hntf_tot_renewal_comm": { canonical: "hNTf_Tot_Renewal_Comm", type: "DOUBLE", tableCode: "NT" },
        "hntf_tot_renewal_fee" : { canonical: "hNTf_Tot_Renewal_Fee" , type: "DOUBLE", tableCode: "NT" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hntl_trans_ref"       : { canonical: "hNTl_Trans_Ref"       , type: "INTEGER", tableCode: "NT" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hntz_cont_type"       : { canonical: "hNTz_Cont_Type"       , type: "STRING", tableCode: "NT" },
        "hntz_division"        : { canonical: "hNTz_Division"        , type: "STRING", tableCode: "NT" },
        "hntz_fund"            : { canonical: "hNTz_Fund"            , type: "STRING", tableCode: "NT" },
        "hntz_member"          : { canonical: "hNTz_Member"          , type: "STRING", tableCode: "NT" },
        "hntz_spare"           : { canonical: "hNTz_Spare"           , type: "STRING", tableCode: "NT" },
    }
};

export default NT;
