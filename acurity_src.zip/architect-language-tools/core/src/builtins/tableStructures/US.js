/**
 * US.js — table structure for the US (User Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "US").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force US
 */

/** @type {Object} */
const US = {
    code: "US",
    name: "User_Details",
    recordLength: null,
    helpRegistry: "hUS.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "USi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "husc_as400_printer"   : { canonical: "hUSc_AS400_Printer"   , type: "STRING", tableCode: "US" },
        "husc_auto_diary"      : { canonical: "hUSc_Auto_Diary"      , type: "STRING", tableCode: "US" },
        "husc_customisations"  : { canonical: "hUSc_Customisations"  , type: "STRING", tableCode: "US" },
        "husc_deleted"         : { canonical: "hUSc_Deleted"         , type: "STRING", tableCode: "US" },
        "husc_force_pswd_chng" : { canonical: "hUSc_Force_Pswd_Chng" , type: "STRING", tableCode: "US" },
        "husc_level"           : { canonical: "hUSc_Level"           , type: "STRING", tableCode: "US" },
        "husc_num_pwd_fails"   : { canonical: "hUSc_Num_Pwd_Fails"   , type: "STRING", tableCode: "US" },
        "husc_payroll_security": { canonical: "hUSc_Payroll_Security", type: "STRING", tableCode: "US" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "husd_birthday"        : { canonical: "hUSd_Birthday"        , type: "DATE", tableCode: "US" },
        "husd_last_pwd_change" : { canonical: "hUSd_Last_Pwd_Change" , type: "DATE", tableCode: "US" },
        "husd_mod_date"        : { canonical: "hUSd_Mod_Date"        , type: "DATE", tableCode: "US" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "husl_port_number"     : { canonical: "hUSl_Port_Number"     , type: "INTEGER", tableCode: "US" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hust_mod_time"        : { canonical: "hUSt_Mod_Time"        , type: "TIME", tableCode: "US" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "husz_as400_user_prf"  : { canonical: "hUSz_AS400_User_Prf"  , type: "STRING", tableCode: "US" },
        "husz_client"          : { canonical: "hUSz_Client"          , type: "STRING", tableCode: "US" },
        "husz_email"           : { canonical: "hUSz_Email"           , type: "STRING", tableCode: "US" },
        "husz_fund_exit_sec"   : { canonical: "hUSz_Fund_Exit_Sec"   , type: "STRING", tableCode: "US" },
        "husz_fund_security01" : { canonical: "hUSz_Fund_Security01" , type: "STRING", tableCode: "US" },
        "husz_fund_security02" : { canonical: "hUSz_Fund_Security02" , type: "STRING", tableCode: "US" },
        "husz_fund_security03" : { canonical: "hUSz_Fund_Security03" , type: "STRING", tableCode: "US" },
        "husz_fund_security04" : { canonical: "hUSz_Fund_Security04" , type: "STRING", tableCode: "US" },
        "husz_fund_security05" : { canonical: "hUSz_Fund_Security05" , type: "STRING", tableCode: "US" },
        "husz_fund_security06" : { canonical: "hUSz_Fund_Security06" , type: "STRING", tableCode: "US" },
        "husz_fund_security07" : { canonical: "hUSz_Fund_Security07" , type: "STRING", tableCode: "US" },
        "husz_fund_security08" : { canonical: "hUSz_Fund_Security08" , type: "STRING", tableCode: "US" },
        "husz_fund_security09" : { canonical: "hUSz_Fund_Security09" , type: "STRING", tableCode: "US" },
        "husz_fund_security10" : { canonical: "hUSz_Fund_Security10" , type: "STRING", tableCode: "US" },
        "husz_fund_security11" : { canonical: "hUSz_Fund_Security11" , type: "STRING", tableCode: "US" },
        "husz_fund_security12" : { canonical: "hUSz_Fund_Security12" , type: "STRING", tableCode: "US" },
        "husz_fund_security13" : { canonical: "hUSz_Fund_Security13" , type: "STRING", tableCode: "US" },
        "husz_fund_security14" : { canonical: "hUSz_Fund_Security14" , type: "STRING", tableCode: "US" },
        "husz_fund_security15" : { canonical: "hUSz_Fund_Security15" , type: "STRING", tableCode: "US" },
        "husz_fund_security16" : { canonical: "hUSz_Fund_Security16" , type: "STRING", tableCode: "US" },
        "husz_fund_security17" : { canonical: "hUSz_Fund_Security17" , type: "STRING", tableCode: "US" },
        "husz_fund_security18" : { canonical: "hUSz_Fund_Security18" , type: "STRING", tableCode: "US" },
        "husz_fund_security19" : { canonical: "hUSz_Fund_Security19" , type: "STRING", tableCode: "US" },
        "husz_fund_security20" : { canonical: "hUSz_Fund_Security20" , type: "STRING", tableCode: "US" },
        "husz_fund_tran_sec"   : { canonical: "hUSz_Fund_Tran_Sec"   , type: "STRING", tableCode: "US" },
        "husz_ldap_user_id"    : { canonical: "hUSz_LDAP_User_ID"    , type: "STRING", tableCode: "US" },
        "husz_mod_user"        : { canonical: "hUSz_Mod_User"        , type: "STRING", tableCode: "US" },
        "husz_name"            : { canonical: "hUSz_Name"            , type: "STRING", tableCode: "US" },
        "husz_password"        : { canonical: "hUSz_Password"        , type: "STRING", tableCode: "US" },
        "husz_payroll"         : { canonical: "hUSz_Payroll"         , type: "STRING", tableCode: "US" },
        "husz_spare"           : { canonical: "hUSz_Spare"           , type: "STRING", tableCode: "US" },
        "husz_user_group"      : { canonical: "hUSz_User_Group"      , type: "STRING", tableCode: "US" },
        "husz_user_id"         : { canonical: "hUSz_User_Id"         , type: "STRING", tableCode: "US" },
    }
};

export default US;
