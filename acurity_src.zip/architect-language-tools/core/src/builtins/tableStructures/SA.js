/**
 * SA.js — table structure for the SA (Salary History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SA").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SA
 */

/** @type {Object} */
const SA = {
    code: "SA",
    name: "Salary_History",
    recordLength: null,
    helpRegistry: "hSA.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SAi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hsac_conv_record"     : { canonical: "hSAc_Conv_Record"     , type: "STRING", tableCode: "SA" },
        "hsac_deleted"         : { canonical: "hSAc_Deleted"         , type: "STRING", tableCode: "SA" },
        "hsac_description"     : { canonical: "hSAc_Description"     , type: "STRING", tableCode: "SA" },
        "hsac_description_2"   : { canonical: "hSAc_Description_2"   , type: "STRING", tableCode: "SA" },
        "hsac_reduce_unts_held": { canonical: "hSAc_Reduce_Unts_Held", type: "STRING", tableCode: "SA" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hsad_effective"       : { canonical: "hSAd_Effective"       , type: "DATE", tableCode: "SA" },
        "hsad_mod_date"        : { canonical: "hSAd_Mod_Date"        , type: "DATE", tableCode: "SA" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hsaf_annual_salary"   : { canonical: "hSAf_Annual_Salary"   , type: "DOUBLE", tableCode: "SA" },
        "hsaf_base_salary"     : { canonical: "hSAf_Base_Salary"     , type: "DOUBLE", tableCode: "SA" },
        "hsaf_packaged_salary" : { canonical: "hSAf_Packaged_Salary" , type: "DOUBLE", tableCode: "SA" },
        "hsaf_part_time_salary": { canonical: "hSAf_Part_Time_Salary", type: "DOUBLE", tableCode: "SA" },
        "hsaf_salary"          : { canonical: "hSAf_Salary"          , type: "DOUBLE", tableCode: "SA" },
        "hsaf_salary_ratio"    : { canonical: "hSAf_Salary_Ratio"    , type: "DOUBLE", tableCode: "SA" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hsat_mod_time"        : { canonical: "hSAt_Mod_Time"        , type: "TIME", tableCode: "SA" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hsaz_fund"            : { canonical: "hSAz_Fund"            , type: "STRING", tableCode: "SA" },
        "hsaz_member"          : { canonical: "hSAz_Member"          , type: "STRING", tableCode: "SA" },
        "hsaz_mod_user"        : { canonical: "hSAz_Mod_User"        , type: "STRING", tableCode: "SA" },
        "hsaz_payroll"         : { canonical: "hSAz_Payroll"         , type: "STRING", tableCode: "SA" },
        "hsaz_sal_redn_reason" : { canonical: "hSAz_Sal_Redn_Reason" , type: "STRING", tableCode: "SA" },
        "hsaz_spare"           : { canonical: "hSAz_Spare"           , type: "STRING", tableCode: "SA" },
    }
};

export default SA;
