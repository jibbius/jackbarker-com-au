/**
 * IM.js — table structure for the IM (Investment Manager Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "IM").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force IM
 */

/** @type {Object} */
const IM = {
    code: "IM",
    name: "Investment_Manager_Details",
    recordLength: null,
    helpRegistry: "hIM.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "IMi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "himc_cont_tax"        : { canonical: "hIMc_Cont_Tax"        , type: "STRING", tableCode: "IM" },
        "himc_dist_freq"       : { canonical: "hIMc_Dist_Freq"       , type: "STRING", tableCode: "IM" },
        "himc_exclude_formula" : { canonical: "hIMc_Exclude_Formula" , type: "STRING", tableCode: "IM" },
        "himc_frozen"          : { canonical: "hIMc_Frozen"          , type: "STRING", tableCode: "IM" },
        "himc_inv_flag"        : { canonical: "hIMc_Inv_Flag"        , type: "STRING", tableCode: "IM" },
        "himc_invest_type"     : { canonical: "hIMc_Invest_Type"     , type: "STRING", tableCode: "IM" },
        "himc_linked_manager"  : { canonical: "hIMc_Linked_Manager"  , type: "STRING", tableCode: "IM" },
        "himc_property_trust"  : { canonical: "hIMc_Property_Trust"  , type: "STRING", tableCode: "IM" },
        "himc_rep_frequency"   : { canonical: "hIMc_Rep_Frequency"   , type: "STRING", tableCode: "IM" },
        "himc_taxable"         : { canonical: "hIMc_Taxable"         , type: "STRING", tableCode: "IM" },
        "himc_tofa_manager"    : { canonical: "hIMc_TOFA_Manager"    , type: "STRING", tableCode: "IM" },
        "himc_units_guaranteed": { canonical: "hIMc_Units_Guaranteed", type: "STRING", tableCode: "IM" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "himd_books_closed"    : { canonical: "hIMd_Books_Closed"    , type: "DATE", tableCode: "IM" },
        "himd_declared"        : { canonical: "hIMd_Declared"        , type: "DATE", tableCode: "IM" },
        "himd_distribution_due": { canonical: "hIMd_Distribution_Due", type: "DATE", tableCode: "IM" },
        "himd_maturity_or_conv": { canonical: "hIMd_Maturity_Or_Conv", type: "DATE", tableCode: "IM" },
        "himd_mod_date"        : { canonical: "hIMd_Mod_Date"        , type: "DATE", tableCode: "IM" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "himf_inv_increment"   : { canonical: "hIMf_Inv_Increment"   , type: "DOUBLE", tableCode: "IM" },
        "himf_margin_loan"     : { canonical: "hIMf_Margin_Loan"     , type: "DOUBLE", tableCode: "IM" },
        "himf_min_investment"  : { canonical: "hIMf_Min_Investment"  , type: "DOUBLE", tableCode: "IM" },
        "himf_unit_price_88"   : { canonical: "hIMf_Unit_Price_88"   , type: "DOUBLE", tableCode: "IM" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hims_fixed_term"      : { canonical: "hIMs_Fixed_Term"      , type: "INTEGER", tableCode: "IM" },
        "hims_spare"           : { canonical: "hIMs_Spare"           , type: "INTEGER", tableCode: "IM" },
        "hims_unt_calc_rnd_dp" : { canonical: "hIMs_Unt_Calc_Rnd_DP" , type: "INTEGER", tableCode: "IM" },
        "hims_unt_price_rnd_dp": { canonical: "hIMs_Unt_Price_Rnd_DP", type: "INTEGER", tableCode: "IM" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "himt_mod_time"        : { canonical: "hIMt_Mod_Time"        , type: "TIME", tableCode: "IM" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "himz_aas25_grouping"  : { canonical: "hIMz_AAS25_Grouping"  , type: "STRING", tableCode: "IM" },
        "himz_address01"       : { canonical: "hIMz_Address01"       , type: "STRING", tableCode: "IM" },
        "himz_address02"       : { canonical: "hIMz_Address02"       , type: "STRING", tableCode: "IM" },
        "himz_address03"       : { canonical: "hIMz_Address03"       , type: "STRING", tableCode: "IM" },
        "himz_apra_annual"     : { canonical: "hIMz_APRA_Annual"     , type: "STRING", tableCode: "IM" },
        "himz_apra_quarterly"  : { canonical: "hIMz_APRA_Quarterly"  , type: "STRING", tableCode: "IM" },
        "himz_bank_acct_name"  : { canonical: "hIMz_Bank_Acct_Name"  , type: "STRING", tableCode: "IM" },
        "himz_bank_acct_no"    : { canonical: "hIMz_Bank_Acct_No"    , type: "STRING", tableCode: "IM" },
        "himz_bdm_email01"     : { canonical: "hIMz_BDM_Email01"     , type: "STRING", tableCode: "IM" },
        "himz_bdm_email02"     : { canonical: "hIMz_BDM_Email02"     , type: "STRING", tableCode: "IM" },
        "himz_bsb"             : { canonical: "hIMz_BSB"             , type: "STRING", tableCode: "IM" },
        "himz_c_name"          : { canonical: "hIMz_C_Name"          , type: "STRING", tableCode: "IM" },
        "himz_c_phone_no"      : { canonical: "hIMz_C_Phone_No"      , type: "STRING", tableCode: "IM" },
        "himz_class"           : { canonical: "hIMz_Class"           , type: "STRING", tableCode: "IM" },
        "himz_code"            : { canonical: "hIMz_Code"            , type: "STRING", tableCode: "IM" },
        "himz_corr_cf_manager" : { canonical: "hIMz_Corr_CF_Manager" , type: "STRING", tableCode: "IM" },
        "himz_corr_manager"    : { canonical: "hIMz_Corr_Manager"    , type: "STRING", tableCode: "IM" },
        "himz_email"           : { canonical: "hIMz_Email"           , type: "STRING", tableCode: "IM" },
        "himz_fax"             : { canonical: "hIMz_Fax"             , type: "STRING", tableCode: "IM" },
        "himz_fund_manager"    : { canonical: "hIMz_Fund_Manager"    , type: "STRING", tableCode: "IM" },
        "himz_group"           : { canonical: "hIMz_Group"           , type: "STRING", tableCode: "IM" },
        "himz_incometax_formf" : { canonical: "hIMz_IncomeTax_FormF" , type: "STRING", tableCode: "IM" },
        "himz_ind_code"        : { canonical: "hIMz_Ind_Code"        , type: "STRING", tableCode: "IM" },
        "himz_ind_source"      : { canonical: "hIMz_Ind_Source"      , type: "STRING", tableCode: "IM" },
        "himz_instruction"     : { canonical: "hIMz_Instruction"     , type: "STRING", tableCode: "IM" },
        "himz_investor_no01"   : { canonical: "hIMz_Investor_No01"   , type: "STRING", tableCode: "IM" },
        "himz_investor_no02"   : { canonical: "hIMz_Investor_No02"   , type: "STRING", tableCode: "IM" },
        "himz_investor_no03"   : { canonical: "hIMz_Investor_No03"   , type: "STRING", tableCode: "IM" },
        "himz_investor_no04"   : { canonical: "hIMz_Investor_No04"   , type: "STRING", tableCode: "IM" },
        "himz_isc_grouping"    : { canonical: "hIMz_ISC_Grouping"    , type: "STRING", tableCode: "IM" },
        "himz_leased"          : { canonical: "hIMz_Leased"          , type: "STRING", tableCode: "IM" },
        "himz_long_code"       : { canonical: "hIMz_Long_Code"       , type: "STRING", tableCode: "IM" },
        "himz_mod_user"        : { canonical: "hIMz_Mod_User"        , type: "STRING", tableCode: "IM" },
        "himz_mysuper_status"  : { canonical: "hIMz_MySuper_Status"  , type: "STRING", tableCode: "IM" },
        "himz_name"            : { canonical: "hIMz_Name"            , type: "STRING", tableCode: "IM" },
        "himz_name_short_desc" : { canonical: "hIMz_Name_Short_Desc" , type: "STRING", tableCode: "IM" },
        "himz_old_home_phone"  : { canonical: "hIMz_Old_Home_Phone"  , type: "STRING", tableCode: "IM" },
        "himz_payment_method01": { canonical: "hIMz_Payment_Method01", type: "STRING", tableCode: "IM" },
        "himz_payment_method02": { canonical: "hIMz_Payment_Method02", type: "STRING", tableCode: "IM" },
        "himz_payment_method03": { canonical: "hIMz_Payment_Method03", type: "STRING", tableCode: "IM" },
        "himz_payment_method04": { canonical: "hIMz_Payment_Method04", type: "STRING", tableCode: "IM" },
        "himz_post_code"       : { canonical: "hIMz_Post_Code"       , type: "STRING", tableCode: "IM" },
        "himz_related_party"   : { canonical: "hIMz_Related_Party"   , type: "STRING", tableCode: "IM" },
        "himz_rounding_method" : { canonical: "hIMz_Rounding_Method" , type: "STRING", tableCode: "IM" },
        "himz_spare"           : { canonical: "hIMz_Spare"           , type: "STRING", tableCode: "IM" },
        "himz_ss_nz"           : { canonical: "hIMz_SS_NZ"           , type: "STRING", tableCode: "IM" },
        "himz_status"          : { canonical: "hIMz_Status"          , type: "STRING", tableCode: "IM" },
        "himz_trustee_grouping": { canonical: "hIMz_Trustee_Grouping", type: "STRING", tableCode: "IM" },
        "himz_type"            : { canonical: "hIMz_Type"            , type: "STRING", tableCode: "IM" },
        "himz_unit_description": { canonical: "hIMz_Unit_Description", type: "STRING", tableCode: "IM" },
        "himz_user_flags01"    : { canonical: "hIMz_User_Flags01"    , type: "STRING", tableCode: "IM" },
        "himz_user_flags02"    : { canonical: "hIMz_User_Flags02"    , type: "STRING", tableCode: "IM" },
        "himz_user_flags03"    : { canonical: "hIMz_User_Flags03"    , type: "STRING", tableCode: "IM" },
        "himz_user_flags04"    : { canonical: "hIMz_User_Flags04"    , type: "STRING", tableCode: "IM" },
        "himz_user_flags05"    : { canonical: "hIMz_User_Flags05"    , type: "STRING", tableCode: "IM" },
        "himz_user_flags06"    : { canonical: "hIMz_User_Flags06"    , type: "STRING", tableCode: "IM" },
    }
};

export default IM;
