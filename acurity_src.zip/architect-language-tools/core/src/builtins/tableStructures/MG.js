/**
 * MG.js — table structure for the MG (Merge History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "MG").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force MG
 */

/** @type {Object} */
const MG = {
    code: "MG",
    name: "Merge_History",
    recordLength: null,
    helpRegistry: "hMG.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "MGi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hmgd_effective"      : { canonical: "hMGd_Effective"      , type: "DATE", tableCode: "MG" },
        "hmgd_mod_date"       : { canonical: "hMGd_Mod_Date"       , type: "DATE", tableCode: "MG" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hmgl_trans_ref"      : { canonical: "hMGl_Trans_Ref"      , type: "INTEGER", tableCode: "MG" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hmgt_mod_time"       : { canonical: "hMGt_Mod_Time"       , type: "TIME", tableCode: "MG" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hmgz_division"       : { canonical: "hMGz_Division"       , type: "STRING", tableCode: "MG" },
        "hmgz_fund"           : { canonical: "hMGz_Fund"           , type: "STRING", tableCode: "MG" },
        "hmgz_member"         : { canonical: "hMGz_Member"         , type: "STRING", tableCode: "MG" },
        "hmgz_merged_fund"    : { canonical: "hMGz_Merged_Fund"    , type: "STRING", tableCode: "MG" },
        "hmgz_merged_member"  : { canonical: "hMGz_Merged_Member"  , type: "STRING", tableCode: "MG" },
        "hmgz_mod_user"       : { canonical: "hMGz_Mod_User"       , type: "STRING", tableCode: "MG" },
        "hmgz_original_fund"  : { canonical: "hMGz_Original_Fund"  , type: "STRING", tableCode: "MG" },
        "hmgz_original_member": { canonical: "hMGz_Original_Member", type: "STRING", tableCode: "MG" },
        "hmgz_restore_reason" : { canonical: "hMGz_Restore_Reason" , type: "STRING", tableCode: "MG" },
        "hmgz_spare"          : { canonical: "hMGz_Spare"          , type: "STRING", tableCode: "MG" },
    }
};

export default MG;
