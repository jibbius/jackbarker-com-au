/**
 * FC.js — table structure for the FC (Contribution Lines) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "FC").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force FC
 */

/** @type {Object} */
const FC = {
    code: "FC",
    name: "Contribution_Lines",
    recordLength: null,
    helpRegistry: "hFC.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "FCi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hfcc_context"         : { canonical: "hFCc_Context"         , type: "STRING", tableCode: "FC" },
        "hfcc_deleted"         : { canonical: "hFCc_Deleted"         , type: "STRING", tableCode: "FC" },
        "hfcc_transfer_cont"   : { canonical: "hFCc_Transfer_Cont"   , type: "STRING", tableCode: "FC" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hfcd_mod_date"        : { canonical: "hFCd_Mod_Date"        , type: "DATE", tableCode: "FC" },
        "hfcd_period_end"      : { canonical: "hFCd_Period_End"      , type: "DATE", tableCode: "FC" },
        "hfcd_reported"        : { canonical: "hFCd_Reported"        , type: "DATE", tableCode: "FC" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hfcf_amount"          : { canonical: "hFCf_Amount"          , type: "DOUBLE", tableCode: "FC" },
        "hfcf_correction_amt"  : { canonical: "hFCf_Correction_Amt"  , type: "DOUBLE", tableCode: "FC" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hfcl_bank_stmt_ref"   : { canonical: "hFCl_Bank_Stmt_Ref"   , type: "INTEGER", tableCode: "FC" },
        "hfcl_file_reg_ref"    : { canonical: "hFCl_File_Reg_Ref"    , type: "INTEGER", tableCode: "FC" },
        "hfcl_line_no"         : { canonical: "hFCl_Line_No"         , type: "INTEGER", tableCode: "FC" },
        "hfcl_message_code"    : { canonical: "hFCl_Message_Code"    , type: "INTEGER", tableCode: "FC" },
        "hfcl_reallocation_ref": { canonical: "hFCl_Reallocation_Ref", type: "INTEGER", tableCode: "FC" },
        "hfcl_receipt_ref"     : { canonical: "hFCl_Receipt_Ref"     , type: "INTEGER", tableCode: "FC" },
        "hfcl_refund_trans_ref": { canonical: "hFCl_Refund_Trans_Ref", type: "INTEGER", tableCode: "FC" },
        "hfcl_refunding_ref"   : { canonical: "hFCl_Refunding_Ref"   , type: "INTEGER", tableCode: "FC" },
        "hfcl_reversing_ref"   : { canonical: "hFCl_Reversing_Ref"   , type: "INTEGER", tableCode: "FC" },
        "hfcl_trans_ref"       : { canonical: "hFCl_Trans_Ref"       , type: "INTEGER", tableCode: "FC" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hfcs_orig_sequence"   : { canonical: "hFCs_Orig_Sequence"   , type: "INTEGER", tableCode: "FC" },
        "hfcs_sequence"        : { canonical: "hFCs_Sequence"        , type: "INTEGER", tableCode: "FC" },
        "hfcs_spare01"         : { canonical: "hFCs_Spare01"         , type: "INTEGER", tableCode: "FC" },
        "hfcs_spare02"         : { canonical: "hFCs_Spare02"         , type: "INTEGER", tableCode: "FC" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hfct_mod_time"        : { canonical: "hFCt_Mod_Time"        , type: "TIME", tableCode: "FC" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hfcz_adjust_reason"   : { canonical: "hFCz_Adjust_Reason"   , type: "STRING", tableCode: "FC" },
        "hfcz_cont_account"    : { canonical: "hFCz_Cont_Account"    , type: "STRING", tableCode: "FC" },
        "hfcz_cont_desc"       : { canonical: "hFCz_Cont_Desc"       , type: "STRING", tableCode: "FC" },
        "hfcz_division"        : { canonical: "hFCz_Division"        , type: "STRING", tableCode: "FC" },
        "hfcz_fund"            : { canonical: "hFCz_Fund"            , type: "STRING", tableCode: "FC" },
        "hfcz_member"          : { canonical: "hFCz_Member"          , type: "STRING", tableCode: "FC" },
        "hfcz_mod_user"        : { canonical: "hFCz_Mod_User"        , type: "STRING", tableCode: "FC" },
        "hfcz_orig_trans_ref"  : { canonical: "hFCz_Orig_Trans_Ref"  , type: "STRING", tableCode: "FC" },
        "hfcz_payment_type"    : { canonical: "hFCz_Payment_Type"    , type: "STRING", tableCode: "FC" },
        "hfcz_payroll"         : { canonical: "hFCz_Payroll"         , type: "STRING", tableCode: "FC" },
        "hfcz_preserved"       : { canonical: "hFCz_Preserved"       , type: "STRING", tableCode: "FC" },
        "hfcz_reallocatefund"  : { canonical: "hFCz_ReallocateFund"  , type: "STRING", tableCode: "FC" },
        "hfcz_reallocatemember": { canonical: "hFCz_ReallocateMember", type: "STRING", tableCode: "FC" },
        "hfcz_refund_division" : { canonical: "hFCz_Refund_Division" , type: "STRING", tableCode: "FC" },
        "hfcz_refunding_div"   : { canonical: "hFCz_Refunding_Div"   , type: "STRING", tableCode: "FC" },
        "hfcz_reject_reason"   : { canonical: "hFCz_Reject_Reason"   , type: "STRING", tableCode: "FC" },
        "hfcz_reversing_div"   : { canonical: "hFCz_Reversing_Div"   , type: "STRING", tableCode: "FC" },
        "hfcz_spare"           : { canonical: "hFCz_Spare"           , type: "STRING", tableCode: "FC" },
        "hfcz_static_informatn": { canonical: "hFCz_Static_Informatn", type: "STRING", tableCode: "FC" },
        "hfcz_status"          : { canonical: "hFCz_Status"          , type: "STRING", tableCode: "FC" },
        "hfcz_supplied_trn_ref": { canonical: "hFCz_Supplied_Trn_Ref", type: "STRING", tableCode: "FC" },
        "hfcz_user_def_flags01": { canonical: "hFCz_User_Def_Flags01", type: "STRING", tableCode: "FC" },
        "hfcz_user_def_flags02": { canonical: "hFCz_User_Def_Flags02", type: "STRING", tableCode: "FC" },
        "hfcz_user_def_flags03": { canonical: "hFCz_User_Def_Flags03", type: "STRING", tableCode: "FC" },
        "hfcz_user_def_flags04": { canonical: "hFCz_User_Def_Flags04", type: "STRING", tableCode: "FC" },

        // ── (v-prefix) ──────────────────────────────────────────────────
        "hfcv_rlvrcontextid"   : { canonical: "hFCv_RlvrContextID"   , type: "VARSTRING", tableCode: "FC" },
    }
};

export default FC;
