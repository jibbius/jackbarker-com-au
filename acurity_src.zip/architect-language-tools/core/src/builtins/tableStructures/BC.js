/**
 * BC.js — table structure for the BC (Job Calculation Variables) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "BC").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force BC
 */

/** @type {Object} */
const BC = {
    code: "BC",
    name: "Job_Calculation_Variables",
    recordLength: null,
    helpRegistry: "hBC.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "BCi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hbcc_control"    : { canonical: "hBCc_Control"    , type: "STRING", tableCode: "BC" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hbcd_mod_date"   : { canonical: "hBCd_Mod_Date"   , type: "DATE", tableCode: "BC" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hbcl_depend01"   : { canonical: "hBCl_Depend01"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend02"   : { canonical: "hBCl_Depend02"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend03"   : { canonical: "hBCl_Depend03"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend04"   : { canonical: "hBCl_Depend04"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend05"   : { canonical: "hBCl_Depend05"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend06"   : { canonical: "hBCl_Depend06"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend07"   : { canonical: "hBCl_Depend07"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend08"   : { canonical: "hBCl_Depend08"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend09"   : { canonical: "hBCl_Depend09"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend10"   : { canonical: "hBCl_Depend10"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend11"   : { canonical: "hBCl_Depend11"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend12"   : { canonical: "hBCl_Depend12"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend13"   : { canonical: "hBCl_Depend13"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend14"   : { canonical: "hBCl_Depend14"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend15"   : { canonical: "hBCl_Depend15"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend16"   : { canonical: "hBCl_Depend16"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend17"   : { canonical: "hBCl_Depend17"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend18"   : { canonical: "hBCl_Depend18"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend19"   : { canonical: "hBCl_Depend19"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend20"   : { canonical: "hBCl_Depend20"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend21"   : { canonical: "hBCl_Depend21"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend22"   : { canonical: "hBCl_Depend22"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend23"   : { canonical: "hBCl_Depend23"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_depend24"   : { canonical: "hBCl_Depend24"   , type: "INTEGER", tableCode: "BC" },
        "hbcl_done"       : { canonical: "hBCl_Done"       , type: "INTEGER", tableCode: "BC" },
        "hbcl_job_ref"    : { canonical: "hBCl_Job_Ref"    , type: "INTEGER", tableCode: "BC" },
        "hbcl_need"       : { canonical: "hBCl_Need"       , type: "INTEGER", tableCode: "BC" },
        "hbcl_request"    : { canonical: "hBCl_Request"    , type: "INTEGER", tableCode: "BC" },
        "hbcl_spare"      : { canonical: "hBCl_Spare"      , type: "INTEGER", tableCode: "BC" },
        "hbcl_user"       : { canonical: "hBCl_User"       , type: "INTEGER", tableCode: "BC" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hbct_mod_time"   : { canonical: "hBCt_Mod_Time"   , type: "TIME", tableCode: "BC" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hbcz_calc_date"  : { canonical: "hBCz_Calc_Date"  , type: "STRING", tableCode: "BC" },
        "hbcz_calc_string": { canonical: "hBCz_Calc_String", type: "STRING", tableCode: "BC" },
        "hbcz_caller"     : { canonical: "hBCz_Caller"     , type: "STRING", tableCode: "BC" },
        "hbcz_fund"       : { canonical: "hBCz_Fund"       , type: "STRING", tableCode: "BC" },
        "hbcz_member"     : { canonical: "hBCz_Member"     , type: "STRING", tableCode: "BC" },
        "hbcz_mod_user"   : { canonical: "hBCz_Mod_User"   , type: "STRING", tableCode: "BC" },
        "hbcz_show_calc"  : { canonical: "hBCz_Show_Calc"  , type: "STRING", tableCode: "BC" },
        "hbcz_user_id"    : { canonical: "hBCz_User_ID"    , type: "STRING", tableCode: "BC" },
    }
};

export default BC;
