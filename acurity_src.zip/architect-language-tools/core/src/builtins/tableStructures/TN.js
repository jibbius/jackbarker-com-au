/**
 * TN.js — table structure for the TN (Temporary Transaction History Records) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "TN").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force TN
 */

/** @type {Object} */
const TN = {
    code: "TN",
    name: "Temporary_Transaction_History_Records",
    recordLength: null,
    helpRegistry: "hTN.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "TNi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "htnc_archived"        : { canonical: "hTNc_Archived"        , type: "STRING", tableCode: "TN" },
        "htnc_batch_tran"      : { canonical: "hTNc_Batch_Tran"      , type: "STRING", tableCode: "TN" },
        "htnc_ben_01_74"       : { canonical: "hTNc_Ben_01_74"       , type: "STRING", tableCode: "TN" },
        "htnc_cheque_no"       : { canonical: "hTNc_Cheque_No"       , type: "STRING", tableCode: "TN" },
        "htnc_completed"       : { canonical: "hTNc_Completed"       , type: "STRING", tableCode: "TN" },
        "htnc_cont_type"       : { canonical: "hTNc_Cont_Type"       , type: "STRING", tableCode: "TN" },
        "htnc_create_conts"    : { canonical: "hTNc_Create_Conts"    , type: "STRING", tableCode: "TN" },
        "htnc_created_ledgers" : { canonical: "hTNc_Created_Ledgers" , type: "STRING", tableCode: "TN" },
        "htnc_edited_tran"     : { canonical: "hTNc_Edited_Tran"     , type: "STRING", tableCode: "TN" },
        "htnc_exit"            : { canonical: "hTNc_Exit"            , type: "STRING", tableCode: "TN" },
        "htnc_fid_applies"     : { canonical: "hTNc_FID_Applies"     , type: "STRING", tableCode: "TN" },
        "htnc_flag_1"          : { canonical: "hTNc_Flag_1"          , type: "STRING", tableCode: "TN" },
        "htnc_flag_2"          : { canonical: "hTNc_Flag_2"          , type: "STRING", tableCode: "TN" },
        "htnc_flag_3"          : { canonical: "hTNc_Flag_3"          , type: "STRING", tableCode: "TN" },
        "htnc_flag_4"          : { canonical: "hTNc_Flag_4"          , type: "STRING", tableCode: "TN" },
        "htnc_flag_5"          : { canonical: "hTNc_Flag_5"          , type: "STRING", tableCode: "TN" },
        "htnc_flag_6"          : { canonical: "hTNc_Flag_6"          , type: "STRING", tableCode: "TN" },
        "htnc_group"           : { canonical: "hTNc_Group"           , type: "STRING", tableCode: "TN" },
        "htnc_in_use"          : { canonical: "hTNc_In_Use"          , type: "STRING", tableCode: "TN" },
        "htnc_interfaced"      : { canonical: "hTNc_Interfaced"      , type: "STRING", tableCode: "TN" },
        "htnc_manual_alloc"    : { canonical: "hTNc_Manual_Alloc"    , type: "STRING", tableCode: "TN" },
        "htnc_multiple_chqs"   : { canonical: "hTNc_Multiple_Chqs"   , type: "STRING", tableCode: "TN" },
        "htnc_notes"           : { canonical: "hTNc_Notes"           , type: "STRING", tableCode: "TN" },
        "htnc_part_posted"     : { canonical: "hTNc_Part_Posted"     , type: "STRING", tableCode: "TN" },
        "htnc_partial_reverse" : { canonical: "hTNc_Partial_Reverse" , type: "STRING", tableCode: "TN" },
        "htnc_rcpt_allocation" : { canonical: "hTNc_Rcpt_Allocation" , type: "STRING", tableCode: "TN" },
        "htnc_rebalance"       : { canonical: "hTNc_Rebalance"       , type: "STRING", tableCode: "TN" },
        "htnc_receipt_tran"    : { canonical: "hTNc_Receipt_Tran"    , type: "STRING", tableCode: "TN" },
        "htnc_reverse_fid"     : { canonical: "hTNc_Reverse_FID"     , type: "STRING", tableCode: "TN" },
        "htnc_reversing_tran"  : { canonical: "hTNc_Reversing_Tran"  , type: "STRING", tableCode: "TN" },
        "htnc_tran_status"     : { canonical: "hTNc_Tran_Status"     , type: "STRING", tableCode: "TN" },
        "htnc_unit_price_meth" : { canonical: "hTNc_Unit_Price_Meth" , type: "STRING", tableCode: "TN" },
        "htnc_units_processed" : { canonical: "hTNc_Units_Processed" , type: "STRING", tableCode: "TN" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "htnd_banked"          : { canonical: "hTNd_Banked"          , type: "DATE", tableCode: "TN" },
        "htnd_cont_end"        : { canonical: "hTNd_Cont_End"        , type: "DATE", tableCode: "TN" },
        "htnd_contribution"    : { canonical: "hTNd_Contribution"    , type: "DATE", tableCode: "TN" },
        "htnd_effective"       : { canonical: "hTNd_Effective"       , type: "DATE", tableCode: "TN" },
        "htnd_interest_calc"   : { canonical: "hTNd_Interest_Calc"   , type: "DATE", tableCode: "TN" },
        "htnd_journal_date"    : { canonical: "hTNd_Journal_Date"    , type: "DATE", tableCode: "TN" },
        "htnd_mod_date"        : { canonical: "hTNd_Mod_Date"        , type: "DATE", tableCode: "TN" },
        "htnd_paperwork_rcvd"  : { canonical: "hTNd_Paperwork_Rcvd"  , type: "DATE", tableCode: "TN" },
        "htnd_posted"          : { canonical: "hTNd_Posted"          , type: "DATE", tableCode: "TN" },
        "htnd_posted_report"   : { canonical: "hTNd_Posted_Report"   , type: "DATE", tableCode: "TN" },
        "htnd_spare"           : { canonical: "hTNd_Spare"           , type: "DATE", tableCode: "TN" },
        "htnd_tran"            : { canonical: "hTNd_Tran"            , type: "DATE", tableCode: "TN" },
        "htnd_unit_price_date" : { canonical: "hTNd_Unit_Price_Date" , type: "DATE", tableCode: "TN" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "htnf_amount"          : { canonical: "hTNf_Amount"          , type: "DOUBLE", tableCode: "TN" },
        "htnf_bank_acct_tot"   : { canonical: "hTNf_Bank_Acct_Tot"   , type: "DOUBLE", tableCode: "TN" },
        "htnf_cheque_amt"      : { canonical: "hTNf_Cheque_Amt"      , type: "DOUBLE", tableCode: "TN" },
        "htnf_cheque_total"    : { canonical: "hTNf_Cheque_Total"    , type: "DOUBLE", tableCode: "TN" },
        "htnf_foreign_tax_cr"  : { canonical: "hTNf_Foreign_Tax_CR"  , type: "DOUBLE", tableCode: "TN" },
        "htnf_imputation_cr"   : { canonical: "hTNf_Imputation_CR"   , type: "DOUBLE", tableCode: "TN" },
        "htnf_inv_acct_total"  : { canonical: "hTNf_Inv_Acct_Total"  , type: "DOUBLE", tableCode: "TN" },
        "htnf_max_deductible"  : { canonical: "hTNf_Max_Deductible"  , type: "DOUBLE", tableCode: "TN" },
        "htnf_no_of_units"     : { canonical: "hTNf_No_Of_Units"     , type: "DOUBLE", tableCode: "TN" },
        "htnf_tax_amt"         : { canonical: "hTNf_Tax_Amt"         , type: "DOUBLE", tableCode: "TN" },
        "htnf_tran_run_tot"    : { canonical: "hTNf_Tran_Run_Tot"    , type: "DOUBLE", tableCode: "TN" },
        "htnf_tran_run_tot_2"  : { canonical: "hTNf_Tran_Run_Tot_2"  , type: "DOUBLE", tableCode: "TN" },
        "htnf_unalloc_tax_amt" : { canonical: "hTNf_Unalloc_Tax_Amt" , type: "DOUBLE", tableCode: "TN" },
        "htnf_unallocnontaxamt": { canonical: "hTNf_UnallocNonTaxAmt", type: "DOUBLE", tableCode: "TN" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "htnl_bank_ref"        : { canonical: "hTNl_Bank_Ref"        , type: "INTEGER", tableCode: "TN" },
        "htnl_batch_ref"       : { canonical: "hTNl_Batch_Ref"       , type: "INTEGER", tableCode: "TN" },
        "htnl_cheque_ref"      : { canonical: "hTNl_Cheque_Ref"      , type: "INTEGER", tableCode: "TN" },
        "htnl_corr_noncost"    : { canonical: "hTNl_Corr_NonCost"    , type: "INTEGER", tableCode: "TN" },
        "htnl_corres_batch"    : { canonical: "hTNl_Corres_Batch"    , type: "INTEGER", tableCode: "TN" },
        "htnl_corres_batch_ref": { canonical: "hTNl_Corres_Batch_Ref", type: "INTEGER", tableCode: "TN" },
        "htnl_corres_receipt"  : { canonical: "hTNl_Corres_Receipt"  , type: "INTEGER", tableCode: "TN" },
        "htnl_corres_tran"     : { canonical: "hTNl_Corres_Tran"     , type: "INTEGER", tableCode: "TN" },
        "htnl_counter"         : { canonical: "hTNl_Counter"         , type: "INTEGER", tableCode: "TN" },
        "htnl_deposit_id"      : { canonical: "hTNl_Deposit_Id"      , type: "INTEGER", tableCode: "TN" },
        "htnl_elec_batch_ref"  : { canonical: "hTNl_Elec_Batch_Ref"  , type: "INTEGER", tableCode: "TN" },
        "htnl_file_reg_ref"    : { canonical: "hTNl_File_Reg_Ref"    , type: "INTEGER", tableCode: "TN" },
        "htnl_job_ref"         : { canonical: "hTNl_Job_Ref"         , type: "INTEGER", tableCode: "TN" },
        "htnl_master_batch_ref": { canonical: "hTNl_Master_Batch_Ref", type: "INTEGER", tableCode: "TN" },
        "htnl_no_batch_recs"   : { canonical: "hTNl_No_Batch_Recs"   , type: "INTEGER", tableCode: "TN" },
        "htnl_no_trans_recs"   : { canonical: "hTNl_No_Trans_Recs"   , type: "INTEGER", tableCode: "TN" },
        "htnl_receipt_ref"     : { canonical: "hTNl_Receipt_Ref"     , type: "INTEGER", tableCode: "TN" },
        "htnl_reversed_by"     : { canonical: "hTNl_Reversed_By"     , type: "INTEGER", tableCode: "TN" },
        "htnl_reversing_ref"   : { canonical: "hTNl_Reversing_Ref"   , type: "INTEGER", tableCode: "TN" },
        "htnl_spare"           : { canonical: "hTNl_Spare"           , type: "INTEGER", tableCode: "TN" },
        "htnl_trans_ref"       : { canonical: "hTNl_Trans_Ref"       , type: "INTEGER", tableCode: "TN" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "htns_no_of_chqs"      : { canonical: "hTNs_No_Of_Chqs"      , type: "INTEGER", tableCode: "TN" },
        "htns_no_of_processes" : { canonical: "hTNs_No_Of_Processes" , type: "INTEGER", tableCode: "TN" },
        "htns_no_periods_conts": { canonical: "hTNs_No_Periods_Conts", type: "INTEGER", tableCode: "TN" },
        "htns_no_periodsfreq01": { canonical: "hTNs_No_PeriodsFreq01", type: "INTEGER", tableCode: "TN" },
        "htns_no_periodsfreq02": { canonical: "hTNs_No_PeriodsFreq02", type: "INTEGER", tableCode: "TN" },
        "htns_no_periodsfreq03": { canonical: "hTNs_No_PeriodsFreq03", type: "INTEGER", tableCode: "TN" },
        "htns_no_periodsfreq04": { canonical: "hTNs_No_PeriodsFreq04", type: "INTEGER", tableCode: "TN" },
        "htns_process_no"      : { canonical: "hTNs_Process_No"      , type: "INTEGER", tableCode: "TN" },
        "htns_sas_version"     : { canonical: "hTNs_SAS_Version"     , type: "INTEGER", tableCode: "TN" },
        "htns_sequence"        : { canonical: "hTNs_Sequence"        , type: "INTEGER", tableCode: "TN" },
        "htns_spare01"         : { canonical: "hTNs_Spare01"         , type: "INTEGER", tableCode: "TN" },
        "htns_spare02"         : { canonical: "hTNs_Spare02"         , type: "INTEGER", tableCode: "TN" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "htnt_mod_time"        : { canonical: "hTNt_Mod_Time"        , type: "TIME", tableCode: "TN" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "htnz_allocation_fname": { canonical: "hTNz_Allocation_Fname", type: "STRING", tableCode: "TN" },
        "htnz_bank_account"    : { canonical: "hTNz_Bank_Account"    , type: "STRING", tableCode: "TN" },
        "htnz_bank_st_ref"     : { canonical: "hTNz_Bank_St_Ref"     , type: "STRING", tableCode: "TN" },
        "htnz_batch_code"      : { canonical: "hTNz_Batch_Code"      , type: "STRING", tableCode: "TN" },
        "htnz_branch"          : { canonical: "hTNz_Branch"          , type: "STRING", tableCode: "TN" },
        "htnz_bsb"             : { canonical: "hTNz_BSB"             , type: "STRING", tableCode: "TN" },
        "htnz_calc_basis"      : { canonical: "hTNz_Calc_Basis"      , type: "STRING", tableCode: "TN" },
        "htnz_cheque_no"       : { canonical: "hTNz_Cheque_No"       , type: "STRING", tableCode: "TN" },
        "htnz_client"          : { canonical: "hTNz_Client"          , type: "STRING", tableCode: "TN" },
        "htnz_cont_status"     : { canonical: "hTNz_Cont_Status"     , type: "STRING", tableCode: "TN" },
        "htnz_deposit_id"      : { canonical: "hTNz_Deposit_ID"      , type: "STRING", tableCode: "TN" },
        "htnz_division"        : { canonical: "hTNz_Division"        , type: "STRING", tableCode: "TN" },
        "htnz_drawer"          : { canonical: "hTNz_Drawer"          , type: "STRING", tableCode: "TN" },
        "htnz_electronic_fname": { canonical: "hTNz_Electronic_Fname", type: "STRING", tableCode: "TN" },
        "htnz_exception_reason": { canonical: "hTNz_Exception_Reason", type: "STRING", tableCode: "TN" },
        "htnz_fund"            : { canonical: "hTNz_Fund"            , type: "STRING", tableCode: "TN" },
        "htnz_inv_mgr_code"    : { canonical: "hTNz_Inv_Mgr_Code"    , type: "STRING", tableCode: "TN" },
        "htnz_invalid_mbr_no"  : { canonical: "hTNz_Invalid_Mbr_No"  , type: "STRING", tableCode: "TN" },
        "htnz_kyc_status"      : { canonical: "hTNz_KYC_Status"      , type: "STRING", tableCode: "TN" },
        "htnz_member"          : { canonical: "hTNz_Member"          , type: "STRING", tableCode: "TN" },
        "htnz_mod_user"        : { canonical: "hTNz_Mod_User"        , type: "STRING", tableCode: "TN" },
        "htnz_partid"          : { canonical: "hTNz_PartID"          , type: "STRING", tableCode: "TN" },
        "htnz_payee"           : { canonical: "hTNz_Payee"           , type: "STRING", tableCode: "TN" },
        "htnz_payroll"         : { canonical: "hTNz_Payroll"         , type: "STRING", tableCode: "TN" },
        "htnz_posted"          : { canonical: "hTNz_Posted"          , type: "STRING", tableCode: "TN" },
        "htnz_receipt_method"  : { canonical: "hTNz_Receipt_Method"  , type: "STRING", tableCode: "TN" },
        "htnz_receipted"       : { canonical: "hTNz_Receipted"       , type: "STRING", tableCode: "TN" },
        "htnz_reconciled"      : { canonical: "hTNz_Reconciled"      , type: "STRING", tableCode: "TN" },
        "htnz_reference"       : { canonical: "hTNz_Reference"       , type: "STRING", tableCode: "TN" },
        "htnz_set_no"          : { canonical: "hTNz_Set_No"          , type: "STRING", tableCode: "TN" },
        "htnz_spare"           : { canonical: "hTNz_Spare"           , type: "STRING", tableCode: "TN" },
        "htnz_string"          : { canonical: "hTNz_String"          , type: "STRING", tableCode: "TN" },
        "htnz_subsidy_ctype"   : { canonical: "hTNz_Subsidy_CType"   , type: "STRING", tableCode: "TN" },
        "htnz_subsidy_fund"    : { canonical: "hTNz_Subsidy_Fund"    , type: "STRING", tableCode: "TN" },
        "htnz_subsidy_payroll" : { canonical: "hTNz_Subsidy_Payroll" , type: "STRING", tableCode: "TN" },
        "htnz_supplied_trn_ref": { canonical: "hTNz_Supplied_Trn_Ref", type: "STRING", tableCode: "TN" },
        "htnz_tran_created_by" : { canonical: "hTNz_Tran_Created_By" , type: "STRING", tableCode: "TN" },
        "htnz_tran_desc"       : { canonical: "hTNz_Tran_Desc"       , type: "STRING", tableCode: "TN" },
        "htnz_tran_requestd_by": { canonical: "hTNz_Tran_Requestd_By", type: "STRING", tableCode: "TN" },
        "htnz_transaction"     : { canonical: "hTNz_Transaction"     , type: "STRING", tableCode: "TN" },
    }
};

export default TN;
