/**
 * PD.js — table structure for the PD (AS400 Printer Override) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "PD").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force PD
 */

/** @type {Object} */
const PD = {
    code: "PD",
    name: "AS400_Printer_Override",
    recordLength: null,
    helpRegistry: "hPD.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "PDi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hpdc_code"     : { canonical: "hPDc_Code"     , type: "STRING", tableCode: "PD" },
        "hpdc_spare"    : { canonical: "hPDc_Spare"    , type: "STRING", tableCode: "PD" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hpdz_overrides": { canonical: "hPDz_Overrides", type: "STRING", tableCode: "PD" },
    }
};

export default PD;
