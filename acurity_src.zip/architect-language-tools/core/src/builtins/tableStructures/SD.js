/**
 * SD.js — table structure for the SD (Share Certificate Details) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "SD").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force SD
 */

/** @type {Object} */
const SD = {
    code: "SD",
    name: "Share_Certificate_Details",
    recordLength: null,
    helpRegistry: "hSD.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "SDi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hsdc_fully_redeemed"  : { canonical: "hSDc_Fully_Redeemed"  , type: "STRING", tableCode: "SD" },
        "hsdc_merge"           : { canonical: "hSDc_Merge"           , type: "STRING", tableCode: "SD" },
        "hsdc_share_type"      : { canonical: "hSDc_Share_Type"      , type: "STRING", tableCode: "SD" },
        "hsdc_switch_share"    : { canonical: "hSDc_Switch_Share"    , type: "STRING", tableCode: "SD" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hsdd_effective"       : { canonical: "hSDd_Effective"       , type: "DATE", tableCode: "SD" },
        "hsdd_invested"        : { canonical: "hSDd_Invested"        , type: "DATE", tableCode: "SD" },
        "hsdd_maturity"        : { canonical: "hSDd_Maturity"        , type: "DATE", tableCode: "SD" },
        "hsdd_mod_date"        : { canonical: "hSDd_Mod_Date"        , type: "DATE", tableCode: "SD" },
        "hsdd_redeemed"        : { canonical: "hSDd_Redeemed"        , type: "DATE", tableCode: "SD" },
        "hsdd_requested"       : { canonical: "hSDd_Requested"       , type: "DATE", tableCode: "SD" },
        "hsdd_termination"     : { canonical: "hSDd_Termination"     , type: "DATE", tableCode: "SD" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hsdf_accrued_cg"      : { canonical: "hSDf_Accrued_CG"      , type: "DOUBLE", tableCode: "SD" },
        "hsdf_amt_div_repayed" : { canonical: "hSDf_Amt_Div_Repayed" , type: "DOUBLE", tableCode: "SD" },
        "hsdf_amt_loan_repayed": { canonical: "hSDf_Amt_Loan_Repayed", type: "DOUBLE", tableCode: "SD" },
        "hsdf_amt_redeemed"    : { canonical: "hSDf_Amt_Redeemed"    , type: "DOUBLE", tableCode: "SD" },
        "hsdf_amt_shares"      : { canonical: "hSDf_Amt_Shares"      , type: "DOUBLE", tableCode: "SD" },
        "hsdf_bonus_shares"    : { canonical: "hSDf_Bonus_Shares"    , type: "DOUBLE", tableCode: "SD" },
        "hsdf_cap_base_reduct" : { canonical: "hSDf_Cap_Base_Reduct" , type: "DOUBLE", tableCode: "SD" },
        "hsdf_capital_expend"  : { canonical: "hSDf_Capital_Expend"  , type: "DOUBLE", tableCode: "SD" },
        "hsdf_entry_fee"       : { canonical: "hSDf_Entry_Fee"       , type: "DOUBLE", tableCode: "SD" },
        "hsdf_exit_fee"        : { canonical: "hSDf_Exit_Fee"        , type: "DOUBLE", tableCode: "SD" },
        "hsdf_expenses"        : { canonical: "hSDf_Expenses"        , type: "DOUBLE", tableCode: "SD" },
        "hsdf_interest"        : { canonical: "hSDf_Interest"        , type: "DOUBLE", tableCode: "SD" },
        "hsdf_no_of_shares"    : { canonical: "hSDf_No_Of_Shares"    , type: "DOUBLE", tableCode: "SD" },
        "hsdf_no_redeem_shares": { canonical: "hSDf_No_Redeem_Shares", type: "DOUBLE", tableCode: "SD" },
        "hsdf_rate_reduction"  : { canonical: "hSDf_Rate_Reduction"  , type: "DOUBLE", tableCode: "SD" },
        "hsdf_reduction"       : { canonical: "hSDf_Reduction"       , type: "DOUBLE", tableCode: "SD" },
        "hsdf_repayment_amt"   : { canonical: "hSDf_Repayment_Amt"   , type: "DOUBLE", tableCode: "SD" },
        "hsdf_return_of_cap"   : { canonical: "hSDf_Return_of_Cap"   , type: "DOUBLE", tableCode: "SD" },
        "hsdf_revaluation_ytd" : { canonical: "hSDf_Revaluation_YTD" , type: "DOUBLE", tableCode: "SD" },
        "hsdf_tax_free_income" : { canonical: "hSDf_Tax_Free_Income" , type: "DOUBLE", tableCode: "SD" },
        "hsdf_termdeposit_rate": { canonical: "hSDf_TermDeposit_Rate", type: "DOUBLE", tableCode: "SD" },
        "hsdf_total_shares"    : { canonical: "hSDf_Total_Shares"    , type: "DOUBLE", tableCode: "SD" },
        "hsdf_unreal_reval"    : { canonical: "hSDf_Unreal_Reval"    , type: "DOUBLE", tableCode: "SD" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hsdl_shr_cert_no_sys" : { canonical: "hSDl_Shr_Cert_No_Sys" , type: "INTEGER", tableCode: "SD" },
        "hsdl_trans_ref"       : { canonical: "hSDl_Trans_Ref"       , type: "INTEGER", tableCode: "SD" },
        "hsdl_transfertransref": { canonical: "hSDl_TransferTransRef", type: "INTEGER", tableCode: "SD" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hsdt_mod_time"        : { canonical: "hSDt_Mod_Time"        , type: "TIME", tableCode: "SD" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hsdz_division"        : { canonical: "hSDz_Division"        , type: "STRING", tableCode: "SD" },
        "hsdz_fund"            : { canonical: "hSDz_Fund"            , type: "STRING", tableCode: "SD" },
        "hsdz_inv_mgr_code"    : { canonical: "hSDz_Inv_Mgr_Code"    , type: "STRING", tableCode: "SD" },
        "hsdz_member"          : { canonical: "hSDz_Member"          , type: "STRING", tableCode: "SD" },
        "hsdz_mod_user"        : { canonical: "hSDz_Mod_User"        , type: "STRING", tableCode: "SD" },
        "hsdz_model_no"        : { canonical: "hSDz_Model_No"        , type: "STRING", tableCode: "SD" },
        "hsdz_share_cert_no"   : { canonical: "hSDz_Share_Cert_No"   , type: "STRING", tableCode: "SD" },
        "hsdz_shareholder_no"  : { canonical: "hSDz_Shareholder_No"  , type: "STRING", tableCode: "SD" },
        "hsdz_sharescript_no"  : { canonical: "hSDz_Sharescript_No"  , type: "STRING", tableCode: "SD" },
        "hsdz_spare"           : { canonical: "hSDz_Spare"           , type: "STRING", tableCode: "SD" },
    }
};

export default SD;
