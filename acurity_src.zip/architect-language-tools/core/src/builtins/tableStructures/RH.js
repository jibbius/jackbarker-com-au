/**
 * RH.js — table structure for the RH (Employer Rates History) table.
 *
 * Indexes: PK only — replace with authoritative schema data when available.
 * Fields:  sourced from fieldRegistry.js (all entries where tableCode === "RH").
 *
 * Re-generate the fields block with:
 *   node scripts/generate-table-structures.js --force RH
 */

/** @type {Object} */
const RH = {
    code: "RH",
    name: "Employer_Rates_History",
    recordLength: null,
    helpRegistry: "hRH.htm",
    indexes: [
        {
            name: "PK",
            modifiable: false,
            duplicates: false,
            segments: [
                { position: 0, field: "RHi_Identity", type: "BIGINT", length: 8 }
            ]
        }
    ],
    fields: {
        // ── STRING (c-prefix) ─────────────────────────────────────────────────
        "hrhc_credit_app"      : { canonical: "hRHc_Credit_app"      , type: "STRING", tableCode: "RH" },
        "hrhc_deleted"         : { canonical: "hRHc_Deleted"         , type: "STRING", tableCode: "RH" },

        // ── DATE (d-prefix) ───────────────────────────────────────────────────
        "hrhd_effective"       : { canonical: "hRHd_Effective"       , type: "DATE", tableCode: "RH" },
        "hrhd_mod_date"        : { canonical: "hRHd_Mod_Date"        , type: "DATE", tableCode: "RH" },

        // ── DOUBLE (f-prefix) ─────────────────────────────────────────────────
        "hrhf_basic_ben"       : { canonical: "hRHf_Basic_Ben"       , type: "DOUBLE", tableCode: "RH" },
        "hrhf_basic_ben_factor": { canonical: "hRHf_Basic_Ben_Factor", type: "DOUBLE", tableCode: "RH" },
        "hrhf_comp_cont"       : { canonical: "hRHf_Comp_Cont"       , type: "DOUBLE", tableCode: "RH" },
        "hrhf_prosp_mbr"       : { canonical: "hRHf_Prosp_Mbr"       , type: "DOUBLE", tableCode: "RH" },
        "hrhf_spare"           : { canonical: "hRHf_Spare"           , type: "DOUBLE", tableCode: "RH" },
        "hrhf_std_cont"        : { canonical: "hRHf_Std_Cont"        , type: "DOUBLE", tableCode: "RH" },
        "hrhf_std_cont_max"    : { canonical: "hRHf_Std_Cont_Max"    , type: "DOUBLE", tableCode: "RH" },
        "hrhf_std_cont_min"    : { canonical: "hRHf_Std_Cont_Min"    , type: "DOUBLE", tableCode: "RH" },

        // ── INTEGER (l-prefix) ────────────────────────────────────────────────
        "hrhl_invoice_no"      : { canonical: "hRHl_Invoice_No"      , type: "INTEGER", tableCode: "RH" },
        "hrhl_trans_ref"       : { canonical: "hRHl_Trans_Ref"       , type: "INTEGER", tableCode: "RH" },

        // ── INTEGER (s-prefix) ────────────────────────────────────────────────
        "hrhs_no_periods"      : { canonical: "hRHs_No_Periods"      , type: "INTEGER", tableCode: "RH" },
        "hrhs_spare01"         : { canonical: "hRHs_Spare01"         , type: "INTEGER", tableCode: "RH" },
        "hrhs_spare02"         : { canonical: "hRHs_Spare02"         , type: "INTEGER", tableCode: "RH" },
        "hrhs_spare03"         : { canonical: "hRHs_Spare03"         , type: "INTEGER", tableCode: "RH" },

        // ── TIME (t-prefix) ───────────────────────────────────────────────────
        "hrht_mod_time"        : { canonical: "hRHt_Mod_Time"        , type: "TIME", tableCode: "RH" },

        // ── STRING (z-prefix) ─────────────────────────────────────────────────
        "hrhz_division"        : { canonical: "hRHz_Division"        , type: "STRING", tableCode: "RH" },
        "hrhz_fund"            : { canonical: "hRHz_Fund"            , type: "STRING", tableCode: "RH" },
        "hrhz_mod_user"        : { canonical: "hRHz_Mod_User"        , type: "STRING", tableCode: "RH" },
        "hrhz_payroll"         : { canonical: "hRHz_Payroll"         , type: "STRING", tableCode: "RH" },
        "hrhz_spare"           : { canonical: "hRHz_Spare"           , type: "STRING", tableCode: "RH" },
    }
};

export default RH;
