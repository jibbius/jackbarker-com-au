/**
 * tableRegistry.js — registry for database table codes and structures.
 *
 * This module serves two related purposes:
 *
 * 1. Table code registry — a flat map of all known 2-character table codes,
 *    carrying the human-readable table name and optional category. Used to
 *    validate table code string arguments and produce hover/completion labels.
 *
 *    Source: ai-workspace/reference-data/db-table-codes.md (v15, 171 tables).
 *    Note: D2 and T4 are edge-case codes containing a digit.
 *
 *    Exports: TABLE_REGISTRY, getTableEntry, isValidTableSynonym, getHPrefixSuggestion
 *
 * 2. Table structure registry — lazy-loading registry for detailed table
 *    structures (indexes, fields, record length). Each table has a dedicated
 *    structure file under ./tableStructures/<CODE>.js that is loaded on first
 *    access via dynamic import(). Only the tables relevant to a given script
 *    are ever loaded.
 *
 *    Exports: isKnownTableStructure, getTableStructure, getLoadedTableStructure
 *
 * Usage:
 *   import { getTableEntry, isValidTableSynonym } from './tableRegistry.js';
 *   import { getTableStructure, isKnownTableStructure } from './tableRegistry.js';
 *
 * To add a new table structure file:
 *   1. Create  core/src/builtins/tableStructures/<CODE>.js  (export default tableObject)
 *   2. Register the table code in TABLE_REGISTRY above (if not already present).
 *      KNOWN_TABLE_CODES is derived automatically from TABLE_REGISTRY keys.
 */

// ============================================================
// Part 1 — Table code registry (all known 2-character codes)
// ============================================================

const TABLE_REGISTRY = {
  // ============================================================
  // A
  // ============================================================
  "AB": { name: "API CLOB",                                    category: null },
  "AC": { name: "Archive",                                     category: null },
  "AD": { name: "Member Contribution Adjustment History",      category: null },
  "AH": { name: "Member Acquisition History",                  category: null },
  "AK": { name: "Member Review Backup",                        category: null },
  "AN": { name: "Address Details",                             category: "Accounting" },
  "AP": { name: "Advisor Proportions History",                 category: null },
  "AQ": { name: "Member Review Quotes",                        category: null },
  "AR": { name: "Member Review History",                       category: null },
  "AT": { name: "Audit Trail",                                 category: "Audit" },
  "AU": { name: "Audit Control",                               category: "Audit" },
  "AV": { name: "Advisor History",                             category: null },
  "AX": { name: "Audit Header",                                category: "Audit" },
  "AY": { name: "Audit Child",                                 category: "Audit" },
  "AZ": { name: "Audit Character Large Objects",               category: "Audit" },

  // ============================================================
  // B
  // ============================================================
  "BA": { name: "Journal",                                     category: "Accounting" },
  "BB": { name: "BSB Codes",                                   category: null },
  "BC": { name: "Job Calculation Variables",                   category: null },
  "BD": { name: "Broker",                                      category: null },
  "BE": { name: "Bank Accounts",                               category: "Accounting" },
  "BH": { name: "Broker History",                              category: null },
  "BJ": { name: "Background Jobs",                             category: null },
  "BK": { name: "Member Balance History Backup",               category: null },
  "BL": { name: "Balance History",                             category: null },
  "BN": { name: "Bank Reconciliation History",                 category: "Accounting" },
  "BP": { name: "Batch Processing Steps",                      category: null },
  "BS": { name: "Processed Batches",                           category: null },
  "BT": { name: "Batch Codes",                                 category: null },

  // ============================================================
  // C
  // ============================================================
  "CA": { name: "Chart of Accounts",                           category: "Accounting" },
  "CB": { name: "Tax Flag History",                            category: null },
  "CC": { name: "Corporate Action Election",                   category: null },
  "CD": { name: "Codes and Descriptions",                      category: null },
  "CE": { name: "Client To Member Relationships",              category: null },
  "CF": { name: "Configuration Items",                         category: "Configuration" },
  "CG": { name: "Capital Gains Indexation Rates",              category: null },
  "CH": { name: "Benefit Category History",                    category: null },
  "CK": { name: "Benefit Category - Member History Backup",    category: null },
  "CL": { name: "Employer Location",                           category: "Employer" },
  "CM": { name: "Client Match",                                category: null },
  "CN": { name: "Corporate Actions",                           category: null },
  "CO": { name: "Employer Details",                            category: "Employer" },
  "CP": { name: "Capital Gains Reporting",                     category: null },
  "CQ": { name: "Cheque Reconciliation",                       category: null },
  "CR": { name: "Commission Rates",                            category: null },
  "CS": { name: "Contribution Accounts",                       category: null },
  "CT": { name: "Benefit Category",                            category: "Category" },
  "CV": { name: "Benefit Category - Group Life Insurance",     category: "Category" },
  "CX": { name: "Commissions",                                 category: null },

  // ============================================================
  // D
  // ============================================================
  "D2": { name: "Personal Details",                            category: "Member" },   // edge case: digit in code
  "DA": { name: "Data Register",                               category: null },
  "DH": { name: "Tax Rates History",                           category: "Taxation" },
  "DU": { name: "User Codes and Descriptions",                 category: null },
  "DV": { name: "Global Information",                          category: null },
  "DX": { name: "Dependants Details",                          category: "Member" },
  "DY": { name: "Auto Diary",                                  category: null },

  // ============================================================
  // E
  // ============================================================
  "EB": { name: "Event and Exception Bases",                   category: null },
  "EC": { name: "Message Codes",                               category: null },
  "ED": { name: "Member Exit History",                         category: null },
  "EE": { name: "Employer Enquiry",                            category: "Employer" },
  "EH": { name: "Exception History",                           category: null },
  "EI": { name: "Event and Exception Information",             category: null },
  "EM": { name: "Member Enquiry",                              category: "Member" },
  "EN": { name: "Event Exception Details",                     category: null },
  "ER": { name: "Results (Error) Messages",                    category: null },
  "ES": { name: "Eligible Service Date History",               category: null },
  "EV": { name: "Event Definitions",                           category: null },
  "EX": { name: "Extensions",                                  category: null },

  // ============================================================
  // F
  // ============================================================
  "FB": { name: "Fee Calculation Bases",                       category: "Fees/Formulas/Tables" },
  "FC": { name: "Contribution Lines",                          category: "Accounting" },
  "FD": { name: "Fee Definitions",                             category: "Fees/Formulas/Tables" },
  "FF": { name: "Fund Supplementary Details",                  category: "Fund" },
  "FG": { name: "Fee Group",                                   category: "Fees/Formulas/Tables" },
  "FH": { name: "Fund Supplementary Labels 1",                 category: "Fund" },
  "FL": { name: "Locked Files and Caches",                     category: null },
  "FP": { name: "Fee Parameters",                              category: "Fees/Formulas/Tables" },
  "FQ": { name: "Transfer Request Lines",                      category: "Accounting" },
  "FR": { name: "Fund Information",                            category: "Fund" },
  "FS": { name: "Static Data Lines",                           category: "Accounting" },
  "FT": { name: "File Type Details",                           category: "Accounting" },
  "FU": { name: "Fund History Details",                        category: "Fund" },
  "FV": { name: "Last Member Number",                          category: "Fund" },
  "FW": { name: "Workbench Lines",                             category: "Accounting" },
  "FX": { name: "Formula Definitions",                         category: "Fees/Formulas/Tables" },
  "FZ": { name: "Fund Information 3 (Trustee Details)",        category: "Fund" },

  // ============================================================
  // G
  // ============================================================
  "GL": { name: "General Ledger",                              category: "Accounting" },
  "GR": { name: "Group Certificate",                           category: null },
  "GV": { name: "Division Global Information",                 category: null },

  // ============================================================
  // I
  // ============================================================
  "ID": { name: "Insurer",                                     category: "Insurer" },
  "IE": { name: "Income Election History",                     category: null },
  "IH": { name: "Investment Manager History",                  category: "Investment" },
  "IL": { name: "Insurance Category Defaults",                 category: "Insurer" },
  "IM": { name: "Investment Manager Details",                  category: "Investment" },
  "IN": { name: "Insurer History",                             category: "Insurer" },
  "IP": { name: "Member Investment Profile History",           category: "Member" },
  "IR": { name: "Fund Interest Rate History",                  category: "Fund" },
  "IT": { name: "Interest Table History",                      category: null },

  // ============================================================
  // J
  // ============================================================
  "JQ": { name: "Job Queuing Rules",                           category: null },

  // ============================================================
  // K
  // ============================================================
  "KE": { name: "Acurity Manager Keys",                        category: null },

  // ============================================================
  // M
  // ============================================================
  "MC": { name: "Member Contribution Rate History",            category: "Member" },
  "MD": { name: "Member Details",                              category: "Member" },
  "MG": { name: "Merge History",                               category: "Member" },
  "MH": { name: "Medical History",                             category: "Member" },
  "MS": { name: "Message History",                             category: "Accounting" },
  "MU": { name: "Multiple Cheques",                            category: null },

  // ============================================================
  // N
  // ============================================================
  "NT": { name: "New Zealand - Insurance Records",             category: null },
  "NX": { name: "Notes",                                       category: null },
  "NZ": { name: "New Zealand Exchange Rates",                  category: null },

  // ============================================================
  // O
  // ============================================================
  "OF": { name: "Member Transfer History",                     category: "Member" },
  "OG": { name: "Member - Other Fund Details",                 category: "Member" },
  "OH": { name: "Member Past Benefit History",                 category: "Member" },

  // ============================================================
  // P
  // ============================================================
  "PA": { name: "Password History",                            category: "Security" },
  "PB": { name: "Daily Portfolio Balances",                    category: "Accounting" },
  "PC": { name: "Post Code",                                   category: null },
  "PD": { name: "AS400 Printer Override",                      category: null },
  "PE": { name: "Member Pension History",                      category: "Member" },
  "PG": { name: "Client Groups",                               category: null },
  "PH": { name: "Employer/Payroll History",                    category: "Employer" },
  "PI": { name: "Policy Benefit Details",                      category: null },
  "PL": { name: "Policy Details",                              category: null },
  "PO": { name: "Policy Committee",                            category: null },
  "PP": { name: "Temporary P04 and P05 Totals",                category: null },
  "PR": { name: "Payee Details",                               category: "Payee" },
  "PS": { name: "Publishing Details",                          category: "Reports" },
  "PT": { name: "Member Periodical Payments",                  category: "Member" },
  "PY": { name: "Member Payment History",                      category: "Member" },

  // ============================================================
  // R
  // ============================================================
  "RA": { name: "File Register",                               category: null },
  "RE": { name: "Member Unit Refund Details",                  category: "Member" },
  "RG": { name: "Correspondence Register",                     category: null },
  "RH": { name: "Employer Rates History",                      category: "Employer" },
  "RL": { name: "Report Control",                              category: "Reports" },
  "RO": { name: "Rollover History",                            category: null },
  "RR": { name: "Report History",                              category: "Reports" },
  "RV": { name: "Report Variables",                            category: "Reports" },

  // ============================================================
  // S
  // ============================================================
  "SA": { name: "Salary History",                              category: "Member" },
  "SB": { name: "Supplementary Details",                       category: "Member" },
  "SC": { name: "System Security - Access",                    category: "Security" },
  "SD": { name: "Share Certificate Details",                   category: null },
  "SF": { name: "Member Supplementary Labels",                 category: "Member" },
  "SG": { name: "Fund Supplementary Labels 2",                 category: "Fund" },
  "SH": { name: "Share Certificate - Redemption History",      category: null },
  "SL": { name: "SAML Artifacts",                              category: "Security" },
  "SM": { name: "System Security - Supplementary Fields",      category: "Security" },
  "SP": { name: "Posting Transaction Control",                 category: null },
  "SR": { name: "Service Request Form",                        category: null },
  "SS": { name: "Jobs System - Global Variables",              category: null },
  "ST": { name: "Share Scheme - Temporary Records",            category: null },
  "SU": { name: "System Security - Transactions",              category: "Security" },
  "SX": { name: "ATO Data History",                            category: "Taxation" },

  // ============================================================
  // T
  // ============================================================
  "T4": { name: "Transaction 04 - History",                    category: "Transactional" }, // edge case: digit in code
  "TA": { name: "Tax Table History",                           category: "Taxation" },
  "TB": { name: "Trustee Details",                             category: null },
  "TC": { name: "Transaction Control Lines",                   category: "Transactional" },
  "TD": { name: "Transaction Header Details",                  category: "Transactional" },
  "TE": { name: "Member Exit Batch Details",                   category: null },
  "TF": { name: "Temporary Payment Records",                   category: null },
  "TH": { name: "Transaction History",                         category: "Transactional" },
  "TN": { name: "Temporary Transaction History Records",       category: "Transactional" },
  "TR": { name: "Table Records",                               category: "Fees/Formulas/Tables" },
  "TS": { name: "Taxable Salary History",                      category: "Taxation" },
  "TT": { name: "Transaction Lines",                           category: "Transactional" },
  "TU": { name: "User Defined Transaction (77)",               category: "Transactional" },
  "TZ": { name: "Sliding Scale Tables",                        category: "Fees/Formulas/Tables" },

  // ============================================================
  // U
  // ============================================================
  "UL": { name: "Unpost General Ledger",                       category: "Accounting" },
  "UN": { name: "Unit Entitlement History",                    category: null },
  "UP": { name: "Unit Price History Records",                  category: null },
  "US": { name: "User Details",                                category: "Security" },

  // ============================================================
  // V
  // ============================================================
  "VA": { name: "Contribution Variance History",               category: "Accounting" },
  "VH": { name: "Data Version History",                        category: null },

  // ============================================================
  // W
  // ============================================================
  "WH": { name: "Working Hours History",                       category: null },
  "WS": { name: "Working Status History",                      category: null },
  "WU": { name: "Web User Details",                            category: "Security" },
};

/**
 * Returns the registry entry for a table code, or undefined if not found.
 * @param {string} code
 * @returns {{ name: string, category: string|null } | undefined}
 */
function getTableEntry(code) {
  return TABLE_REGISTRY[code];
}

/**
 * Returns true if the given string is a valid table code.
 * @param {string} value
 * @returns {boolean}
 */
function isValidTableSynonym(value) {
  return Object.prototype.hasOwnProperty.call(TABLE_REGISTRY, value);
}

/**
 * If the value looks like an h-prefixed table code (e.g. "hMD"), returns the
 * bare code ("MD") if it is a valid table code. Otherwise returns null.
 * @param {string} value
 * @returns {string|null}
 */
function getHPrefixSuggestion(value) {
  if (value.length >= 2 && (value[0] === "h" || value[0] === "H")) {
    const bare = value.slice(1).toUpperCase();
    if (isValidTableSynonym(bare)) {
      return bare;
    }
  }
  return null;
}

// ============================================================
// Part 2 — Table structure registry (lazy-loaded detail files)
// ============================================================

/**
 * All table codes that have a corresponding structure file under ./tableStructures/.
 * Derived from TABLE_REGISTRY keys so the two are always in sync.
 * @type {ReadonlySet<string>}
 */
const KNOWN_TABLE_CODES = new Set(Object.keys(TABLE_REGISTRY));

/**
 * Cache of already-loaded table structures, keyed by table code.
 * @type {Map<string, Object>}
 */
const _cache = new Map();

/**
 * Returns true if a structure file is registered for the given table code.
 * This is a synchronous check — no I/O is performed.
 *
 * @param {string} code - 2-character table code (e.g. "CD", "MD").
 * @returns {boolean}
 */
function isKnownTableStructure(code) {
    return KNOWN_TABLE_CODES.has(code);
}

/**
 * Returns the full structure object for a table, loading and caching it on first
 * access.  Returns null if no structure file is registered for the code.
 *
 * The returned object has the shape:
 * {
 *   code:         string,
 *   name:         string,
 *   recordLength: number,
 *   helpRegistry: string,
 *   indexes:      Array<{ name, modifiable, duplicates, segments: Array<{position, field, type, length}> }>,
 *   fields:       { [lowercaseFieldName]: { canonical, type, tableCode } }
 * }
 *
 * @param {string} code - 2-character table code.
 * @returns {Promise<Object|null>}
 */
async function getTableStructure(code) {
    if (!KNOWN_TABLE_CODES.has(code)) {
        return null;
    }
    if (_cache.has(code)) {
        return _cache.get(code);
    }
    const { default: structure } = await import(`./tableStructures/${code}.js`);
    _cache.set(code, structure);
    return structure;
}

/**
 * Returns the structure for a table if it has already been loaded into the cache,
 * otherwise returns undefined.
 *
 * This is a synchronous accessor intended for callers that have already awaited
 * at least one call to getTableStructure() for this code.
 *
 * @param {string} code - 2-character table code.
 * @returns {Object|undefined}
 */
function getLoadedTableStructure(code) {
    return _cache.get(code);
}

/**
 * Looks up a field handle in its table's structure file.
 *
 * The table code is derived from the handle itself: the two characters
 * immediately after the leading 'h' (e.g. "hMDz_Member" → "MD").
 * Returns null if the table has no structure file or the field is not found.
 *
 * @param {string} handle - Field handle in any casing (e.g. "hMDz_Member").
 * @returns {Promise<{ canonical: string, type: string, tableCode: string }|null>}
 */
async function getFieldByHandle(handle) {
    const code = handle.slice(1, 3).toUpperCase();
    const structure = await getTableStructure(code);
    return structure?.fields[handle.toLowerCase()] ?? null;
}

/**
 * Registers a supplementary table at runtime.
 *
 * - Adds the table code and its registry entry to TABLE_REGISTRY so validators
 *   and completion providers recognise the code as valid.
 * - Adds the code to KNOWN_TABLE_CODES so isKnownTableStructure() returns true.
 * - Pre-populates the structure cache so getTableStructure() returns the provided
 *   object immediately without attempting a file import.
 *
 * When preferCore is true and the code already exists, the call is a no-op (the
 * existing entries are preserved). When preferCore is false (default), the new
 * entry replaces any existing one.
 *
 * @param {string} code       - 2-character table code (e.g. "ZZ"). Normalised to uppercase.
 * @param {{ name: string, category: string|null }} entry - TABLE_REGISTRY entry shape.
 * @param {object} structure  - Full table structure object (same shape as tableStructures/*.js).
 * @param {boolean} [preferCore=false]
 */
function registerSupplementaryTable(code, entry, structure, preferCore = false) {
    const key = code.toUpperCase();
    const conflict = Object.prototype.hasOwnProperty.call(TABLE_REGISTRY, key);
    if (conflict && preferCore) {
        return;
    }
    TABLE_REGISTRY[key] = entry;
    KNOWN_TABLE_CODES.add(key);
    _cache.set(key, structure);
}

export {
    TABLE_REGISTRY,
    getTableEntry,
    isValidTableSynonym,
    getHPrefixSuggestion,
    isKnownTableStructure,
    getTableStructure,
    getLoadedTableStructure,
    getFieldByHandle,
    registerSupplementaryTable,
};
