/**
 * Built-in global variables for Acurity Architect.
 *
 * readOnly semantics:
 *   true  — set exclusively by the runtime; scripts should treat as read-only.
 *   false — writable by scripts; value changes are meaningful and expected.
 *
 */

import { AcurityTypes } from "../types/acurityTypes.js";

/**
 * Built-in global variables (used without a #VAR declaration).
 * Format: { name: { type, readOnly, description } }
 */
const BuiltInGlobalVariables = {

    PK_INDEX: { type: AcurityTypes.SHORT, readOnly: true, description: "Used to open a table via its primary index." },

    // ============================================================
    // Boundary / sentinel values
    // ============================================================

    NEW_LINE_STR: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "A newline (line-break) character string."
    },
    MIN_STR: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "A null value string."
    },
    MAX_STR: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Maximum string sentinel value - a string of 80 valid (high-value) characters."
    },
    MIN_DATE: {
        type: AcurityTypes.DATE,
        readOnly: true,
        description: "The minimum representable date value (00/00/0000)."
    },
    MAX_DATE: {
        type: AcurityTypes.DATE,
        readOnly: true,
        description: "The maximum representable date value (31/12/9998)."
    },
    MIN_TIME: {
        type: AcurityTypes.TIME,
        readOnly: true,
        description: "The minimum representable time value (00:00:00:00)."
    },
    MAX_TIME: {
        type: AcurityTypes.TIME,
        readOnly: true,
        description: "The maximum representable time value (23:59:59:99)."
    },
    MIN_DOUBLE: {
        type: AcurityTypes.DOUBLE,
        readOnly: true,
        description: "The minimum representable double-precision value."
    },
    MAX_DOUBLE: {
        type: AcurityTypes.DOUBLE,
        readOnly: true,
        description: "The maximum representable double-precision value."
    },
    MIN_SHORT: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "The minimum representable SHORT integer value."
    },
    MAX_SHORT: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "The maximum representable SHORT integer value."
    },
    MIN_LONG: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "The minimum representable LONG integer value (−2,147,483,648)."
    },
    MAX_LONG: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "The maximum representable LONG integer value."
    },
    MIN_TIMESTAMP: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "The minimum representable timestamp value (0000-00-00 00:00:00.0000000)."
    },
    MAX_TIMESTAMP: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "The maximum representable timestamp value (9998-12-31 23:59:59.9999999)."
    },
    MIN_BIGINT: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "The minimum representable BIGINT value (-9,223,372,036,854,775,808)."
    },
    MAX_BIGINT: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "The maximum representable BIGINT value."
    },

    // ============================================================
    // Database / I/O status
    // ============================================================

    DB_STATUS: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Status code from the most recent database operation. Set by the runtime after each DB read/write; scripts should not assign to this."
    },

    // ============================================================
    // Report context / schedule phase flags
    // ============================================================

    INIT_SCHED: {
        type: AcurityTypes.BOOLEAN,
        readOnly: true,
        description: "Automatically managed in schedule-style reports. TRUE only on the first pass through the report code; FALSE at all other times."
    },
    HEADER: {
        type: AcurityTypes.BOOLEAN,
        readOnly: true,
        description: "Automatically managed in schedule-style reports. TRUE for the first member on each page; FALSE at all other times."
    },
    BODY: {
        type: AcurityTypes.BOOLEAN,
        readOnly: true,
        description: "Automatically managed in schedule-style reports. TRUE at all times, except when FIN_SCHED or FOOTER are TRUE on the last page."
    },
    FOOTER: {
        type: AcurityTypes.BOOLEAN,
        readOnly: true,
        description: "Automatically managed in schedule-style reports. TRUE for the last member on each page; FALSE at all other times."
    },
    FIN_SCHED: {
        type: AcurityTypes.BOOLEAN,
        readOnly: true,
        description: "Automatically managed in schedule-style reports. TRUE only after the last member has been processed; FALSE at all other times."
    },
    ACCEPT_REC: {
        type: AcurityTypes.BOOLEAN,
        readOnly: false,
        description: "Default TRUE. In schedule-style reports, set to FALSE to reject the current record - it will not be processed further and counters such as NUM_LINE_PRINTED will not be incremented."
    },
    FORM_FEED: {
        type: AcurityTypes.BOOLEAN,
        readOnly: true,
        description: "Automatically managed in schedule-style reports. TRUE for whenever HEADER is TRUE, except on the very first pass. Useful for suppressing a blank first page by checking FORM_FEED before issuing a page-break command."
    },
    SUB_TOTALLING: {
        type: AcurityTypes.BOOLEAN,
        readOnly: false,
        description: "Set to TRUE in schedule-style reports to enable subtotalling (e.g. per Employer/Payroll). Must be combined with an appropriate sort order."
    },
    SUBTOTAL: {
        type: AcurityTypes.BOOLEAN,
        readOnly: true,
        description: "Automatically managed. TRUE for the last member in each sub-group when SUB_TOTALLING is enabled."
    },

    // ============================================================
    // Pagination / line counters
    // ============================================================

    CURRENT_PRINTER: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Index of the printer currently in use."
    },
    NUM_HEADER_LINES: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Specifies the number of output lines allocated to the HEADER section of a schedule-style report."
    },
    NUM_BODY_LINES: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Specifies the number of output lines allocated to the BODY section of a schedule-style report (e.g. '1' per member)."
    },
    NUM_FOOTER_LINES: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Specifies the number of output lines allocated to the FOOTER section of a schedule-style report."
    },
    NUM_FINAL_LINES: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Specifies the number of output lines allocated to the grand total section (FIN_SCHED) of a schedule-style report."
    },
    NUM_LINES_PER_PAGE: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Specifies the maximum number of BODY lines per each page in a schedule style report."
    },
    NUM_LINES_PRINTED: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "Running counter of body lines produced by the report so far."
    },
    PAGE_NUMBER: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "System generated page number for schedule-style reports."
    },
    TAB_STR: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "A tab character string used for column alignment."
    },

    // ============================================================
    // Schedule total accumulators (TOTCOL_1..30)
    // ============================================================

    TOTCOL_1: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (1). Initialised to 0. Use in the FOOTER section of a schedule-style report to accumulate page totals, and reset as needed."
    },
    TOTCOL_2: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (2). Initialised to 0."
    },
    TOTCOL_3: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (3). Initialised to 0."
    },
    TOTCOL_4: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (4). Initialised to 0."
    },
    TOTCOL_5: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (5). Initialised to 0."
    },
    TOTCOL_6: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (6). Initialised to 0."
    },
    TOTCOL_7: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (7). Initialised to 0."
    },
    TOTCOL_8: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (8). Initialised to 0."
    },
    TOTCOL_9: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (9). Initialised to 0."
    },
    TOTCOL_10: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (10). Initialised to 0."
    },
    TOTCOL_11: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (11). Initialised to 0."
    },
    TOTCOL_12: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (12). Initialised to 0."
    },
    TOTCOL_13: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (13). Initialised to 0."
    },
    TOTCOL_14: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (14). Initialised to 0."
    },
    TOTCOL_15: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (15). Initialised to 0."
    },
    TOTCOL_16: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (16). Initialised to 0."
    },
    TOTCOL_17: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (17). Initialised to 0."
    },
    TOTCOL_18: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (18). Initialised to 0."
    },
    TOTCOL_19: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (19). Initialised to 0."
    },
    TOTCOL_20: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (20). Initialised to 0."
    },
    TOTCOL_21: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (21). Initialised to 0."
    },
    TOTCOL_22: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (22). Initialised to 0."
    },
    TOTCOL_23: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (23). Initialised to 0."
    },
    TOTCOL_24: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (24). Initialised to 0."
    },
    TOTCOL_25: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (25). Initialised to 0."
    },
    TOTCOL_26: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (26). Initialised to 0."
    },
    TOTCOL_27: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (27). Initialised to 0."
    },
    TOTCOL_28: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (28). Initialised to 0."
    },
    TOTCOL_29: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (29). Initialised to 0."
    },
    TOTCOL_30: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Page level accumulator (30). Initialised to 0."
    },

    // ============================================================
    // Sub-total accumulators (SUBCOL_1..30)
    // ============================================================

    SUBCOL_1: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (1). Initialised to 0. Use in the SUBTOTAL section of a schedule-style report to accumulate subtotals, and reset as needed."
    },
    SUBCOL_2: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (2). Initialised to 0."
    },
    SUBCOL_3: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (3). Initialised to 0."
    },
    SUBCOL_4: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (4). Initialised to 0."
    },
    SUBCOL_5: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (5). Initialised to 0."
    },
    SUBCOL_6: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (6). Initialised to 0."
    },
    SUBCOL_7: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (7). Initialised to 0."
    },
    SUBCOL_8: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (8). Initialised to 0."
    },
    SUBCOL_9: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (9). Initialised to 0."
    },
    SUBCOL_10: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (10). Initialised to 0."
    },
    SUBCOL_11: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (11). Initialised to 0."
    },
    SUBCOL_12: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (12). Initialised to 0."
    },
    SUBCOL_13: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (13). Initialised to 0."
    },
    SUBCOL_14: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (14). Initialised to 0."
    },
    SUBCOL_15: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (15). Initialised to 0."
    },
    SUBCOL_16: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (16). Initialised to 0."
    },
    SUBCOL_17: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (17). Initialised to 0."
    },
    SUBCOL_18: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (18). Initialised to 0."
    },
    SUBCOL_19: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (19). Initialised to 0."
    },
    SUBCOL_20: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (20). Initialised to 0."
    },
    SUBCOL_21: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (21). Initialised to 0."
    },
    SUBCOL_22: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (22). Initialised to 0."
    },
    SUBCOL_23: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (23). Initialised to 0."
    },
    SUBCOL_24: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (24). Initialised to 0."
    },
    SUBCOL_25: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (25). Initialised to 0."
    },
    SUBCOL_26: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (26). Initialised to 0."
    },
    SUBCOL_27: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (27). Initialised to 0."
    },
    SUBCOL_28: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (28). Initialised to 0."
    },
    SUBCOL_29: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (29). Initialised to 0."
    },
    SUBCOL_30: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Subtotal accumulator (30). Initialised to 0."
    },

    // ============================================================
    // Grand-total accumulators (GNDCOL_1..30)
    // ============================================================

    GNDCOL_1: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (1). Initialised to 0. Use in the FIN_SCHED section of a schedule-style report to accumulate grand totals across all pages."
    },
    GNDCOL_2: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (2). Initialised to 0."
    },
    GNDCOL_3: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (3). Initialised to 0."
    },
    GNDCOL_4: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (4). Initialised to 0."
    },
    GNDCOL_5: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (5). Initialised to 0."
    },
    GNDCOL_6: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (6). Initialised to 0."
    },
    GNDCOL_7: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (7). Initialised to 0."
    },
    GNDCOL_8: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (8). Initialised to 0."
    },
    GNDCOL_9: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (9). Initialised to 0."
    },
    GNDCOL_10: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (10). Initialised to 0."
    },
    GNDCOL_11: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (11). Initialised to 0."
    },
    GNDCOL_12: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (12). Initialised to 0."
    },
    GNDCOL_13: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (13). Initialised to 0."
    },
    GNDCOL_14: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (14). Initialised to 0."
    },
    GNDCOL_15: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (15). Initialised to 0."
    },
    GNDCOL_16: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (16). Initialised to 0."
    },
    GNDCOL_17: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (17). Initialised to 0."
    },
    GNDCOL_18: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (18). Initialised to 0."
    },
    GNDCOL_19: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (19). Initialised to 0."
    },
    GNDCOL_20: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (20). Initialised to 0."
    },
    GNDCOL_21: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (21). Initialised to 0."
    },
    GNDCOL_22: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (22). Initialised to 0."
    },
    GNDCOL_23: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (23). Initialised to 0."
    },
    GNDCOL_24: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (24). Initialised to 0."
    },
    GNDCOL_25: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (25). Initialised to 0."
    },
    GNDCOL_26: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (26). Initialised to 0."
    },
    GNDCOL_27: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (27). Initialised to 0."
    },
    GNDCOL_28: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (28). Initialised to 0."
    },
    GNDCOL_29: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (29). Initialised to 0."
    },
    GNDCOL_30: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Grand-total accumulator (30). Initialised to 0."
    },

    // ============================================================
    // Report / scheduling control
    // ============================================================

    UNALLOC_FLAG: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Returns the value entered in the Alloc Level field on the Report screen."
    },
    REPORT_LEVEL: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Controls which ledger records accounting functions can acces. Initially set from the Fund, Member, and Alloc level fields on the Report screen, but can be overridden as needed."
    },
    FATAL_ERROR_FLAG: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Multi-purpose control flag. Set to 1 to raise an error (stops processing); set to 0 for warnings. Also used in F6/F9 filter contexts (1 = exclude record; 0 = include record)."
    },
    PRESAVE_EVENT_FATAL: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "Is automatically set to 1 within a pre-save event chain, if any earlier pre-save event script has failed."
    },
    SCH_COMPANY: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "In schedule-style reports, returns the member's employer/company code, based on report end date."
    },
    CLIENT_SYS_FLAG: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Returns the Acurity Division code, based on the current session."
    },
    INV_BANK_ACC: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Returns the Investment Manager code designated as the 'cash at bank' account."
    },
    CONT_CALCS_ONLY: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Returns 'Y' or 'N' from the `Contribution Calculations Only` flag on Review data forms (e.g. 'Review a Member')."
    },
    CONFIRM_REVIEW: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag indicating whether the run is a confirmation review pass. [best guess]"
    },
    PROCESS_DESC: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Description of the current process or schedule run."
    },
    INTERIM_REVIEW: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag indicating whether the run is an interim review pass. [best guess]"
    },
    EXITING_FLAG: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag set by a script to signal that the process should exit gracefully. [best guess]"
    },
    EXIT_FLAG: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag set by a script to trigger an early exit from the current report or function."
    },
    USE_EXIT_DATE: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag controlling whether the exit date is applied during processing. [best guess]"
    },
    SORT_FLAG: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Sort key or sort-control flag written by a script to influence record ordering."
    },
    REPORT_AMT: {
        type: AcurityTypes.DOUBLE,
        readOnly: true,
        description: "A general-purpose report amount accumulator that scripts may read and write."
    },
    REPORT_CUSTOM_DATA: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Free-form custom data string that scripts may attach to a report run."
    },
    REPORT_FILTERING_PARAMS: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Filtering parameters passed in by the caller for the current report run."
    },
    OUTPUT_TEMPLATE: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Name or path of the output template to use for this report. [best guess]"
    },
    OUTPUT_FILE_TYPE: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Code indicating the output file format (e.g. RTF, PDF, plain text). [best guess]"
    },
    ERRORS_TO_WARNINGS: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "When non-zero, errors are demoted to warnings rather than aborting the run."
    },
    LAST_ERROR: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Message string describing the most recent error condition."
    },
    SCRIPT_HAS_OUTPUT: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Set to non-zero by a script to indicate that it has produced output."
    },
    AUTOMATIC_PRINT: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "Controls whether the report is automatically printed at the end of the run."
    },

    // ============================================================
    // Client / fund / member context
    // ============================================================

    CLIENT_CODE: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Code identifying the current client (fund) being processed."
    },
    COMPANY_CODE: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Code identifying the employer or company within the current client."
    },
    DIVISION: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Division code within the current company context."
    },
    SYSTEM_DATE: {
        type: AcurityTypes.DATE,
        readOnly: true,
        description: "The current system (valuation) date as set by the runtime."
    },
    START_DATE: {
        type: AcurityTypes.DATE,
        readOnly: true,
        description: "The start date of the current processing period or transaction."
    },
    DAT_PATH: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "File system path to the client data directory."
    },
    TRANS_REF: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "Reference number of the current transaction being processed."
    },
    BATCH_REF: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "Reference number of the current processing batch."
    },
    MBR_GL_KEY: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "General ledger key for the current member record. [best guess]"
    },
    SCREEN_UPDATES: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "Controls whether progress updates are displayed on screen during processing."
    },
    VERSION_NBR: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Version number of the Acurity Architect runtime."
    },
    ATO_IDENTITY: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Australian Tax Office identity string used for ATO reporting."
    },
    QQTE_SURCHARGE: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Surcharge rate for QQTE (qualifying equivalent tax entity) calculations. [best guess]"
    },
    QQTE_PRE83: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Pre-1983 component proportion for QQTE tax calculations. [best guess]"
    },
    SAL_FREQ: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Salary frequency factor (e.g. 52 for weekly, 12 for monthly). [best guess]"
    },
    TESTING_BATCH: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "Non-zero when the current run is a test batch (not a live production run)."
    },
    UNIT_TESTING: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "Non-zero when the script is being executed under the unit-test harness."
    },

    // ============================================================
    // Web / external integration
    // ============================================================

    WEB_USERID: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "User ID provided by the web or external caller for the current request."
    },
    WEB_PASSWORD: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Password provided by the web or external caller. [best guess — treat as sensitive]"
    },
    WEB_REQUEST: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "The incoming request payload or request-type code from the web caller."
    },
    WEB_TEXT_STR1: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Output text slot 1 written by the script as part of a web response."
    },
    WEB_TEXT_STR2: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Output text slot 2 written by the script as part of a web response."
    },
    WEB_TEXT_STR3: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Output text slot 3 written by the script as part of a web response."
    },
    WEB_TEXT_STR4: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Output text slot 4 written by the script as part of a web response."
    },
    WEB_TEXT_STR5: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Output text slot 5 written by the script as part of a web response."
    },
    WEB_TEXT_TYPE: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "MIME type or format indicator written by the script to describe its web response."
    },
    WEB_FILE_REF_ID: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "File reference ID provided by the web caller for the current request. [best guess]"
    },
    WEB_FILE_LINE_NO: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "Line number within the referenced file, provided by the web caller. [best guess]"
    },
    CONFIG_FILENAME: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Path or name of the configuration file loaded at startup."
    },
    AIS_URL: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "URL of the Acurity Integration Service endpoint. [best guess — not in treedata5 v15]"
    },

    // ============================================================
    // Separator strings (SEP0..5 + named separators)
    // ============================================================

    SEP0: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 0, set from the system or client configuration."
    },
    SEP1: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 1, set from the system or client configuration."
    },
    SEP2: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 2, set from the system or client configuration."
    },
    SEP3: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 3, set from the system or client configuration."
    },
    SEP4: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 4, set from the system or client configuration."
    },
    SEP5: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 5, set from the system or client configuration."
    },
    SEP_CP: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Separator string used between compound key parts (e.g. client/plan codes). [best guess]"
    },
    SEP_FOLDER: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "File system path separator for folder paths (platform-specific). [best guess]"
    },
    SEP_LDAP_GROUP: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Separator character used between LDAP group names in a group list. [best guess]"
    },
    LDAP_USER_GROUPS_PREFIX: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Prefix applied to LDAP group names when evaluating user authorisation. [best guess]"
    },

    // ============================================================
    // GCF (global client flags)
    // ============================================================

    GCF_SHORT_FUND: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Short display name for 'fund' as configured for this client (e.g. 'Fund')."
    },
    GCF_LONG_FUND: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Long display name for 'fund' as configured for this client (e.g. 'Superannuation Fund')."
    },
    GCF_SHORT_MEMBER: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Short display name for 'member' as configured for this client (e.g. 'Member')."
    },
    GCF_LONG_MEMBER: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Long display name for 'member' as configured for this client (e.g. 'Fund Member')."
    },
    GCF_PRNT_AUTH: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Print authority flag from the global client flags. [best guess]"
    },
    GCF_TAX: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Tax regime or tax-related flag from the global client flags. [best guess]"
    },
    GCF_PRINT_PAGE: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag controlling page-level print behaviour from the global client flags. [best guess]"
    },
    GCF_REST_UNP_MAX: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Restriction on unrestricted non-preserved maximum, from the global client flags. [best guess]"
    },
    GCF_VEST_PRES: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Vesting and preservation flag from the global client flags. [best guess]"
    },

    // ============================================================
    // Printer configuration
    // ============================================================

    PRN_NAME: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Name of the configured printer for this report."
    },
    PRN_SCRIPT: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Printer control script or escape sequence profile name. [best guess]"
    },
    PRN_CVT: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Printer conversion / character-set mapping identifier. [best guess]"
    },
    PRN_TRAY1: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Printer tray 1 selection code or name. [best guess]"
    },
    PRN_TRAY2: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Printer tray 2 selection code or name. [best guess]"
    },
    PRN_PARMS: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Additional printer parameters passed to the print driver. [best guess]"
    },
    PRN_FILENAME: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Output filename when printing to a file rather than a physical printer."
    },

    // ============================================================
    // Extension / presenter integration
    // ============================================================

    EXTENSION_MESSAGE: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Message string written by the script to communicate with the Acurity Presenter extension."
    },
    EXTENSION_CONTEXT: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Context string provided by the Acurity Presenter extension for the current invocation."
    },
};

export {
    BuiltInGlobalVariables
};
