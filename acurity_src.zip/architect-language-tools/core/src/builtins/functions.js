/**
 * Backward-compatible built-ins barrel.
 * Registry data now lives in functionsRegistry/globalVariablesRegistry and helper logic in helpers.
 */

import { BuiltInFunctions } from "./functionsRegistry.js";
import { BuiltInGlobalVariables } from "./globalVariablesRegistry.js";
import {
    getFunctionReturnType,
    getFunctionSignature,
    isBuiltInGlobalVariable,
    getGlobalVariableType,
    validateFunctionCall
} from "./helpers.js";
import {
    OutputPositioningDirectives,
    getOutputDirective,
    isOutputDirective
} from "./outputPositioningDirectives.js";

export {
    BuiltInFunctions,
    BuiltInGlobalVariables,
    getFunctionReturnType,
    getFunctionSignature,
    isBuiltInGlobalVariable,
    getGlobalVariableType,
    validateFunctionCall,
    OutputPositioningDirectives,
    getOutputDirective,
    isOutputDirective
};
