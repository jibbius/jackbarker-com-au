/**
 * supplementaryLoader — manages the sibling plugin injection contract.
 *
 * A sibling plugin (companion VS Code extension or employer supplementary module)
 * may call registerSupplementary() at startup to provide additional validators
 * and builtins. This module holds those registrations and exposes them to the
 * validation pipeline in collectDiagnostics.js.
 *
 * ---
 *
 * ## Supplementary module shape
 *
 * The module's default export (or the module object itself for CJS) must be:
 *
 * ```js
 * {
 *   validators?: Array<SupplementaryValidator>,
 *   severityOverrides?: { [ruleId: string]: "error"|"warning"|"information"|"hint"|"off" },
 *   builtins?: {
 *     functions?:         { [UPPER_NAME: string]: FunctionEntry },
 *     globalVariables?:   { [UPPER_NAME: string]: GlobalVariableEntry },
 *     tables?:            { [TWO_CHAR_CODE: string]: { entry: TableEntry, structure: TableStructure } },
 *     help?:              { [UPPER_TOKEN: string]: string },   // token → help page filename
 *     deprecatedSymbols?: { [UPPER_OLD_NAME: string]: string } // old name → replacement name/expression
 *   }
 * }
 * ```
 *
 * ## severityOverrides
 *
 * Maps ACU-XXX-NNN messageIds to a desired severity level. Positioned at **layer 2**
 * in the resolution chain — above catalog defaults but below all project, workspace,
 * file, and line tailoring. This means any `.acurity.json`, VS Code workspace setting,
 * `@mode:` annotation, or `@rule-ignore` can override the supplementary setting.
 *
 * The messageIds are translated to camelCase ruleIds at registration time (using
 * `getCatalogEntry`). Unknown messageIds are skipped with a warning. Applies only
 * to core diagnostics; supplementary validators set their own severity directly.
 *
 * ```js
 * severityOverrides: {
 *   "ACU-INT-002": "warning",   // organisation baseline: downgrade from error
 *   "ACU-TODO-001": "off"       // suppress entirely at organisation level
 * }
 * ```
 *
 * "off" suppresses the rule unless overridden by a higher-priority layer.
 * Overrides cannot restore a rule suppressed to null at the workspace/catalog layer —
 * those diagnostics are never produced in the first place.
 *
 * ## SupplementaryValidator signature
 *
 * ```js
 * function myValidator(document, context) {
 *   // document — VS Code TextDocument or PlainTextDocument
 *   // context.facts    — full documentFacts object
 *   // context.filePath — absolute path to the file being validated
 *   // context.config   — .acurity.json config object, or null
 *   return [/* diagnostic[] *\/];
 * }
 * ```
 *
 * ## Diagnostic shape
 *
 * Each supplementary validator must return an array of plain objects:
 *
 * ```js
 * {
 *   range:    { start: { line, character }, end: { line, character } },
 *   message:  string,
 *   severity: 0 | 1 | 2 | 3,   // Error=0, Warning=1, Information=2, Hint=3
 *   code:     string,            // employer rule ID — must NOT start with 'ACU-'
 *   source:   string             // recommended: 'acurity-ext'
 * }
 * ```
 *
 * ## FunctionEntry shape
 *
 * Same as entries in core/src/builtins/functionsRegistry.js:
 *
 * ```js
 * {
 *   params:      AcurityType[],
 *   returns:     AcurityType,
 *   paramModes?: string[],   // "REF" | "VAR" | "VAR_init_not_required" | "VAR_destroy"
 *   varArgs?:    boolean,
 *   description?: string
 * }
 * ```
 *
 * ## GlobalVariableEntry shape
 *
 * ```js
 * { type: AcurityType, description?: string }
 * ```
 */

import { BuiltInFunctions } from "./builtins/functionsRegistry.js";
import { BuiltInGlobalVariables } from "./builtins/globalVariablesRegistry.js";
import { DeprecatedHandles } from "./builtins/deprecatedHandlesRegistry.js";
import { registerSupplementaryTable, isValidTableSynonym } from "./builtins/tableRegistry.js";
import { registerHelpEntries } from "./builtins/helpRegistry.js";
import { getCatalogEntry } from "./diagnostics/diagnosticCatalog.js";
import * as logger from "./logger.js";

/** @type {Array<Function>} */
const _supplementaryValidators = [];

/**
 * Supplementary severity overrides keyed by camelCase ruleId (not messageId).
 * Values are severity strings ("error"|"warning"|"information"|"hint"|"off").
 * Stored in this form so they slot directly into the getRuleSeverity resolution
 * chain at layer 2 — between catalog defaults and project/workspace tailoring.
 * @type {{ [ruleId: string]: string }}
 */
const _severityOverrides = {};

/**
 * Keys injected into BuiltInFunctions and BuiltInGlobalVariables by the current
 * supplementary registration. Tracked so clearSupplementary can reverse them.
 */
const _injectedFunctionKeys = new Set();
const _injectedGlobalVariableKeys = new Set();
const _injectedDeprecatedSymbolKeys = new Set();

const _VALID_SEVERITY_STRINGS = new Set(["error", "warning", "information", "hint", "off"]);

// ---------------------------------------------------------------------------
// Schema validation
// ---------------------------------------------------------------------------

/**
 * Validates the shape of a supplementary module object.
 * Throws an Error with a clear message on any violation.
 * @param {*} mod
 */
function validateSupplementaryModule(mod) {
    if (typeof mod !== "object" || mod === null || Array.isArray(mod)) {
        throw new Error("Supplementary module must export a plain object.");
    }

    if (mod.validators !== undefined) {
        if (!Array.isArray(mod.validators)) {
            throw new Error('"validators" must be an array.');
        }
        for (let i = 0; i < mod.validators.length; i++) {
            if (typeof mod.validators[i] !== "function") {
                throw new Error(`validators[${i}] must be a function.`);
            }
        }
    }

    if (mod.severityOverrides !== undefined) {
        if (typeof mod.severityOverrides !== "object" || mod.severityOverrides === null || Array.isArray(mod.severityOverrides)) {
            throw new Error('"severityOverrides" must be an object.');
        }
        for (const [ruleId, severity] of Object.entries(mod.severityOverrides)) {
            if (!_VALID_SEVERITY_STRINGS.has(severity)) {
                throw new Error(`severityOverrides["${ruleId}"] must be one of: error, warning, information, hint, off.`);
            }
        }
    }

    if (mod.builtins !== undefined) {
        if (typeof mod.builtins !== "object" || mod.builtins === null || Array.isArray(mod.builtins)) {
            throw new Error('"builtins" must be an object.');
        }

        if (mod.builtins.functions !== undefined) {
            if (
                typeof mod.builtins.functions !== "object" ||
                mod.builtins.functions === null ||
                Array.isArray(mod.builtins.functions)
            ) {
                throw new Error('"builtins.functions" must be an object.');
            }
            for (const [name, entry] of Object.entries(mod.builtins.functions)) {
                if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
                    throw new Error(`builtins.functions["${name}"] must be an object.`);
                }
                if (!Array.isArray(entry.params)) {
                    throw new Error(`builtins.functions["${name}"].params must be an array.`);
                }
                if (entry.returns === undefined) {
                    throw new Error(`builtins.functions["${name}"].returns is required.`);
                }
            }
        }

        if (mod.builtins.globalVariables !== undefined) {
            if (
                typeof mod.builtins.globalVariables !== "object" ||
                mod.builtins.globalVariables === null ||
                Array.isArray(mod.builtins.globalVariables)
            ) {
                throw new Error('"builtins.globalVariables" must be an object.');
            }
            for (const [name, entry] of Object.entries(mod.builtins.globalVariables)) {
                if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
                    throw new Error(`builtins.globalVariables["${name}"] must be an object.`);
                }
                if (typeof entry.type !== "string") {
                    throw new Error(`builtins.globalVariables["${name}"].type must be a string.`);
                }
            }
        }

        if (mod.builtins.tables !== undefined) {
            if (
                typeof mod.builtins.tables !== "object" ||
                mod.builtins.tables === null ||
                Array.isArray(mod.builtins.tables)
            ) {
                throw new Error('"builtins.tables" must be an object.');
            }
            for (const [code, reg] of Object.entries(mod.builtins.tables)) {
                if (typeof reg !== "object" || reg === null || Array.isArray(reg)) {
                    throw new Error(`builtins.tables["${code}"] must be an object.`);
                }
                if (typeof reg.entry !== "object" || reg.entry === null || Array.isArray(reg.entry)) {
                    throw new Error(`builtins.tables["${code}"].entry must be an object.`);
                }
                if (typeof reg.entry.name !== "string") {
                    throw new Error(`builtins.tables["${code}"].entry.name must be a string.`);
                }
                if (typeof reg.structure !== "object" || reg.structure === null || Array.isArray(reg.structure)) {
                    throw new Error(`builtins.tables["${code}"].structure must be an object.`);
                }
                if (typeof reg.structure.code !== "string") {
                    throw new Error(`builtins.tables["${code}"].structure.code must be a string.`);
                }
                if (!Array.isArray(reg.structure.indexes)) {
                    throw new Error(`builtins.tables["${code}"].structure.indexes must be an array.`);
                }
                if (typeof reg.structure.fields !== "object" || reg.structure.fields === null || Array.isArray(reg.structure.fields)) {
                    throw new Error(`builtins.tables["${code}"].structure.fields must be an object.`);
                }
            }
        }

        if (mod.builtins.help !== undefined) {
            if (
                typeof mod.builtins.help !== "object" ||
                mod.builtins.help === null ||
                Array.isArray(mod.builtins.help)
            ) {
                throw new Error('"builtins.help" must be an object.');
            }
            for (const [token, page] of Object.entries(mod.builtins.help)) {
                if (typeof page !== "string") {
                    throw new Error(`builtins.help["${token}"] must be a string.`);
                }
            }
        }

        if (mod.builtins.deprecatedSymbols !== undefined) {
            if (
                typeof mod.builtins.deprecatedSymbols !== "object" ||
                mod.builtins.deprecatedSymbols === null ||
                Array.isArray(mod.builtins.deprecatedSymbols)
            ) {
                throw new Error('"builtins.deprecatedSymbols" must be an object.');
            }
            for (const [name, replacement] of Object.entries(mod.builtins.deprecatedSymbols)) {
                if (typeof replacement !== "string") {
                    throw new Error(`builtins.deprecatedSymbols["${name}"] must be a string.`);
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Builtin merging
// ---------------------------------------------------------------------------

/**
 * Merges supplementary builtins into the live core registries.
 * Call once at startup — mutates shared registry objects.
 *
 * @param {object}  builtins
 * @param {boolean} preferCore  When true, core entries win on conflict (logged as
 *                              a warning). When false (default), employer entries
 *                              overwrite core entries (logged at debug level).
 */
function _mergeBuiltins(builtins, preferCore) {
    if (builtins.functions) {
        let added = 0;
        let overwritten = 0;
        for (const [name, entry] of Object.entries(builtins.functions)) {
            const key = name.toUpperCase();
            const conflict = Object.prototype.hasOwnProperty.call(BuiltInFunctions, key);
            if (conflict && preferCore) {
                logger.warn(`supplementaryLoader: function "${key}" conflicts with a core entry — keeping core (preferCore=true).`);
                continue;
            }
            BuiltInFunctions[key] = entry;
            _injectedFunctionKeys.add(key);
            if (conflict) {
                logger.log(`supplementaryLoader: function "${key}" overrides core entry (preferCore=false).`);
                overwritten++;
            } else {
                added++;
            }
        }
        if (added > 0)      logger.log(`supplementaryLoader: merged ${added} new supplementary function(s).`);
        if (overwritten > 0) logger.log(`supplementaryLoader: overrode ${overwritten} core function(s) with employer definitions.`);
    }

    if (builtins.globalVariables) {
        let added = 0;
        let overwritten = 0;
        for (const [name, entry] of Object.entries(builtins.globalVariables)) {
            const key = name.toUpperCase();
            const conflict = Object.prototype.hasOwnProperty.call(BuiltInGlobalVariables, key);
            if (conflict && preferCore) {
                logger.warn(`supplementaryLoader: global variable "${key}" conflicts with a core entry — keeping core (preferCore=true).`);
                continue;
            }
            BuiltInGlobalVariables[key] = entry;
            _injectedGlobalVariableKeys.add(key);
            if (conflict) {
                logger.log(`supplementaryLoader: global variable "${key}" overrides core entry (preferCore=false).`);
                overwritten++;
            } else {
                added++;
            }
        }
        if (added > 0)      logger.log(`supplementaryLoader: merged ${added} new supplementary global variable(s).`);
        if (overwritten > 0) logger.log(`supplementaryLoader: overrode ${overwritten} core global variable(s) with employer definitions.`);
    }

    if (builtins.tables) {
        let added = 0;
        let overwritten = 0;
        for (const [code, reg] of Object.entries(builtins.tables)) {
            const key = code.toUpperCase();
            const conflict = isValidTableSynonym(key);
            registerSupplementaryTable(key, reg.entry, reg.structure, preferCore);
            if (conflict) {
                if (!preferCore) overwritten++;
            } else {
                added++;
            }
        }
        if (added > 0)       logger.log(`supplementaryLoader: merged ${added} new supplementary table(s).`);
        if (overwritten > 0) logger.log(`supplementaryLoader: overrode ${overwritten} core table(s) with employer definitions.`);
    }

    if (builtins.help) {
        registerHelpEntries(builtins.help, preferCore);
        logger.log(`supplementaryLoader: merged ${Object.keys(builtins.help).length} supplementary help entry(ies).`);
    }

    if (builtins.deprecatedSymbols) {
        let added = 0;
        let overwritten = 0;
        for (const [name, replacement] of Object.entries(builtins.deprecatedSymbols)) {
            const key = name.toUpperCase();
            const conflict = Object.prototype.hasOwnProperty.call(DeprecatedHandles, key);
            if (conflict && preferCore) {
                logger.warn(`supplementaryLoader: deprecated symbol "${key}" conflicts with a core entry — keeping core (preferCore=true).`);
                continue;
            }
            DeprecatedHandles[key] = replacement;
            _injectedDeprecatedSymbolKeys.add(key);
            if (conflict) {
                logger.log(`supplementaryLoader: deprecated symbol "${key}" overrides core entry (preferCore=false).`);
                overwritten++;
            } else {
                added++;
            }
        }
        if (added > 0)       logger.log(`supplementaryLoader: merged ${added} new supplementary deprecated symbol(s).`);
        if (overwritten > 0) logger.log(`supplementaryLoader: overrode ${overwritten} core deprecated symbol(s) with employer definitions.`);
    }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Registers a supplementary module.
 *
 * Validates the module shape and — on success — merges builtins into the live
 * registries and appends validators to the pipeline. Call once at startup.
 *
 * The default export is unwrapped automatically, so both CJS and ESM modules
 * work without the caller needing to access `.default`:
 *
 *   // VS Code companion extension (CJS):
 *   core.registerSupplementary(require('./supplementary'));
 *
 *   // CLI (ESM):
 *   const mod = await import('./supplementary/index.js');
 *   registerSupplementary(mod);
 *
 * @param {object}  mod              - The supplementary module (or its default export)
 * @param {object}  [options]
 * @param {boolean} [options.preferCore=false]
 *   When false (default), employer builtin entries overwrite core entries on conflict —
 *   the employer's registry is treated as authoritative. When true, core entries win and
 *   the conflict is logged as a warning. Set to true in tests that rely on the exact
 *   core function signatures, or when integrating a module whose entries are not yet
 *   fully validated against the production function set.
 * @throws {Error} if the module shape is invalid
 */
function registerSupplementary(mod, options = {}) {
    const preferCore = options.preferCore === true;

    // Unwrap default export so both `require()` and `import()` callers work.
    const resolved = mod && mod.default !== undefined ? mod.default : mod;

    validateSupplementaryModule(resolved);

    if (resolved.validators && resolved.validators.length > 0) {
        _supplementaryValidators.push(...resolved.validators);
        logger.log(`supplementaryLoader: registered ${resolved.validators.length} supplementary validator(s).`);
    }

    if (resolved.severityOverrides) {
        let count = 0;
        let skipped = 0;
        for (const [messageId, severity] of Object.entries(resolved.severityOverrides)) {
            const entry = getCatalogEntry(messageId);
            if (!entry) {
                logger.warn(`supplementaryLoader: severityOverrides["${messageId}"] — messageId not found in catalog, skipped.`);
                skipped++;
                continue;
            }
            _severityOverrides[entry.ruleId] = severity;
            count++;
        }
        if (count > 0)   logger.log(`supplementaryLoader: registered ${count} severity override(s).`);
        if (skipped > 0) logger.warn(`supplementaryLoader: skipped ${skipped} unrecognised severity override(s).`);
    }

    if (resolved.builtins) {
        _mergeBuiltins(resolved.builtins, preferCore);
    }
}

/**
 * Returns a snapshot of the currently registered supplementary validators.
 * @returns {Function[]}
 */
function getSupplementaryValidators() {
    return _supplementaryValidators.slice();
}

/**
 * Returns the registered severity overrides as a plain object mapping
 * camelCase ruleId → severity string ("error"|"warning"|"information"|"hint"|"off").
 * Returns null when no overrides have been registered.
 *
 * These overrides sit at layer 2 in the resolution chain — above catalog defaults
 * but below all project, workspace, file, and line tailoring. Callers incorporate
 * them as a fallback between catalog profile severity and any higher-priority source:
 *
 *   workspaceOverride ?? supplementaryOverrides?.[ruleId] ?? profileRules[ruleId]
 *
 * @returns {{ [ruleId: string]: string }|null}
 */
function getSupplementarySeverityOverrides() {
    return Object.keys(_severityOverrides).length > 0 ? _severityOverrides : null;
}

/**
 * Clears all supplementary registrations: validators, severity overrides, and
 * any function/globalVariable entries injected into the live registries.
 * Intended for use in tests — reverses all mutations made by registerSupplementary.
 */
function clearSupplementary() {
    _supplementaryValidators.length = 0;
    for (const key of Object.keys(_severityOverrides)) {
        delete _severityOverrides[key];
    }
    for (const key of _injectedFunctionKeys) {
        delete BuiltInFunctions[key];
    }
    _injectedFunctionKeys.clear();
    for (const key of _injectedGlobalVariableKeys) {
        delete BuiltInGlobalVariables[key];
    }
    _injectedGlobalVariableKeys.clear();
    for (const key of _injectedDeprecatedSymbolKeys) {
        delete DeprecatedHandles[key];
    }
    _injectedDeprecatedSymbolKeys.clear();
}

export { registerSupplementary, getSupplementaryValidators, getSupplementarySeverityOverrides, clearSupplementary };
