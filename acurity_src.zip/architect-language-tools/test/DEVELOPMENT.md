# Test — Context

This workspace contains the syntax-test suite — the TDD layer for all validators.
Tests are written as real Architect code (`.TXT` files) paired with JSON spec files
that declare what diagnostics must (or must not) be produced.

Full format documentation: `test/syntax-tests/README.md`

---

## Test Anatomy

Every test scenario lives in its own subfolder under `test/syntax-tests/`:

```
test/syntax-tests/<category>/<suite>/
├── 0001.TXT                  ← Architect source code (the input)
├── 0001.test-spec.json       ← Expectations: which diagnostics should appear
├── 0001.FIXED.TXT            ← (code-action tests only) expected result after quick fix
└── 0001.INCLUDE1.TXT         ← (include tests only) additional included files
```

Numbering is suite-local — each subfolder starts at `0001`.

---

## Spec Schema (summary)

```json
{
  "schema-version": "2.0",
  "test-id": "my-0001",
  "test-name": "Descriptive name",
  "test-entry": "my-0001.TXT",
  "assert-only-listed": true,
  "assert-message-exists": [
    { "id": "ACU-XXX-NNN", "line": 5, "severity": "error" }
  ],
  "assert-message-not-exists": [
    { "id": "ACU-XXX-NNN" }
  ]
}
```

Use `assert-message-exists` for diagnostics that must fire; use `assert-message-not-exists` for
diagnostics that must never appear (check is always file-wide — `line` is ignored in
`assert-message-not-exists`). Set `assert-only-listed: true` when the test should be exhaustive
and no unexpected diagnostics are permitted.

---

## Categories

| Folder | What it covers |
|---|---|
| `core/` | General integration: functions, types, include resolution |
| `validators/` | Individual validator rules |
| `code-actions/` | Quick fix correctness (requires `.FIXED.TXT`) |
| `block-structure/` | IF/ENDIF, DO/ENDDO block pairing |
| `arguments-string-*/` | Literal string argument validators |
| `edge-cases/` | Boundary conditions, regression captures |

---

## How to Write a New Test (TDD Approach)

1. **Create a subfolder** under the most relevant category (or create a new category folder).
2. **Write `0001.TXT`** — Architect code that demonstrates the scenario.
   Write it to be readable by anyone familiar with Architect.
3. **Write `0001.test-spec.json`** — declare what the validator *should* produce.
   The test will fail until the validator is implemented — that is the point.
4. **Run the test suite** to confirm the new test fails: `npm run test:syntax`
5. **Implement the validator** in `core/src/validators/` until the test passes.
6. **Add `assert-message-not-exists`** entries for messages that must *never* appear —
   this guards against false positives.

---

## Running Tests

```bash
# From architect-language-tools/
npm run test:syntax
```

The runner recursively scans all subfolders for `.test-spec.json` files and reports
pass/fail per scenario. Exit code `0` = all pass, `1` = one or more failures.

---

## Rules

- Tests must be written **before** the validator implementation (TDD).
- Test `.TXT` files must be valid-looking Architect code — they document intent.
- A test that only uses `assert-message-not-exists` (no `assert-message-exists`) is valid — it
  asserts that a rule does *not* fire on a given input (non-regression).
- Do not delete tests — mark them with a note in the spec if they are intentionally
  skipped or superseded.
