/**
 * Supplementary syntax-spec runner.
 *
 * Loads the sample supplementary module, registers it, and runs all
 * `.test-spec.json` files found under
 *   architect-language-tools-supplementary/test/syntax-tests/
 *
 * Uses the same `runSingleSpec` / `findAllTestSpecs` helpers from
 * `runSyntaxSpecs.js` so the spec format and assertion logic are identical.
 * Because `runSingleSpec` calls `collectDiagnostics` (VS Code extension path)
 * which in turn calls `collectDiagnosticsAsync` from core, supplementary
 * validators fire automatically when they are registered.
 *
 * Calls `clearSupplementary()` in a finally block so that this runner never
 * leaves supplementary state visible to any subsequently-executed test suite.
 */

import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

import { registerSupplementary, clearSupplementary } from "../core/src/supplementaryLoader.js";
import { runSingleSpec, findAllTestSpecs } from "./runSyntaxSpecs.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname  = dirname(__filename);

// Path to the supplementary package's syntax-test directory (sibling repo)
const SUPPLEMENTARY_TESTS_DIR = path.resolve(
    __dirname,
    "../../architect-language-tools-supplementary/test/syntax-tests"
);

/**
 * Runs all supplementary syntax specs.
 *
 * @returns {Promise<{ total: number, passed: number, failed: number, results: Array }>}
 */
async function runSupplementarySyntaxSpecs() {
    const supplementaryMod = await import(
        "../../architect-language-tools-supplementary/index.js"
    );

    registerSupplementary(supplementaryMod);

    try {
        const testSpecs = findAllTestSpecs(SUPPLEMENTARY_TESTS_DIR);
        const results = [];

        for (const { specPath, baseDir } of testSpecs) {
            const result = await runSingleSpec(specPath, baseDir);
            const relativeSpecPath = path.relative(SUPPLEMENTARY_TESTS_DIR, specPath);
            const suiteDir = path.dirname(relativeSpecPath);

            results.push({
                ...result,
                suite:    suiteDir === "." ? "root" : suiteDir.replace(/\\/g, "/"),
                specPath: relativeSpecPath.replace(/\\/g, "/")
            });
        }

        const passed = results.filter((r) => r.pass).length;

        return {
            total:   results.length,
            passed,
            failed:  results.length - passed,
            results
        };
    } finally {
        clearSupplementary();
    }
}

export { runSupplementarySyntaxSpecs };
