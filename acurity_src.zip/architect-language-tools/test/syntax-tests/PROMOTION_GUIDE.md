# Promotion Guide: Draft Tests to Syntax Suite

This guide is for human developers and AI agents promoting tests from
`test/syntax-tests-draft/_ready_to_promote/` into the live suite at
`test/syntax-tests/`.

---

## The Promotion Task

A draft test consists of a `.TXT` file (Architect source code) sitting in the
`_ready_to_promote/` folder. To promote it you:

1. Copy the `.TXT` file into the correct subfolder under `test/syntax-tests/`.
2. Write a `test-spec.json` file alongside it (same filename prefix, `.test-spec.json` suffix).

The runner picks up any `.test-spec.json` file it finds recursively under `test/syntax-tests/`,
so no registration step is needed.

---

## Step-by-Step Process

1. **Read the TXT file.** The header comments usually state what the test is verifying.
   Understand the intent before writing any assertions.

2. **Decide the target subfolder.**
   - `core/` — general language behaviour (functions, variables, include resolution, types)
   - `coding-standards/` — style and profile rules (keyword casing, operator spacing, etc.)
   - Create a new category folder if neither fits.

3. **Copy the TXT file** into the chosen subfolder. Do not rename it unless the filename
   conflicts with an existing file in that folder.

4. **Write the spec file.** Name it with the same base as the TXT file and a
   `.test-spec.json` suffix (e.g. `my-rule-0001.TXT` → `my-rule-0001.test-spec.json`).
   Always start with `"schema-version": "2.0"`.

5. **Run the suite** and observe which diagnostics actually fire:
   ```bash
   cd architect-language-tools
   npm run test:syntax
   ```
   A new spec with empty `assert-message-exists` will pass trivially — use the runner
   output to discover what diagnostics the file actually produces.

6. **Populate `assert-message-exists`** with every diagnostic that should fire.
   Use `id` (preferred) plus `line` and `severity` where you want precision.

7. **Set `assert-only-listed: true`** if the test should be exhaustive — i.e. no
   diagnostic may fire that is not listed in `assert-message-exists`. Only set this
   once you have enumerated every diagnostic the file produces.

8. **For rules not yet implemented,** add an `assert-message-not-exists` entry instead
   of an `assert-message-exists` entry. Leave a `comment` field explaining the stub
   (see TDD Stub Pattern below). The test will pass now and flip to failing when the
   rule is implemented — that is the correct TDD signal.

9. **Iterate** until only intentional TDD stubs are failing.

---

## Critical Gotchas (things that catch agents out)

- **Line numbers are 1-indexed** in spec files, matching what the editor shows. The runner
  converts to the 0-based internal representation automatically.

- **`// @mode:strict` in the TXT file auto-activates the strict profile.** If the TXT file
  has this annotation in a comment near the top, the strict profile is active for the entire
  file. This causes strict-only rules (e.g. ACU-STY-004 operator spacing) to fire even
  without any explicit `test-config`. Expect and account for these diagnostics.

- **DO...UNTIL is a known limitation.** The block structure validator only recognises `ENDDO`
  as closing a `DO` block — `UNTIL` is not recognised. This means every `DO ... UNTIL`
  pattern fires `ACU-BLK-003` ("DO at line N is not closed with ENDDO"). Include these in
  `assert-message-exists`.

- **`assert-message-not-exists` ignores `line`.** The absence check is always file-wide.
  Writing `{ "id": "ACU-VAR-002", "line": 5 }` in `assert-message-not-exists` means
  "ACU-VAR-002 must not appear anywhere in the file", not just on line 5.

- **Use `assert-only-listed: true` carefully.** Only set it once you have enumerated every
  diagnostic the file emits. Do not set it on TDD stubs — a stub spec should not assert
  exhaustiveness when the rule is not yet implemented.

- **`count` is exact.** `{ "id": "ACU-STY-004", "count": 3 }` requires exactly 3 instances —
  not 2, not 4. If you are unsure of the count, omit the field (each entry in
  `assert-message-exists` matches one occurrence by default).

---

## TDD Stub Pattern

When a rule is not yet implemented, write the spec as if the rule were implemented but use
`assert-message-not-exists` to assert the rule does NOT fire. Because the rule does not exist,
the diagnostic will not be emitted, so the test passes. When the rule is later implemented, the
diagnostic will start firing and this test will flip to failing — which is the correct TDD signal
to go and update the spec.

```json
{
  "schema-version": "2.0",
  "test-id": "my-rule-0001",
  "test-name": "My rule — not yet implemented (STUB)",
  "test-entry": "my-rule-0001.TXT",
  "comment": "STUB: ACU-XYZ-001 is not yet implemented. When implemented, this should emit on line 15.",
  "assert-message-not-exists": [{ "id": "ACU-XYZ-001" }]
}
```

Do not add `assert-only-listed: true` to a stub spec.

---

## Running the Suite

```bash
cd architect-language-tools
npm run test:syntax
```

Exit 0 = all pass. Exit 1 = one or more failures. Output shows per-spec pass/fail with a
line-by-line diagnostic table for failures, including which assertions were not satisfied and
which unexpected diagnostics were emitted.
