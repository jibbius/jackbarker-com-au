/**
 * Test helper for creating mock VS Code document objects.
 */

/**
 * Creates a mock vscode.TextDocument from an array of lines.
 * @param {string[]} lines - Array of line content
 * @param {string} fileName - Optional file name
 * @returns {Object} Mock document object
 */
function createMockDocument(lines, fileName = '/test/mock.acurity') {
    return {
        lineCount: lines.length,
        lineAt: (index) => {
            if (index < 0 || index >= lines.length) {
                throw new Error(`Line index ${index} out of bounds (0-${lines.length - 1})`);
            }
            return {
                text: lines[index],
                lineNumber: index,
                range: {
                    start: { line: index, character: 0 },
                    end: { line: index, character: lines[index].length }
                }
            };
        },
        getText: (range) => {
            if (!range) {
                return lines.join('\n');
            }
            // Simple implementation for single-line ranges
            if (range.start.line === range.end.line) {
                const line = lines[range.start.line];
                return line.substring(range.start.character, range.end.character);
            }
            // Multi-line ranges
            const result = [];
            for (let i = range.start.line; i <= range.end.line; i++) {
                if (i === range.start.line) {
                    result.push(lines[i].substring(range.start.character));
                } else if (i === range.end.line) {
                    result.push(lines[i].substring(0, range.end.character));
                } else {
                    result.push(lines[i]);
                }
            }
            return result.join('\n');
        },
        getWordRangeAtPosition: (position, regex) => {
            const line = lines[position.line];
            if (!regex) {
                regex = /[A-Za-z_][A-Za-z0-9_]*/;
            }
            
            // Find word at position
            const flags = regex instanceof RegExp
                ? (regex.flags.includes('g') ? regex.flags : regex.flags + 'g')
                : 'g';
            const matches = [...line.matchAll(regex instanceof RegExp ? new RegExp(regex.source, flags) : new RegExp(regex, 'g'))];
            for (const match of matches) {
                const start = match.index;
                const end = start + match[0].length;
                if (position.character >= start && position.character <= end) {
                    return {
                        start: { line: position.line, character: start },
                        end: { line: position.line, character: end }
                    };
                }
            }
            return undefined;
        },
        uri: {
            fsPath: fileName,
            toString: () => `file://${fileName}`
        },
        fileName: fileName,
        languageId: 'acurity',
        version: 1,
        isDirty: false,
        isUntitled: false,
        isClosed: false
    };
}

/**
 * Creates a mock document from a multi-line string.
 * @param {string} content - Multi-line string content
 * @param {string} fileName - Optional file name
 * @returns {Object} Mock document object
 */
function createMockDocumentFromString(content, fileName = '/test/mock.acurity') {
    const lines = content.split(/\r?\n/);
    return createMockDocument(lines, fileName);
}

export {
    createMockDocument,
    createMockDocumentFromString
};
