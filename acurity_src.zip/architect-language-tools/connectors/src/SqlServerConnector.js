import { spawn } from 'child_process';

const QUERY = 'SELECT CDz_Group, CDz_Description_Type, CDz_Description_Code, CDz_Description, CDc_Deleted FROM Description_Codes';

function buildPsScript() {
    return [
        "$ErrorActionPreference = 'Stop'",
        '$conn = New-Object System.Data.SqlClient.SqlConnection("Server=$env:ARCH_LANG_CONN_SERVER;Database=$env:ARCH_LANG_CONN_DATABASE;Integrated Security=True")',
        '$conn.Open()',
        '$cmd = $conn.CreateCommand()',
        `$cmd.CommandText = '${QUERY}'`,
        '$reader = $cmd.ExecuteReader()',
        '$rows = [System.Collections.Generic.List[object]]::new()',
        'while ($reader.Read()) {',
        '    $rows.Add(@{',
        '        g = $reader["CDz_Group"].Trim()',
        '        t = $reader["CDz_Description_Type"].Trim()',
        '        c = $reader["CDz_Description_Code"].Trim()',
        '        d = $reader["CDz_Description"].Trim()',
        '        x = $reader["CDc_Deleted"].Trim()',
        '    })',
        '}',
        '$conn.Close()',
        '$rows | ConvertTo-Json -Compress -Depth 1',
    ].join('\n');
}

function buildSqlcmdQuery() {
    return `SELECT RTRIM(CDz_Group) AS g, RTRIM(CDz_Description_Type) AS t, RTRIM(CDz_Description_Code) AS c, RTRIM(CDz_Description) AS d, RTRIM(CDc_Deleted) AS x FROM Description_Codes FOR JSON PATH`;
}

function spawnProcess(command, args, env) {
    return new Promise((resolve, reject) => {
        const proc = spawn(command, args, { env });
        let stdout = '';
        let stderr = '';
        proc.stdout.on('data', chunk => { stdout += chunk; });
        proc.stderr.on('data', chunk => { stderr += chunk; });
        proc.on('error', reject);
        proc.on('close', code => {
            if (code !== 0) {
                reject(new Error(stderr.trim() || `Process exited with code ${code}`));
            } else {
                resolve(stdout);
            }
        });
    });
}

function parseRows(stdout) {
    const text = stdout.trim();
    if (!text || text === 'null') return [];
    let parsed = JSON.parse(text);
    if (!Array.isArray(parsed)) parsed = [parsed];
    return parsed;
}

async function queryDescriptionCodes(server, database) {
    const env = { ...process.env, ARCH_LANG_CONN_SERVER: server, ARCH_LANG_CONN_DATABASE: database };

    // Primary: PowerShell via System.Data.SqlClient (handles Windows Auth natively)
    try {
        const script = buildPsScript();
        const encoded = Buffer.from(script, 'utf16le').toString('base64');
        const stdout = await spawnProcess(
            'powershell',
            ['-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded],
            env
        );
        return parseRows(stdout);
    } catch (psError) {
        // Fallback: sqlcmd with FOR JSON PATH (requires SQL Server 2016+)
        try {
            const query = buildSqlcmdQuery();
            const stdout = await spawnProcess(
                'sqlcmd',
                ['-S', server, '-d', database, '-E', '-Q', query, '-o', '-', '-f', '65001'],
                env
            );
            const jsonStart = stdout.indexOf('[');
            if (jsonStart === -1) throw new Error('sqlcmd returned no JSON output');
            return parseRows(stdout.slice(jsonStart));
        } catch (sqlcmdError) {
            throw new Error(`PowerShell: ${psError.message} | sqlcmd: ${sqlcmdError.message}`);
        }
    }
}

export { queryDescriptionCodes };
