import { readFile, writeFile, mkdir } from 'fs/promises';
import { dirname } from 'path';

const CACHE_VERSION = 1;

class DescriptionCodesCache {
    constructor() {
        this._map = new Map();
        this._status = { populated: false, fetchedAt: null, server: null, database: null };
    }

    async load(filePath) {
        try {
            const raw = await readFile(filePath, 'utf8');
            const parsed = JSON.parse(raw);
            if (parsed.version !== CACHE_VERSION || !parsed.data) {
                return { ok: false, age: null };
            }
            this._populateMap(parsed.data);
            this._status = {
                populated: true,
                fetchedAt: parsed.fetchedAt,
                server: parsed.server,
                database: parsed.database
            };
            return { ok: true, age: Date.now() - new Date(parsed.fetchedAt).getTime() };
        } catch {
            return { ok: false, age: null };
        }
    }

    async build(rows, server, database, filePath) {
        const data = {};
        for (const row of rows) {
            const key = row.g + row.t;
            if (!data[key]) data[key] = [];
            data[key].push({
                code: row.c,
                description: row.d,
                deprecated: row.x === 'Y'
            });
        }

        const fetchedAt = new Date().toISOString();
        const cacheFile = { version: CACHE_VERSION, fetchedAt, server, database, data };

        await mkdir(dirname(filePath), { recursive: true });
        await writeFile(filePath, JSON.stringify(cacheFile), 'utf8');

        this._populateMap(data);
        this._status = { populated: true, fetchedAt, server, database };
    }

    lookup(lookupCode) {
        return this._map.get(lookupCode) ?? [];
    }

    getStatus() {
        return { ...this._status };
    }

    clear() {
        this._map.clear();
        this._status = { populated: false, fetchedAt: null, server: null, database: null };
    }

    _populateMap(data) {
        this._map.clear();
        for (const [key, entries] of Object.entries(data)) {
            this._map.set(key, entries);
        }
    }
}

export { DescriptionCodesCache };
