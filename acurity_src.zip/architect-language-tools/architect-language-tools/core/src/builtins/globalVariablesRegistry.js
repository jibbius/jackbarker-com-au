/**
 * Built-in global variables for Acurity Architect.
 *
 * This registry supersedes the now-deleted constantsRegistry.js. Unlike that registry, each
 * entry carries `readOnly` and `description` metadata, reflecting the fact
 * that many of these variables are writable at runtime (they are not true
 * constants despite some historical naming).
 *
 * Source: treedata5.txt v15, section 03 > 0300 (Global Variables).
 * Types are as documented in treedata5. Where treedata5 uses INTEGER, the
 * canonical registry type is LONG (they are equivalent in Acurity).
 *
 * readOnly semantics:
 *   true  — set exclusively by the runtime; scripts should treat as read-only.
 *   false — writable by scripts; value changes are meaningful and expected.
 *
 * Descriptions marked [best guess] were inferred from naming conventions and
 * context; they have not been verified against authoritative documentation.
 */

import { AcurityTypes } from "../types/acurityTypes.js";

/**
 * Built-in global variables (used without a #VAR declaration).
 * Format: { name: { type, readOnly, description } }
 */
const BuiltInGlobalVariables = {

    // ============================================================
    // Boundary / sentinel values
    // ============================================================

    NEW_LINE_STR: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "A newline (line-break) character string."
    },
    MIN_STR: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "The minimum (lowest sort-order) string sentinel value."
    },
    MAX_STR: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "The maximum (highest sort-order) string sentinel value."
    },
    MIN_DATE: {
        type: AcurityTypes.DATE,
        readOnly: true,
        description: "The minimum representable date value."
    },
    MAX_DATE: {
        type: AcurityTypes.DATE,
        readOnly: true,
        description: "The maximum representable date value."
    },
    MIN_TIME: {
        type: AcurityTypes.TIME,
        readOnly: true,
        description: "The minimum representable time value."
    },
    MAX_TIME: {
        type: AcurityTypes.TIME,
        readOnly: true,
        description: "The maximum representable time value."
    },
    MIN_DOUBLE: {
        type: AcurityTypes.DOUBLE,
        readOnly: true,
        description: "The minimum representable double-precision value."
    },
    MAX_DOUBLE: {
        type: AcurityTypes.DOUBLE,
        readOnly: true,
        description: "The maximum representable double-precision value."
    },
    MIN_SHORT: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "The minimum representable SHORT integer value."
    },
    MAX_SHORT: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "The maximum representable SHORT integer value."
    },
    MIN_LONG: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "The minimum representable LONG integer value."
    },
    MAX_LONG: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "The maximum representable LONG integer value."
    },

    // ============================================================
    // Database / I/O status
    // ============================================================

    DB_STATUS: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Status code from the most recent database operation. Set by the runtime after each DB read/write; scripts should not assign to this."
    },

    // ============================================================
    // Report context / schedule phase flags
    // ============================================================

    INIT_SCHED: {
        type: AcurityTypes.BOOLEAN,
        readOnly: true,
        description: "TRUE during the schedule initialisation phase."
    },
    HEADER: {
        type: AcurityTypes.BOOLEAN,
        readOnly: false,
        description: "TRUE when the report is rendering its header section."
    },
    BODY: {
        type: AcurityTypes.BOOLEAN,
        readOnly: false,
        description: "TRUE when the report is rendering its body (detail) section."
    },
    FOOTER: {
        type: AcurityTypes.BOOLEAN,
        readOnly: false,
        description: "TRUE when the report is rendering its footer section."
    },
    FIN_SCHED: {
        type: AcurityTypes.BOOLEAN,
        readOnly: true,
        description: "TRUE during the schedule finalisation phase."
    },
    ACCEPT_REC: {
        type: AcurityTypes.BOOLEAN,
        readOnly: false,
        description: "Set to TRUE to accept the current record for output, or FALSE to suppress it. Scripts write this to filter records."
    },
    FORM_FEED: {
        type: AcurityTypes.BOOLEAN,
        readOnly: false,
        description: "Set to TRUE by a script to force a form-feed (page break) before the next output line."
    },
    SUB_TOTALLING: {
        type: AcurityTypes.BOOLEAN,
        readOnly: false,
        description: "TRUE when the report engine is currently evaluating a sub-total break. [best guess]"
    },
    SUBTOTAL: {
        type: AcurityTypes.BOOLEAN,
        readOnly: true,
        description: "TRUE when the current output pass is a sub-total row. [best guess]"
    },

    // ============================================================
    // Pagination / line counters
    // ============================================================

    CURRENT_PRINTER: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Index of the printer currently in use."
    },
    NUM_HEADER_LINES: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Number of lines in the report header section."
    },
    NUM_BODY_LINES: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Number of lines in the report body section."
    },
    NUM_FOOTER_LINES: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Number of lines in the report footer section."
    },
    NUM_FINAL_LINES: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Number of lines in the report final-schedule section."
    },
    NUM_LINES_PER_PAGE: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Configured number of output lines per page."
    },
    NUM_LINES_PRINTED: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Running count of lines printed on the current page."
    },
    PAGE_NUMBER: {
        type: AcurityTypes.LONG,
        readOnly: false,
        description: "Current page number in the report output."
    },
    TAB_STR: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "A tab character string used for column alignment."
    },

    // ============================================================
    // Schedule total accumulators (TOTCOL_1..30)
    // ============================================================

    TOTCOL_1:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 1." },
    TOTCOL_2:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 2." },
    TOTCOL_3:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 3." },
    TOTCOL_4:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 4." },
    TOTCOL_5:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 5." },
    TOTCOL_6:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 6." },
    TOTCOL_7:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 7." },
    TOTCOL_8:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 8." },
    TOTCOL_9:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 9." },
    TOTCOL_10: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 10." },
    TOTCOL_11: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 11." },
    TOTCOL_12: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 12." },
    TOTCOL_13: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 13." },
    TOTCOL_14: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 14." },
    TOTCOL_15: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 15." },
    TOTCOL_16: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 16." },
    TOTCOL_17: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 17." },
    TOTCOL_18: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 18." },
    TOTCOL_19: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 19." },
    TOTCOL_20: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 20." },
    TOTCOL_21: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 21." },
    TOTCOL_22: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 22." },
    TOTCOL_23: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 23." },
    TOTCOL_24: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 24." },
    TOTCOL_25: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 25." },
    TOTCOL_26: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 26." },
    TOTCOL_27: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 27." },
    TOTCOL_28: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 28." },
    TOTCOL_29: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 29." },
    TOTCOL_30: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule total accumulator column 30." },

    // ============================================================
    // Sub-total accumulators (SUBCOL_1..30)
    // ============================================================

    SUBCOL_1:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 1." },
    SUBCOL_2:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 2." },
    SUBCOL_3:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 3." },
    SUBCOL_4:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 4." },
    SUBCOL_5:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 5." },
    SUBCOL_6:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 6." },
    SUBCOL_7:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 7." },
    SUBCOL_8:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 8." },
    SUBCOL_9:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 9." },
    SUBCOL_10: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 10." },
    SUBCOL_11: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 11." },
    SUBCOL_12: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 12." },
    SUBCOL_13: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 13." },
    SUBCOL_14: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 14." },
    SUBCOL_15: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 15." },
    SUBCOL_16: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 16." },
    SUBCOL_17: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 17." },
    SUBCOL_18: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 18." },
    SUBCOL_19: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 19." },
    SUBCOL_20: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 20." },
    SUBCOL_21: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 21." },
    SUBCOL_22: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 22." },
    SUBCOL_23: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 23." },
    SUBCOL_24: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 24." },
    SUBCOL_25: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 25." },
    SUBCOL_26: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 26." },
    SUBCOL_27: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 27." },
    SUBCOL_28: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 28." },
    SUBCOL_29: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 29." },
    SUBCOL_30: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule sub-total accumulator column 30." },

    // ============================================================
    // Grand-total accumulators (GNDCOL_1..30)
    // ============================================================

    GNDCOL_1:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 1." },
    GNDCOL_2:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 2." },
    GNDCOL_3:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 3." },
    GNDCOL_4:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 4." },
    GNDCOL_5:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 5." },
    GNDCOL_6:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 6." },
    GNDCOL_7:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 7." },
    GNDCOL_8:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 8." },
    GNDCOL_9:  { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 9." },
    GNDCOL_10: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 10." },
    GNDCOL_11: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 11." },
    GNDCOL_12: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 12." },
    GNDCOL_13: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 13." },
    GNDCOL_14: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 14." },
    GNDCOL_15: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 15." },
    GNDCOL_16: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 16." },
    GNDCOL_17: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 17." },
    GNDCOL_18: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 18." },
    GNDCOL_19: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 19." },
    GNDCOL_20: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 20." },
    GNDCOL_21: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 21." },
    GNDCOL_22: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 22." },
    GNDCOL_23: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 23." },
    GNDCOL_24: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 24." },
    GNDCOL_25: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 25." },
    GNDCOL_26: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 26." },
    GNDCOL_27: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 27." },
    GNDCOL_28: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 28." },
    GNDCOL_29: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 29." },
    GNDCOL_30: { type: AcurityTypes.DOUBLE, readOnly: false, description: "Schedule grand-total accumulator column 30." },

    // ============================================================
    // Report / scheduling control
    // ============================================================

    UNALLOC_FLAG: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag indicating whether an unallocated condition applies. [best guess]"
    },
    REPORT_LEVEL: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Current report detail level. Scripts may set this to control output verbosity."
    },
    FATAL_ERROR_FLAG: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Set to a non-zero value by a script to signal a fatal error and abort processing."
    },
    SCH_COMPANY: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Company code supplied by the scheduler for the current run. [best guess]"
    },
    CLIENT_SYS_FLAG: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Client system flag provided by the runtime environment. [best guess]"
    },
    INV_BANK_ACC: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Investment bank account code for the current context. [best guess]"
    },
    CONT_CALCS_ONLY: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag indicating that only contribution calculations should be performed. [best guess]"
    },
    CONFIRM_REVIEW: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag indicating whether the run is a confirmation review pass. [best guess]"
    },
    PROCESS_DESC: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Description of the current process or schedule run."
    },
    INTERIM_REVIEW: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag indicating whether the run is an interim review pass. [best guess]"
    },
    EXITING_FLAG: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag set by a script to signal that the process should exit gracefully. [best guess]"
    },
    EXIT_FLAG: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag set by a script to trigger an early exit from the current report or function."
    },
    USE_EXIT_DATE: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag controlling whether the exit date is applied during processing. [best guess]"
    },
    SORT_FLAG: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Sort key or sort-control flag written by a script to influence record ordering."
    },
    REPORT_AMT: {
        type: AcurityTypes.DOUBLE,
        readOnly: true,
        description: "A general-purpose report amount accumulator that scripts may read and write."
    },
    REPORT_CUSTOM_DATA: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Free-form custom data string that scripts may attach to a report run."
    },
    REPORT_FILTERING_PARAMS: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Filtering parameters passed in by the caller for the current report run."
    },
    OUTPUT_TEMPLATE: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Name or path of the output template to use for this report. [best guess]"
    },
    OUTPUT_FILE_TYPE: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Code indicating the output file format (e.g. RTF, PDF, plain text). [best guess]"
    },
    ERRORS_TO_WARNINGS: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "When non-zero, errors are demoted to warnings rather than aborting the run."
    },
    LAST_ERROR: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Message string describing the most recent error condition."
    },
    SCRIPT_HAS_OUTPUT: {
        type: AcurityTypes.SHORT,
        readOnly: false,
        description: "Set to non-zero by a script to indicate that it has produced output."
    },
    AUTOMATIC_PRINT: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "Controls whether the report is automatically printed at the end of the run."
    },

    // ============================================================
    // Client / fund / member context
    // ============================================================

    CLIENT_CODE: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Code identifying the current client (fund) being processed."
    },
    COMPANY_CODE: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Code identifying the employer or company within the current client."
    },
    DIVISION: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Division code within the current company context."
    },
    SYSTEM_DATE: {
        type: AcurityTypes.DATE,
        readOnly: true,
        description: "The current system (valuation) date as set by the runtime."
    },
    START_DATE: {
        type: AcurityTypes.DATE,
        readOnly: true,
        description: "The start date of the current processing period or transaction."
    },
    DAT_PATH: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "File system path to the client data directory."
    },
    TRANS_REF: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "Reference number of the current transaction being processed."
    },
    BATCH_REF: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "Reference number of the current processing batch."
    },
    MBR_GL_KEY: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "General ledger key for the current member record. [best guess]"
    },
    SCREEN_UPDATES: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "Controls whether progress updates are displayed on screen during processing."
    },
    VERSION_NBR: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Version number of the Acurity Architect runtime."
    },
    ATO_IDENTITY: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Australian Tax Office identity string used for ATO reporting."
    },
    QQTE_SURCHARGE: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Surcharge rate for QQTE (qualifying equivalent tax entity) calculations. [best guess]"
    },
    QQTE_PRE83: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Pre-1983 component proportion for QQTE tax calculations. [best guess]"
    },
    SAL_FREQ: {
        type: AcurityTypes.DOUBLE,
        readOnly: false,
        description: "Salary frequency factor (e.g. 52 for weekly, 12 for monthly). [best guess]"
    },
    TESTING_BATCH: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "Non-zero when the current run is a test batch (not a live production run)."
    },
    UNIT_TESTING: {
        type: AcurityTypes.SHORT,
        readOnly: true,
        description: "Non-zero when the script is being executed under the unit-test harness."
    },

    // ============================================================
    // Web / external integration
    // ============================================================

    WEB_USERID: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "User ID provided by the web or external caller for the current request."
    },
    WEB_PASSWORD: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Password provided by the web or external caller. [best guess — treat as sensitive]"
    },
    WEB_REQUEST: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "The incoming request payload or request-type code from the web caller."
    },
    WEB_TEXT_STR1: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Output text slot 1 written by the script as part of a web response."
    },
    WEB_TEXT_STR2: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Output text slot 2 written by the script as part of a web response."
    },
    WEB_TEXT_STR3: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Output text slot 3 written by the script as part of a web response."
    },
    WEB_TEXT_STR4: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Output text slot 4 written by the script as part of a web response."
    },
    WEB_TEXT_STR5: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Output text slot 5 written by the script as part of a web response."
    },
    WEB_TEXT_TYPE: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "MIME type or format indicator written by the script to describe its web response."
    },
    WEB_FILE_REF_ID: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "File reference ID provided by the web caller for the current request. [best guess]"
    },
    WEB_FILE_LINE_NO: {
        type: AcurityTypes.LONG,
        readOnly: true,
        description: "Line number within the referenced file, provided by the web caller. [best guess]"
    },
    CONFIG_FILENAME: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Path or name of the configuration file loaded at startup."
    },
    AIS_URL: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "URL of the Acurity Integration Service endpoint. [best guess — not in treedata5 v15]"
    },

    // ============================================================
    // Separator strings (SEP0..5 + named separators)
    // ============================================================

    SEP0: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 0, set from the system or client configuration."
    },
    SEP1: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 1, set from the system or client configuration."
    },
    SEP2: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 2, set from the system or client configuration."
    },
    SEP3: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 3, set from the system or client configuration."
    },
    SEP4: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 4, set from the system or client configuration."
    },
    SEP5: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Configurable separator string 5, set from the system or client configuration."
    },
    SEP_CP: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Separator string used between compound key parts (e.g. client/plan codes). [best guess]"
    },
    SEP_FOLDER: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "File system path separator for folder paths (platform-specific). [best guess]"
    },
    SEP_LDAP_GROUP: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Separator character used between LDAP group names in a group list. [best guess]"
    },
    LDAP_USER_GROUPS_PREFIX: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Prefix applied to LDAP group names when evaluating user authorisation. [best guess]"
    },

    // ============================================================
    // GCF (global client flags)
    // ============================================================

    GCF_SHORT_FUND: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Short display name for 'fund' as configured for this client (e.g. 'Fund')."
    },
    GCF_LONG_FUND: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Long display name for 'fund' as configured for this client (e.g. 'Superannuation Fund')."
    },
    GCF_SHORT_MEMBER: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Short display name for 'member' as configured for this client (e.g. 'Member')."
    },
    GCF_LONG_MEMBER: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Long display name for 'member' as configured for this client (e.g. 'Fund Member')."
    },
    GCF_PRNT_AUTH: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Print authority flag from the global client flags. [best guess]"
    },
    GCF_TAX: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Tax regime or tax-related flag from the global client flags. [best guess]"
    },
    GCF_PRINT_PAGE: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Flag controlling page-level print behaviour from the global client flags. [best guess]"
    },
    GCF_REST_UNP_MAX: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Restriction on unrestricted non-preserved maximum, from the global client flags. [best guess]"
    },
    GCF_VEST_PRES: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Vesting and preservation flag from the global client flags. [best guess]"
    },

    // ============================================================
    // Printer configuration
    // ============================================================

    PRN_NAME: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Name of the configured printer for this report."
    },
    PRN_SCRIPT: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Printer control script or escape sequence profile name. [best guess]"
    },
    PRN_CVT: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Printer conversion / character-set mapping identifier. [best guess]"
    },
    PRN_TRAY1: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Printer tray 1 selection code or name. [best guess]"
    },
    PRN_TRAY2: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Printer tray 2 selection code or name. [best guess]"
    },
    PRN_PARMS: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Additional printer parameters passed to the print driver. [best guess]"
    },
    PRN_FILENAME: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Output filename when printing to a file rather than a physical printer."
    },

    // ============================================================
    // Extension / presenter integration
    // ============================================================

    EXTENSION_MESSAGE: {
        type: AcurityTypes.STRING,
        readOnly: false,
        description: "Message string written by the script to communicate with the Acurity Presenter extension."
    },
    EXTENSION_CONTEXT: {
        type: AcurityTypes.STRING,
        readOnly: true,
        description: "Context string provided by the Acurity Presenter extension for the current invocation."
    },
};

export {
    BuiltInGlobalVariables
};
