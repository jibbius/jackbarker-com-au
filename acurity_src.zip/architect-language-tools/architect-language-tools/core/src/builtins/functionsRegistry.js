/**
 * Built-in function signatures for Acurity Architect.
 */

import { AcurityTypes } from "../types/acurityTypes.js";

/**
 * Built-in function signatures.
 * Format: {
 * name: { -- function name
 *  params: [types...], -- parameter types in order
 *  paramModes: [modes...], -- "REF", "VAR", "VAR_init_not_required", "VAR_destroy" (optional, default all "REF")
 *  returns: type, -- return type
 *  varArgs: boolean, -- Function accepts variable number of arguments (optional, default false)
 *  description: string -- human-readable description of the function's behavior (optional)
 * } }
 */
const BuiltInFunctions = {
    // String functions
    GET_TOKEN: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.SHORT],
        paramLabels: ["inputString", "delimiter", "tokenIndex"],
        returns: AcurityTypes.STRING,
        description: "Extracts a token from a string using a delimiter"
    },
    TRIM_ALL: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.STRING,
        description: "Removes leading and trailing whitespace"
    },
    GET_STR: {
        params: [AcurityTypes.STRING],
        paramLabels: ["expression"],
        returns: AcurityTypes.STRING,
        description: "Returns a string value from an expression"
    },
    FORMAT: {
        params: [AcurityTypes.STRING, [AcurityTypes.SHORT, AcurityTypes.LONG, AcurityTypes.INTEGER, AcurityTypes.DOUBLE]],
        paramLabels: ["formatString", "value"],
        returns: AcurityTypes.STRING,
        description: "Formats a value according to a format string"
    },
    STR: {
        params: [[AcurityTypes.SHORT, AcurityTypes.LONG, AcurityTypes.INTEGER, AcurityTypes.DOUBLE, AcurityTypes.DATE, AcurityTypes.TIME, AcurityTypes.BOOLEAN, AcurityTypes.STRING, AcurityTypes.BIGINT]],
        paramLabels: ["value"],
        returns: AcurityTypes.STRING,
        description: "Converts a value to a string"
    },
    TO_LONG: {
        params: [[AcurityTypes.SHORT, AcurityTypes.INTEGER, AcurityTypes.DOUBLE, AcurityTypes.BIGINT]],
        paramLabels: ["value"],
        returns: AcurityTypes.LONG,
        description: "Converts a value to LONG"
    },
    TO_SHORT: {
        params: [[AcurityTypes.LONG, AcurityTypes.INTEGER, AcurityTypes.DOUBLE, AcurityTypes.BIGINT]],
        paramLabels: ["value"],
        returns: AcurityTypes.SHORT,
        description: "Converts a value to SHORT"
    },
    TO_DOUBLE: {
        params: [[AcurityTypes.SHORT, AcurityTypes.LONG, AcurityTypes.INTEGER, AcurityTypes.BIGINT]],
        paramLabels: ["value"],
        returns: AcurityTypes.DOUBLE,
        description: "Converts a value to DOUBLE"
    },
    TO_BIGINT: {
        params: [[AcurityTypes.SHORT, AcurityTypes.LONG, AcurityTypes.DOUBLE, AcurityTypes.INTEGER]],
        paramLabels: ["value"],
        returns: AcurityTypes.BIGINT,
        description: "Converts a value to BIGINT"
    },

    // Date functions
    DD: {
        params: [AcurityTypes.DATE],
        paramLabels: ["date"],
        returns: AcurityTypes.SHORT,
        description: "Extracts day from date"
    },
    MM: {
        params: [AcurityTypes.DATE],
        paramLabels: ["date"],
        returns: AcurityTypes.SHORT,
        description: "Extracts month from date"
    },
    YYYY: {
        params: [AcurityTypes.DATE],
        paramLabels: ["date"],
        returns: AcurityTypes.SHORT,
        description: "Extracts year from date"
    },

    // String functions (discovered from analysis)
    LENGTH: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.LONG,
        description: "Returns length of string"
    },
    REPEAT: {
        params: [AcurityTypes.STRING, AcurityTypes.SHORT],
        paramLabels: ["inputString", "count"],
        returns: AcurityTypes.STRING,
        description: "Repeats string n times"
    },
    INSERT_STR: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.SHORT],
        paramLabels: ["inputString", "insertString", "position"],
        returns: AcurityTypes.STRING,
        description: "Inserts string at position"
    },
    UPPER: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.STRING,
        description: "Converts string to uppercase"
    },
    STRIP: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.STRING,
        description: "Removes leading/trailing whitespace"
    },
    SEARCH: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING],
        paramLabels: ["inputString", "searchString"],
        returns: AcurityTypes.LONG,
        description: "Searches for substring position"
    },
    // CENTER removed — it is an output-positioning directive, not a function.
    // See core/src/builtins/outputPositioningDirectives.js
    STR_TO_DOUBLE: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.DOUBLE,
        description: "Converts string to DOUBLE"
    },
    STR_TO_LONG: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.LONG,
        description: "Converts string to LONG"
    },
    SUBSTR: {
        params: [AcurityTypes.STRING, AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["inputString", "startPosition", "length"],
        returns: AcurityTypes.STRING,
        description: "Extracts substring starting at position for length"
    },
    TRIM: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.STRING,
        description: "Removes leading and trailing whitespace"
    },
    // FROM removed — it is an output-positioning directive, not a function.
    // See core/src/builtins/outputPositioningDirectives.js

    // Additional date functions (discovered from analysis)
    DDADD: {
        params: [AcurityTypes.DATE, AcurityTypes.SHORT],
        paramLabels: ["date", "days"],
        returns: AcurityTypes.DATE,
        description: "Adds days to date"
    },
    YY: {
        params: [AcurityTypes.DATE],
        paramLabels: ["date"],
        returns: AcurityTypes.SHORT,
        description: "Extracts 2-digit year from date"
    },
    YYADD: {
        params: [AcurityTypes.DATE, AcurityTypes.SHORT],
        paramLabels: ["date", "years"],
        returns: AcurityTypes.DATE,
        description: "Adds years to date"
    },
    FORMAT_TIME: {
        params: [AcurityTypes.LONG],
        paramLabels: ["timeValue"],
        returns: AcurityTypes.STRING,
        description: "Formats time value as string"
    },
    SYS_SECONDS: {
        params: [],
        returns: AcurityTypes.DOUBLE,
        description: "Returns the current system time as elapsed seconds"
    },
    MONTH_ABV: {
        params: [AcurityTypes.SHORT],
        paramLabels: ["monthNumber"],
        returns: AcurityTypes.STRING,
        description: "Returns abbreviated month name"
    },
    RET_STR_TO_DATE: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.DATE,
        description: "Converts string to DATE"
    },
    STR_TO_DATE: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.DATE,
        description: "Converts string to DATE"
    },
    SYS_DATE: {
        params: [],
        returns: AcurityTypes.DATE,
        description: "Returns current system date"
    },
    SYS_TIME: {
        params: [],
        returns: AcurityTypes.STRING,
        description: "Returns current system time as a string"
    },

    // File I/O functions (discovered from analysis)
    FILE_WRITE: {
        params: [AcurityTypes.SHORT, AcurityTypes.STRING],
        paramLabels: ["fileHandle", "content"],
        returns: AcurityTypes.SHORT,
        description: "Writes string to file"
    },
    FILE_OPEN: {
        params: [AcurityTypes.SHORT, AcurityTypes.STRING, AcurityTypes.STRING],
        paramLabels: ["fileHandle", "filename", "mode"],
        paramModes:  ["VAR_init_not_required", "REF", "REF"],
        returns: AcurityTypes.SHORT,
        description: "Opens file and returns a status code. Param 0: file handle variable (VAR_init_not_required) — written by function, need not be initialised. Param 1: filename (REF). Param 2: mode (REF) — e.g. 'R' for read, 'W' for write."
    },
    FILE_READ: {
        params: [AcurityTypes.SHORT],
        paramLabels: ["fileHandle"],
        returns: AcurityTypes.STRING,
        description: "Reads line from file"
    },
    FILE_CLOSE: {
        params: [AcurityTypes.SHORT],
        paramLabels: ["fileHandle"],
        paramModes: ["VAR_destroy"],
        returns: AcurityTypes.SHORT,
        description: "Closes file handle. Param 0: file handle (VAR_destroy) — treat as uninitialised after this call."
    },
    FILE_DELETE: {
        params: [AcurityTypes.STRING],
        paramLabels: ["filename"],
        returns: AcurityTypes.SHORT,
        description: "Deletes file. Param 0: filename (REF)."
    },

    // Database/Index functions (discovered from analysis)
    INDEX_OPEN_STANDARD: {
        params:      [AcurityTypes.STRING, AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["tableCode", "indexNumber", "handle"],
        paramModes:  ["REF",              "REF",              "VAR_init_not_required"],
        // arg 2 (handle) becomes bound to the table code supplied in arg 0
        bindsHandle: { handleParam: 2, tableCodeParam: 0 },
        returns: AcurityTypes.SHORT,
        description: "Opens a standard index. Arg 0: table code (REF). Arg 1: index number (REF). Arg 2: handle variable — written by function, need not be initialised (VAR_init_not_required).",
        // Only the function name is pre-filled in the snippet so that the index-number
        // completion provider can offer choices after the user types the '('.
        // $0 places the final cursor inside the parens
        insertSnippet: "INDEX_OPEN_STANDARD$0"
    },
    INDEX_READ_BY_KEY: {
        params:      [AcurityTypes.SHORT, AcurityTypes.STRING],
        paramLabels: ["handle", "cursorDirection"],
        paramModes:  ["REF",              "REF"],
        // moves the cursor for the table that was bound to the handle in arg 0
        cursorTableFromHandle: 0,
        returns: AcurityTypes.SHORT,
        description: "Reads the next record from an open index. Arg 0: handle (REF). Arg 1: cursor direction (REF). Advances the DB cursor for the table the handle is bound to."
    },
    INDEX_CLOSE: {
        params:      [AcurityTypes.SHORT],
        paramLabels: ["handle"],
        paramModes:  ["VAR_destroy"],
        returns: AcurityTypes.SHORT,
        description: "Closes an open index and invalidates the handle. Arg 0: handle (VAR_destroy) — treat as uninitialised after this call."
    },
    INDEX_SAVE_POSITION: {
        params:      [AcurityTypes.STRING],
        paramLabels: ["tableCode"],
        paramModes:  ["REF"],
        returns: AcurityTypes.SHORT,
        description: "Saves the current cursor position for a table. Arg 0: table code (REF)."
    },
    INDEX_RESTORE_POSITION: {
        params:      [AcurityTypes.STRING],
        paramLabels: ["tableCode"],
        paramModes:  ["REF"],
        returns: AcurityTypes.SHORT,
        description: "Restores a previously saved cursor position for a table. Arg 0: table code (REF)."
    },
    INDEX_LOAD_KEY_STRING: {
        params:      [AcurityTypes.SHORT, AcurityTypes.STRING, AcurityTypes.SHORT],
        paramLabels: ["handle", "keyValue", "keyLength"],
        paramModes:  ["REF",              "REF",       "REF"],
        returns: AcurityTypes.SHORT,
        description: "Loads a STRING key segment into an open index."
    },
    INDEX_LOAD_KEY_LONG: {
        params:      [AcurityTypes.SHORT, AcurityTypes.LONG],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: AcurityTypes.SHORT,
        description: "Loads a LONG key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    INDEX_LOAD_KEY_SHORT: {
        params:      [AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: AcurityTypes.SHORT,
        description: "Loads a SHORT key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    INDEX_LOAD_KEY_DATE: {
        params:      [AcurityTypes.SHORT, AcurityTypes.DATE],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: AcurityTypes.SHORT,
        description: "Loads a DATE key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    INDEX_CLEAR_KEY: {
        params:      [AcurityTypes.SHORT],
        paramLabels: ["handle"],
        paramModes:  ["REF"],
        returns: AcurityTypes.SHORT,
        description: "Clears all loaded key segments for an open index. Arg 0: handle (REF)."
    },
    GET_DOUBLE_ARRAY: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["arrayHandle", "index"],
        returns: AcurityTypes.DOUBLE,
        description: "Gets value from DOUBLE array"
    },
    PUT_DOUBLE_ARRAY: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT, AcurityTypes.DOUBLE],
        paramLabels: ["arrayHandle", "index", "value"],
        returns: AcurityTypes.SHORT,
        description: "Puts value into DOUBLE array"
    },
    DB_SET_COLUMN: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT],
        returns: AcurityTypes.SHORT,
        description: "Sets database column"
    },

    // Display/Message functions (discovered from analysis)
    SANITISE_XML: {
        params: [AcurityTypes.STRING],
        paramLabels: ["xmlContent"],
        returns: AcurityTypes.STRING,
        description: "Sanitizes XML content"
    },
    CWB_ADD_MESSAGE: {
        params: [AcurityTypes.STRING],
        paramLabels: ["message"],
        returns: AcurityTypes.SHORT,
        description: "Adds message to CWB"
    },

    // Array functions
    GET_UNUSED_ARRAY_HANDLE: {
        params: [AcurityTypes.SHORT],
        paramLabels: ["handleVar"],
        paramModes:  ["VAR_init_not_required"],
        returns: AcurityTypes.SHORT,
        description: "Gets an unused array handle"
    },
    NUM_SORTED_ARRAYS: {
        params: [AcurityTypes.SHORT],
        returns: AcurityTypes.SHORT,
        description: "Returns the number of sorted arrays"
    },
    INIT_SORTED_ARRAY: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT, AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["arrayHandle", "maxRecords", "keyLength", "numColumns"],
        returns: AcurityTypes.SHORT,
        description: "Initializes a sorted array"
    },
    ADD_ARRAY_REC: {
        params: [AcurityTypes.SHORT, AcurityTypes.STRING],
        paramLabels: ["arrayHandle", "key"],
        returns: AcurityTypes.SHORT,
        description: "Adds a record to array"
    },
    PUT_STRING_SAY: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT, AcurityTypes.STRING],
        paramLabels: ["arrayHandle", "columnIndex", "value"],
        returns: AcurityTypes.SHORT,
        description: "Stores string value in array column"
    },
    PUT_DOUBLE_SAY: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT, AcurityTypes.DOUBLE, AcurityTypes.SHORT],
        paramLabels: ["arrayHandle", "columnIndex", "value", "precision"],
        returns: AcurityTypes.SHORT,
        description: "Stores DOUBLE value in array column with precision"
    },
    GET_STRING_SAY: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["arrayHandle", "columnIndex"],
        returns: AcurityTypes.STRING,
        description: "Retrieves string value from array"
    },
    GET_DOUBLE_SAY: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["arrayHandle", "columnIndex"],
        returns: AcurityTypes.DOUBLE,
        description: "Retrieves DOUBLE value from array"
    },
    READ_ARRAY_REC: {
        params: [AcurityTypes.STRING, AcurityTypes.SHORT, AcurityTypes.STRING],
        paramLabels:  ["readDirection", "arrayHandle", "arrayKey"],
        paramModes:  ["REF", "REF", "VAR"],
        returns: AcurityTypes.SHORT,
        description: "Reads array record by key"
    },
    FIN_SORTED_ARRAY: {
        params: [],
        returns: AcurityTypes.SHORT,
        description: "Finalizes sorted array"
    },
    FREE_SORTED_ARRAY: {
        params: [AcurityTypes.SHORT],
        paramLabels: ["arrayHandle"],
        returns: AcurityTypes.SHORT,
        description: "Frees a sorted array handle"
    },

    // Batch/Job functions
    RUN_BATCH_JOB: {
        params: [AcurityTypes.STRING, AcurityTypes.SHORT, AcurityTypes.SHORT, AcurityTypes.STRING],
        returns: AcurityTypes.LONG,
        description: "Runs a batch job"
    },

    // Ledger/Database functions
    GET_NEXT_DAILY_SS_CF: {
        params: [AcurityTypes.DATE, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.DOUBLE, AcurityTypes.DOUBLE],
        returns: AcurityTypes.SHORT,
        description: "Gets next daily cash flow record"
    },
    GET_DAILY_SS_ACC_CF: {
        params: [AcurityTypes.DATE, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.DOUBLE, AcurityTypes.DOUBLE],
        returns: AcurityTypes.SHORT,
        description: "Gets daily account cash flow"
    },
    LEDGER_CHGE_KEY: {
        params: [AcurityTypes.SHORT],
        returns: AcurityTypes.SHORT,
        description: "Changes ledger key context"
    },
    READ_INVMGR: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING],
        returns: AcurityTypes.SHORT,
        description: "Reads investment manager record"
    },
    GET_NEXT_EFF_DAY: {
        params: [AcurityTypes.DATE],
        returns: AcurityTypes.SHORT,
        description: "Gets next effective business day"
    },

    // Database read functions
    READ_ACCTHIST_MEM: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.DATE],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Reads account history record for member"
    },
    READ_ACCOUNT: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Reads account record"
    },
    READ_COMPANY: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Reads company record"
    },
    READ_INSURER: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Reads insurer record"
    },
    READ_BROKER: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Reads broker record"
    },
    READ_FEE_CODE: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Reads fee code record"
    },
    READ_FUND: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Reads fund record"
    },
    READ_MEMBER: {
        params:      [AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING],
        paramLabels: ["cursorDirection", "keyField1", "keyField2"],
        paramModes:  ["REF",              "VAR",               "VAR"],
        // arg 1 and 2 must be initialised before the call (VAR, not VAR_init_not_required)
        varArgs: true,
        cursorTables: ["MD", "D2"],
        returns: AcurityTypes.SHORT,
        description: "Reads a member record. Arg 0: cursor direction (REF). Args 1+: key fields (VAR — must be initialised). Moves the DB cursor for tables MD and D2."
    },
    READ_MEMB: {
        params:      [AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING],
        paramLabels: ["cursorDirection", "keyField1", "keyField2"],
        paramModes:  ["REF",              "VAR",               "VAR"],
        varArgs: true,
        cursorTables: ["MD", "D2"],
        returns: AcurityTypes.SHORT,
        description: "Reads a member record (short form). Arg 0: cursor direction (REF). Args 1+: key fields (VAR — must be initialised). Moves the DB cursor for tables MD and D2."
    },
    READ_FILE: {
        params: [AcurityTypes.SHORT],
        returns: AcurityTypes.STRING,
        description: "Reads line from file"
    },

    // Accounting/Balance functions
    FM_AC_BAL: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING],
        returns: AcurityTypes.SHORT,
        description: "Fast method account balance"
    },
    AC_BAL_TYPE_DIV: {
        params: [AcurityTypes.SHORT, AcurityTypes.STRING, AcurityTypes.DATE, AcurityTypes.DATE, AcurityTypes.DATE, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.DOUBLE, AcurityTypes.DOUBLE, AcurityTypes.DOUBLE, AcurityTypes.DOUBLE, AcurityTypes.DOUBLE, AcurityTypes.DOUBLE],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Account balance by type and division"
    },

    // Description/Lookup functions
    DESCRIPTION: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING],
        returns: AcurityTypes.STRING,
        description: "Retrieves description for code"
    },
    // Utility/Math functions
    ROUND: {
        params: [AcurityTypes.DOUBLE, AcurityTypes.SHORT],
        paramLabels: ["value", "decimalPlaces"],
        returns: AcurityTypes.DOUBLE,
        description: "Rounds value to specified decimal places"
    },
    RNDLO: {
        params: [AcurityTypes.DOUBLE, AcurityTypes.SHORT],
        paramLabels: ["value", "decimalPlaces"],
        returns: AcurityTypes.DOUBLE,
        description: "Rounds value downward to specified decimal places"
    },
    INDEX: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.SHORT],
        paramLabels: ["inputString", "searchString", "startPosition"],
        returns: AcurityTypes.LONG,
        description: "Finds position of substring in string"
    },
    // TO removed — it is an output-positioning directive, not a function.
    // See core/src/builtins/outputPositioningDirectives.js

    // Array retrieval functions
    PUT_SHORT_SAY: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["arrayHandle", "columnIndex", "value"],
        returns: AcurityTypes.SHORT,
        description: "Stores SHORT value in array column"
    },
    GET_SHORT_SAY: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["arrayHandle", "columnIndex"],
        returns: AcurityTypes.SHORT,
        description: "Retrieves SHORT value from array"
    },

    // Additional display/output functions
    DISPLAY_MESSAGE: {
        params: [AcurityTypes.SHORT, AcurityTypes.STRING],
        paramLabels: ["messageType", "messageText"],
        returns: AcurityTypes.SHORT,
        description: "Displays message to user"
    },

    // Corpus-derived legacy builtins (2026-03 classification pass)
    SYMBOL: {
        params: [AcurityTypes.STRING],
        returns: AcurityTypes.BOOLEAN,
        varArgs: true,
        description: "Checks whether a symbol/function is defined"
    },
    READ_PAYMENT: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads payment record"
    },
    READ_UNIT_PRICE: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads unit price record"
    },
    INITIALS: {
        params: [AcurityTypes.STRING],
        paramLabels: ["nameString"],
        returns: AcurityTypes.STRING,
        description: "Returns initials from a name string"
    },
    ASSERT: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.BOOLEAN,
        varArgs: true,
        description: "Assertion helper"
    },
    READ_PERSONAL: {
        params: [],
        returns: AcurityTypes.SHORT,
        description: "Reads current personal record"
    },
    WRITE_ERROR_MSG: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Writes an error message"
    },
    ZERO_DATE: {
        params: [AcurityTypes.DATE],
        paramLabels: ["date"],
        returns: AcurityTypes.BOOLEAN,
        description: "Checks whether a date is the zero date"
    },
    READ_INVMGR_RATE: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads investment manager rate"
    },
    READ_EXIT_DETAILS: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads member exit details"
    },
    READ_PERSONAL2: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads personal record with selector"
    },
    READ_CATEGORY: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads category record"
    },
    READ_PEN_HIST: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads pension history"
    },
    WRITE_HEADER_CODE_RECORD: {
        params: [AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Writes header code record"
    },
    READ_SUPPMEMB_HIST_TYP: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads supplementary member history by type"
    },
    GET_USR_DEF_CONTROL_PARAM: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.STRING,
        description: "Gets user-defined control parameter"
    },
    SQL_GET_STRING_COL: {
        params: [AcurityTypes.LONG, AcurityTypes.SHORT, AcurityTypes.STRING],
        paramLabels: ["statementHandle", "columnIndex", "outputValue"],
        paramModes: ["REF", "REF", "VAR_init_not_required"],
        returns: AcurityTypes.STRING,
        description: "Gets SQL column as STRING"
    },
    READ_ANR_HIST: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads ANR history"
    },
    READ_CATHIST2: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads category history variant 2"
    },
    READ_PAYHIST: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads payment history"
    },
    READ_TMP_CRTR: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads temporary contributor record"
    },
    RIGHT: {
        params: [AcurityTypes.STRING, AcurityTypes.SHORT],
        paramLabels: ["inputString", "length"],
        returns: AcurityTypes.STRING,
        description: "Returns right-most characters from string"
    },
    INITIALISED_ARRAY: {
        params: [AcurityTypes.SHORT],
        paramLabels: ["arrayHandle"],
        returns: AcurityTypes.SHORT,
        description: "Checks whether an array handle is initialised"
    },
    MONTH_NAME: {
        params: [AcurityTypes.SHORT],
        paramLabels: ["monthNumber"],
        returns: AcurityTypes.STRING,
        description: "Returns full month name"
    },
    READ_ACCTHIST_1: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads account history variant 1"
    },
    READ_SHARECRT_5: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads share certificate variant 5"
    },
    GET_TRANSREF: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Gets transaction reference"
    },
    MMADD: {
        params: [AcurityTypes.DATE, AcurityTypes.SHORT],
        paramLabels: ["date", "months"],
        returns: AcurityTypes.DATE,
        description: "Adds months to date"
    },
    LOWER: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.STRING,
        description: "Converts string to lowercase"
    },
    READ_TRANSREF_5: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads transaction reference variant 5"
    },
    READ_CONTACC: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads contribution account"
    },
    READ_BALANCES: {
        params: [],
        returns: AcurityTypes.SHORT,
        description: "Reads balances"
    },
    PERIOD_RND: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.DOUBLE,
        description: "Rounds amount by period rules"
    },
    TABLE_VALUE_2: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.DOUBLE,
        description: "Returns table value variant 2"
    },
    UPD_SUPPMEMB_ALL: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Updates supplementary member record"
    },
    FILE_COPY: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING],
        paramLabels: ["sourceFilename", "destFilename"],
        returns: AcurityTypes.SHORT,
        description: "Copies file"
    },
    DSPACE: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.STRING,
        description: "Returns de-spaced string"
    },
    REPORT_FILENAME: {
        params: [AcurityTypes.UNKNOWN],
        returns: AcurityTypes.STRING,
        description: "Returns report filename component"
    },
    FILE_EXISTS: {
        params: [AcurityTypes.STRING, AcurityTypes.UNKNOWN],
        paramLabels: ["filename"],
        returns: AcurityTypes.BOOLEAN,
        varArgs: true,
        description: "Checks whether file exists"
    },
    READ_PAYEE: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads payee record"
    },
    READ_MEMDEPS: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads member dependants"
    },
    READ_FILE_REG: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads file register"
    },
    COUNT_ARRAY_RECS: {
        params: [AcurityTypes.SHORT],
        paramLabels: ["arrayHandle"],
        returns: AcurityTypes.SHORT,
        description: "Counts array records"
    },
    WRITE_FILE_REG1: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Writes file register variant 1"
    },
    GET_SHORT_ARRAY: {
        params: [AcurityTypes.SHORT],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Reads SHORT from array"
    },
    GET_STRING_ARRAY: {
        params: [AcurityTypes.SHORT],
        returns: AcurityTypes.STRING,
        varArgs: true,
        description: "Reads STRING from array"
    },
    READ_BTCH_REF2: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads batch reference variant 2"
    },
    DATE_TO_STR: {
        params: [AcurityTypes.DATE, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.STRING,
        varArgs: true,
        description: "Formats date as string"
    },
    READ_BAL: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads balance record"
    },
    CHECK_SYMBOL: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.BOOLEAN,
        description: "Checks whether symbol exists"
    },
    READ_MEMB5: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads member record variant 5"
    },
    READ_TMP_CONT_2A: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads temporary contribution variant 2A"
    },
    READ_TRANSREF_7: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads transaction reference variant 7"
    },
    CWB_TRANS_GET_FIELD_VALUE: {
        params: [AcurityTypes.UNKNOWN],
        returns: AcurityTypes.STRING,
        varArgs: true,
        description: "Gets transformed contribution field value"
    },
    READ_TRANSREF: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads transaction reference"
    },
    READ_TRANSREF_2: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads transaction reference variant 2"
    },
    UPD_SUPPMEMB_HIST: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Updates supplementary member history"
    },
    LEDGER_ACCOUNT_BAL: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.DOUBLE,
        description: "Returns ledger account balance"
    },
    MAX_VALUE: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.DOUBLE,
        description: "Returns maximum of supplied values"
    },
    READ_ROLLOVER: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads rollover record"
    },
    MEMBER_CHGE_KEY: {
        params: [AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Changes member key context"
    },
    READ_TRANSREF_4: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads transaction reference variant 4"
    },
    READ_AUDIT: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads audit record"
    },
    PERIOD: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Calculates period offset"
    },
    READ_NOTES: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads notes record"
    },
    READ_INVPROP: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads investment property"
    },
    REPLACE: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.STRING],
        paramLabels: ["inputString", "searchString", "replacementString"],
        returns: AcurityTypes.STRING,
        description: "Replaces substring occurrences"
    },
    GET_CONFIGURATION_STRING: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.STRING,
        description: "Gets configuration value as string"
    },
    REGEX_MATCH_SIMPLE: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING],
        paramLabels: ["inputString", "pattern"],
        returns: AcurityTypes.BOOLEAN,
        description: "Performs simple regex match"
    },
    IPATH: {
        params: [AcurityTypes.STRING],
        paramLabels: ["path"],
        returns: AcurityTypes.STRING,
        description: "Normalizes/derives internal path"
    },
    SQL_GET_DOUBLE_COL: {
        params: [AcurityTypes.LONG, AcurityTypes.SHORT, AcurityTypes.DOUBLE],
        paramLabels: ["statementHandle", "columnIndex", "outputValue"],
        paramModes: ["REF", "REF", "VAR_init_not_required"],
        returns: AcurityTypes.DOUBLE,
        description: "Gets SQL column as DOUBLE"
    },
    SQL_GET_SHORT_COL: {
        params: [AcurityTypes.LONG, AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["statementHandle", "columnIndex", "outputValue"],
        paramModes: ["REF", "REF", "VAR_init_not_required"],
        returns: AcurityTypes.SHORT,
        description: "Gets SQL column as SHORT"
    },
    SMEMBER_READ: {
        params: [],
        returns: AcurityTypes.SHORT,
        description: "Reads member into current context"
    },
    PUT_SHORT_ARRAY: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Writes SHORT into array"
    },
    TFN_VALIDATE: {
        params: [AcurityTypes.STRING],
        paramLabels: ["tfnValue"],
        returns: AcurityTypes.BOOLEAN,
        description: "Validates TFN"
    },
    READ_FUND_SIG: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads fund signature"
    },
    READ_SURCHARGE: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads surcharge record"
    },
    STR_TO_SHORT: {
        params: [AcurityTypes.STRING],
        paramLabels: ["inputString"],
        returns: AcurityTypes.SHORT,
        description: "Converts string to SHORT"
    },
    READ_ERRORMSG_2: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads error message variant 2"
    },
    READ_GLOBHIST: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads global history"
    },
    READ_ELEC_FILE: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads electronic file metadata"
    },
    READ_ERRORMSG: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads error message"
    },
    UNDEFINED: {
        params: [AcurityTypes.UNKNOWN],
        paramLabels: ["value"],
        returns: AcurityTypes.BOOLEAN,
        description: "Checks whether value is undefined"
    },
    AC_BAL_TYPE: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Account balance by type"
    },
    READ_ASCII_FILE: {
        params: [AcurityTypes.STRING],
        paramLabels: ["filename"],
        returns: AcurityTypes.SHORT,
        description: "Reads an ASCII file"
    },
    DOS_COMMAND: {
        params: [AcurityTypes.STRING],
        paramLabels: ["command"],
        returns: AcurityTypes.SHORT,
        description: "Executes DOS command"
    },
    READ_TMP_EXIT: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads temporary exit record"
    },
    CHEQUE_WORDS: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Converts amount to cheque words components"
    },
    CALC_PENSION_PER_PERIOD: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Calculates pension per period"
    },
    READ_BKGD_JOB_4: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads background job variant 4"
    },
    READ_INTEREST_RATE: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads interest rate"
    },
    NEXT_PENSION_PAYMENT: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Gets next pension payment date"
    },
    YEARS: {
        params: [AcurityTypes.DATE, AcurityTypes.DATE],
        paramLabels: ["fromDate", "toDate"],
        returns: AcurityTypes.SHORT,
        description: "Returns full year difference between dates"
    },
    GET_FULL_NOTE: {
        params: [],
        returns: AcurityTypes.STRING,
        description: "Returns full note text"
    },
    DB_GET_VALUE_BY_SQL_COLUMN_NAME: {
        params: [AcurityTypes.SHORT, AcurityTypes.STRING],
        paramLabels: ["handle", "columnName"],
        returns: AcurityTypes.STRING,
        description: "Gets SQL column value by column name"
    },
    VALIDATE_DATE: {
        params: [AcurityTypes.DATE],
        paramLabels: ["date"],
        returns: AcurityTypes.SHORT,
        description: "Validates date and returns status code"
    },
    VERIFY_FILE_REG_STATUS: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING, AcurityTypes.LONG],
        returns: AcurityTypes.BOOLEAN,
        description: "Checks file register status against invalid list"
    },
    CLEAR_DATABASE_RECORD: {
        params: [AcurityTypes.STRING],
        paramLabels: ["tableCode"],
        returns: AcurityTypes.SHORT,
        description: "Clears current database record by table code"
    },
    SQL_SET_SHORT: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["statementHandle", "paramIndex", "value"],
        returns: AcurityTypes.SHORT,
        description: "Sets SQL short parameter value"
    },
    WRITE_JOURNAL: {
        params: [],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Writes journal entry"
    },
    CREATE_SPECIAL_LEDGER: {
        params: [AcurityTypes.STRING],
        returns: AcurityTypes.SHORT,
        description: "Creates special ledger"
    },
    READ_SUPPMEMB_HIST: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads supplementary member history"
    },
    DESCR_STR: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.STRING,
        description: "Returns description as string"
    },
    READ_SAL_HIST: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads salary history"
    },
    AC_BAL_SET_ARRAY: {
        params: [AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Sets AC_BAL output array handle"
    },
    GET_BAL_SS_CF: {
        params: [],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        deprecated: true,
        description: "Gets balance cashflow details"
    },
    SEND_STATEMENT: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Sends statement"
    },
    UPDATE_LOST_MBR_DATE: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Updates lost-member date"
    },
    READ_SWIMLOG: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads SWIM log record"
    },
    WRITE_SWIMLOG: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Writes SWIM log record"
    },
    UPDATE_CHQREC: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Updates cheque record"
    },
    CALC_PENSION_AMTS_PERIOD: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Calculates pension amount components for a period"
    },
    MIN_VALUE: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Returns minimum value/status"
    },
    GET_BSB_NAME: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING],
        returns: AcurityTypes.STRING,
        description: "Gets BSB bank/branch name"
    },
    TABLE_VALUE: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.BOOLEAN,
        description: "Reads table value"
    },
    READ_ACQUHIST: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads acquisition history"
    },
    READ_SHCRTHST: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads share certificate history"
    },
    READ_SHARECRT: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads share certificate"
    },
    READ_ERRORS_INDEX2: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads errors index 2"
    },
    WRITE_ERROR_MSG_BY_CDE_VAR: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Writes error message by code and variables"
    },
    CHECK_ZERO_DATE: {
        params: [AcurityTypes.DATE],
        paramLabels: ["date"],
        returns: AcurityTypes.BOOLEAN,
        description: "Checks whether date is zero date"
    },
    CWB_TRANS_READ_STATIC: {
        params: [AcurityTypes.STRING, AcurityTypes.LONG, AcurityTypes.SHORT],
        returns: AcurityTypes.SHORT,
        description: "Reads transformed static line"
    },
    TRANSLATE_CLICKSUPER_FILE: {
        params: [AcurityTypes.LONG],
        returns: AcurityTypes.LONG,
        description: "Translates ClickSuper file"
    },
    SCH_TRANSLATE_FILE: {
        params: [AcurityTypes.LONG],
        returns: AcurityTypes.LONG,
        description: "Translates SCH file"
    },
    WESTPAC_TRANSLATE_FILE: {
        params: [AcurityTypes.LONG],
        returns: AcurityTypes.LONG,
        description: "Translates Westpac file"
    },
    READ_FILE_REG1: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Reads file register variant 1"
    },
    NEXT_MESSAGE_ID: {
        params: [],
        returns: AcurityTypes.LONG,
        description: "Returns next message ID"
    },
    DB_GET_SQL_COLUMN_VALUE: {
        params: [AcurityTypes.SHORT, AcurityTypes.SHORT],
        paramLabels: ["handle", "columnIndex"],
        returns: AcurityTypes.STRING,
        description: "Gets SQL column value by ordinal"
    },
    OUTPUT_FILENAME_COMPONENTS: {
        params: [AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Parses output filename components"
    },
    PRINT_IMAGE: {
        params: [AcurityTypes.STRING, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN, AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        description: "Prints image at given coordinates"
    },
    DISPLAY_MESSAGE_PROMPT: {
        params: [AcurityTypes.STRING],
        paramLabels: ["message"],
        returns: AcurityTypes.SHORT,
        description: "Displays message prompt"
    },
    SQL_GET_LONG_COL: {
        params: [AcurityTypes.LONG, AcurityTypes.SHORT, AcurityTypes.LONG],
        paramLabels: ["statementHandle", "columnIndex", "outputValue"],
        paramModes: ["REF", "REF", "VAR_init_not_required"],
        returns: AcurityTypes.SHORT,
        description: "Gets SQL LONG column into output variable"
    },
    SQL_GET_DATE_COL: {
        params: [AcurityTypes.LONG, AcurityTypes.SHORT, AcurityTypes.DATE],
        paramLabels: ["statementHandle", "columnIndex", "outputValue"],
        paramModes: ["REF", "REF", "VAR_init_not_required"],
        returns: AcurityTypes.SHORT,
        description: "Gets SQL DATE column into output variable"
    },
    READ_SUPPFUND_DETLS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads supplementary fund details"
    },
    READ_REP_VARS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads report variables"
    },
    AC_BAL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DOUBLE,
        description: "Returns account balance"
    },
    READ_PATH: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads path record"
    },
    WORDS_WITH_CAPITAL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
        description: "Converts string to title case"
    },
    WRITE_ERR_MSG_BY_CDE_VAR_SET: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Writes error message by code variable set"
    },
    TRANSREF_KEY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.UNKNOWN,
        description: "Returns transaction reference key"
    },
    READ_ACCTHIST_2: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads account history variant 2"
    },
    FILE_APPEND_DELETE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Appends then deletes a file"
    },
    GUI_GET_STRING_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
        description: "Gets string value from GUI control"
    },
    DB_GET_COLUMN_ID: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Gets database column ID"
    },
    DB_GET_SQL_TABLE_NUMBER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Gets SQL table number"
    },
    GUI_SET_FOCUSABLE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Sets GUI control focusable state"
    },
    LDM: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.UNKNOWN,
        description: "LDM system function"
    },
    READ_INSR_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads insurance history record"
    },
    SQL_FETCH: {
        params: [AcurityTypes.LONG],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Fetches next row from SQL cursor"
    },
    WRITE_EXCEPTION_HISTORY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Writes exception history record"
    },
    BTCH_REF_KEY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.UNKNOWN,
        description: "Returns batch reference key"
    },
    CREATE_DIRECTORY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Creates a directory"
    },
    DATE_TO_JULIAN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
        description: "Converts a date to Julian day number"
    },
    DB_GET_SQL_COLUMN_NAME: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
        description: "Gets SQL column name"
    },
    INDEX_LOAD_HIGH_VALUES: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Loads high values into index"
    },
    PAYHIST_CHGE_KEY: {
        params: [AcurityTypes.SHORT],
        returns: AcurityTypes.SHORT,
        description: "Changes payment history key context"
    },
    PUT_STRING_ARRAY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Puts string value into array"
    },
    READ_BATCH_ERRORS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads batch error records"
    },
    READ_BTCH_REF_6: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads batch reference variant 6"
    },
    READ_CAT_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads category history record"
    },
    READ_EXIT_DETLS4: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads exit details variant 4"
    },
    READ_PAYHIST_1: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads payment history variant 1"
    },
    READ_WRKHIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads work history record"
    },
    RNDHI: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DOUBLE,
        description: "Rounds up (high)"
    },
    SHARECRT_CHGE_KEY: {
        params: [AcurityTypes.SHORT],
        returns: AcurityTypes.SHORT,
        description: "Changes share certificate key context"
    },
    FILE_COPY_DELETE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Copies then deletes a file"
    },
    GET_TIME: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
        description: "Returns current time as string"
    },
    INDEX_READ_BY_RRN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads index record by relative record number"
    },
    JAVA_CALL_MAIN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Calls a Java main method"
    },
    MEMEXIT_CHGE_KEY: {
        params: [AcurityTypes.SHORT],
        returns: AcurityTypes.SHORT,
        description: "Changes member exit key context"
    },
    READ_CONTRATES: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads contribution rates"
    },
    READ_INVMGR_EXT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads investment manager extended record"
    },
    READ_TRANSREF_6: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads transaction reference variant 6"
    },
    READ_USER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads user record"
    },
    SQL_EXEC_DIRECT: {
        params: [AcurityTypes.LONG, AcurityTypes.STRING],
        paramModes: ["REF", "VAR_init_not_required"],
        returns: AcurityTypes.SHORT,
        description: "Executes a SQL statement directly"
    },
    SQL_SET_STRING: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Sets a SQL parameter to a string value"
    },
    TMP_CONT_CHGE_KEY: {
        params: [AcurityTypes.SHORT],
        returns: AcurityTypes.SHORT,
        description: "Changes temporary contribution key context"
    },
    UPDATE_TRANSREF: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Updates transaction reference record"
    },
    WRITE_FILE_REG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Writes file register record"
    },
    AC_BAL_DIV: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DOUBLE,
        description: "Returns account balance for a division"
    },
    AC_BAL_IMGR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DOUBLE,
        description: "Returns account balance for an investment manager"
    },
    INDEX_CURRENT_RRN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Returns current relative record number of index"
    },
    INITIALISE_ARRAY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Initialises an array"
    },
    INTEGER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
        description: "Converts a value to integer (truncates)"
    },
    JULIAN_TO_DATE: {
        params: [AcurityTypes.LONG],
        paramLabels: ["julianDayNumber"],
        returns: AcurityTypes.DATE,
        description: "Converts a Julian day number to a date"
    },
    READ_BKGD_JOB: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads background job record"
    },
    READ_CORR_NO: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads correspondence number record"
    },
    READ_EXCEPTION_HISTORY_KEY1: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads exception history by key 1"
    },
    READ_RRECS_MBR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads rollover records for member"
    },
    READ_SAL_HIST_2: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads salary history variant 2"
    },
    READ_SHCRTHST_1: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads share certificate history variant 1"
    },
    REPORT_DESCRIPTION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
        description: "Returns report description string"
    },
    SPAN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Calculates span/range"
    },
    SQL_CONNECT: {
        params: [],
        returns: AcurityTypes.SHORT,
        description: "Connects to a SQL database",
        deprecated: true
    },
    XPATHCONTEXT_COUNT_ELEMENTS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Counts elements matching an XPath expression"
    },
    EMAILX: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Sends an email"
    },
    FINALISE_ARRAY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Finalises and releases an array"
    },
    SHCRTHST_CHGE_KEY: {
        params: [AcurityTypes.SHORT],
        returns: AcurityTypes.SHORT,
        description: "Changes share certificate history key context"
    },
    SQL_DISCONNECT: {
        params: [],
        returns: AcurityTypes.SHORT,
        description: "Disconnects from a SQL database",
        deprecated: true
    },
    BASE64_ENCODE: {
        params: [AcurityTypes.STRING, AcurityTypes.STRING],
        paramLabels: ["inputFile", "outputFile"],
        varArgs: true,
        returns: AcurityTypes.STRING,
        description: "Base64-encodes a value"
    },
    COMPUTE_SOUNDEX: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
        description: "Computes Soundex phonetic code"
    },
    DAY_OF_WEEK: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Returns the day of the week for a date"
    },
    DELETE_ARRAY_REC: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Deletes a record from an array"
    },
    DELETE_CONTRIBUTION_LINE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Deletes a contribution line record"
    },
    DELETE_SPECIAL_LEDGER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Deletes a special ledger entry"
    },
    GUI_SET_STRING_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Sets string value on GUI control"
    },
    GUI_VAR_GET_LONG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
        description: "Gets LONG variable value from GUI context"
    },
    GUI_VAR_SET_LONG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Sets LONG variable value in GUI context"
    },
    HTTPS_POST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Performs an HTTPS POST request"
    },
    INDEX_LOAD_KEY_DOUBLE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Loads a DOUBLE key into index context"
    },
    INDEX_LOAD_KEY_TIME: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Loads a TIME key into index context"
    },
    INSERT_SPECIAL_LEDGER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Inserts a special ledger entry"
    },
    INVMGR_CHGE_KEY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Changes investment manager key context"
    },
    LEDGER_ACC_BAL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DOUBLE,
        description: "Returns ledger account balance"
    },
    PCL2PDF: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Converts PCL content to PDF"
    },
    RANDOM_NO: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
        description: "Returns a random number"
    },
    READ_BTCH_REF: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads batch reference record"
    },
    READ_BTCHCODE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads batch code record"
    },
    READ_CHQREC_NO: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads cheque record by number"
    },
    READ_INVMHIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads investment manager history"
    },
    READ_URL_TEMPLATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Reads URL template record"
    },
    REGEX_LAST_MATCHED_GROUP: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
        description: "Returns last regex matched group"
    },
    REGEX_MATCH: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.BOOLEAN,
        description: "Performs regex match"
    },
    REPAIR_FILENAME: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
        description: "Repairs/sanitizes filename"
    },
    SET_TIME_VAR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Sets a time variable"
    },
    SPECIAL_LEDGER_GET_FIRST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Gets first special ledger record"
    },
    SPECIAL_LEDGER_GET_NEXT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Gets next special ledger record"
    },
    SQL_EXECUTE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Executes prepared SQL statement"
    },
    SQL_FREE_HANDLE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Frees SQL statement handle"
    },
    SQL_PREPARE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Prepares SQL statement"
    },
    TFN_ENCRYPT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
        description: "Encrypts a TFN value"
    },
    TRANSACTION_LISTING: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Produces transaction listing output"
    },
    UPD_TMP_CRTR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Updates temporary contributor record"
    },
    UPDATE_ERROR_MSG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Updates error message record"
    },
    UPDATE_PAYMENT_DETAILS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Updates payment details"
    },
    WRITE_INSR_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Writes insurance history record"
    },
    WRITE_NOTES: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Writes notes record"
    },
    WRITE_PAYHIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Writes payment history record"
    },
    WRITE_WEB_USER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Writes web user record"
    },
    WRITE_WEB_USER_PASSWORD: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Writes web user password"
    },
    XMLDOCUMENT_CREATE_FROM_FILE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Creates XML document from file"
    },
    XMLDOCUMENT_CREATE_FROM_STRING: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Creates XML document from string"
    },
    XPATHCONTEXT_CHECK_XPATH: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Checks XPath expression in context"
    },
    XPATHCONTEXT_CREATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        description: "Creates XPath context"
    },
    XPATHCONTEXT_GET_STRING: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
        description: "Gets string value from XPath context"
    },
    // Additional system functions
    OCCURS: {
        params: [AcurityTypes.UNKNOWN],
        returns: AcurityTypes.SHORT,
        varArgs: true,
        description: "Returns occurrence count"
    },

    // ============================================================
    // Database (0202)
    // ============================================================
    AC_REC2: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    ALLOC_GCERT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    ASSET_PROFILE_SWITCHES: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    BALANCES_CHGE_KEY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    BATCH_PROCESS_ORDER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CALCULATE_CAPGAINS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CALC_CONTS_DUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CALC_MIN_MAX_AMTS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CALC_OR_SET_PURCHASE_PRICE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CALC_PENSION_AMTS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CALC_PENSION_AMTS_EXT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CALC_PENSION_AMTS_POST2007: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CALC_PEN_AMTS_PERIOD: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CALC_PEN_AMTS_POST2007: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CATCH_UP_PAYMENTS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CHEQUE_WORDS_MILL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CLEAR_CORR_REG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CLEAR_EXIT_TRANSREF_RBL_FLAG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    COMPARE_SHARECRT_LEDGER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CONFIRM_DOCUMENT_PUBLISHED: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CONFIRM_EXCEPTION_PUBLISHED: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    COPY_UNIT_ENTIT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CREATE_REVERSING_TRAN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    CREATE_TRANSACTION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DB_D: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DATE,
    },
    DB_F: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DOUBLE,
    },
    DB_L: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    DB_S: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DB_T: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.TIME,
    },
    DB_V: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    DB_Z: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    DELETE_CATEGORY_HISTORY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DELETE_ERROR_MSG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DELETE_FILE_REG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DELETE_NOTES: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DELETE_SUPERGATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DELETE_SUPPMEMB: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DETERMINE_NEXT_REVIEW: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DATE,
    },
    DET_SORT_ORDER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DV_D: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DV_F: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DV_L: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DV_S: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DV_T: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DV_V: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DV_Z: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    ENQ_MBR_CHGE_KEY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    FIRST_CONTRIBUTION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    FIRST_CONTRIBUTION_MBR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    FONT_FILE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GENERATE_AND_PUBLISH_KEYS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GET_CLOB: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GET_CURRENT_INDEX: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GET_DAILY_ACC_CF: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GET_LAST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GET_MEMBER_ID: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    GET_MSGCODE_BY_ID: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    GET_NEXT_DAILY_SSS_CF: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GET_NEXT_SSS_ACC_BAL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GET_NEXT_SS_ACC_BAL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GET_NEXT_SS_CF: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
        deprecated:true
    },
    INTEREST_CONTS_DUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    INVM_ASSET_ALLOC: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DOUBLE,
    },
    IsUserMemberOfGroup: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.BOOLEAN,
    },
    LAST_CONTRIBUTION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LAST_CONTRIBUTION_DATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LAST_CONTRIBUTION_MBR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LAST_PENSION_PAYMENT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LEDGER_ACCOUNT_TOT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LEDGER_ACC_BALS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LEDGER_CLEAR_POS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LEDGER_CONT_AC_BAL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LEDGER_RESTORE_POS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LEDGER_SAVE_POS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LINK_CHQ_BANK_RECS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    LINK_TRN_BANK_RECS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    LIST_SUPERGATE_LINES: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LOAD_EXCEPTION_DATA: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    NEXT_CHEQUE_ID: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    NEXT_DEPOSIT_ID: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    NEXT_EFT_ID: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    NEXT_FUND_CHEQUE_ID: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    NEXT_FUND_EFT_ID: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    NOTES: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    NUMBER_SUPER_PERIODS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    PAY_PERIOD_START_DATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    POLICY_CHGE_KEY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    POST_TRANSACTION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    PUBLISH_CURRENT_EXCEPTION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    PUBLISH_DOCUMENT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_ACCTHIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_ACCT_MEM_DIV: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_ANR_HIST_COPY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_ASCII_TABLE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DOUBLE,
    },
    READ_ASCII_TABLE2: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_AWOTE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_BAL1: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_BATCHIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_BTCH_DEF: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CAPGAINS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CAPGNS_R: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CAPGNS_R_KEY1: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CHQREC_TRAN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CHQR_STAT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CHQR_TYPE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_COMMISSION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_COMPHIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_COMP_LOC: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CONTRATES_UNPRES: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CONT_ADJ: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CONT_ADJ2: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CONT_ADJ_3: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CONT_VARIANCE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CORR_NO_RECTYPE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CORR_PAYROLL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CORR_STAT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_CORR_STAT_PAYROLL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_DATA_REG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_DIARY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_ELS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_ENQ_EMP: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_ENQ_MBR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_ENQ_MBR3: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_ENQ_MBR_TOT1: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_ENQ_MBR_TOTS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_EXIT_DETLS2: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_FUND_GROUP: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_FUND_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_GCERT_STAT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_GCERT_TYPE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_GROUP: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_INSDEFLT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_INSR_HIST_CLT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_INT_TABLE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_LAST_NO: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_MCHQS_REF: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_MCHQS_TRAN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_MED_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_MED_HIST_CLIENT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_MEMB4: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_MERGE_HISTORY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_NZEXCHGE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_PAST_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_PAYHIST_2: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_PAYHIST_4: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_PAY_REINSURER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_POLCOMM: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_POLICY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_POLICY_BEN_DTLS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_PRD_PAYMENT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_RCT_RFND: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_RCT_RFND_2: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_REFUND: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_RRECS_REP: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_SAL_HIST_RR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_SERVICE_REQUESTS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_SUPER_PERIOD: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_SUPPFUND_LABELS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_SUPPMEMB: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_SUPP_ADVISER_HIST_TYP: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_SUPP_INVMGR_HIST_TYP: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_SUPP_PAY_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_SURCHARGE2: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_TAXFLAG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_TAX_SAL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_TMP_CONT_3: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_TRANSREF_5_EFLG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_UNIT_ENTIT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_UNIT_ENTIT3: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_WHRSHIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    READ_WHRSHIST_TOT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    REPUBLISH_DOCUMENT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    REPUBLISH_EXCEPTION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    RESET_CLIENT_SYS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    RESET_REFUND: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    RES_INTEREST_CONTS_DUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    SET_CLIENT_SYS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    SORT_INVMGR_R: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    SORT_INVMGR_W: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    SQL_GET_TIME_COL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    SQL_INDEX_ADD_CONDITION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    SQL_INDEX_CLEAR_KEY: {
        params: [AcurityTypes.LONG],
        returns: AcurityTypes.SHORT,
    },
    SQL_INDEX_CLOSE: {
        params: [AcurityTypes.LONG],
        returns: AcurityTypes.SHORT,
    },
    SQL_INDEX_FIX_KEY: {
        params: [AcurityTypes.LONG],
        returns: AcurityTypes.SHORT,
    },
    SQL_INDEX_LOAD_KEY_STRING: {
        params:      [AcurityTypes.LONG, AcurityTypes.STRING, AcurityTypes.SHORT],
        paramLabels: ["handle", "keyValue", "keyLength"],
        paramModes:  ["REF",              "REF",       "REF"],
        returns: AcurityTypes.SHORT,
        description: "Loads a STRING key segment into an open index."
    },
    SQL_INDEX_LOAD_KEY_LONG: {
        params:      [AcurityTypes.LONG, AcurityTypes.LONG],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: AcurityTypes.SHORT,
        description: "Loads a LONG key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    SQL_INDEX_LOAD_KEY_SHORT: {
        params:      [AcurityTypes.LONG, AcurityTypes.SHORT],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: AcurityTypes.SHORT,
        description: "Loads a SHORT key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    SQL_INDEX_LOAD_KEY_DATE: {
        params:      [AcurityTypes.LONG, AcurityTypes.DATE],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: AcurityTypes.SHORT,
        description: "Loads a DATE key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    SQL_INDEX_LOAD_KEY_DOUBLE: {
        params:      [AcurityTypes.LONG, AcurityTypes.DOUBLE],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: AcurityTypes.SHORT,
    },
    SQL_INDEX_LOAD_KEY_TIME: {
        params:      [AcurityTypes.LONG, AcurityTypes.TIME],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: AcurityTypes.SHORT,
    },
    SQL_INDEX_OPEN_STANDARD: {
        params:      [AcurityTypes.STRING, AcurityTypes.SHORT, AcurityTypes.LONG],
        paramLabels: ["tableCode", "indexNumber", "handle"],
        paramModes:  ["REF",              "REF",              "VAR_init_not_required"],
        // arg 2 (handle) becomes bound to the table code supplied in arg 0
        bindsHandle: { handleParam: 2, tableCodeParam: 0 },
        returns: AcurityTypes.SHORT,
        description: "Opens a standard index. Arg 0: table code (REF). Arg 1: index number (REF). Arg 2: handle variable — written by function, need not be initialised (VAR_init_not_required).",
        // Only the function name is pre-filled in the snippet so that the index-number
        // completion provider can offer choices after the user types the '('.
        // $0 places the final cursor inside the parens
        insertSnippet: "SQL_INDEX_OPEN_STANDARD$0"
    },
    SQL_INDEX_READ_BY_KEY: {
        params:      [AcurityTypes.LONG, AcurityTypes.STRING],
        paramLabels: ["handle", "cursorDirection"],
        paramModes:  ["REF",              "REF"],
        // moves the cursor for the table that was bound to the handle in arg 0
        cursorTableFromHandle: 0,
        returns: AcurityTypes.SHORT,
        description: "Reads the next record from an open index. Arg 0: handle (REF). Arg 1: cursor direction (REF). Advances the DB cursor for the table the handle is bound to."
    },
    SQL_SET_DATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    SQL_SET_DOUBLE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    SQL_SET_LONG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    SQL_SET_TIME: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    TABLE_DESC: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    TOT_ACC_AT_EFF: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    TRANSACTION_DESC: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    UNLOAD_EXCEPTION_DATA: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UNPOST_TRANSACTION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_AUDITAUTH: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_BROKER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_CLIENT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_CLIENT_ELS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_CLIENT_GROUPS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_CONTS_TO_BE_TAKEN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_DEDUCTIBLE_PERCENTAGE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_EMPLOYER_STATUS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_EXIT_CO_CONTRIBUTIONS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_EXIT_TAX: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_MAX_CALC: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_MEMBER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_MIN_MAX_CALC: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_RCT_RFND: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_ROLLOVER_ELS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_SHARECRT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_SHARECRT_REDN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_SHARE_CERTIFICATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_STATEMENT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_STATEMENT_BY_REPORT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPDATE_SUPER_MATCH: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_BTCH_REF: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_CONT_ADJ: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_CORR_REG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_CORR_REG_RECTYPE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_MBR_DETAILS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_MBR_ISSUED: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_MBR_NOTFD: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_PAID_CONTS_TO: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SHARECRT_EXITFEE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SUPPFUND_DETLS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SUPPMEMB: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SUPPMEMB_FLAGS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SUPP_ADVISER_ALL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SUPP_CLIENT_ALL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SUPP_CLIENT_FLAGS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SUPP_CLIENT_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SUPP_INVMGR_ALL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SUPP_PAY_ALL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SUPP_PAY_FLAGS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_SUPP_PAY_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_TMP_EXIT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UPD_USR_BTCH: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    USER_MD5_HASH: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    VALIDATE_WEBUSER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    WRITE_ADVISOR_AUTHORITY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_ADVISOR_PROPORTIONS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_ANRHIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_BANK_REC: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_CAT_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_CHQREC: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_CHQREC_LINE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_CHQREC_TYPE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_CHQREC_TYPE_LINE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_COMPHIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_CONTRATES: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_CONTRIBUTION_LINE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_CONT_VARIANCE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_DATA_REG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_DATA_REG2: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_ERROR_MSG_BY_CDE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_ERR_MSG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_ERR_MSG_BY_CDE_DESC: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_FILE_REG2: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_INSR_HIST_CLT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_INSR_HIST_CLT1: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_INVESTMENT_MANAGER_HISTORY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_INVPROP: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_INVPROP_CLT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_MED_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_NOTES_MBR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_NOTES_REG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_PAYMENT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_PAYMENT_OPTIONS_DEFAULTS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_PAY_REINSURER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_PENSION_HISTORY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_REFUND: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_REP_VARS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_ROLLOVER: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_SAL_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_SAL_HIST_EMP: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_STATEMENT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_SUPERGATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_TAXSAL_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_UNIT_ENTIT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_UNIT_ENTIT3: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_UNIT_PRICE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_WHRSHIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_WRK_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    WRITE_WRK_HRS_HIST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },

    // ============================================================
    // Date (0203)
    // ============================================================
    DAY_ABV: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    DAY_NAME: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    DAY_OF_YEAR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DAY_TO_DATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DATE,
    },
    ISLEAP: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.BOOLEAN,
    },

    // ============================================================
    // File (0204)
    // ============================================================
    DO_PRINT_FILE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    FILE_INSERT_DELETE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    FILE_SIZE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },

    // ============================================================
    // Numeric (0205)
    // ============================================================
    NUMBER_FRIDAYS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },

    // ============================================================
    // String (0206)
    // ============================================================
    NUMBER_OF_TOKENS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    RANK: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    UNSANITISE_XML: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },

    // ============================================================
    // Time (0207)
    // ============================================================
    ELAPSED_SECONDS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DOUBLE,
    },
    MILLISECONDS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },

    // ============================================================
    // Miscellaneous (0208)
    // ============================================================
    BARCODE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    BASE64_DECODE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    DOS_COMMAND_WAIT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    EMAIL: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    EMAILX_WARN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    FORM_EXTENSION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    FORM_NAME: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    FORM_OPTIONS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    GET_CONFIGURATION_STRING_BY_ID: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GET_TABLE_NAME: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    HTTPS_POST_AUTHENTICATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    HTTP_GET: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    HTTP_POST: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    HTTP_POST_SOAPACTION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    JAVA_EXECUTE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    LOG_STRING: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    NEXT_WORKING_DAY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.DATE,
    },
    NO_SWITCHES_SINCE_EOY: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    PAYROLL_ACCESS_DAYS: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    PRINT_CMD: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    REPORT_VARCHAR_PARAM: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    RUN_BATCH_JOB_EX: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },
    SAVE_AS_XLSX: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    SET_PURGE_FLAG: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    SYS_VERSION: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.STRING,
    },
    WORKING_DAYS_BETWEEN: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.LONG,
    },

    // ============================================================
    // GUI Extension (0209)
    // ============================================================
    GUI_GET_DATE_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_GET_DOUBLE_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_GET_FOCUSABLE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_GET_LONG_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_GET_SHORT_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_GET_TIME_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_GET_VALUE_REQUIRED: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_GET_VISIBLE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_POP_VALIDATION_ERROR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_PUSH_VALIDATION_ERROR: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_DATE_FIELD: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_DATE_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_DOUBLE_FIELD: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_DOUBLE_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_LONG_FIELD: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_LONG_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_SHORT_FIELD: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_SHORT_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_STRING_FIELD: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_TIME_FIELD: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_TIME_VALUE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_VALUE_REQUIRED: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_SET_VISIBLE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_VAR_GET_DATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_VAR_GET_DOUBLE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_VAR_GET_SHORT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_VAR_GET_STRING: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_VAR_GET_TIME: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_VAR_SET_DATE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_VAR_SET_DOUBLE: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_VAR_SET_SHORT: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_VAR_SET_STRING: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    GUI_VAR_SET_TIME: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
    PROMPT_FORM: {
        params: [],
        varArgs: true,
        returns: AcurityTypes.SHORT,
    },
};

/**
 * Returns an array of all known built-in function names.
 */
function getAllKnownFunctions() {
    return Object.keys(BuiltInFunctions);
}

export {
    BuiltInFunctions,
    getAllKnownFunctions
};
