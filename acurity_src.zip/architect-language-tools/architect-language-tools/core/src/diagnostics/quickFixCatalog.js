/**
 * Canonical quick-fix metadata for diagnostics.
 *
 * This keeps documentation and editor behavior queryable from a single
 * source rather than forcing tools to reverse-engineer code-action logic.
 */

const QUICK_FIX_CATALOG = Object.freeze({
    keywordCapitalization: {
        messageId: "ACU-KWD-001",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    typeKeywordCapitalization: {
        messageId: "ACU-TYPE-001",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    interpolationUnclosed: {
        messageId: "ACU-INT-003",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    interpolationCaseMismatch: {
        messageId: "ACU-INT-002",
        actionCount: 2,
        kinds: ["quickfix"]
    },
    functionCaseMismatch: {
        messageId: "ACU-FNC-007",
        actionCount: 2,
        kinds: ["quickfix"]
    },
    namingDatabaseFieldDeclaration: {
        messageId: "ACU-NAM-001",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    namingPrefixType: {
        messageId: "ACU-NAM-003",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    namingPrefixScope: {
        messageId: "ACU-NAM-002",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    unclosedString: {
        messageId: "ACU-VAR-003",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    indexUsageMissingClose: {
        messageId: "ACU-PAT-001",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    indexUsageSaveRestorePair: {
        messageId: "ACU-PAT-002",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    indexUsageSaveRestoreRecommendation: {
        messageId: "ACU-PAT-003",
        actionCount: 2,
        kinds: ["quickfix"]
    },
    indexReadBeforeLoad: {
        messageId: "ACU-PAT-004",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    indexReadBeforeOpen: {
        messageId: "ACU-PAT-005",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    indexCloseBeforeRead: {
        messageId: "ACU-PAT-006",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    exitTerminatorIssue: {
        messageId: "ACU-STY-008",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    discouragedIntegerType: {
        messageId: "ACU-TYPE-003",
        actionCount: 1,
        kinds: ["quickfix"]
    },
    declaredButNeverUsedVariable: {
        messageId: "ACU-VAR-007",
        actionCount: 1,
        kinds: ["quickfix"]
    }
});

function getQuickFixMetadata(ruleId) {
    return QUICK_FIX_CATALOG[ruleId] || null;
}

function getQuickFixActionCount(ruleId) {
    return getQuickFixMetadata(ruleId)?.actionCount || 0;
}

function getQuickFixMessageId(ruleId) {
    return getQuickFixMetadata(ruleId)?.messageId || null;
}

function getQuickFixCatalogEntries() {
    return Object.entries(QUICK_FIX_CATALOG).map(([ruleId, metadata]) => ({
        ruleId,
        ...metadata
    }));
}

export {
    QUICK_FIX_CATALOG,
    getQuickFixMetadata,
    getQuickFixActionCount,
    getQuickFixMessageId,
    getQuickFixCatalogEntries
};