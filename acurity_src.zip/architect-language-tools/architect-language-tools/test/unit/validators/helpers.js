/**
 * Shared test helpers for validator unit tests.
 */

import * as vscode from "../../__mocks__/vscode.js";

let _docSeq = 0;

/**
 * Builds a mock TextDocument from an array of line strings.
 * Each call gets a unique URI so the AST cache cannot bleed between tests.
 * @param {string[]} lines
 * @param {string} [fsPath]
 * @returns {object}
 */
function makeDocument(lines, fsPath = '/workspace/test.txt') {
    const uid = ++_docSeq;
    return {
        lineCount: lines.length,
        lineAt: (i) => ({ text: lines[i] }),
        getText: () => lines.join('\n'),
        uri: { fsPath, toString: () => `file://${fsPath}/${uid}` },
        version: 1
    };
}

/**
 * A getRuleSeverity that always returns Warning.
 */
function alwaysWarn(_ruleId) {
    return vscode.DiagnosticSeverity.Warning;
}

/**
 * A getRuleSeverity that always returns Error.
 */
function alwaysError(_ruleId) {
    return vscode.DiagnosticSeverity.Error;
}

/**
 * A getRuleSeverity that suppresses all diagnostics (returns null).
 */
function alwaysOff(_ruleId) {
    return null;
}

/**
 * Extracts diagnostic message IDs (from diagnostic.data.messageId).
 * @param {object[]} diagnostics
 * @returns {string[]}
 */
function messageIds(diagnostics) {
    return diagnostics.map((d) => d.data.messageId);
}

/**
 * Extracts diagnostic rule IDs (from diagnostic.data.ruleId).
 * @param {object[]} diagnostics
 * @returns {string[]}
 */
function ruleIds(diagnostics) {
    return diagnostics.map((d) => d.data.ruleId);
}

export { makeDocument, alwaysWarn, alwaysError, alwaysOff, messageIds, ruleIds };
