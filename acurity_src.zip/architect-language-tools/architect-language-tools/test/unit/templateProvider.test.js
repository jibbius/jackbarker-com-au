/**
 * Tests for template provider functionality.
 */

import { generateReportTemplate, generateTemplateForFilename, isBlankDocument } from "../../vscode-extension/src/templateProvider.js";

describe("Template Provider", () => {
    describe("generateReportTemplate", () => {
        test("generates template with filename", () => {
            const template = generateReportTemplate("MY_TEST_REPORT.TXT");
            
            expect(template).toContain("MY_TEST_REPORT");
            expect(template).toContain("REPORT/MY_TEST_REPORT");
            expect(template).toContain("<HTML>"); // Architect section marker (uppercase keyword)
            expect(template).toContain("#HASH-OFF");
            expect(template).toContain("//@docStart");
            expect(template).toContain("//@docEnd");
        });
        
        test("generates template without .TXT extension in report name", () => {
            const template = generateReportTemplate("MY_REPORT.TXT");
            
            // Should not have double .TXT
            expect(template).not.toContain("MY_REPORT.TXT.TXT");
            expect(template).toContain("REPORT/MY_REPORT");
        });
        
        test("includes modern comment syntax (// not #NOTE)", () => {
            const template = generateReportTemplate("TEST.TXT");
            
            // Should use // for comments
            expect(template).toContain("// DESCRIPTION");
            expect(template).toContain("// PARAMETERS");
            expect(template).toContain("// CHANGE HISTORY");
            
            // Should not use #NOTE
            expect(template).not.toContain("#NOTE");
        });
        
        test("includes standard variable declarations", () => {
            const template = generateReportTemplate("TEST.TXT");
            
            expect(template).toContain("VAR zFund, zMember");
            expect(template).toContain("VAR dStartDate, dEndDate");
            expect(template).toContain("VAR lRowCount");
        });
        
        test("includes HTML structure with Bootstrap", () => {
            const template = generateReportTemplate("TEST.TXT");
            
            expect(template).toContain("<html>"); // actual HTML tag in >> output lines (distinct from Architect <HTML> marker)
            expect(template).toContain("<head>");
            expect(template).toContain("<title>");
            expect(template).toContain("bootstrap");
            expect(template).toContain("</html>");
        });
        
        test("initializes variables from report parameters", () => {
            const template = generateReportTemplate("TEST.TXT");
            
            expect(template).toContain("SET dStartDate = hRLd_Start");
            expect(template).toContain("SET dEndDate   = hRLd_End");
            expect(template).toContain("SET zFund      = hRLz_Fund");
            expect(template).toContain("SET zMember    = hRLz_Member");
        });
        
        test("includes date in change history", () => {
            const template = generateReportTemplate("TEST.TXT");
            
            // Should include current date in YYYY-MM-DD format
            const dateRegex = /\d{4}-\d{2}-\d{2}/;
            expect(template).toMatch(dateRegex);
        });

        test("supports author name override", () => {
            const template = generateReportTemplate("TEST.TXT", { authorName: "Jack Barker" });

            expect(template).toContain("Jack Barker");
            expect(template).not.toContain("[Your Name]");
        });
        
        test("includes section headers with organization", () => {
            const template = generateReportTemplate("TEST.TXT");
            
            expect(template).toContain("// ==================");
            expect(template).toContain("// VARIABLE DECLARATIONS");
            expect(template).toContain("// MAIN REPORT LOGIC");
            expect(template).toContain("// HTML HEADER");
            expect(template).toContain("// HTML FOOTER");
        });
        
        test("handles null filename gracefully", () => {
            const template = generateReportTemplate(null);
            
            expect(template).toContain("NEW_REPORT");
            expect(template).toContain("REPORT/NEW_REPORT");
        });
    });

    describe("generateTemplateForFilename", () => {
        test("infers report template for 4-character report filenames", () => {
            const template = generateTemplateForFilename("AC14.TXT", { authorName: "Test Author" });

            expect(template).toContain("//@docStart*r* REPORT/AC14");
            expect(template).toContain("<HTML>"); // Architect section marker (uppercase keyword)
            expect(template).toContain("RLz_Report_Parms");
        });

        test("infers include template for non-report filenames", () => {
            const template = generateTemplateForFilename("FN_UTILS.TXT", { authorName: "Test Author" });

            expect(template).toContain("//@docStart*h* INCLUDE/FN_UTILS.TXT");
            expect(template).toContain("// SNIPPET");
            expect(template).toContain("FUNCTION FN_UTILS_Example():STRING");
            expect(template).not.toContain("<HTML>");
        });
    });
    
    describe("isBlankDocument", () => {
        test("identifies empty document as blank", () => {
            const mockDocument = {
                lineCount: 0,
                getText: () => ""
            };
            
            expect(isBlankDocument(mockDocument)).toBe(true);
        });
        
        test("identifies whitespace-only document as blank", () => {
            const mockDocument = {
                lineCount: 5,
                getText: () => "   \n\n  \t  \n   "
            };
            
            expect(isBlankDocument(mockDocument)).toBe(true);
        });
        
        test("identifies document with content as not blank", () => {
            const mockDocument = {
                lineCount: 1,
                getText: () => "VAR x : STRING"
            };
            
            expect(isBlankDocument(mockDocument)).toBe(false);
        });
        
        test("identifies document with content after whitespace as not blank", () => {
            const mockDocument = {
                lineCount: 3,
                getText: () => "\n\n  VAR x : STRING  "
            };
            
            expect(isBlankDocument(mockDocument)).toBe(false);
        });
    });
});
