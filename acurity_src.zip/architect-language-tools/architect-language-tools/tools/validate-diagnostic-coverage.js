import { fileURLToPath } from "url";
import { DIAGNOSTIC_CATALOG } from "../core/src/diagnostics/diagnosticCatalog.js";
import {
    buildCoverageMap,
    getDiagnosticsWithoutPositiveCoverage
} from "./generate-comprehensive-diagnostic-reference.js";

function validateDiagnosticCoverage() {
    const coverageMap = buildCoverageMap();
    const uncovered = getDiagnosticsWithoutPositiveCoverage(coverageMap);

    if (uncovered.length === 0) {
        console.log("All diagnostics have at least one positive coverage assertion.");
        return 0;
    }

    console.error("Diagnostics without positive coverage assertions:");
    uncovered.forEach((messageId) => {
        const entry = DIAGNOSTIC_CATALOG[messageId];
        console.error(`- ${messageId} (${entry.ruleId})`);
    });

    return 1;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
    process.exitCode = validateDiagnosticCoverage();
}

export {
    validateDiagnosticCoverage
};