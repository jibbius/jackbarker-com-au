/**
 * Column manifest for the comprehensive diagnostic reference reports.
 *
 * This is the single source of truth for:
 *   - Column order and display labels (shared by markdown and HTML renderers)
 *   - Which columns are sortable in the HTML table
 *   - Which columns have filter controls in the HTML report, and of what kind
 *   - Which columns are included in the HTML free-text search
 *
 * When adding, removing, or reordering a column:
 *   1. Add/move/remove its entry here.
 *   2. Update buildReferenceRows() in generate-comprehensive-diagnostic-reference.js
 *      to match (markdown cell rendering — hand-authored because of custom formatting).
 *   3. Update the <tr> data-* attributes and <td> cells in buildHtml() in
 *      generate-diagnostic-html-report.js (HTML cell rendering — hand-authored).
 *
 * filterable values:
 *   false     — no filter control
 *   "select"  — dropdown populated from unique row values (exact match)
 *   "qf"      — special yes/no dropdown (Quick Fixes column)
 *
 * multiValue: true — the cell contains a comma-separated list; the filter
 *   dropdown is populated by splitting individual values and matching uses
 *   .includes() rather than ===. Only meaningful when filterable is "select".
 */
const COLUMNS = [
    { key: "id",    label: "Message ID",              sortable: true,  filterable: false,    searchable: true  },
    { key: "src",   label: "📖",                      sortable: false, filterable: false,    searchable: false },
    { key: "cat",   label: "Category",                sortable: true,  filterable: "select", searchable: false },
    { key: "surf",  label: "Surface",                 sortable: true,  filterable: "select", searchable: false },
    { key: "msg",   label: "Message",                 sortable: true,  filterable: false,    searchable: true  },
    { key: "rule",  label: "Rule",                    sortable: true,  filterable: false,    searchable: true  },
    { key: "val",   label: "Validator(s)",             sortable: true,  filterable: "select", searchable: true,  multiValue: true  },
    { key: "str",   label: "Strict",                  sortable: true,  filterable: "select", searchable: false },
    { key: "def",   label: "Default",                 sortable: true,  filterable: "select", searchable: false },
    { key: "leg",   label: "Legacy",                  sortable: true,  filterable: "select", searchable: false },
    { key: "qf",    label: "Quick Fixes",             sortable: true,  filterable: "qf",     searchable: false },
    { key: "suite", label: "Syntax Test Suite",       sortable: true,  filterable: "checkbox", searchable: false, checkboxOptions: [
        { value: "core",             label: "Core"             },
        { value: "coding-standards", label: "Coding Standards" },
        { value: "-",                label: "None"             }
    ] },
    { key: "cov",   label: "Test Coverage",           sortable: false, filterable: false,    searchable: false },
    { key: "grp",   label: "VS Code Settings Group",  sortable: true,  filterable: "select", searchable: false },
    { key: "set",   label: "VS Code Setting",         sortable: true,  filterable: false,    searchable: true  },
];

export { COLUMNS };
