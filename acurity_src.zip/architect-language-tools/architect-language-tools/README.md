# Acurity Architect Extension (Unofficial)

An unofficial VS Code extension providing syntax highlighting and language support for the Acurity Architect domain-specific language.

**Disclaimer:** This extension is not provided, maintained, or endorsed by the maintainers of the Acurity product or Acurity Architect language.

## Features

### Syntax Highlighting
- Rich syntax highlighting for Acurity Architect files
- Proper tokenization of keywords, variables, functions, macros, and comments
- Support for HASH-ON/HASH-OFF modes with context-aware highlighting
- String interpolation syntax support

### Code Intelligence
- **35+ Built-in Diagnostics** covering:
  - Block structure validation (IF/ENDIF, WHILE/ENDWHILE, etc.)
  - Variable scope and usage checking
  - Function definition and calling conventions
  - Macro definition and invocation
  - Type checking and validation
  - INCLUDE/REQUIRE file resolution
  - String interpolation validation
  - INDEX operation patterns
  - ROBODOC documentation validation
  - Naming convention enforcement

### Quick Fixes (Code Actions)
- Auto-fix capitalization mismatches for variables, functions, and macros
- Suppress diagnostics with inline comments
- File-level diagnostic suppression

### Editor Support
- Language configuration with proper comment and bracket support
- File type recognition for `.txt` files containing Acurity Architect code
- Definition provider (Go to Definition for functions, macros, variables)
- Hover provider with symbol information
- Code completion suggestions

## Installation

### From VS Code Marketplace
1. Open VS Code
2. Go to Extensions view (`Ctrl+Shift+X` or `Cmd+Shift+X`)
3. Search for "Acurity Architect"
4. Click **Install**

### From VSIX File
1. Download the `.vsix` file from releases
2. Open VS Code
3. Go to Extensions view
4. Click the `...` menu → **Install from VSIX...**
5. Select the downloaded `.vsix` file

### First Run
The extension activates automatically when you open any `.txt` file. If your Acurity files use a different extension, you can configure VS Code to associate them with this extension:

1. Open a file with Acurity code
2. Click the language indicator in the bottom-right corner
3. Select "Configure File Association for '.txt'..."
4. Choose "Acurity Architect"

Recommended: use `Acurity: Configure Extension` on first run and select the TXT association step. You can also run `Acurity: Associate .txt Files with Acurity` later from the Command Palette.

## Getting Started

### Basic Usage

1. **Open an Acurity file** - The extension activates on `.txt` files
2. **View diagnostics** - Problems appear in the Problems panel (`Ctrl+Shift+M`)
3. **Apply quick fixes** - Click the lightbulb icon or press `Ctrl+.` on a diagnostic
4. **Navigate code** - Use `F12` (Go to Definition) on functions, macros, or variables
5. **Batch-validate a folder** - Run `Acurity: Validate TXT Folder And Export Report` from Command Palette to scan all `.txt/.TXT` files in a selected folder and save a JSON diagnostics report.
6. **Discover builtin candidates** - Run `Acurity: Discover Builtin Candidates in TXT Folder` from Command Palette to scan all `.txt/.TXT` files in a selected folder, extract all function calls not recognized as builtins or known functions, and export a discovery report (JSON or CSV) listing unique candidates and their locations/counts. Useful for profiling external codebases and identifying potential new builtins.

### Example: Your First Acurity File

Create a file called `example.txt`:

```
REPORT
    VAR zName : STRING
    
    zName = "Hello, Acurity!"
    
    OUTPUT "Name: ^zName^"
ENDREPORT
```

The extension will provide:
- Syntax highlighting for keywords, variables, and strings
- Validation that `zName` is properly declared and used
- String interpolation syntax checking

## Configuration

### Standards Profiles

The extension includes three predefined standards profiles to match your coding style:

- **`default`** (recommended) - Balanced strictness for general use
- **`legacy-compatible`** - Permissive mode for maintaining older codebases
- **`strict-modern`** - Strictest checking for new projects

**To change your profile:**

1. Open VS Code Settings (`Ctrl+,` or `Cmd+,`)
2. Search for "Acurity"
3. Set **Acurity: Standards Profile** to your preferred option

### Customizing Individual Rules

You can override any diagnostic rule severity in your settings:

```json
{
  "acurity.rules.profile": "default",
  "acurity.rules.core.blockStructure.severity": "error",
  "acurity.rules.core.undefinedVariable.severity": "error",
  "acurity.rules.standards.namingPrefixScope.severity": "warning",
  "acurity.rules.standards.keywordCapitalization.severity": "off"
}
```

**Severity Options:**
- `"error"` - Red underline, blocks in Problems panel
- `"warning"` - Yellow underline, appears in Problems panel
- `"info"` - Blue underline, informational
- `"off"` - Disable the rule completely

### Other Settings

- **`acurity.diagnostics.debounceMs`** - Delay before re-running validation (default: 150ms)
- **`acurity.logging`** - Enable verbose extension logging for debugging
- **`acurity.naming.scopePrefixes.global.prefixChar`** - Global variable prefix (default: `g`)
- **`acurity.naming.scopePrefixes.parameter.prefixChar`** - Parameter prefix (default: `p`)
- **`acurity.naming.scopePrefixes.functionScoped.prefixChar`** - Function-scoped prefix (default: `f`)

## Suppressing Diagnostics

### Inline Suppression

Suppress a specific diagnostic for a single line:

```
VAR zUnused : STRING  // @acurity-ignore ACU-VAR-002
```

### File-Level Suppression

Suppress diagnostics for an entire file:

```
// @acurity-ignore-file ACU-VAR-002 ACU-NAM-002
```

## Troubleshooting

### Extension Not Activating

**Problem:** Syntax highlighting or diagnostics not appearing.

**Solutions:**
- Verify the file is recognized as Acurity (`Acurity Architect` should appear in the bottom-right status bar)
- Manually set the language: Click the language indicator → Select "Acurity Architect"
- Check the Output panel: View → Output → Select "Acurity" from dropdown

### Diagnostics Not Running

**Problem:** No errors or warnings appearing in the Problems panel.

**Solutions:**
- Check if diagnostics are disabled: Search settings for "Acurity" and verify rules aren't set to `"off"`
- Increase debounce time if on a slower machine: Set `acurity.diagnostics.debounceMs` to `500`
- Enable logging: Set `acurity.logging: true` and check the Output panel

### False Positives on INCLUDE Files

**Problem:** "INCLUDE: File not found" errors when files exist.

**Solutions:**
- Ensure INCLUDE paths are relative to the workspace root
- Verify file name case matches exactly (case-sensitive on some systems)
- Open the root folder containing your Acurity files as the workspace

### Performance Issues

**Problem:** Extension feels slow or unresponsive.

**Solutions:**
- Increase `acurity.diagnostics.debounceMs` to `300` or higher
- Disable expensive rules you don't need (e.g., ROBODOC validation)
- Close unused editor tabs to reduce background processing

## Known Limitations

This extension is under active development. The following features are not yet supported:

- Code formatting / beautification
- Rename refactoring across files
- Extract function refactoring
- Multi-file symbol search (Workspace Symbol)
- Semantic symbol outline in large files
- Debugging support

## Requirements

- VS Code 1.33.0 or higher

## Diagnostic Catalog

This section is auto-generated from `src/diagnostics/diagnosticCatalog.js` during build/packaging.

### Concepts

Two distinct entities appear in this table:

- **Message** — a specific diagnostic with a stable `ACU-XXX-NNN` ID. Shown in VS Code hover tooltips and the Problems panel. Used for suppression (`// @rule-ignore ACU-INT-001`). A Rule may produce several distinct Message types.
- **Rule** — a named validation behaviour (camelCase key). Controls a single VS Code setting (`acurity.rules.<group>.<rule>.severity`). All Messages that share a Rule are affected by that one setting.

<!-- DIAGNOSTIC_CATALOG_TABLE_START -->
| Message ID | Rule | Category | Default Severity | Message | Params |
| --- | --- | --- | --- | --- | --- |
| `ACU-ARG-001` | invalidDateStringFormat | validity | error | Invalid date string '{value}'. Expected format DD/MM/YYYY (e.g. '31/12/2026'). | value |
| `ACU-ARG-002` | invalidDateStringOutOfRange | validity | error | Date string '{value}' is out of the valid range (00/00/0000 to 31/12/9998). | value |
| `ACU-ARG-003` | invalidCursorDirection | validity | error | Invalid cursor direction '{value}'. Valid directions: >=, >, +, =, -, <, <=. | value |
| `ACU-ARG-004` | invalidCursorDirection | validity | error | Invalid cursor direction '{value}'. Did you mean '{suggestion}'? | value, suggestion |
| `ACU-ARG-005` | invalidTableSynonym | validity | error | Invalid table synonym '{value}'. Expected a valid 2-letter table code (e.g. 'MD', 'PH'). | value |
| `ACU-ARG-008` | literalForVarParam | validity | error | '{paramLabel}' argument of {functionName}() requires a variable, not a literal. | paramLabel, functionName |
| `ACU-BLK-001` | blockStructure | validity | error | Unexpected {closeKeyword} without matching {openKeyword}. | closeKeyword, openKeyword |
| `ACU-BLK-002` | blockStructure | validity | error | {closeKeyword} does not match {openKeyword} at line {lineNumber}. | closeKeyword, openKeyword, lineNumber |
| `ACU-BLK-003` | blockStructure | validity | error | '{openKeyword}' at line {lineNumber} is not closed with '{closeKeyword}'. | openKeyword, lineNumber, closeKeyword |
| `ACU-BLK-004` | blockIndentation | standards | warning | '{keyword}' indentation ({column}) does not match '{openKeyword}' at line {lineNumber} (indentation {openColumn}). | keyword, column, openKeyword, lineNumber, openColumn |
| `ACU-BLK-005` | elseIfMisuse | validity | error | 'ELSE IF' is not a conditional — the IF condition is ignored and the ELSE branch always executes. Restructure with nested IF or CASE. | - |
| `ACU-BLK-006` | duplicateElse | validity | error | Duplicate ELSE branch — an IF block may only have one ELSE. | - |
| `ACU-FNC-001` | functionUndefined | validity | error | Function '{functionName}' is not defined. | functionName |
| `ACU-FNC-002` | functionOutOfScope | validity | error | Function '{functionName}' is not yet defined at this point. | functionName |
| `ACU-FNC-003` | functionRedeclared | validity | error | Function '{functionName}' is declared multiple times. Functions cannot be redeclared. | functionName |
| `ACU-FNC-004` | functionConstantUsage | validity | error | '{functionName}' is a system constant and should be used without parentheses. | functionName |
| `ACU-FNC-005` | functionCallUnclosed | validity | error | Unclosed function call for '{functionName}'. | functionName |
| `ACU-FNC-006` | functionSignature | validity | error | Function signature error: {errorDetail} | errorDetail |
| `ACU-FNC-007` | functionCaseMismatch | standards | warning | Function '{functionName}' capitalisation differs from declared function '{declaredName}'. | functionName, declaredName |
| `ACU-FNC-008` | functionReturnValueUnused | advisory | error | Function '{functionName}' return value is unused. Consider assigning function return to a variable. | functionName |
| `ACU-FNC-009` | functionArgumentType | validity | error | Argument {n} to '{function}': expected {expectedType}, got {actualType}. | n, function, expectedType, actualType |
| `ACU-FNC-010` | functionReturnTypeMismatch | validity | error | Return type mismatch in '{functionName}': declared return type is {expectedType}, but '{expression}' is {actualType}. | functionName, expectedType, expression, actualType |
| `ACU-FNC-011` | functionMissingReturn | validity | error | Function '{functionName}' declares return type {returnType} but contains no RETURN statement. | functionName, returnType |
| `ACU-FNC-012` | functionCallWhitespace | standards | warning | Whitespace is not allowed between '{name}' and '('. | name |
| `ACU-FNC-013` | functionBuiltinCollision | validity | error | '{functionName}' is a built-in function. User-defined functions cannot shadow built-in names. Wrap in IF NOT SYMBOL('{functionName}') ... ENDIF to define a conditional polyfill. | functionName |
| `ACU-FNC-014` | functionDeclarationMissingParamType | validity | error | Parameter '{paramName}' in function '{functionName}' is missing a type annotation. Each parameter must be declared as 'paramName : TYPE'. | paramName, functionName |
| `ACU-FNC-015` | functionDeclarationMissingReturnType | validity | error | Function '{functionName}' is missing a return type. Add ': TYPE' after the closing parenthesis (e.g., ': STRING'). | functionName |
| `ACU-FNC-016` | functionDeprecated | advisory | warning | '{functionName}' is a deprecated/legacy function. | functionName |
| `ACU-INC-001` | includeCircular | validity | warning | Circular include detected for '{includeFilename}'. | includeFilename |
| `ACU-INC-002` | includeFilenameCaseMismatch | standards | warning | Include filename case differs from actual file '{actualFilename}' for '{includeFilename}'. | includeFilename, actualFilename |
| `ACU-INC-003` | includeFileNotFound | validity | error | INCLUDE: File '{filename}' not found. | filename |
| `ACU-INC-004` | requireFileNotFound | validity | error | REQUIRE: File '{filename}' not found. | filename |
| `ACU-INT-001` | interpolationUndefined | validity | error | Variable '{variableName}' is not defined. | variableName |
| `ACU-INT-002` | interpolationCaseMismatch | standards | warning | Variable '{variableName}' capitalisation differs from declared variable '{declaredName}'. | variableName, declaredName |
| `ACU-INT-003` | interpolationUnclosed | validity | error | Unclosed string interpolation for '{variableName}'. Expected '^{variableName}^'. | variableName |
| `ACU-KWD-001` | keywordCapitalization | standards | warning | Keyword '{keyword}' should be capitalized as '{uppercase}'. | keyword, uppercase |
| `ACU-MAC-001` | macroRedeclared | validity | error | Macro '{macroName}' is declared multiple times. Macros cannot be redeclared. | macroName |
| `ACU-MAC-002` | macroCaseMismatch | standards | warning | Macro '{usedName}' capitalisation differs from declared macro '{declaredName}'. | usedName, declaredName |
| `ACU-MAC-003` | macroUnexpectedParameters | validity | error | Macro '{macroName}' expects no parameters but was called with {actualCount}. | macroName, actualCount |
| `ACU-MAC-004` | macroMissingParameters | validity | error | Macro '{macroName}' expects {expectedCount} parameter(s) but was called without parentheses. | macroName, expectedCount |
| `ACU-MAC-005` | macroParameterCountMismatch | validity | error | Macro '{macroName}' expects {expectedCount} parameter(s) but was called with {actualCount}. | macroName, expectedCount, actualCount |
| `ACU-NAM-001` | namingDatabaseFieldDeclaration | standards | error | ERROR: Declaring variables with an 'h' prefix is strongly discouraged, as variables may be confused with database fields. | - |
| `ACU-NAM-002` | namingPrefixScope | standards | warning | Naming convention (scope): '{variableName}' has scope prefix '{actualPrefix}' ({actualScope}) but is {expectedScope}. Consider '{recommendedName}'. | variableName, actualPrefix, actualScope, expectedScope, recommendedName |
| `ACU-NAM-003` | namingPrefixType | standards | warning | Naming convention (type): '{variableName}' has type prefix suggesting {expectedType} but is declared as {actualType}. Consider '{recommendedName}'. | variableName, expectedType, actualType, recommendedName |
| `ACU-OPT-001` | invalidOptionCharacter | validity | error | '{char}' is not a valid ICC/OICC/CICC character. Allowed characters are: {allowed}. | char, allowed |
| `ACU-OPT-002` | nonDefaultIccCharacter | validity | warning | Custom ICC character '{char}' — IDE interpolation support requires the default '#'. | char |
| `ACU-OUT-001` | outputDirectiveInCodeContext | validity | error | '{name}' is an output-positioning directive, not a function. It can only be used between OICC/CICC delimiters on output lines (e.g., >>@{name}(...)@). | name |
| `ACU-OUT-002` | outputDirectiveArgumentCount | validity | error | '{name}' expects {expected} argument(s) but was called with {actual}. | name, expected, actual |
| `ACU-OUT-003` | outputDirectiveColumnRange | validity | warning | Column value {value} is out of the valid range (1 to 16000). | value |
| `ACU-PAT-001` | indexUsageMissingClose | advisory | warning | Index cursor operations detected without an INDEX_CLOSE call in the same scope. | - |
| `ACU-PAT-002` | indexUsageSaveRestorePair | advisory | warning | INDEX_SAVE_POSITION and INDEX_RESTORE_POSITION should be used as a pair in the same scope. | - |
| `ACU-PAT-003` | indexUsageSaveRestoreRecommendation | advisory | warning | Consider wrapping index cursor movement with INDEX_SAVE_POSITION and INDEX_RESTORE_POSITION. | - |
| `ACU-PAT-004` | indexReadBeforeLoad | validity | warning | INDEX_READ_BY_KEY should occur after INDEX_LOAD_KEY_* in standard flow. | - |
| `ACU-PAT-005` | indexReadBeforeOpen | validity | warning | INDEX_READ_BY_KEY should occur after INDEX_OPEN_* in standard flow. | - |
| `ACU-PAT-006` | indexCloseBeforeRead | validity | warning | INDEX_CLOSE should occur after cursor operations (LOAD/READ) in standard flow. | - |
| `ACU-PAT-007` | arrayOpsWithoutInit | validity | warning | Array record operations on '{handle}' detected without an INIT_SORTED_ARRAY call in the same scope. | handle |
| `ACU-PAT-008` | arrayInitWithoutFree | advisory | warning | INIT_SORTED_ARRAY called without a corresponding FREE_SORTED_ARRAY or FIN_SORTED_ARRAY. | - |
| `ACU-PAT-009` | arrayFreeBeforeOps | validity | warning | Array record operation on '{handle}' after FREE_SORTED_ARRAY. Free the handle only after all operations are complete. | handle |
| `ACU-PAT-010` | staleIndexHandle | validity | warning | '{handle}' was passed to INDEX_CLOSE and may no longer refer to a valid index cursor. | handle |
| `ACU-PAT-011` | getUnusedHandleOverwrite | validity | warning | '{variable}' is used as both the assignment target and the argument to GET_UNUSED_ARRAY_HANDLE, overwriting the handle with the status code. | variable |
| `ACU-PAT-012` | consecutiveGetUnusedHandle | validity | warning | GET_UNUSED_ARRAY_HANDLE called again before INIT_SORTED_ARRAY was called for the previous handle. Both calls will return the same handle value. | - |
| `ACU-PAT-013` | indexRestoreWithoutSave | validity | warning | INDEX_RESTORE_POSITION('{tableCode}'): no active save for this table code. | tableCode |
| `ACU-PAT-014` | indexLoadKeyTypeMismatch | validity | warning | Index key at position {pos} expects type {expected} but '{callName}' loads a {actual} value. | pos, expected, callName, actual |
| `ACU-PAT-015` | indexLoadKeyCountExceeded | validity | warning | Index '{indexName}' on table '{tableCode}' has {total} key segment(s). This load exceeds that count. | indexName, tableCode, total |
| `ACU-PAT-016` | indexHandleOverwrite | validity | warning | Assigning to '{handle}' will overwrite an active index cursor handle. | handle |
| `ACU-PAT-017` | indexLoadKeyStringTooLong | validity | warning | Length argument {length} exceeds the maximum width of segment {pos} ('{field}', max: {maxWidth}). | length, pos, field, maxWidth |
| `ACU-RBD-001` | robodocMissingStart | standards | information | Missing ROBODOC start marker. Expected '//@docStart*...* ...'. | - |
| `ACU-RBD-002` | robodocMissingEnd | standards | information | Missing ROBODOC end marker. Expected '//@docEnd'. | - |
| `ACU-RBD-003` | robodocKindMismatch | standards | information | ROBODOC kind mismatch. Expected {expectedKind} tag '{expectedTag}' but found '{actualTag}'. | expectedKind, expectedTag, actualTag |
| `ACU-RBD-004` | robodocTargetMismatch | standards | information | ROBODOC header target mismatch. Expected '{expectedTarget}' but found '{actualTarget}'. | expectedTarget, actualTarget |
| `ACU-RBD-005` | robodocMissingSection | standards | information | ROBODOC section '{sectionName}' is missing from the doc block. | sectionName |
| `ACU-STY-003` | emptyDateLiteral | standards | warning | Date literal '00/00/0000' is discouraged. Use MIN_DATE instead. | - |
| `ACU-STY-004` | operatorSpacing | standards | off | Operator '{operator}' must have a single space on each side. | operator |
| `ACU-STY-005` | discouragedHardcodedArrayHandle | advisory | warning | Hard-coded integer '{handle}' used as an array handle. Obtain the handle via GET_UNUSED_ARRAY_HANDLE() instead. | handle |
| `ACU-STY-008` | exitTerminatorIssue | standards | warning | '{keyword}' {issue}. | keyword, issue |
| `ACU-SYN-001` | redundantHashOn | standards | warning | Redundant '#HASH-ON' directive. Reports are HASH-ON by default until HASH-OFF is encountered. | - |
| `ACU-SYN-002` | invalidExecutableLine | validity | error | Unexpected token or unrecognized statement in executable context. Use '//' for comments or '>>' for output text. | - |
| `ACU-SYN-003` | preferSlashSlashComments | standards | warning | Prefer '//' comments over legacy '#NOTE' directives. | - |
| `ACU-SYN-004` | doIteratorMissingClause | validity | error | DO iterator '{variable}' has no TO or BY clause. Use 'DO {variable} = start TO end' or 'DO {variable} = start TO end BY step'. | variable |
| `ACU-SYN-005` | doIteratorNoUpperBound | advisory | warning | DO {variable}: This loop runs indefinitely (no BREAK / TO / UNTIL / WHILE). | variable |
| `ACU-SYN-006` | incompleteAssignment | validity | error | Assignment statement is incomplete — no value on the right-hand side. | - |
| `ACU-SYN-007` | invalidContinuation | validity | error | The continuation operator '...' must appear at the end of a line, before any comment. Code cannot follow '...' on the same line. | - |
| `ACU-SYN-008` | unexpectedTokensAfterStatement | validity | error | Unexpected tokens after {keyword} statement — expected end of line. | keyword |
| `ACU-SYN-009` | untilMissingCondition | validity | error | 'UNTIL' requires a condition expression. Unexpected end of line. | - |
| `ACU-TODO-001` | todoItem | advisory | information | TODO: {description} | description |
| `ACU-TODO-002` | fixmeItem | advisory | information | FIXME: {description} | description |
| `ACU-TODO-003` | hackItem | advisory | information | HACK: {description} | description |
| `ACU-TYPE-001` | typeKeywordCapitalization | standards | warning | Type keyword '{keyword}' should be capitalized as '{uppercase}'. | keyword, uppercase |
| `ACU-TYPE-002` | typeMismatch | validity | error | Type mismatch: Cannot assign {sourceType} to {targetType} variable '{target}'. | sourceType, targetType, target |
| `ACU-TYPE-003` | discouragedIntegerType | advisory | warning | Type 'INTEGER' is discouraged. Use 'LONG' instead. | - |
| `ACU-VAR-001` | undefinedVariable | validity | error | {variableName} is not defined. | variableName |
| `ACU-VAR-002` | unsetVariable | validity | warning | {variableName} is not set. | variableName |
| `ACU-VAR-003` | unclosedString | validity | error | String is unclosed. | - |
| `ACU-VAR-004` | pseudoConstantMultipleAssignment | standards | warning | Pseudo-constant '{variableName}' is assigned multiple times. First assigned on line {firstLine}. | variableName, firstLine |
| `ACU-VAR-005` | nearMissConstantName | validity | error | '{variableName}' is not defined. Did you mean '{suggestion}'? | variableName, suggestion |
| `ACU-VAR-006` | readOnlyGlobalVariableAssignment | validity | error | '{variableName}' is a read-only built-in global variable and cannot be assigned. | variableName |
| `ACU-VAR-007` | declaredButNeverUsedVariable | standards | off | '{variableName}' is declared but never used. | variableName |
| `ACU-VAR-008` | invalidFieldHandle | advisory | warning | '{name}' does not match any known database field handle. | name |
| `ACU-VAR-009` | fieldHandleCapitalization | standards | warning | Field handle '{name}' should be '{canonical}'. | name, canonical |
<!-- DIAGNOSTIC_CATALOG_TABLE_END -->

### Understanding Diagnostic Codes

Diagnostic codes follow the pattern `ACU-XXX-###`:
- **ACU** - Acurity extension prefix
- **XXX** - Category code (e.g., VAR = Variables, FNC = Functions, BLK = Block Structure)
- **###** - Specific rule number within category

**Categories:**
- **BLK** - Block Structure (IF/ENDIF, WHILE/ENDWHILE, etc.)
- **FNC** - Function Definition and Usage
- **INC** - INCLUDE Statement Resolution
- **INT** - String Interpolation
- **KWD** - Keyword Capitalization
- **MAC** - Macro Definition and Usage
- **NMG** - Naming Conventions
- **PAT** - Usage Patterns (INDEX operations, etc.)
- **RBD** - ROBODOC Documentation
- **REQ** - REQUIRE Statement Resolution
- **SYN** - General Syntax
- **TYPE** - Type System and Validation
- **VAR** - Variable Declaration and Usage

## Contributing

This is an unofficial community extension. Contributions are welcome!

### Reporting Issues

If you encounter bugs or have feature requests:
1. Check existing issues in the repository
2. Provide a minimal code sample that reproduces the issue
3. Include your extension version and VS Code version
4. Enable logging (`acurity.logging: true`) and attach relevant output

### Feature Requests

When suggesting new features:
- Describe the use case and expected behavior
- Provide code examples if applicable
- Consider if it should apply to all profiles or be configurable

## Release Notes

See `CHANGELOG.md` for detailed release notes.

## License

This extension is licensed under the MIT License. See `LICENSE.txt` for details.

## Acknowledgments

This is an unofficial extension created to support the Acurity Architect developer community. It is not affiliated with, endorsed by, or supported by the maintainers of the Acurity product.

---

