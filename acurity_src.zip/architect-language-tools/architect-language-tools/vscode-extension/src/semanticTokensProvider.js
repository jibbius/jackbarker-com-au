/**
 * Semantic tokens provider for Acurity Architect.
 *
 * Provides registry-aware token classification overlaying the tmLanguage grammar:
 *   - Builtin constants (SYSTEM_DATE, HEADER, DB_STATUS, …) → variable.readonly
 *   - Builtin functions (GET_TOKEN, FORMAT, …)               → function + defaultLibrary
 *
 * Token type and modifier names are declared here AND in package.json
 * contributes.semanticTokensProvider.legend. The two lists must match exactly.
 *
 * Classification logic lives in core/src/analysis/semanticTokenClassifier.js
 * (no vscode dependency) so it can be unit-tested independently.
 */

import * as vscode from "vscode";
import { LANGUAGE_ID } from "../../core/src/constants.js";
import { classifySemanticTokens } from "../../core/src/analysis/semanticTokenClassifier.js";

const TOKEN_TYPES     = ["variable", "function", "keyword", "annotationKeyword", "annotationRuleId"];
const TOKEN_MODIFIERS = ["readonly", "defaultLibrary"];

const LEGEND = new vscode.SemanticTokensLegend(TOKEN_TYPES, TOKEN_MODIFIERS);

/**
 * @param {vscode.TextDocument} document
 * @returns {vscode.SemanticTokens}
 */
function provideDocumentSemanticTokens(document) {
    const builder = new vscode.SemanticTokensBuilder(LEGEND);
    for (const t of classifySemanticTokens(document)) {
        builder.push(t.line, t.char, t.length, t.tokenType, t.tokenModifiers);
    }
    return builder.build();
}

/**
 * @param {vscode.ExtensionContext} context
 */
function initializeSemanticTokensProvider(context) {
    context.subscriptions.push(
        vscode.languages.registerDocumentSemanticTokensProvider(
            LANGUAGE_ID,
            { provideDocumentSemanticTokens },
            LEGEND
        )
    );
}

export { initializeSemanticTokensProvider };
