/**
 * Acurity Architect Language Extension
 * 
 * Provides syntax highlighting and language support for Acurity Architect.
 */

import * as vscode from "vscode";
import { initializeDiagnostics, disposeDiagnostics } from "./src/diagnostics.js";
import { initializeHoverProvider } from "./src/hoverProvider.js";
import { initializeCompletionProvider } from "./src/completionProvider.js";
import { initializeBuiltinCompletionProvider } from "./src/builtinCompletionProvider.js";
import { initializeAnnotationCompletionProvider } from "./src/annotationCompletionProvider.js";
import { initializeKeywordCompletionProvider } from "./src/keywordCompletionProvider.js";
import { initializeDefinitionProvider } from "./src/definitionProvider.js";
import { registerCodeActions } from "./src/codeActionProvider.js";
import { initializeTemplateProvider } from "./src/templateProvider.js";
import { initializeSemanticTokensProvider } from "./src/semanticTokensProvider.js";
import { initLogger, setLoggingEnabled, log } from "../core/src/logger.js";
import { registerSetupCommands, checkFirstRun } from "./src/commands/setupWizard.js";
import { registerBatchValidateTxtFolderCommand } from "./src/commands/batchValidateTxtFolder.js";
import { runDiscoveryReport } from "./src/commands/discoveryReport.js";
import { registerOpenContextHelpCommand } from "./src/commands/openContextHelp.js";
import { initializeIndexCompletionProvider } from "./src/indexCompletionProvider.js";
import { initializeCodeLensProvider } from "./src/codeLensProvider.js";
import { initializeVariableCompletionProvider } from "./src/variableCompletionProvider.js";
import { createRequire } from "module";

const _require = createRequire(import.meta.url);

function isLoggingEnabled() {
    return vscode.workspace.getConfiguration("acurity").get("logging", false);
}

/**
 * Called when the extension is activated.
 * @param {import('vscode').ExtensionContext} context - The extension context
 */
function activate(context) {
    try {
        // Initialize file logging
        initLogger();
        setLoggingEnabled(isLoggingEnabled());

        context.subscriptions.push(
            vscode.workspace.onDidChangeConfiguration((event) => {
                if (event.affectsConfiguration("acurity.logging")) {
                    setLoggingEnabled(isLoggingEnabled());
                }
            })
        );
        
        // Log build metadata to help verify latest build is running
        try {
            const metadata = _require("../core/src/build-metadata.json");
            log(`✓ Extension activated - Build: ${metadata.buildTime} (v${metadata.version})`);
        } catch (e) {
            log(`Extension activated - Build metadata not available`);
        }
        
        initializeDiagnostics(context);
        initializeHoverProvider(context);
        initializeCompletionProvider(context);
        initializeBuiltinCompletionProvider(context);
        initializeAnnotationCompletionProvider(context);
        initializeKeywordCompletionProvider(context);
        initializeDefinitionProvider(context);
        registerCodeActions(context);
        initializeTemplateProvider(context);
        initializeSemanticTokensProvider(context);
        registerSetupCommands(context);
        registerBatchValidateTxtFolderCommand(context);
        context.subscriptions.push(
            vscode.commands.registerCommand('acurity.discoveryReport', runDiscoveryReport)
        );
        initializeIndexCompletionProvider(context);
        initializeCodeLensProvider(context);
        initializeVariableCompletionProvider(context);
        registerOpenContextHelpCommand(context);
        // Check if this is the first run and show setup wizard
        checkFirstRun(context);
    } catch (err) {
        const msg = (err && err.message) ? err.message : String(err);
        vscode.window.showErrorMessage(`[Acurity] Extension failed to activate: ${msg}`);
        log(`[Acurity] Extension failed to activate: ${msg}`);
        throw err;
    }
}

/**
 * Called when the extension is deactivated.
 */
function deactivate() {
    disposeDiagnostics();
}

export {
    activate,
    deactivate
};
