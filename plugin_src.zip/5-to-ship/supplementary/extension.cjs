/**
 * Companion extension activation entry for the Architect Language Tools
 * supplementary-module injection contract.
 *
 * Lifecycle:
 *   1. VS Code loads the main extension first (guaranteed by extensionDependencies
 *      in package.json).
 *   2. On our activation, we retrieve the main extension's public API via
 *      vscode.extensions.getExtension(...).exports and call registerSupplementary
 *      with this package's default export.
 *
 * ESM/CJS bridge:
 *   VS Code loads extension entry points as CommonJS. This package's runtime
 *   modules (validators, builtins, catalog) are ES modules, so we reach them via
 *   dynamic import(). Keeping this file CJS preserves compatibility with the
 *   VS Code extension host loader without forcing the rest of the package to CJS.
 */

const vscode = require("vscode");

const MAIN_EXTENSION_ID = "jibbius.arch-lang-tools";

async function activate(_context) {
    const mainExtension = vscode.extensions.getExtension(MAIN_EXTENSION_ID);
    if (!mainExtension) {
        vscode.window.showErrorMessage(
            `[Acurity Supplementary] Cannot find main extension "${MAIN_EXTENSION_ID}". ` +
            `The supplementary companion requires the main Architect Language Tools ` +
            `extension to be installed.`
        );
        return;
    }

    // extensionDependencies should have already activated it, but be defensive.
    if (!mainExtension.isActive) {
        await mainExtension.activate();
    }

    const api = mainExtension.exports;
    if (!api || typeof api.registerSupplementary !== "function") {
        vscode.window.showErrorMessage(
            `[Acurity Supplementary] Main extension "${MAIN_EXTENSION_ID}" did not ` +
            `expose registerSupplementary. Check that the installed version supports ` +
            `the supplementary-module contract.`
        );
        return;
    }

    // Dynamic import bridges CJS → ESM for the supplementary module graph.
    // The VSIX ships the esbuild bundle (`./dist/architect-supplementary.js`)
    // rather than the source tree — single-file activation, sourcemap
    // support for stack traces. The source layout under `src/` is still
    // the authoring source, but is excluded from the VSIX via .vscodeignore.
    //
    // Both calls below can fail (syntax error in the supplementary bundle, or
    // schema validation failure after a future contract tightening). Surface
    // those failures the same way as the earlier guards — without this,
    // VS Code only reports a generic "Activating extension … failed" line.
    let supplementaryModule;
    try {
        supplementaryModule = await import("./dist/architect-supplementary.js");
    } catch (err) {
        vscode.window.showErrorMessage(
            `[Acurity Supplementary] Failed to load supplementary module: ${err.message}`
        );
        return;
    }
    try {
        api.registerSupplementary(supplementaryModule);
    } catch (err) {
        vscode.window.showErrorMessage(
            `[Acurity Supplementary] registerSupplementary rejected the module: ${err.message}`
        );
    }
}

function deactivate() {
    // The core loader tracks its own injections; there is no reverse API exposed
    // to companion extensions at this time. Left as a no-op for forward compat.
}

module.exports = { activate, deactivate };
