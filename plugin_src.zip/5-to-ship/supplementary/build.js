/**
 * Build the supplementary module into a self-contained `dist/` directory.
 *
 * Two passes:
 *
 *   1. esbuild — bundles `index.js` + the `src/` graph into a single ESM
 *      file at `dist/architect-supplementary.js`.
 *   2. data — projects the JSON authoring tree under `src/builtins-data/`
 *      into JSON sidecars next to the JS bundle, plus a copy of the
 *      vendored schemas folder. Filenames mirror core's bundle artefacts
 *      (`functions.bundle.json`, `global-variables.bundle.json`,
 *      `tables-registry.bundle.json`, `tables.bundle.json`,
 *      `help-registry.json`, `deprecated-symbols.json`, `schemas/`).
 *
 * Both passes are required for the standalone-MCP hand-off, where only
 * `dist/` ships. The supplementary's loaders probe the dist-mode sidecars
 * before falling back to the source-tree layout — so the same bundle JS
 * works whether it's loaded from the repo (tests, VS Code companion) or
 * from a copied `dist/` directory (MCP standalone).
 *
 * Pairs with the standalone MCP bundle
 * (`architect-language-tools/mcp/dist/architect-mcp-standalone.js`).
 *
 * Plain Node — no esbuild plugin used for the data pass. The module has
 * zero third-party runtime deps and the runtime helpers are vendored from
 * core (see `tools/sync-from-core.js`), so the bundle is fully
 * self-contained and the supplementary tree builds standalone — no sibling
 * core checkout required at the recipient end.
 *
 * The data pass projects through the vendored `tools/_dataProjectors.js`
 * — the same primitives core's `tools/build-builtins-bundle.js` uses, so
 * the bundle shape evolves in lockstep. Drift between the vendored copies
 * and core is asserted by core's `supplementarySchemaSync.test.js`.
 */

import * as esbuild from "esbuild";
import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import {
    projectArrayBundle,
    projectTableBundles,
    projectCompositeCopy,
    projectSchemasFolder
} from "./tools/_dataProjectors.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIST_DIR = path.join(__dirname, "dist");
const DATA_DIR = path.join(__dirname, "src", "builtins-data");
// Sidecar location next to the registry JS. Runtime loaders are source-first:
// when src/builtins-data/ is present they read from there, so dev edits go
// live without rebuilding. VSIX packaging excludes src/builtins-data/ via
// .vscodeignore, leaving only these sidecars — the loaders then fall back to
// them. Gitignored so a fresh clone has no stale artefacts.
const SIDECAR_DIR = path.join(__dirname, "src", "builtins");

// ---------------------------------------------------------------------------
// Pass 1 — esbuild
// ---------------------------------------------------------------------------

await esbuild.build({
    entryPoints: [path.join(__dirname, "index.js")],
    outfile: path.join(DIST_DIR, "architect-supplementary.js"),
    bundle: true,
    format: "esm",
    platform: "node",
    target: "node20",
    sourcemap: process.env.ARCH_LANG_BUILD !== "release",
    banner: {
        js: "// Architect Language Tools — supplementary module (bundled)."
    },
    logLevel: "info"
});

// ---------------------------------------------------------------------------
// Pass 2 — data
//
// dist/ side:        bundle JS + builtins/ subfolder of data files. The
//                    bundled loaders' preferSubfolder() lookup finds them
//                    under ./builtins/ when running from dist (or from
//                    a hand-off install where dist/ has been copied as-is).
// src/builtins/ side: flat layout — these sidecars are a fallback for
//                    consumers that import the source-tree `index.js`
//                    after `src/builtins-data/` has been excluded by some
//                    upstream packaging step. preferSubfolder() probes
//                    src/builtins/builtins/ first, doesn't find it, and
//                    falls back to flat src/builtins/.
// ---------------------------------------------------------------------------

const DIST_BUILTINS = path.join(DIST_DIR, "builtins");
fs.mkdirSync(DIST_BUILTINS, { recursive: true });
fs.mkdirSync(SIDECAR_DIR,   { recursive: true });

function buildArray(subdir, outName) {
    const { count } = projectArrayBundle({
        sourceDir: path.join(DATA_DIR, subdir),
        outFiles: [
            path.join(DIST_BUILTINS, outName),
            path.join(SIDECAR_DIR,   outName)
        ]
    });
    console.log(`[data] ${subdir}: ${count} entries -> dist/builtins/${outName} + src/builtins/${outName}`);
}

function buildTables() {
    const { count } = projectTableBundles({
        sourceDir: path.join(DATA_DIR, "tables"),
        targets: [
            {
                registryOut:   path.join(DIST_BUILTINS, "tables-registry.bundle.json"),
                structuresOut: path.join(DIST_BUILTINS, "tables.bundle.json")
            },
            {
                registryOut:   path.join(SIDECAR_DIR, "tables-registry.bundle.json"),
                structuresOut: path.join(SIDECAR_DIR, "tables.bundle.json")
            }
        ]
    });
    console.log(`[data] tables: ${count} entries -> dist/builtins/{tables-registry,tables}.bundle.json + src/builtins/...`);
}

function copyComposite(name) {
    projectCompositeCopy({
        sourceFile: path.join(DATA_DIR, name),
        outFiles: [
            path.join(DIST_BUILTINS, name),
            path.join(SIDECAR_DIR,   name)
        ]
    });
    console.log(`[data] copy ${name} -> dist/builtins/${name} + src/builtins/${name}`);
}

function copySchemas() {
    const src = path.join(DATA_DIR, "schemas");
    if (!fs.existsSync(src)) {
        console.warn("[data] schemas/ not found, skipping");
        return;
    }
    const { count } = projectSchemasFolder({
        sourceDir: src,
        outDirs:   [path.join(DIST_BUILTINS, "schemas")]
    });
    console.log(`[data] schemas: ${count} files -> dist/builtins/schemas/`);
}

buildArray("functions",        "functions.bundle.json");
buildArray("global-variables", "global-variables.bundle.json");
buildTables();
copyComposite("help-registry.json");
copyComposite("deprecated-symbols.json");
copySchemas();
