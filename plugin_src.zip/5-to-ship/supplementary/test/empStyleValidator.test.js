/**
 * Unit tests for empStyleValidator.
 *
 * Tests the EMP-STY-001 rule: variables prefixed with TEMP_ should use zTmp_ instead.
 */

import { validateEmpStyle } from "../src/validators/empStyleValidator.js";

// ---------------------------------------------------------------------------
// Minimal document stub
// ---------------------------------------------------------------------------

function makeDocument(lines) {
    return {
        lineCount: lines.length,
        lineAt: (i) => ({ text: lines[i] })
    };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("validateEmpStyle — EMP-STY-001", () => {
    test("returns an empty array for a document with no TEMP_ prefixes", () => {
        const doc = makeDocument([
            "sResult = 'OK'",
            "nCount = 0"
        ]);
        expect(validateEmpStyle(doc, {})).toEqual([]);
    });

    test("reports a diagnostic for a line containing TEMP_X", () => {
        const doc = makeDocument(["TEMP_Value = 'bad'"]);
        const result = validateEmpStyle(doc, {});
        expect(result).toHaveLength(1);
        expect(result[0].code).toBe("EMP-STY-001");
        expect(result[0].source).toBe("architect-ext");
        expect(result[0].severity).toBe(1);
    });

    test("diagnostic range covers the matched token", () => {
        const doc = makeDocument(["  TEMP_Value = 0"]);
        const [d] = validateEmpStyle(doc, {});
        expect(d.range.start).toEqual({ line: 0, character: 2 });
        expect(d.range.end).toEqual({ line: 0, character: 2 + "TEMP_V".length });
    });

    test("reports on the correct line number (zero-based)", () => {
        const doc = makeDocument([
            "sOk = 1",
            "TEMP_X = 2",
            "sAlsoOk = 3"
        ]);
        const result = validateEmpStyle(doc, {});
        expect(result).toHaveLength(1);
        expect(result[0].range.start.line).toBe(1);
    });

    test("reports multiple matches on the same line", () => {
        const doc = makeDocument(["TEMP_A = TEMP_B"]);
        const result = validateEmpStyle(doc, {});
        expect(result).toHaveLength(2);
        expect(result[0].range.start.character).toBe(0);
        expect(result[1].range.start.character).toBe(9);
    });

    test("reports matches on multiple lines", () => {
        const doc = makeDocument([
            "TEMP_First = 1",
            "sOk = 2",
            "TEMP_Second = 3"
        ]);
        const result = validateEmpStyle(doc, {});
        expect(result).toHaveLength(2);
        expect(result[0].range.start.line).toBe(0);
        expect(result[1].range.start.line).toBe(2);
    });

    test("is case-sensitive: does not flag temp_ (lowercase)", () => {
        const doc = makeDocument(["temp_value = 1"]);
        expect(validateEmpStyle(doc, {})).toHaveLength(0);
    });

    test("does not flag a variable that starts with zTmp_", () => {
        const doc = makeDocument(["zTmp_Value = 1"]);
        expect(validateEmpStyle(doc, {})).toHaveLength(0);
    });

    test("does not flag a word boundary match inside another word (e.g. ITEMP_X)", () => {
        const doc = makeDocument(["ITEMP_Value = 0"]);
        expect(validateEmpStyle(doc, {})).toHaveLength(0);
    });

    test("diagnostic message contains the rule ID", () => {
        const doc = makeDocument(["TEMP_X = 0"]);
        const [d] = validateEmpStyle(doc, {});
        expect(d.message).toContain("EMP-STY-001");
    });
});
