/**
 * Integration test — supplementary dist bundle is self-contained.
 *
 * Runs `node build.js`, copies the resulting `dist/` tree into an
 * isolated tmp directory (no `src/` reachable), then dynamic-imports the
 * bundled JS and asserts that all five builtin registries load via the
 * dist-tree sidecars. This is the MCP-standalone hand-off path.
 *
 * Source-tree mode is exercised by every other test in this workspace
 * (which import from `src/` directly), so this file only covers the
 * dist-tree branch of the loader fallback.
 */

import { spawnSync } from "child_process";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";
import { fileURLToPath, pathToFileURL } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const DIST = path.join(ROOT, "dist");

function copyDirRecursive(src, dst) {
    fs.mkdirSync(dst, { recursive: true });
    for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
        const s = path.join(src, entry.name);
        const d = path.join(dst, entry.name);
        if (entry.isDirectory()) copyDirRecursive(s, d);
        else                     fs.copyFileSync(s, d);
    }
}

describe("supplementary dist bundle", () => {
    let tmpDir;
    let supplementary;

    beforeAll(async () => {
        // Build the bundle + sidecars.
        const result = spawnSync(process.execPath, [path.join(ROOT, "build.js")], {
            cwd: ROOT,
            stdio: "pipe",
            encoding: "utf8"
        });
        if (result.status !== 0) {
            throw new Error(`build.js failed (status ${result.status}):\n${result.stdout}\n${result.stderr}`);
        }

        // Copy dist/ into an isolated tmp dir with no src/ alongside, so the
        // dist-mode loader path is the only reachable option. Using a tmp
        // sibling of the dist source ensures Node module-graph resolution
        // doesn't accidentally walk back up into src/.
        tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "arch-supp-dist-"));
        copyDirRecursive(DIST, tmpDir);
        // The bundle is ESM but the tmp dir has no package.json; without one,
        // the .js extension is loaded as CommonJS and `import` blows up.
        fs.writeFileSync(
            path.join(tmpDir, "package.json"),
            JSON.stringify({ type: "module" }) + "\n"
        );

        // Sanity: tmpDir is not nested inside ROOT, so loaders in the bundle
        // resolve next-to-self paths (the JSON sidecars) but cannot find a
        // sibling src/builtins-data tree.
        expect(fs.existsSync(path.join(tmpDir, "architect-supplementary.js"))).toBe(true);
        expect(fs.existsSync(path.join(tmpDir, "functions.bundle.json"))).toBe(true);

        const bundleUrl = pathToFileURL(path.join(tmpDir, "architect-supplementary.js")).href;
        supplementary = (await import(bundleUrl)).default;
    });

    afterAll(() => {
        if (tmpDir && fs.existsSync(tmpDir)) {
            fs.rmSync(tmpDir, { recursive: true, force: true });
        }
    });

    test("default export carries the full module shape", () => {
        expect(supplementary).toBeDefined();
        expect(typeof supplementary).toBe("object");
        expect(supplementary.builtins).toBeDefined();
        expect(Array.isArray(supplementary.validators)).toBe(true);
    });

    test("functions registry loaded from bundle sidecar", () => {
        const { functions } = supplementary.builtins;
        expect(typeof functions).toBe("object");
        expect(Object.keys(functions).length).toBeGreaterThan(0);
        // EMP_LOOKUP is the canonical sample entry — present in src/.
        expect(functions.EMP_LOOKUP).toBeDefined();
    });

    test("globalVariables registry loaded from bundle sidecar", () => {
        const { globalVariables } = supplementary.builtins;
        expect(typeof globalVariables).toBe("object");
        expect(Object.keys(globalVariables).length).toBeGreaterThan(0);
        expect(globalVariables.EMP_SITE_CODE).toBeDefined();
    });

    test("tables registry loaded from registry+structures bundles", () => {
        const { tables } = supplementary.builtins;
        expect(typeof tables).toBe("object");
        expect(tables.ZZ).toBeDefined();
        expect(tables.ZZ.entry).toBeDefined();
        expect(tables.ZZ.structure).toBeDefined();
        expect(tables.ZZ.structure.code).toBe("ZZ");
        // Fields preserved verbatim through the bundle round-trip.
        expect(tables.ZZ.structure.fields).toBeDefined();
    });

    test("help registry copied verbatim into dist", () => {
        const { help } = supplementary.builtins;
        expect(typeof help).toBe("object");
        expect(Object.keys(help).length).toBeGreaterThan(0);
    });

    test("deprecatedSymbols copied verbatim into dist", () => {
        const { deprecatedSymbols } = supplementary.builtins;
        expect(typeof deprecatedSymbols).toBe("object");
        expect(Object.keys(deprecatedSymbols).length).toBeGreaterThan(0);
    });
});
