#!/usr/bin/env node
/**
 * Vendor core artefacts into the supplementary tree.
 *
 * Copies four sets of files from `architect-language-tools/` (sibling
 * checkout) into this module so the supplementary build is self-contained:
 *
 *   1. Schema JSONs              → src/builtins-data/schemas/
 *   2. _schemaValidator.js       → src/builtins/_schemaValidator.js
 *   3. _dataLoaders.js           → src/builtins/_dataLoaders.js
 *   4. _dataProjectors.js        → tools/_dataProjectors.js
 *
 * Why vendor: the standalone hand-off model lets a third party rebuild
 * the supplementary VSIX from this tree alone (no core checkout). The
 * runtime helpers must therefore travel with the source. Drift between
 * vendored copies and core is asserted by
 * `architect-language-tools/test/unit/supplementarySchemaSync.test.js`.
 *
 * Run after a core change to any of the above:
 *   cd architect-language-tools-supplementary
 *   npm run sync:core
 */
import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SUP_ROOT  = path.resolve(__dirname, "..");
const CORE_ROOT = path.resolve(SUP_ROOT, "..", "architect-language-tools");

if (!fs.existsSync(CORE_ROOT)) {
    throw new Error(
        `sync:core: sibling architect-language-tools/ not found at ${CORE_ROOT}.\n` +
        `  This script is for in-repo use; recipients of the standalone\n` +
        `  hand-off receive a tree with vendored copies already in place.`
    );
}

function copy(srcRel, dstRel) {
    const src = path.join(CORE_ROOT, srcRel);
    const dst = path.join(SUP_ROOT,  dstRel);
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(src, dst);
    console.log(`  ${srcRel} → ${dstRel}`);
}

console.log("[sync:core] schemas");
const SCHEMA_SRC = path.join(CORE_ROOT, "builtins-data", "schemas");
const SCHEMA_DST = path.join(SUP_ROOT,  "src", "builtins-data", "schemas");
fs.mkdirSync(SCHEMA_DST, { recursive: true });
for (const f of fs.readdirSync(SCHEMA_SRC).filter(x => x.endsWith(".json"))) {
    fs.copyFileSync(path.join(SCHEMA_SRC, f), path.join(SCHEMA_DST, f));
    console.log(`  builtins-data/schemas/${f} → src/builtins-data/schemas/${f}`);
}

console.log("[sync:core] runtime helpers");
copy("core/src/builtins/_schemaValidator.js", "src/builtins/_schemaValidator.js");
copy("core/src/builtins/_dataLoaders.js",     "src/builtins/_dataLoaders.js");

console.log("[sync:core] build helpers");
copy("tools/_dataProjectors.js", "tools/_dataProjectors.js");

console.log("[sync:core] done");
