# Change Log

## 0.3.0

- Supplementary builtins migrated from JS literals to JSON authoring, in shape
  parity with core. Source of truth is now `src/builtins-data/` (per-entry files
  for functions, global variables, and tables; composite files for help and
  deprecated symbols). Loaders under `src/builtins/` parse the JSON and return
  the in-memory shape; runtime validation lives centrally in core's
  `supplementaryLoader.js`.
- Loaders and `build.js` consume vendored copies of core's
  `_dataLoaders.js`, `_schemaValidator.js`, `_dataProjectors.js`, and the
  builtin schemas. The supplementary tree therefore builds standalone in
  the third-party hand-off scenario — no sibling core checkout required.
  `npm run sync:core` resyncs all four vendored sets; the drift test in
  core's suite (`test/unit/supplementarySchemaSync.test.js`) covers them all.

## 0.1.0

- Initial companion-extension packaging. Registers sample employer builtins,
  the EMP-STY-001 validator, and the test-only DEMO-SEV-* catalog entries used
  by the validation-model syntax test suite.
