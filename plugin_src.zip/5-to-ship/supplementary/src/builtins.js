/**
 * Builtins barrel — re-exports from the individual JSON-backed registries.
 *
 * Each registry loader reads from `../src/builtins-data/<dir>/` and returns
 * the in-memory shape that core's supplementaryLoader.js consumes:
 *
 *   functionsRegistry.js        ← functions/<NAME>.json
 *   globalVariablesRegistry.js  ← global-variables/<NAME>.json
 *   tableRegistry.js            ← tables/<CODE>.json (single composite per table)
 *   helpRegistry.js             ← help-registry.json (composite)
 *   deprecatedSymbols.js        ← deprecated-symbols.json (composite)
 */
export { functions }         from "./builtins/functionsRegistry.js";
export { globalVariables }   from "./builtins/globalVariablesRegistry.js";
export { tables }            from "./builtins/tableRegistry.js";
export { help }              from "./builtins/helpRegistry.js";
export { deprecatedSymbols } from "./builtins/deprecatedSymbols.js";
