/**
 * Catalog entries for the test-only DEMO-SEV-* rules.
 *
 * These rules exercise the core validation model from the supplementary layer.
 * Each profile covers a distinct band of the severity matrix:
 *
 *   DEMO-SEV-001  validity         error   / error   / error
 *   DEMO-SEV-002  advisory         off     / warning / warning
 *   DEMO-SEV-003  strict-only      off     / off     / warning
 *   DEMO-SEV-004  unsuppressable   error   / error   / error   (suppressable: false)
 *   DEMO-SEV-005  information tier off     / information / information
 *
 * NOT SHIPPED: kept in the supplementary package so the syntax-test suite can
 * verify mode resolution, overrides, and suppression without shipping throwaway
 * rules in the product catalog.
 */

export const demoSeverityCatalog = {
    "DEMO-SEV-001": {
        ruleId:   "demoSev001",
        message:  "Variable name 'demo_validity' is reserved for the validation-model test suite.",
        paramKeys: [],
        surfaces: ["ide", "cicd"],
        category: "validity",
        severity: { legacy: "error", default: "error", strict: "error" },
        suppressable: true
    },
    "DEMO-SEV-002": {
        ruleId:   "demoSev002",
        message:  "Variable name 'demo_advisory' is reserved for the validation-model test suite.",
        paramKeys: [],
        surfaces: ["ide", "cicd"],
        category: "advisory",
        severity: { legacy: "off", default: "warning", strict: "warning" },
        suppressable: true
    },
    "DEMO-SEV-003": {
        ruleId:   "demoSev003",
        message:  "Variable name 'demo_strict_style' is reserved for the validation-model test suite.",
        paramKeys: [],
        surfaces: ["ide", "cicd"],
        category: "standards",
        severity: { legacy: "off", default: "off", strict: "warning" },
        suppressable: true
    },
    "DEMO-SEV-004": {
        ruleId:   "demoSev004",
        message:  "Variable name 'demo_unsuppressable' is reserved for the validation-model test suite.",
        paramKeys: [],
        surfaces: ["ide", "cicd"],
        category: "validity",
        severity: { legacy: "error", default: "error", strict: "error" },
        suppressable: false
    },
    "DEMO-SEV-005": {
        ruleId:   "demoSev005",
        message:  "Variable name 'demo_hint' is reserved for the validation-model test suite.",
        paramKeys: [],
        surfaces: ["ide", "cicd"],
        category: "advisory",
        severity: { legacy: "off", default: "information", strict: "information" },
        suppressable: true
    }
};
