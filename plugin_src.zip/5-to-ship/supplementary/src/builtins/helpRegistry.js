/**
 * Supplementary help entries — composite-file JSON loader.
 *
 * Thin wrapper over the vendored `loadCompositeFile` helper (a copy of
 * core's `_dataLoaders.js`, kept in lockstep via `tools/sync-from-core.js`).
 * The helper handles source-first / dist-fallback resolution, `$schema`
 * stripping, and fail-loud diagnostics uniformly with core's own registries.
 *
 * Schema validation runs centrally in core's `supplementaryLoader.js` at
 * registration time — the helper is invoked without a schema arg.
 */
import * as path from "path";
import { fileURLToPath } from "url";
import { loadCompositeFile, preferSubfolder } from "./_dataLoaders.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const help = loadCompositeFile({
    sourceFile: path.resolve(__dirname, "..", "builtins-data", "help-registry.json"),
    distFile:   preferSubfolder(__dirname, "help-registry.json"),
    label:      "supplementary help registry"
});
