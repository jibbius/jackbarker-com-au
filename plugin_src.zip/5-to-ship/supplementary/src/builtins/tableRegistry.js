/**
 * Supplementary table registrations — JSON loader.
 *
 * Thin wrapper over the vendored `loadTableBundles` helper (a copy of
 * core's `_dataLoaders.js`, kept in lockstep via `tools/sync-from-core.js`).
 * The helper handles source-first / dist-fallback resolution (per-file
 * walk in source mode, paired registry+structures bundle in dist mode),
 * `$schema` stripping, and fail-loud diagnostics uniformly with core's
 * own table registry. This module just supplies paths and reshapes the
 * parsed structures into the `{ [code]: { entry, structure } }` map that
 * core's `supplementaryLoader.js` expects.
 *
 * Schema validation runs centrally in core's `supplementaryLoader.js` at
 * registration time — the helper is invoked without a schema arg.
 */
import * as path from "path";
import { fileURLToPath } from "url";
import { loadTableBundles, preferSubfolder } from "./_dataLoaders.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const structures = loadTableBundles({
    sourceDir:            path.resolve(__dirname, "..", "builtins-data", "tables"),
    registryBundleFile:   preferSubfolder(__dirname, "tables-registry.bundle.json"),
    structuresBundleFile: preferSubfolder(__dirname, "tables.bundle.json"),
    label:                "supplementary tables registry"
});

export const tables = Object.fromEntries(
    structures.map(s => [
        s.code,
        {
            entry:     { name: s.name },
            structure: {
                code:         s.code,
                name:         s.name,
                recordLength: s.recordLength,
                helpPage:     s.helpPage,
                indexes:      s.indexes,
                fields:       s.fields
            }
        }
    ])
);
