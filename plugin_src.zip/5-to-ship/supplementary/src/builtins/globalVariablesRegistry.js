/**
 * Supplementary global variable entries — JSON loader.
 *
 * Thin wrapper over the vendored `loadArrayBundle` helper (a copy of
 * core's `_dataLoaders.js`, kept in lockstep via `tools/sync-from-core.js`).
 * The helper handles source-first / dist-fallback resolution, `$schema`
 * stripping, and fail-loud diagnostics uniformly with core's own
 * registries; this module just supplies paths and reshapes the result
 * into the `{ [name]: { ...rest } }` map that core's
 * `supplementaryLoader.js` expects.
 *
 * Schema validation runs centrally in core's `supplementaryLoader.js` at
 * registration time — the helper is invoked without a schema arg.
 */
import * as path from "path";
import { fileURLToPath } from "url";
import { loadArrayBundle, preferSubfolder } from "./_dataLoaders.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const entries = loadArrayBundle({
    sourceDir:  path.resolve(__dirname, "..", "builtins-data", "global-variables"),
    bundleFile: preferSubfolder(__dirname, "global-variables.bundle.json"),
    label:      "supplementary globalVariables registry"
});

export const globalVariables = Object.fromEntries(
    entries.map(({ name, ...rest }) => [name, rest])
);
