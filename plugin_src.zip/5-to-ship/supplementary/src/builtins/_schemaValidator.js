/**
 * Hand-rolled JSON Schema (draft 2020-12) validator.
 *
 * Covers only the features the builtins-data schemas use. Keep it small;
 * extend deliberately when a new schema needs a feature.
 *
 * Supported keywords:
 *   type (string | array of strings)         — object, string, array, number,
 *                                                integer, boolean, null
 *   properties, required, additionalProperties
 *   enum
 *   const
 *   items (single sub-schema), minItems, maxItems
 *   pattern (regex against strings)
 *   minLength, maxLength
 *   minimum, maximum
 *   oneOf, anyOf, allOf
 *   $ref (to local "#/$defs/<name>" only)
 *
 * Errors are objects { path, message } where `path` is a JSON Pointer-ish
 * string into the validated value (e.g. "/properties/type"). The throwing
 * wrapper composes these with the file location for loud diagnostics.
 */

function isPlainObject(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}

function typeMatches(value, type) {
    switch (type) {
        case "object":  return isPlainObject(value);
        case "array":   return Array.isArray(value);
        case "string":  return typeof value === "string";
        case "number":  return typeof value === "number" && Number.isFinite(value);
        case "integer": return typeof value === "number" && Number.isInteger(value);
        case "boolean": return typeof value === "boolean";
        case "null":    return value === null;
        default:        return false;
    }
}

function resolveRef(ref, root) {
    if (typeof ref !== "string" || !ref.startsWith("#/")) {
        throw new Error(`Unsupported $ref: ${ref} (only same-file '#/$defs/...' refs supported)`);
    }
    const parts = ref.slice(2).split("/");
    let node = root;
    for (const p of parts) {
        if (node == null || typeof node !== "object" || !(p in node)) {
            throw new Error(`Unresolvable $ref: ${ref}`);
        }
        node = node[p];
    }
    return node;
}

function validateNode(value, schema, root, path, errors) {
    if (schema == null) return;

    if (schema.$ref) {
        validateNode(value, resolveRef(schema.$ref, root), root, path, errors);
        return;
    }

    if (schema.type !== undefined) {
        const types = Array.isArray(schema.type) ? schema.type : [schema.type];
        if (!types.some(t => typeMatches(value, t))) {
            errors.push({ path, message: `expected type ${types.join("|")}, got ${Array.isArray(value) ? "array" : value === null ? "null" : typeof value}` });
            return;
        }
    }

    if (schema.enum !== undefined) {
        if (!schema.enum.some(allowed => allowed === value)) {
            errors.push({ path, message: `value ${JSON.stringify(value)} not in enum [${schema.enum.map(v => JSON.stringify(v)).join(", ")}]` });
        }
    }

    if (schema.const !== undefined) {
        if (value !== schema.const) {
            errors.push({ path, message: `value ${JSON.stringify(value)} does not equal const ${JSON.stringify(schema.const)}` });
        }
    }

    if (typeof value === "string") {
        if (schema.minLength !== undefined && value.length < schema.minLength) {
            errors.push({ path, message: `string length ${value.length} < minLength ${schema.minLength}` });
        }
        if (schema.maxLength !== undefined && value.length > schema.maxLength) {
            errors.push({ path, message: `string length ${value.length} > maxLength ${schema.maxLength}` });
        }
        if (schema.pattern !== undefined) {
            const re = new RegExp(schema.pattern);
            if (!re.test(value)) {
                errors.push({ path, message: `string does not match pattern /${schema.pattern}/` });
            }
        }
    }

    if (typeof value === "number") {
        if (schema.minimum !== undefined && value < schema.minimum) {
            errors.push({ path, message: `value ${value} < minimum ${schema.minimum}` });
        }
        if (schema.maximum !== undefined && value > schema.maximum) {
            errors.push({ path, message: `value ${value} > maximum ${schema.maximum}` });
        }
    }

    if (Array.isArray(value)) {
        if (schema.minItems !== undefined && value.length < schema.minItems) {
            errors.push({ path, message: `array length ${value.length} < minItems ${schema.minItems}` });
        }
        if (schema.maxItems !== undefined && value.length > schema.maxItems) {
            errors.push({ path, message: `array length ${value.length} > maxItems ${schema.maxItems}` });
        }
        if (schema.items !== undefined) {
            value.forEach((item, i) => {
                validateNode(item, schema.items, root, `${path}/${i}`, errors);
            });
        }
    }

    if (isPlainObject(value)) {
        const props = schema.properties || {};
        const required = schema.required || [];
        for (const key of required) {
            if (!Object.prototype.hasOwnProperty.call(value, key)) {
                errors.push({ path, message: `missing required property "${key}"` });
            }
        }
        for (const [key, sub] of Object.entries(value)) {
            if (key === "$schema") continue;
            if (props[key] !== undefined) {
                validateNode(sub, props[key], root, `${path}/${key}`, errors);
            } else if (schema.additionalProperties === false) {
                errors.push({ path: `${path}/${key}`, message: `additional property "${key}" not allowed` });
            } else if (isPlainObject(schema.additionalProperties)) {
                validateNode(sub, schema.additionalProperties, root, `${path}/${key}`, errors);
            }
        }
    }

    for (const combinator of ["allOf", "anyOf", "oneOf"]) {
        if (!Array.isArray(schema[combinator])) continue;
        const branchErrors = schema[combinator].map(branch => {
            const branchErr = [];
            validateNode(value, branch, root, path, branchErr);
            return branchErr;
        });
        const passing = branchErrors.filter(e => e.length === 0).length;
        if (combinator === "allOf" && passing !== schema.allOf.length) {
            const failed = branchErrors.find(e => e.length > 0);
            errors.push({ path, message: `allOf branch failed: ${failed[0].message}` });
        }
        if (combinator === "anyOf" && passing === 0) {
            errors.push({ path, message: `anyOf: no branch matched` });
        }
        if (combinator === "oneOf" && passing !== 1) {
            errors.push({ path, message: `oneOf: expected exactly 1 matching branch, got ${passing}` });
        }
    }
}

/**
 * Validate `value` against `schema`. Returns `[]` on success, otherwise an
 * array of `{ path, message }` errors.
 *
 * @param {unknown} value
 * @param {object} schema
 * @returns {Array<{ path: string, message: string }>}
 */
function validate(value, schema) {
    const errors = [];
    validateNode(value, schema, schema, "", errors);
    return errors;
}

/**
 * Validate or throw. The thrown Error message is prefixed with `location` so
 * the offending file is obvious.
 *
 * @param {unknown} value
 * @param {object} schema
 * @param {string} location  - e.g. "global-variables/CURRENT_DATE.json"
 */
function validateOrThrow(value, schema, location) {
    const errors = validate(value, schema);
    if (errors.length === 0) return;
    const lines = errors.map(e => `  ${e.path || "/"}: ${e.message}`).join("\n");
    throw new Error(`${location}: schema validation failed:\n${lines}`);
}

export { validate, validateOrThrow };
