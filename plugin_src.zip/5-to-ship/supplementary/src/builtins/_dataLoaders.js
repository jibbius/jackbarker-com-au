/**
 * Shared loader primitives for the builtins registries.
 *
 * Both `core/src/builtins/` and `architect-language-tools-supplementary/`
 * follow the same source-first / dist-sidecar resolution shape: read JSON
 * authoring data from a per-entry directory when present, otherwise fall
 * back to a pre-built bundle. This module factors that shape out so each
 * registry only supplies paths and consumes the parsed result.
 *
 * Exposes four primitives:
 *
 *   resolveDataFile     — pick source-first vs fallback for a single file
 *   loadArrayBundle     — per-file dir OR array bundle → array of entries
 *   loadCompositeFile   — single-object composite → parsed object
 *   loadTableBundles    — dual-bundle (registry + structures) → structures
 *
 * Internal — exported only for use by registry modules in core/ and
 * supplementary/. Not a public API; the underscore prefix mirrors
 * `_schemaValidator.js`.
 *
 * Behaviour shared by every primitive:
 *   - `$schema` keys are stripped from parsed entries / objects.
 *   - When a `schema` arg is supplied, every parsed entry is validated
 *     via `_schemaValidator.validateOrThrow` — so dist-mode loads now
 *     fail loud on schema drift, matching source-mode.
 *   - When no probe location is reachable, throw with all candidate
 *     paths cited.
 */

import * as fs from "fs";
import * as path from "path";
import { validateOrThrow } from "./_schemaValidator.js";

/**
 * Resolve a sidecar/schema path with a `subdir/` preference.
 *
 * When the bundled JS runs from a deployment that opted to keep its
 * runtime data files in a subdirectory (e.g. `mcp/dist/builtins/...`
 * for the standalone MCP bundle, to declutter the deploy root), the
 * caller still resolves paths via `__dirname/<filename>` — the bundle
 * was authored against that shape. This helper checks for the
 * subfolder layout first and falls back to the flat layout when the
 * subfolder isn't present (VSIX install, source-mode dev tree).
 *
 * In the VSIX case `__dirname` is `core/src/builtins/` and the
 * subfolder doesn't exist, so this is a single existsSync probe with
 * no behavioural change. In the standalone bundle case `__dirname` is
 * `mcp/dist/` and the subfolder is populated by the standalone build.
 *
 * @param {string} dirname  - The base directory (typically `__dirname`).
 * @param {string} filename - Path relative to `dirname` (may contain "/").
 * @param {string} [subdir] - Subfolder to prefer; defaults to "builtins".
 * @returns {string} Absolute path to use.
 */
export function preferSubfolder(dirname, filename, subdir = "builtins") {
    const sub = path.resolve(dirname, subdir, filename);
    if (fs.existsSync(sub)) return sub;
    return path.resolve(dirname, filename);
}

function _stripSchema(obj) {
    const { $schema: _ignored, ...rest } = obj;
    return rest;
}

function _readDirEntries({ sourceDir, stemField, label, schema }) {
    const files = fs.readdirSync(sourceDir).filter(f => f.endsWith(".json")).sort();
    const out = [];
    for (const f of files) {
        const full = path.join(sourceDir, f);
        const raw  = JSON.parse(fs.readFileSync(full, "utf8"));
        const entry = _stripSchema(raw);
        const stem  = f.slice(0, -".json".length);
        if (entry[stemField] !== stem) {
            throw new Error(
                `${full}: "${stemField}" (${entry[stemField]}) does not match file stem (${stem})`
            );
        }
        if (schema) validateOrThrow(entry, schema, `${label}/${stem}.json`);
        out.push(entry);
    }
    return out;
}

function _readArrayBundle({ bundleFile, schema, stemField, label }) {
    const raw = JSON.parse(fs.readFileSync(bundleFile, "utf8"));
    if (!Array.isArray(raw)) {
        throw new Error(`${bundleFile}: expected an array of entries`);
    }
    const out = [];
    for (const r of raw) {
        const entry = _stripSchema(r);
        if (schema) {
            const stem = entry[stemField] ?? "<unknown>";
            validateOrThrow(entry, schema, `${label}/${stem}.json`);
        }
        out.push(entry);
    }
    return out;
}

/**
 * Resolve a single composite-file source: source-first, then fallback.
 *
 * @param {{sourceFile:string, fallbackFile:string, label:string}} opts
 * @returns {string} The path to use.
 */
export function resolveDataFile({ sourceFile, fallbackFile, label }) {
    if (fs.existsSync(sourceFile))   return sourceFile;
    if (fs.existsSync(fallbackFile)) return fallbackFile;
    throw new Error(
        `${label}: data file not found.\n` +
        `  source:   ${sourceFile}\n` +
        `  fallback: ${fallbackFile}`
    );
}

/**
 * Walk a per-file source directory OR fall back to a single array bundle.
 *
 * Returns an array of parsed entries with `$schema` stripped. In source-mode
 * the file stem is checked against `entry[stemField]` (default "name") — a
 * mismatch throws. When `schema` is supplied, every entry is validated.
 *
 * @param {{
 *   sourceDir:  string,
 *   bundleFile: string,
 *   schema?:    object|null,
 *   label:      string,
 *   stemField?: string
 * }} opts
 * @returns {Array<object>}
 */
export function loadArrayBundle({
    sourceDir, bundleFile, schema = null, label, stemField = "name"
}) {
    if (fs.existsSync(sourceDir))  return _readDirEntries({ sourceDir, stemField, label, schema });
    if (fs.existsSync(bundleFile)) return _readArrayBundle({ bundleFile, schema, stemField, label });
    throw new Error(
        `${label}: neither source directory nor bundle found.\n` +
        `  source: ${sourceDir}\n` +
        `  bundle: ${bundleFile}`
    );
}

/**
 * Load a composite-file registry (one JSON object). Returns the parsed object
 * with `$schema` stripped. When `schema` is supplied, the whole object is
 * validated.
 *
 * @param {{
 *   sourceFile: string,
 *   distFile:   string,
 *   schema?:    object|null,
 *   label:      string
 * }} opts
 * @returns {object}
 */
export function loadCompositeFile({ sourceFile, distFile, schema = null, label }) {
    const file = resolveDataFile({ sourceFile, fallbackFile: distFile, label });
    const raw  = JSON.parse(fs.readFileSync(file, "utf8"));
    if (schema) validateOrThrow(raw, schema, path.basename(file));
    return _stripSchema(raw);
}

/**
 * Load the table dual-bundle.
 *
 * Source mode walks `sourceDir/<CODE>.json` (stem-checked against `code`).
 * Dist mode reads `registryBundleFile` (the lightweight `{code → name}`
 * projection) AND `structuresBundleFile` (array of full structures); each
 * structure's `code` is cross-checked against the registry projection.
 *
 * Returns an array of structure objects with `$schema` stripped. The caller
 * decides what to retain — supplementary keeps the full structure, core
 * projects to `{name}` for the registry and caches the rest lazily.
 *
 * @param {{
 *   sourceDir:            string,
 *   registryBundleFile:   string,
 *   structuresBundleFile: string,
 *   schema?:              object|null,
 *   label:                string
 * }} opts
 * @returns {Array<object>}
 */
export function loadTableBundles({
    sourceDir, registryBundleFile, structuresBundleFile, schema = null, label
}) {
    if (fs.existsSync(sourceDir)) {
        return _readDirEntries({ sourceDir, stemField: "code", label, schema });
    }
    if (!fs.existsSync(registryBundleFile)) {
        throw new Error(
            `${label}: neither source directory nor registry bundle found.\n` +
            `  source:   ${sourceDir}\n` +
            `  registry: ${registryBundleFile}`
        );
    }
    if (!fs.existsSync(structuresBundleFile)) {
        throw new Error(
            `${label}: registry bundle present but structures bundle missing.\n` +
            `  registry:   ${registryBundleFile}\n` +
            `  structures: ${structuresBundleFile}`
        );
    }
    const registryMap = JSON.parse(fs.readFileSync(registryBundleFile, "utf8"));
    const structures  = JSON.parse(fs.readFileSync(structuresBundleFile, "utf8"));
    if (!Array.isArray(structures)) {
        throw new Error(`${structuresBundleFile}: expected an array of structure objects`);
    }
    const out = [];
    for (const r of structures) {
        const entry = _stripSchema(r);
        if (!Object.prototype.hasOwnProperty.call(registryMap, entry.code)) {
            throw new Error(
                `${path.basename(structuresBundleFile)}: code "${entry.code}" not present in registry projection`
            );
        }
        if (schema) validateOrThrow(entry, schema, `${label}/${entry.code}.json`);
        out.push(entry);
    }
    return out;
}
