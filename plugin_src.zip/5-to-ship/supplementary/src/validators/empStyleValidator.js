/**
 * empStyleValidator — sample employer coding-standards validator.
 *
 * Enforces one fictional employer rule: report files must not use `TEMP_` as a
 * variable name prefix. Employer convention requires `zTmp_` instead.
 *
 * Rule ID : EMP-STY-001
 * Source  : architect-ext
 * Severity: Warning (1)
 */

const TEMP_PREFIX_RE = /\bTEMP_[A-Za-z]/g;

/**
 * @param {object} document  VS Code TextDocument or PlainTextDocument
 * @param {object} _context  { facts, filePath, config }
 * @returns {object[]}
 */
export function validateEmpStyle(document, _context) {
    const diagnostics = [];
    const lineCount = document.lineCount;

    for (let i = 0; i < lineCount; i++) {
        const text = document.lineAt(i).text;
        TEMP_PREFIX_RE.lastIndex = 0;
        let match;
        while ((match = TEMP_PREFIX_RE.exec(text)) !== null) {
            const col = match.index;
            diagnostics.push({
                range: {
                    start: { line: i, character: col },
                    end:   { line: i, character: col + match[0].length }
                },
                message: "Use 'zTmp_' prefix instead of 'TEMP_' (employer coding standard EMP-STY-001).",
                severity: 1,
                code:     "EMP-STY-001",
                source:   "architect-ext"
            });
        }
    }

    return diagnostics;
}
