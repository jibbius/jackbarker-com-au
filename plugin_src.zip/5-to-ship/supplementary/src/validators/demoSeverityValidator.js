/**
 * demoSeverityValidator — test-only validator for exercising the core validation model.
 *
 * Flags variable names reserved for validation-model syntax tests. Each trigger maps
 * to a dedicated DEMO-SEV-NNN rule so a single test fixture can cover validity,
 * advisory, strict-only-style, unsuppressable, and information-tier severities.
 *
 * Rules are registered via the supplementary module's `catalogEntries` field and
 * emitted via context.createDiagnostic — severity is resolved through the full
 * catalog/profile/override pipeline rather than hardcoded at emit time.
 *
 * The factory is injected via context rather than imported directly so this module
 * has no compile-time dependency on core's on-disk layout — essential for running
 * inside an installed companion VSIX where core lives in a different extensions path.
 *
 * NOT SHIPPED: these rules exist only to give the syntax-test suite trivial demo
 * validators it can exercise the validation model against. They must not leak into
 * the product catalog.
 */

const TRIGGERS = [
    { name: "demo_validity",         messageId: "DEMO-SEV-001" },
    { name: "demo_advisory",         messageId: "DEMO-SEV-002" },
    { name: "demo_strict_style",     messageId: "DEMO-SEV-003" },
    { name: "demo_unsuppressable",   messageId: "DEMO-SEV-004" },
    { name: "demo_hint",             messageId: "DEMO-SEV-005" }
];

const WORD_BOUNDARY_RE = /[A-Za-z0-9_]/;

/**
 * @param {object} document  VS Code TextDocument or PlainTextDocument
 * @param {object} context   { facts, filePath, config, getRuleSeverity, createDiagnostic }
 * @returns {object[]}
 */
export function validateDemoSeverity(document, context) {
    const diagnostics = [];
    const { createDiagnostic } = context;
    if (typeof createDiagnostic !== "function") return diagnostics;

    const lineCount = document.lineCount;
    for (let lineIndex = 0; lineIndex < lineCount; lineIndex++) {
        const text = document.lineAt(lineIndex).text;
        for (const trigger of TRIGGERS) {
            let from = 0;
            while (true) {
                const idx = text.indexOf(trigger.name, from);
                if (idx === -1) break;
                const before = idx === 0 ? "" : text[idx - 1];
                const after  = text[idx + trigger.name.length] ?? "";
                const isWord = WORD_BOUNDARY_RE.test(before) || WORD_BOUNDARY_RE.test(after);
                if (!isWord) {
                    const range = {
                        start: { line: lineIndex, character: idx },
                        end:   { line: lineIndex, character: idx + trigger.name.length }
                    };
                    const diag = createDiagnostic(range, { messageId: trigger.messageId });
                    if (diag) diagnostics.push(diag);
                }
                from = idx + trigger.name.length;
            }
        }
    }

    return diagnostics;
}
