module.exports = {
    transform: {},
    testEnvironment: 'node',
    testMatch: ['**/test/**/*.test.js'],
    verbose: true,
    testTimeout: 5000
};
