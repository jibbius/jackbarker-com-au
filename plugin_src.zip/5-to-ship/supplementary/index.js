/**
 * architect-language-tools-supplementary — reference supplementary module.
 *
 * This is the entry point imported by the Architect Language Tools loader.
 * The default export must conform to the supplementary module contract:
 *
 *   {
 *     validators?: SupplementaryValidator[],
 *     builtins?: {
 *       functions?:       { [UPPER_NAME]: FunctionEntry },
 *       globalVariables?: { [UPPER_NAME]: GlobalVariableEntry },
 *       tables?:          { [TWO_CHAR_CODE]: { entry, structure } },
 *       help?:            { [UPPER_TOKEN]: string }
 *     }
 *   }
 *
 * VS Code companion extension (CJS):
 *   const core = vscode.extensions.getExtension('jibbius.arch-lang-tools').exports;
 *   core.registerSupplementary(require('./supplementary'));
 *
 * CLI (.architect.json):
 *   { "supplementaryModule": "../architect-language-tools-supplementary/index.js" }
 */

import { functions, globalVariables, tables, help, deprecatedSymbols } from "./src/builtins.js";
import { validateEmpStyle } from "./src/validators/empStyleValidator.js";
import { validateDemoSeverity } from "./src/validators/demoSeverityValidator.js";
import { demoSeverityCatalog } from "./src/catalog/demoSeverityCatalog.js";

export default {
    catalogEntries: demoSeverityCatalog,
    // Layer-2 baseline override: exercise the resolution chain end-to-end so
    // integration tests can confirm a supplementary-supplied severity reaches
    // collectDiagnostics. ACU-TODO-001 is a stable, low-noise core rule.
    severityOverrides: { "ACU-TODO-001": "off" },
    validators:     [ validateEmpStyle, validateDemoSeverity ],
    builtins:       { functions, globalVariables, tables, help, deprecatedSymbols }
};
