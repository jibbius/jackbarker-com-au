"""
Minimal MCP-aware agent loop.

Spawns the Architect MCP standalone bundle as a child process, advertises
its tools to GitHub Models (gpt-4o-mini by default) via the OpenAI SDK, and
runs the canonical tool-calling loop until the model produces a final
answer. Verbose by default — every provider call, every tool dispatch, and
every result is printed so the mechanics are visible.

Reference Python host. Single default provider for low hand-off friction
(one free API key from one vendor); the `providers/` seam is preserved
so adding another LLM (Azure OpenAI, Anthropic, etc.) is a ~30-line
addition.

Usage:
    python agent.py --workspace path/to/Reports --question "..."
"""

import argparse
import asyncio
import datetime as _dt
import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from providers import azure_provider, github_provider

PROVIDERS = {"github": github_provider, "azure": azure_provider}


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_LOG_DIR = SCRIPT_DIR / "logs"
MAX_TURNS = 10


def _find_default_bundle():
    matches = sorted(SCRIPT_DIR.glob("*standalone.js"))
    return matches[0] if matches else None


def parse_args():
    p = argparse.ArgumentParser(description="Architect MCP — Python host (reference)")
    p.add_argument("--provider", default="github", choices=sorted(PROVIDERS), help="LLM provider (default: github)")
    p.add_argument("--model", default=None, help="Override the provider's default model / deployment name")
    p.add_argument("--workspace", required=True, help="ARCH_LANG_ROOT for the MCP server")
    p.add_argument("--bundle", default=None, help="Path to architect-mcp-standalone.js (defaults to an adjacent *standalone.js file)")
    p.add_argument("--question", required=True, help="The user prompt")
    p.add_argument("--system", default=None, help="Optional system prompt override")
    p.add_argument(
        "--log",
        nargs="?",
        const="__auto__",
        default=None,
        metavar="PATH",
        help=(
            "Write a JSONL transcript of every provider call and tool dispatch. "
            "With no argument, writes to ./logs/run-YYYYMMDD-HHMMSS.jsonl. "
            "With a path, writes to that file."
        ),
    )
    return p.parse_args()


class JsonlLogger:
    """
    Append-only JSONL writer. One event per line; safe to tail with `jq`.
    Disabled when `path is None`. Records every provider request/response and
    every MCP tool dispatch in full — no truncation, unlike the console
    output. API keys never reach this layer (they live in the SDK clients),
    so the log is safe to share for diagnostics.
    """

    def __init__(self, path):
        self.path = path
        self._fh = None
        if path is not None:
            path.parent.mkdir(parents=True, exist_ok=True)
            self._fh = path.open("a", encoding="utf-8")

    def write(self, kind, **data):
        if self._fh is None:
            return
        record = {
            "ts": _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="milliseconds"),
            "kind": kind,
            **data,
        }
        self._fh.write(json.dumps(record, default=str) + "\n")
        self._fh.flush()

    def close(self):
        if self._fh is not None:
            self._fh.close()
            self._fh = None


def resolve_log_path(arg):
    if arg is None:
        return None
    if arg == "__auto__":
        stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        return DEFAULT_LOG_DIR / f"run-{stamp}.jsonl"
    return Path(arg).resolve()


def default_system_prompt():
    return (
        "You are a helpful assistant for the Architect scripting language. "
        "You have access to tools that introspect a workspace of Architect "
        "source files. Prefer calling tools over guessing. When you have "
        "enough information, give a concise answer that cites file paths "
        "and line numbers from the tool results."
    )


def banner(line):
    print(f"\n=== {line} ===", flush=True)


async def run_agent(args, logger):
    provider = PROVIDERS[args.provider]
    model = args.model or provider.DEFAULT_MODEL
    if not model:
        sys.exit(f"no model set — pass --model or set the provider's default (e.g. AZURE_OPENAI_DEPLOYMENT for azure)")

    server_params = StdioServerParameters(
        command="node",
        args=[args.bundle],
        env={**os.environ, "ARCH_LANG_ROOT": args.workspace},
    )

    banner(f"spawning MCP server: {args.bundle}")
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            tools_resp = await session.list_tools()
            mcp_tools = [
                {"name": t.name, "description": t.description or "", "inputSchema": t.inputSchema}
                for t in tools_resp.tools
            ]
            banner(f"{len(mcp_tools)} tools advertised: " + ", ".join(t["name"] for t in mcp_tools))

            provider_tools = provider.translate_tools(mcp_tools)
            system_prompt = args.system or default_system_prompt()
            messages = [{"role": "user", "content": args.question}]

            logger.write(
                "session_start",
                provider=args.provider,
                model=model,
                workspace=args.workspace,
                bundle=args.bundle,
                question=args.question,
                system_prompt=system_prompt,
                mcp_tools=mcp_tools,
                provider_tools=provider_tools,
            )

            for turn in range(1, MAX_TURNS + 1):
                banner(f"turn {turn} — calling {args.provider} model {model}")

                logger.write(
                    "provider_request",
                    turn=turn,
                    messages=messages,
                )
                step = provider.chat(messages, provider_tools, model=model, system=system_prompt)
                logger.write(
                    "provider_response",
                    turn=turn,
                    text=step["text"],
                    tool_calls=[{"id": tc.id, "name": tc.name, "arguments": tc.arguments} for tc in step["tool_calls"]],
                    raw=step["raw"],
                )

                if step["text"]:
                    print(f"[assistant text]\n{step['text']}\n", flush=True)

                if not step["tool_calls"]:
                    banner("done — no further tool calls requested")
                    logger.write("session_end", reason="done", turns=turn, final_text=step["text"])
                    return

                # Dispatch each tool_use to the MCP server.
                results = []
                for tc in step["tool_calls"]:
                    print(f"[tool_use] {tc.name}({json.dumps(tc.arguments)})", flush=True)
                    logger.write("mcp_tool_call", turn=turn, tool=tc.name, arguments=tc.arguments, tool_use_id=tc.id)
                    try:
                        mcp_result = await session.call_tool(tc.name, tc.arguments)
                        # CallToolResult.content is a list of content blocks; we
                        # join the text parts. is_error rides on the result envelope.
                        text = "".join(
                            getattr(c, "text", "") for c in (mcp_result.content or [])
                        ) or "(no content)"
                        is_error = bool(mcp_result.isError)
                        print(f"[tool_result] {text[:400]}{' ...[truncated]' if len(text) > 400 else ''}\n", flush=True)
                        logger.write(
                            "mcp_tool_result",
                            turn=turn,
                            tool=tc.name,
                            tool_use_id=tc.id,
                            content=text,
                            is_error=is_error,
                        )
                        results.append({
                            "tool_use_id": tc.id,
                            "content": text,
                            "is_error": is_error,
                        })
                    except Exception as exc:
                        msg = f"tool dispatch failed: {exc}"
                        print(f"[tool_result ERROR] {msg}\n", flush=True)
                        logger.write(
                            "mcp_tool_result",
                            turn=turn,
                            tool=tc.name,
                            tool_use_id=tc.id,
                            content=msg,
                            is_error=True,
                            dispatch_error=True,
                        )
                        results.append({"tool_use_id": tc.id, "content": msg, "is_error": True})

                provider.append_tool_results(messages, step["raw"], results)

            banner(f"hit MAX_TURNS={MAX_TURNS} without a final answer — bailing")
            logger.write("session_end", reason="max_turns", turns=MAX_TURNS)


def main():
    load_dotenv(Path(__file__).parent / ".env")
    args = parse_args()
    if args.bundle is None:
        bundle = _find_default_bundle()
        if bundle is None:
            sys.exit(f"no *standalone.js found next to agent.py ({SCRIPT_DIR}); pass --bundle explicitly")
        args.bundle = str(bundle)
    elif not Path(args.bundle).exists():
        sys.exit(f"bundle not found: {args.bundle}")
    if not Path(args.workspace).exists():
        sys.exit(f"workspace not found: {args.workspace}")

    log_path = resolve_log_path(args.log)
    logger = JsonlLogger(log_path)
    if log_path:
        banner(f"logging to {log_path}")
    try:
        asyncio.run(run_agent(args, logger))
    finally:
        logger.close()


if __name__ == "__main__":
    main()
