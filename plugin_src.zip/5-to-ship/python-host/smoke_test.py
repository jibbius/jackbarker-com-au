"""
Smoke test for the Architect MCP Python host.

Spawns the standalone MCP bundle as a child process, performs an MCP
handshake, asserts the server advertises a non-empty tool list, and
exits clean. No LLM calls — no credentials required.

Catches:
  - standalone bundle failed to build / fails to start
  - Python MCP SDK contract drift (initialize / tools/list)
  - requirements.txt drift (missing `mcp` package)

Designed to be run from the packaging orchestrator after the bundle
has been built and the host source has been staged.

Exit codes:
  0  — handshake succeeded and tools/list returned at least one tool
  1  — anything else (full traceback to stderr)

Usage:
    python smoke_test.py [--bundle PATH] [--workspace PATH]
"""

import argparse
import asyncio
import sys
import tempfile
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


SCRIPT_DIR = Path(__file__).resolve().parent


def _find_default_bundle():
    # Adjacent staged copy first (orchestrator-staged), then sibling MCP build.
    adjacent = sorted(SCRIPT_DIR.glob("*standalone.js"))
    if adjacent:
        return adjacent[0]
    sibling = SCRIPT_DIR.parent / "architect-language-tools" / "mcp" / "dist" / "architect-mcp-standalone.js"
    return sibling if sibling.exists() else None


async def _run(bundle: Path, workspace: Path) -> int:
    params = StdioServerParameters(
        command="node",
        args=[str(bundle)],
        env={"ARCH_LANG_ROOT": str(workspace)},
    )
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.list_tools()
            tool_names = [t.name for t in result.tools]
            if not tool_names:
                print("FAIL: tools/list returned an empty list", file=sys.stderr)
                return 1
            print(f"OK: {len(tool_names)} tools advertised: {', '.join(tool_names[:5])}"
                  + (", ..." if len(tool_names) > 5 else ""))
            return 0


def main() -> int:
    p = argparse.ArgumentParser(description="Architect MCP host smoke test")
    p.add_argument("--bundle", default=None, help="Path to architect-mcp-standalone.js")
    p.add_argument("--workspace", default=None, help="ARCH_LANG_ROOT (defaults to a temp dir)")
    args = p.parse_args()

    bundle = Path(args.bundle) if args.bundle else _find_default_bundle()
    if bundle is None or not bundle.exists():
        print(f"FAIL: standalone bundle not found ({bundle})", file=sys.stderr)
        return 1

    if args.workspace:
        workspace = Path(args.workspace).resolve()
        return asyncio.run(_run(bundle, workspace))

    with tempfile.TemporaryDirectory(prefix="arch-mcp-smoke-") as tmp:
        return asyncio.run(_run(bundle, Path(tmp)))


if __name__ == "__main__":
    sys.exit(main())
