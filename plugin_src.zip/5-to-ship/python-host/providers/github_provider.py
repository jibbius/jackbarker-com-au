"""
GitHub Models provider — Microsoft-aligned alternative.

Uses the OpenAI Python SDK pointed at the GitHub Models inference endpoint
(https://models.inference.ai.azure.com), authenticated with a GitHub PAT.
Wire format is OpenAI-compatible Chat Completions, which is the same shape
Azure OpenAI uses — so the migration story to a real Azure OpenAI deployment
later is essentially "change endpoint + credential".

Tool format: OpenAI shape — { type: "function", function: { name, description, parameters } }.
Tool results: appended to `messages` as one `tool` role message per call.
"""

import json
import os

from openai import OpenAI

from . import ToolCall


_client = None


def _get_client():
    global _client
    if _client is None:
        token = os.environ.get("GITHUB_TOKEN")
        if not token:
            raise SystemExit(
                "GITHUB_TOKEN is not set. Create a PAT at https://github.com/settings/tokens "
                "(default scopes are fine during preview) and set GITHUB_TOKEN."
            )
        endpoint = os.environ.get("GITHUB_MODELS_ENDPOINT", "https://models.inference.ai.azure.com")
        _client = OpenAI(base_url=endpoint, api_key=token)
    return _client


def translate_tools(mcp_tools):
    return [
        {
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t.get("description", ""),
                "parameters": _sanitise_schema_for_openai(t["inputSchema"]),
            },
        }
        for t in mcp_tools
    ]


# OpenAI Chat Completions rejects top-level oneOf/anyOf/allOf/not/enum on a
# function's `parameters` schema (Anthropic accepts them). Two of our MCP
# tools (find_references, find_impacts) use oneOf to express "exactly one of
# symbol or file" — the prose description already conveys that, so we strip
# the constraint here rather than weakening the source schema for both
# providers. Validation falls back to the agent tool's runtime check.
_OPENAI_TOPLEVEL_BANNED = ("oneOf", "anyOf", "allOf", "not", "enum")


def _sanitise_schema_for_openai(schema):
    if not isinstance(schema, dict):
        return schema
    cleaned = {k: v for k, v in schema.items() if k not in _OPENAI_TOPLEVEL_BANNED}
    if cleaned.get("type") != "object":
        cleaned["type"] = "object"
    return cleaned


def chat(messages, tools, *, model, system=None):
    # OpenAI-shaped APIs take `system` as a regular message turn; if a system
    # prompt is provided AND the messages list doesn't already start with one,
    # prepend it. Caller stays symmetric with the Anthropic provider.
    if system and not (messages and messages[0].get("role") == "system"):
        messages = [{"role": "system", "content": system}, *messages]
    response = _get_client().chat.completions.create(
        model=model,
        messages=messages,
        tools=tools,
    )
    msg = response.choices[0].message

    tool_calls = []
    for tc in (msg.tool_calls or []):
        try:
            args = json.loads(tc.function.arguments or "{}")
        except json.JSONDecodeError:
            args = {}
        tool_calls.append(ToolCall(id=tc.id, name=tc.function.name, arguments=args))

    raw_assistant_message = {
        "role": "assistant",
        "content": msg.content or "",
        "tool_calls": [
            {
                "id": tc.id,
                "type": "function",
                "function": {"name": tc.function.name, "arguments": tc.function.arguments or "{}"},
            }
            for tc in (msg.tool_calls or [])
        ],
    }
    if not raw_assistant_message["tool_calls"]:
        # Chat Completions rejects an empty tool_calls field; drop it.
        del raw_assistant_message["tool_calls"]

    return {
        "text": msg.content if msg.content else None,
        "tool_calls": tool_calls,
        "raw": raw_assistant_message,
    }


def append_tool_results(messages, raw_assistant_message, results):
    """
    `results` is a list of {tool_use_id, content (str), is_error (bool)}.
    OpenAI/Azure-AI-Inference want one `tool` role message per call.
    """
    messages.append(raw_assistant_message)
    for r in results:
        messages.append({
            "role": "tool",
            "tool_call_id": r["tool_use_id"],
            "content": r["content"],
        })


# gpt-4o-mini sits in the GitHub Models free tier and handles tool-calling well.
# Other tool-capable options: gpt-4o, Phi-3.5-MoE-instruct, Mistral-large.
DEFAULT_MODEL = "gpt-4o-mini"
