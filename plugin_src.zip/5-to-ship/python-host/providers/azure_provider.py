"""
Azure OpenAI (Foundry) provider.

For GPT-family models deployed under an Azure OpenAI resource / Azure AI
Foundry project. Wire format is OpenAI Chat Completions, so this mirrors
`github_provider.py` almost exactly — only the client construction and the
`model` semantics differ:

  - The OpenAI SDK's `AzureOpenAI` client is used instead of `OpenAI`.
  - `model=` is the Foundry **deployment name**, not the underlying model
    name (e.g. "gpt-4o-prod-eastus", not "gpt-4o").
  - Auth: API key (`AZURE_OPENAI_API_KEY`) by default; if not set, falls
    back to Entra ID via `DefaultAzureCredential`, which most enterprise
    Foundry tenants require (no static keys allowed).

Required env (key auth):
    AZURE_OPENAI_ENDPOINT       https://<resource>.openai.azure.com
                                (or the Foundry project endpoint)
    AZURE_OPENAI_API_KEY        the resource key
    AZURE_OPENAI_DEPLOYMENT     the deployment name (becomes DEFAULT_MODEL)
    AZURE_OPENAI_API_VERSION    optional; defaults to a recent tool-capable version

Required env (Entra ID auth — no key set):
    AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_DEPLOYMENT, AZURE_OPENAI_API_VERSION
    plus the usual DefaultAzureCredential inputs (az login, managed identity,
    AZURE_CLIENT_ID/TENANT_ID/SECRET, etc.) — requires the `azure-identity`
    package.
"""

import json
import os

from openai import AzureOpenAI

from . import ToolCall


_DEFAULT_API_VERSION = "2024-10-21"
_client = None


def _get_client():
    global _client
    if _client is not None:
        return _client

    endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    if not endpoint:
        raise SystemExit("AZURE_OPENAI_ENDPOINT is not set.")
    api_version = os.environ.get("AZURE_OPENAI_API_VERSION", _DEFAULT_API_VERSION)
    api_key = os.environ.get("AZURE_OPENAI_API_KEY")

    if api_key:
        _client = AzureOpenAI(
            azure_endpoint=endpoint,
            api_key=api_key,
            api_version=api_version,
        )
    else:
        try:
            from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        except ImportError as exc:
            raise SystemExit(
                "AZURE_OPENAI_API_KEY is not set and the `azure-identity` package is not installed. "
                "Either set AZURE_OPENAI_API_KEY or `pip install azure-identity` to use Entra ID."
            ) from exc
        token_provider = get_bearer_token_provider(
            DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default"
        )
        _client = AzureOpenAI(
            azure_endpoint=endpoint,
            azure_ad_token_provider=token_provider,
            api_version=api_version,
        )
    return _client


def translate_tools(mcp_tools):
    return [
        {
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t.get("description", ""),
                "parameters": _sanitise_schema_for_openai(t["inputSchema"]),
            },
        }
        for t in mcp_tools
    ]


_OPENAI_TOPLEVEL_BANNED = ("oneOf", "anyOf", "allOf", "not", "enum")


def _sanitise_schema_for_openai(schema):
    if not isinstance(schema, dict):
        return schema
    cleaned = {k: v for k, v in schema.items() if k not in _OPENAI_TOPLEVEL_BANNED}
    if cleaned.get("type") != "object":
        cleaned["type"] = "object"
    return cleaned


def chat(messages, tools, *, model, system=None):
    if system and not (messages and messages[0].get("role") == "system"):
        messages = [{"role": "system", "content": system}, *messages]
    response = _get_client().chat.completions.create(
        model=model,
        messages=messages,
        tools=tools,
    )
    msg = response.choices[0].message

    tool_calls = []
    for tc in (msg.tool_calls or []):
        try:
            args = json.loads(tc.function.arguments or "{}")
        except json.JSONDecodeError:
            args = {}
        tool_calls.append(ToolCall(id=tc.id, name=tc.function.name, arguments=args))

    raw_assistant_message = {
        "role": "assistant",
        "content": msg.content or "",
        "tool_calls": [
            {
                "id": tc.id,
                "type": "function",
                "function": {"name": tc.function.name, "arguments": tc.function.arguments or "{}"},
            }
            for tc in (msg.tool_calls or [])
        ],
    }
    if not raw_assistant_message["tool_calls"]:
        del raw_assistant_message["tool_calls"]

    return {
        "text": msg.content if msg.content else None,
        "tool_calls": tool_calls,
        "raw": raw_assistant_message,
    }


def append_tool_results(messages, raw_assistant_message, results):
    messages.append(raw_assistant_message)
    for r in results:
        messages.append({
            "role": "tool",
            "tool_call_id": r["tool_use_id"],
            "content": r["content"],
        })


# `model` for Azure OpenAI is the deployment name, not a model id.
DEFAULT_MODEL = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "")
