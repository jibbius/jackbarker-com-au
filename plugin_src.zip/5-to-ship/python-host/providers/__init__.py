"""
Provider abstraction.

Each provider exposes the same two callables so the agent loop in
`agent.py` is provider-agnostic:

    translate_tools(mcp_tools: list[dict]) -> list  (provider-shaped)

    chat(messages, tools, *, model: str) -> {
        "text":       str | None,        # final-answer text from the model
        "tool_calls": list[ToolCall],    # pending dispatches to the MCP server
        "raw":        Any,               # the raw assistant message, to be
                                         # appended to `messages` verbatim before
                                         # we add the matching tool_result(s)
    }

ToolCall is a tiny dataclass: {id, name, arguments(dict)}.

The two providers differ in:
  - tool/argument schema shape (Anthropic vs OpenAI Chat Completions),
  - how tool results are fed back (a `user` message containing `tool_result`
    blocks for Anthropic, a `tool` role message per call for OpenAI).

The agent loop calls `append_tool_results(messages, raw, results)` on the
provider so each provider expresses its own message-shape preference.
"""

from dataclasses import dataclass


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict
