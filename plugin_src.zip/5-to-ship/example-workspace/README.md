# MCP fixture workspace

A minimal, hand-crafted Architect source tree used as `ARCH_LANG_ROOT` when
smoke-testing the MCP server via the MCP Inspector.

Not an automated test suite — this is a fixture the Inspector points at so
every tool in `mcp/tools.js` has something meaningful to resolve against.

## Layout

```
mcp-workspace/
├── .architect.json             # minimal config (no supplementary module)
├── Reports/
│   ├── ORDER_SUMMARY.TXT     # includes COMMON_HELPERS, references STATUS literal
│   ├── CUSTOMER_LIST.TXT     # also includes COMMON_HELPERS (for find_references)
│   ├── COMMON_HELPERS.TXT    # shared helpers; includes VALIDATION
│   └── VALIDATION.TXT        # contains a // @rule-ignore suppression
└── usercalcs/
    └── 0001.TXT              # standalone scratch file (block-structure exercise)
```

## Tool coverage

| Tool                       | Exercise                                                       |
|---------------------------|---------------------------------------------------------------|
| `list_symbols`            | Any file — ORDER_SUMMARY has vars + function calls            |
| `list_includes`           | ORDER_SUMMARY (direct), then `followIncludes=true` for chain   |
| `lookup_symbol`           | `formatOrderLine` (file-scope), `WRITE` (built-in), `zTotal` (function-local of `summariseOrder`) |
| `find_references`         | symbol `formatOrderLine` — referenced from both reports        |
| `find_impacts`  | file `Reports/COMMON_HELPERS.TXT` — used by both reports     |
| `list_literal_comparisons`| ORDER_SUMMARY — `STATUS = "A"`                                |
| `validate_file`           | Any file — should return a clean or small diagnostic set       |
| `list_suppressions`       | `Reports/VALIDATION.TXT` — one `// @rule-ignore ACU-VAR-001` |
| `lookup_description_code` | Requires a populated cache — not covered by this fixture       |
