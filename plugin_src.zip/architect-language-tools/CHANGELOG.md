# Change Log

All notable changes to the "architect" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

## [Unreleased]

- Diagnostic architecture migrated to catalog-driven messages with stable IDs (`ACU-*`) and structured `diagnostic.data` payloads.
- Standards profile severities now resolve from the centralized diagnostic catalog.
- Added quick fixes for variable and function capitalisation mismatch with dual action strategy (fix current usage or normalize in-file).
- Added keyword/type capitalization validators and supporting quick fixes.
- Added output-line context handling for `#HASH-ON` and `#HASH-OFF` modes to avoid false keyword/type diagnostics in output text.
- Added syntax test framework enhancements:
	- Recursive subfolder test discovery.
	- ID-based diagnostic expectations.
	- `code-action-tests` support with selectable `action-index`.
- Added syntax suites for:
	- block structure
	- code actions
	- output-line behavior
	- variable/function capitalisation mismatch
- Added helper tools:
	- `tools/generate-diagnostic-docs.js` for README diagnostic table generation
	- `tools/add-ruleid-to-specs.js` for spec readability updates