#!/usr/bin/env node
/**
 * Walkthrough harness entry point.
 *
 * Spawns the Architect MCP server, drives an LLM through one or more
 * scenarios, writes a markdown transcript per run.
 *
 * Usage:
 *   node walkthrough.js                    # all scenarios
 *   node walkthrough.js trace-function     # one named scenario
 *
 * Configuration (see .env.example):
 *   LLM_BASE_URL   — OpenAI-compatible endpoint
 *   LLM_API_KEY    — auth token
 *   LLM_MODEL      — model identifier
 *   ARCH_LANG_ROOT — fixture workspace (defaults to test/mcp-workspace)
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath, pathToFileURL } from "url";

import "dotenv/config";

import { connectMcpServer } from "./lib/mcpClient.js";
import { toOpenAiTools } from "./lib/toolBridge.js";
import { createTranscript } from "./lib/transcriptLogger.js";
import { runWalkthrough, createOpenAiClient } from "./lib/llmLoop.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SCENARIOS_DIR = path.join(HERE, "scenarios");
const TRANSCRIPTS_DIR = path.join(HERE, "transcripts");
const DEFAULT_ROOT = path.resolve(HERE, "..", "..", "test", "mcp-workspace");

async function loadScenarios(filterName) {
    const files = fs.readdirSync(SCENARIOS_DIR)
        .filter((f) => f.endsWith(".js"))
        .sort();
    const all = [];
    for (const file of files) {
        const mod = await import(pathToFileURL(path.join(SCENARIOS_DIR, file)).href);
        all.push(mod.default);
    }
    return filterName ? all.filter((s) => s.name === filterName) : all;
}

async function main() {
    const filterName = process.argv[2];
    const scenarios = await loadScenarios(filterName);
    if (scenarios.length === 0) {
        console.error(`No scenarios matched "${filterName}"`);
        process.exit(1);
    }

    const baseURL = process.env.LLM_BASE_URL;
    const apiKey = process.env.LLM_API_KEY;
    const model = process.env.LLM_MODEL;
    if (!baseURL || !apiKey || !model) {
        console.error("Missing LLM_BASE_URL / LLM_API_KEY / LLM_MODEL — see .env.example");
        process.exit(1);
    }

    const archLangRoot = process.env.ARCH_LANG_ROOT ?? DEFAULT_ROOT;
    console.log(`[walkthrough] ARCH_LANG_ROOT = ${archLangRoot}`);
    console.log(`[walkthrough] LLM = ${baseURL} / ${model}`);

    const openai = createOpenAiClient({ baseURL, apiKey });
    const { tools: mcpTools, callTool, close } = await connectMcpServer({ archLangRoot });
    const tools = toOpenAiTools(mcpTools);
    console.log(`[walkthrough] ${mcpTools.length} tools bridged to OpenAI`);

    try {
        for (const scenario of scenarios) {
            console.log(`\n[walkthrough] running scenario: ${scenario.name}`);
            const transcript = createTranscript({
                scenarioName: scenario.name,
                model,
                fixtureFile: scenario.fixtureFile
            });
            const { finalText } = await runWalkthrough({
                client: openai,
                model,
                tools,
                callTool,
                userPrompt: scenario.prompt,
                transcript
            });

            const stamp = new Date().toISOString().replace(/[:.]/g, "-");
            const outPath = path.join(
                TRANSCRIPTS_DIR,
                `${scenario.name}__${stamp}.md`
            );
            transcript.writeTo(outPath);
            console.log(`[walkthrough] wrote ${path.relative(HERE, outPath)}`);
            console.log(`[walkthrough] final: ${finalText.slice(0, 160)}${finalText.length > 160 ? "…" : ""}`);
        }
    } finally {
        await close();
    }
}

main().catch((err) => {
    console.error("[walkthrough] FAILED:", err);
    process.exit(1);
});
