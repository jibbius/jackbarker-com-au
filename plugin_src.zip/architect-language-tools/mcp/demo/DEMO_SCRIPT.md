# Architect MCP Demo Script

**Audience:** Stakeholders / facilitators  
**Platform:** VS Code with Copilot Chat enabled  
**Fixture workspace:** `architect-language-tools/test/mcp-workspace/`

---

## Setup

1. Open this repository in VS Code.
2. Ensure GitHub Copilot Chat is signed in and active.
3. Press **F5** to launch the Extension Development Host (config:
   "Run: Quick Launch (Source Dev Host)"). The MCP bundle builds, then the
   EDH window opens with the Architect Language Tools extension loaded —
   which registers the MCP server automatically via
   `vscode.lm.registerMcpServerDefinitionProvider`.
4. In the EDH window, open the fixture workspace (or any folder containing
   Architect files).
5. Open the Copilot Chat panel (`Ctrl+Alt+I`).
6. Confirm the server is loaded: the Copilot Chat panel should show
   `Architect Language Tools` in its tools list (click the tools icon),
   or run `MCP: List Servers` from the command palette.

> **Pointing at a real codebase?**  
> Set `architect.mcp.workspaceRoot` in EDH settings (or open the Architect
> source tree as the workspace folder). All four scenarios work against
> real files.

---

## Scenario 1 — Explain a literal status comparison

**Goal:** Agent chains `list_literal_comparisons` → `lookup_symbol` →
`lookup_description_code` to give a business-level explanation of a raw
status check.

**Prompt:**
```
Using the Architect tools, explain what the status comparison in
Reports/ORDER_SUMMARY.TXT means in business terms.
```

**Expected tool chain:**
1. `list_literal_comparisons` on `Reports/ORDER_SUMMARY.TXT` — returns the
   `sStatus = "A"` comparison.
2. `lookup_symbol` for `sStatus` in `ORDER_SUMMARY.TXT` — returns its type
   and declaration.
3. *(If a description-code lookup code is attached to the field handle)*
   `lookup_description_code` — enumerates valid status codes with labels.

**What a good response looks like:**  
The agent identifies `sStatus = "A"` as a status filter, explains that `"A"`
means *Active* (if the cache is populated), and correctly attributes the
comparison to line 17 in the file. It does not hallucinate additional status
values.

---

## Scenario 2 — Explain an unfamiliar function call

**Goal:** Agent chains `list_symbols` → `lookup_symbol` → `find_references`
to trace a shared helper function across files.

**Prompt:**
```
Using the Architect tools, explain what formatOrderLine does and where it is used.
```

**Expected tool chain:**
1. `lookup_symbol` for `formatOrderLine` — returns its declaration in
   `Reports/COMMON_HELPERS.TXT`, parameter list, and return type.
2. `find_references` for `formatOrderLine` with `kind: "calls"` — returns call
   sites in both `CUSTOMER_LIST.TXT` and `ORDER_SUMMARY.TXT`.

**What a good response looks like:**  
The agent names the two parameters (`sId: STRING`, `nValue: LONG`), identifies
the function as a formatting helper, and lists both call sites with their file
and line number. It does not invent callers.

---

## Scenario 3 — Diagnose a validation error

**Goal:** Agent chains `validate_file` → `lookup_symbol` to explain a
diagnostic in context rather than repeating its raw message.

**Prompt:**
```
Using the Architect tools, validate Reports/VALIDATION.TXT and explain any
errors in plain English.
```

**Expected tool chain:**
1. `validate_file` on `Reports/VALIDATION.TXT` — returns diagnostic list.
2. For each diagnostic, `lookup_symbol` on the flagged identifier — returns
   declaration info or confirms it is undefined.

**What a good response looks like:**  
The agent describes each error by name and explains *why* it is wrong
(e.g. "variable `nResult` is used on line 12 but is never assigned a value")
rather than just echoing the diagnostic code. Unknown symbols are described as
undefined, not invented.

---

## Scenario 4 — Handle an unresolved include

**Goal:** Agent sees an `unknowns` entry with `reason: "unresolved_include"`
from `lookup_symbol` and correctly flags the gap rather than guessing.

**Prompt:**
```
Using the Architect tools, look up the symbol EXTERNAL_HELPER in
Reports/CUSTOMER_LIST.TXT and tell me what it does.
```

**Expected tool chain:**
1. `lookup_symbol` for `EXTERNAL_HELPER` in `Reports/CUSTOMER_LIST.TXT` —
   returns `status: "unknown"` with `reason: "not_found_in_workspace"` (or
   surfaces an `unknowns[]` entry if the include chain is partially resolved).

**What a good response looks like:**  
The agent states that `EXTERNAL_HELPER` could not be resolved in the indexed
workspace and suggests the symbol may come from an include file that is not
present or not yet indexed. It does **not** invent a definition or a return
type.

---

## Tips for facilitators

- The four scenarios are ordered by complexity. Run them in order for a first
  showing; jump to scenario 3 or 4 if the audience is already technical.
- If Copilot does not call a tool automatically, nudge with:
  *"Use the Architect MCP tools to answer this."*
- If `lookup_description_code` returns `cache_not_populated`, explain that the
  cache requires a SQL Server connection to populate — the structure of the
  response (and the fact that it names the lookup code) is still demonstrable.
- For a corporate demo, swap `ARCH_LANG_ROOT` for the org's real Architect
  codebase. The scenario prompts work without modification against real files.
