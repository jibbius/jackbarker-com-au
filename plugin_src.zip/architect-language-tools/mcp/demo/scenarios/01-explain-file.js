/**
 * Scenario 1 — File explanation.
 *
 * Asks the model to explain a report file. Expected behaviour: chain
 * list_symbols → list_includes → lookup_symbol on the imported helper.
 */
export default {
    name: "explain-file",
    fixtureFile: "Reports/ORDER_SUMMARY.TXT",
    prompt: [
        "I have a file called Reports/ORDER_SUMMARY.TXT.",
        "Explain what it does, including any helper functions it relies on",
        "and where they come from. Ground every claim in a tool call."
    ].join(" ")
};
