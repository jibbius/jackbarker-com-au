/**
 * Scenario 3 — Literal comparison investigation.
 *
 * ORDER_SUMMARY.TXT contains `IF sStatus = "A"`. Expected behaviour:
 * list_literal_comparisons to surface the comparison, lookup_symbol on
 * sStatus to see what it is, and a clear acknowledgement when the literal
 * "A" cannot be mapped to a description code (sStatus is not a field handle).
 */
export default {
    name: "literal-comparison",
    fixtureFile: "Reports/ORDER_SUMMARY.TXT",
    prompt: [
        "Find any places in Reports/ORDER_SUMMARY.TXT where a variable is",
        "compared against a hard-coded literal value. For each one, explain",
        "what the variable represents and what the literal means. If you",
        "can't determine the meaning of a literal from the available tools,",
        "say so explicitly rather than guessing."
    ].join(" ")
};
