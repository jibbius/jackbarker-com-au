/**
 * Scenario 2 — Trace a function across the include graph.
 *
 * The function `formatOrderLine` is defined in COMMON_HELPERS.TXT and
 * called from both CUSTOMER_LIST.TXT and ORDER_SUMMARY.TXT. Expected
 * behaviour: lookup_symbol to find the definition, find_references to
 * enumerate call sites.
 */
export default {
    name: "trace-function",
    fixtureFile: "Reports/ORDER_SUMMARY.TXT",
    prompt: [
        "In Reports/ORDER_SUMMARY.TXT there's a call to `formatOrderLine`.",
        "Where is that function defined, what is its signature, and which",
        "other files in the workspace call it?"
    ].join(" ")
};
