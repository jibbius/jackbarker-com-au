# MCP demo — walkthrough harness

POC harness that drives the Architect MCP server through an OpenAI-compatible
LLM. Produces a markdown transcript per run, for stakeholder demos and
tool-design feedback.

This is **not** a regression suite. LLM behaviour is non-deterministic;
asserting on tool-call sequences would test the model, not us. Tool-surface
regressions are caught by `test/unit/agentTools/` and `test/mcp/`.

## What's here

| Path | Purpose |
|---|---|
| `walkthrough.js` | Entry point — runs one or all scenarios |
| `lib/mcpClient.js` | Spawns `mcp/index.js` over stdio, lists/calls tools |
| `lib/toolBridge.js` | MCP tool defs → OpenAI tool defs (structural rename) |
| `lib/llmLoop.js` | OpenAI tool-calling turn loop, dispatches back through MCP |
| `lib/transcriptLogger.js` | Markdown writer |
| `lib/smokeTest.js` | No-LLM smoke test of `mcpClient.js` |
| `scenarios/*.js` | Four file-explanation scenarios |
| `transcripts/` | Output, gitignored. `transcripts/examples/` is committed. |

For the Phase 4a Copilot Chat in-editor demo, **launch the Extension
Development Host** (F5 → "Run: Quick Launch (Source Dev Host)"). The
extension's `mcpServerProvider.js` registers the bundled MCP server
automatically; no `.vscode/mcp.json` is needed (and one is not present —
removed when the provider went GA).

## Setup

```sh
cd architect-language-tools/mcp/demo
npm install
cp .env.example .env
# fill in LLM_BASE_URL / LLM_API_KEY / LLM_MODEL
```

## Running

```sh
# All four scenarios:
node walkthrough.js

# A single scenario by name:
node walkthrough.js trace-function

# Standalone smoke test (no LLM, no .env needed):
node lib/smokeTest.js
```

Transcripts land in `transcripts/<scenario-name>__<timestamp>.md`.

## Scenarios

| Name | What it asks | Tools the agent should reach for |
|---|---|---|
| `explain-file` | Explain ORDER_SUMMARY.TXT end-to-end | `list_symbols`, `list_includes`, `lookup_symbol` |
| `trace-function` | Where is `formatOrderLine` defined and called? | `lookup_symbol`, `find_references` |
| `literal-comparison` | Explain the `sStatus = "A"` comparison | `list_literal_comparisons`, `lookup_symbol` |
| `unknown-symbol` | Look up a symbol that doesn't exist | `lookup_symbol` returning `unknown`, agent honesty |

The PR-review band of scenarios is parked pending feedback from these four
(spec §"Parked: review band").

## Curating a transcript as a demo artefact

By default `transcripts/` is ignored. To promote a particularly illustrative
run as committed reference material, copy it into `transcripts/examples/`
(allowlisted in `.gitignore`).
