#!/usr/bin/env node
/**
 * Architect MCP server (stdio transport).
 *
 * Ordering contract (spec Phase 3, "Ordering rule"):
 *   1. Load config + optional .architect.json
 *   2. Load supplementary module via registerSupplementary() — MUST happen
 *      before any tool handler runs, otherwise GlobalScope will have
 *      lazy-populated from base builtins and supplementary entries will sit
 *      in the builtin maps but be invisible to the resolved symbol table.
 *   3. Construct the document repository and (optionally) the description
 *      codes cache
 *   4. Bind MCP transport + register tools
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath, pathToFileURL } from "url";

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
    CallToolRequestSchema,
    ListToolsRequestSchema
} from "@modelcontextprotocol/sdk/types.js";

import { createDocumentRepository } from "../core/src/query/documentRepository.js";
import { registerSupplementary } from "../core/src/supplementaryLoader.js";
import { compileRulesFilter } from "../core/src/diagnostics/rulesFilter.js";
import { DescriptionCodesCache } from "../connectors/index.js";

import { loadConfig } from "./config.js";
import { TOOLS, OutOfWorkspaceError } from "./tools.js";

async function main() {
    const config = loadConfig();

    // Load supplementary module BEFORE any tool handler can be invoked.
    // A *configured-but-failed* load is fatal: starting the server without
    // the supplementary rules the user explicitly asked for would advertise
    // a rule surface that doesn't fire. The agent client has no way to see
    // a stderr WARNING, so silent partial startup makes the server lie.
    if (config.architectConfig?.supplementaryModule) {
        const configDir = path.dirname(config.configPath);
        const supplementaryPath = path.resolve(configDir, config.architectConfig.supplementaryModule);
        const supplementaryLabel = path.basename(supplementaryPath);
        // Pre-flight existence check so the agent client sees a friendly
        // message instead of Node's stock ERR_MODULE_NOT_FOUND with the full
        // resolved path baked in.
        if (!fs.existsSync(supplementaryPath)) {
            throw new Error(`supplementary module not found: ${supplementaryLabel}`);
        }
        // pathToFileURL: Node's ESM loader rejects bare absolute paths on
        // Windows ("Received protocol 'c:'"). Convert to a file:// URL so the
        // dynamic import works cross-platform.
        const mod = await import(pathToFileURL(supplementaryPath).href);
        const preferCore = config.architectConfig.supplementaryPreferCore === true;
        registerSupplementary(mod, { preferCore });
        logStderr(`supplementary module loaded (${supplementaryLabel})`);
    }

    const documentRepository = createDocumentRepository();
    const descriptionCodesCache = await initDescriptionCodesCache(config);
    const rulesFilter = compileRulesFilter(config.architectConfig);

    const ctx = {
        workspaceRoot: config.workspaceRoot,
        documentRepository,
        descriptionCodesCache,
        connection: config.connection,
        descriptionCachePath: config.descriptionCachePath,
        rulesFilter
    };

    // Drop tools whose required server-side capability is unavailable.
    // The standalone bundle stubs `connectors` to `{ DescriptionCodesCache: null }`,
    // which makes the description-codes tools advertise a surface they can't fulfil.
    const availableTools = TOOLS.filter((t) =>
        !(t.requires === "descriptionCodesCache" && !descriptionCodesCache)
    );

    const toolByName = new Map(availableTools.map((t) => [t.name, t]));

    const server = new Server(
        { name: "architect-language-tools", version: readPackageVersion() },
        { capabilities: { tools: {} } }
    );

    server.setRequestHandler(ListToolsRequestSchema, async () => ({
        tools: availableTools.map(({ name, description, inputSchema, annotations }) => ({
            name,
            description,
            inputSchema,
            ...(annotations ? { annotations } : {})
        }))
    }));

    server.setRequestHandler(CallToolRequestSchema, async (request) => {
        const { name, arguments: args } = request.params;
        const tool = toolByName.get(name);
        if (!tool) {
            return errorContent(`unknown tool: ${name}`);
        }
        try {
            const result = await runWithTimeout(name, () => tool.run(args ?? {}, ctx));
            return {
                content: [{ type: "text", text: JSON.stringify(result) }]
            };
        } catch (err) {
            if (err instanceof ToolTimeoutError) {
                return {
                    content: [{
                        type: "text",
                        text: JSON.stringify({
                            status: "unknown",
                            reason: `tool timed out after ${err.timeoutMs}ms`,
                            hint: "narrow the input (e.g. specify a file or scanRoots) or raise ARCH_LANG_TOOL_TIMEOUT_MS"
                        })
                    }]
                };
            }
            if (err instanceof OutOfWorkspaceError) {
                // Surface as a structured "unknown" so the agent can recover,
                // not an isError envelope that may abort its tool loop.
                return {
                    content: [{
                        type: "text",
                        text: JSON.stringify({
                            status: "unknown",
                            reason: "file is outside the configured workspace",
                            hint: "pass a path under ARCH_LANG_ROOT (workspace-relative is preferred)",
                            file: err.filePath
                        })
                    }]
                };
            }
            // Log the full stack locally; ship only err.message across the wire
            // so server filesystem paths and node_modules layout don't leak to
            // the agent client.
            logStderr(`${name} threw: ${err.stack ?? err.message ?? err}`);
            return errorContent(`${name} failed: ${err.message ?? err}`);
        }
    });

    const transport = new StdioServerTransport();
    await server.connect(transport);
    logStderr(`architect-mcp ready — workspace ${config.workspaceRoot}, ${availableTools.length} tools registered`);

    registerShutdownHandlers(server);
}

function registerShutdownHandlers(server) {
    let shuttingDown = false;
    const shutdown = async (signal) => {
        if (shuttingDown) return;
        shuttingDown = true;
        logStderr(`received ${signal}, shutting down`);
        try {
            await server.close?.();
        } catch (err) {
            logStderr(`error during shutdown: ${err.message ?? err}`);
        }
        process.exit(0);
    };
    process.on("SIGINT", () => shutdown("SIGINT"));
    process.on("SIGTERM", () => shutdown("SIGTERM"));
}

// Per-call timeout. Without this, a slow tool (validateFile or
// findReferences across a large workspace) blocks the server's request
// queue — the MCP SDK serialises requests within a transport. The
// timeout returns a structured "unknown" so the agent can re-issue with
// narrower scope rather than crash its tool loop.
const TOOL_TIMEOUT_MS = Number(process.env.ARCH_LANG_TOOL_TIMEOUT_MS) || 30_000;

async function runWithTimeout(name, fn) {
    let timer;
    const timeout = new Promise((_resolve, reject) => {
        timer = setTimeout(
            () => reject(new ToolTimeoutError(name, TOOL_TIMEOUT_MS)),
            TOOL_TIMEOUT_MS
        );
    });
    try {
        return await Promise.race([Promise.resolve().then(fn), timeout]);
    } finally {
        clearTimeout(timer);
    }
}

class ToolTimeoutError extends Error {
    constructor(toolName, ms) {
        super(`${toolName} exceeded ${ms}ms timeout`);
        this.name = "ToolTimeoutError";
        this.toolName = toolName;
        this.timeoutMs = ms;
    }
}

function readPackageVersion() {
    // The bundle lives at mcp/dist/architect-mcp.js; the source at mcp/index.js.
    // Try both layouts so the same code works dev-mode and shipped-vsix.
    const here = path.dirname(fileURLToPath(import.meta.url));
    const candidates = [
        path.join(here, "package.json"),
        path.join(here, "..", "package.json")
    ];
    for (const p of candidates) {
        try {
            return JSON.parse(fs.readFileSync(p, "utf8")).version;
        } catch {
            // try next
        }
    }
    return "0.0.0-unknown";
}

async function initDescriptionCodesCache(config) {
    // Standalone bundle stubs the connectors module to null exports — there
    // is no SQL layer to back the cache, so refuse construction rather than
    // throw `new (null)` at the agent client.
    if (!DescriptionCodesCache) return null;
    const cache = new DescriptionCodesCache();
    if (config.descriptionCachePath) {
        const result = await cache.load(config.descriptionCachePath);
        if (result.ok) {
            logStderr(`description-codes cache loaded from ${config.descriptionCachePath}`);
        } else {
            logStderr(`description-codes cache not loaded (missing or stale): ${config.descriptionCachePath}`);
        }
    }
    return cache;
}

function errorContent(message) {
    return {
        isError: true,
        content: [{ type: "text", text: message }]
    };
}

const LOG_FILE = process.env.ARCH_LANG_LOG_PATH ?? null;

function logStderr(msg) {
    // stdout is reserved for MCP JSON-RPC framing; diagnostics go to stderr.
    const line = `[architect-mcp] ${msg}\n`;
    process.stderr.write(line);
    if (LOG_FILE) {
        // Best-effort append; never throw from the log path. The provider
        // only sets ARCH_LANG_LOG_PATH when architect.logging is enabled.
        try {
            fs.appendFileSync(LOG_FILE, `[${new Date().toISOString()}] ${line}`);
        } catch {
            // ignore — losing a log line is preferable to crashing the server
        }
    }
}

main().catch((err) => {
    process.stderr.write(`[architect-mcp] fatal: ${err.stack ?? err.message ?? err}\n`);
    process.exit(1);
});
