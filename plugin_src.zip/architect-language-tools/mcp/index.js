#!/usr/bin/env node
/**
 * Architect MCP server (stdio transport).
 *
 * Ordering contract (spec Phase 3, "Ordering rule"):
 *   1. Load config + optional .acurity.json
 *   2. Load supplementary module via registerSupplementary() — MUST happen
 *      before any tool handler runs, otherwise GlobalScope will have
 *      lazy-populated from base builtins and supplementary entries will sit
 *      in the builtin maps but be invisible to the resolved symbol table.
 *   3. Construct the document repository and (optionally) the description
 *      codes cache
 *   4. Bind MCP transport + register tools
 */

import * as path from "path";

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
    CallToolRequestSchema,
    ListToolsRequestSchema
} from "@modelcontextprotocol/sdk/types.js";

import { createDocumentRepository } from "../core/src/query/documentRepository.js";
import { registerSupplementary } from "../core/src/supplementaryLoader.js";
import { DescriptionCodesCache } from "../connectors/index.js";

import { loadConfig } from "./config.js";
import { TOOLS } from "./tools.js";

async function main() {
    const config = loadConfig();

    // Load supplementary module BEFORE any tool handler can be invoked.
    if (config.acurityConfig?.supplementaryModule) {
        const configDir = path.dirname(config.configPath);
        const supplementaryPath = path.resolve(configDir, config.acurityConfig.supplementaryModule);
        try {
            const mod = await import(supplementaryPath);
            const preferCore = config.acurityConfig.supplementaryPreferCore === true;
            registerSupplementary(mod, { preferCore });
            logStderr(`supplementary module loaded from ${supplementaryPath}`);
        } catch (err) {
            logStderr(`WARNING: failed to load supplementary module at ${supplementaryPath}: ${err.message}`);
        }
    }

    const documentRepository = createDocumentRepository();
    const descriptionCodesCache = await initDescriptionCodesCache(config);

    const ctx = {
        workspaceRoot: config.workspaceRoot,
        documentRepository,
        descriptionCodesCache
    };

    const toolByName = new Map(TOOLS.map((t) => [t.name, t]));

    const server = new Server(
        { name: "architect-language-tools", version: "0.1.0" },
        { capabilities: { tools: {} } }
    );

    server.setRequestHandler(ListToolsRequestSchema, async () => ({
        tools: TOOLS.map(({ name, description, inputSchema, annotations }) => ({
            name,
            description,
            inputSchema,
            ...(annotations ? { annotations } : {})
        }))
    }));

    server.setRequestHandler(CallToolRequestSchema, async (request) => {
        const { name, arguments: args } = request.params;
        const tool = toolByName.get(name);
        if (!tool) {
            return errorContent(`unknown tool: ${name}`);
        }
        try {
            const result = await tool.run(args ?? {}, ctx);
            return {
                content: [{ type: "text", text: JSON.stringify(result, null, 2) }]
            };
        } catch (err) {
            return errorContent(`${name} threw: ${err.stack ?? err.message ?? err}`);
        }
    });

    const transport = new StdioServerTransport();
    await server.connect(transport);
    logStderr(`architect-mcp ready — workspace ${config.workspaceRoot}, ${TOOLS.length} tools registered`);
}

async function initDescriptionCodesCache(config) {
    const cache = new DescriptionCodesCache();
    if (config.descriptionCachePath) {
        const result = await cache.load(config.descriptionCachePath);
        if (result.ok) {
            logStderr(`description-codes cache loaded from ${config.descriptionCachePath}`);
        } else {
            logStderr(`description-codes cache not loaded (missing or stale): ${config.descriptionCachePath}`);
        }
    }
    return cache;
}

function errorContent(message) {
    return {
        isError: true,
        content: [{ type: "text", text: message }]
    };
}

function logStderr(msg) {
    // stdout is reserved for MCP JSON-RPC framing; diagnostics go to stderr.
    process.stderr.write(`[architect-mcp] ${msg}\n`);
}

main().catch((err) => {
    process.stderr.write(`[architect-mcp] fatal: ${err.stack ?? err.message ?? err}\n`);
    process.exit(1);
});
