/**
 * MCP tool bindings.
 *
 * Each entry wraps one of `core/src/agentTools/*` with:
 *   - an MCP Tool descriptor (name, description, inputSchema)
 *   - a `run(args, ctx)` adapter that injects server-side context
 *     (workspaceRoot, documentRepository, descriptionCodesCache) and forwards
 *     the remaining args to the agent tool.
 *
 * Agent-facing field names are the ones documented in
 * `planning/specs/option-b-targeted-query-tools.md`. Server-side context
 * fields are never exposed in inputSchema.
 */

import * as path from "path";

import { listFiles } from "../core/src/agentTools/listFiles.js";
import { listSymbols } from "../core/src/agentTools/listSymbols.js";
import { listIncludes } from "../core/src/agentTools/listIncludes.js";
import { lookupSymbol } from "../core/src/agentTools/lookupSymbol.js";
import { findReferences } from "../core/src/agentTools/findReferences.js";
import { findImpacts } from "../core/src/agentTools/findImpacts.js";
import { listLiteralComparisons } from "../core/src/agentTools/listLiteralComparisons.js";
import { validateFile } from "../core/src/agentTools/validateFile.js";
import { lookupDescriptionCode } from "../core/src/agentTools/lookupDescriptionCode.js";
import { listSuppressions } from "../core/src/agentTools/listSuppressions.js";

/**
 * Resolve an agent-supplied file path against the workspace root. Agents
 * typically pass workspace-relative paths (`Reports/FOO.TXT`); accept absolute
 * paths too for robustness.
 */
function resolveFilePath(workspaceRoot, filePath) {
    if (!filePath) return filePath;
    return path.isAbsolute(filePath) ? filePath : path.resolve(workspaceRoot, filePath);
}

// All tools in this module are pure read-only queries over the configured
// workspace and description-codes cache. They never mutate state and never
// reach outside the sandbox, so every descriptor gets the same annotations.
const READ_ONLY_ANNOTATIONS = {
    readOnlyHint: true,
    destructiveHint: false,
    idempotentHint: true,
    openWorldHint: false
};

const TOOLS = [
    {
        annotations: READ_ONLY_ANNOTATIONS,
        name: "list_files",
        description:
            "List Architect source files under the configured scan roots (default: Reports, usercalcs). " +
            "Returns workspace-relative paths with their scan root and line count — useful as a starting " +
            "inventory when you don't already know which files exist.",
        inputSchema: {
            type: "object",
            properties: {
                scanRoots: {
                    type: "array",
                    items: { type: "string" },
                    description: "Optional override of scan roots (workspace-relative directories)."
                }
            }
        },
        run: (args, ctx) => listFiles({
            workspaceRoot: ctx.workspaceRoot,
            scanRoots: args.scanRoots
        })
    },

    {
        annotations: READ_ONLY_ANNOTATIONS,
        name: "list_symbols",
        description:
            "List all top-level and function-scoped symbols declared in an Architect file. " +
            "Optional kindFilter narrows by symbol kind (variable, function, parameter, etc.).",
        inputSchema: {
            type: "object",
            properties: {
                file: { type: "string", description: "Workspace-relative or absolute path to the .TXT file." },
                kindFilter: {
                    type: "array",
                    items: { type: "string" },
                    description: "Optional list of symbol kinds to include."
                }
            },
            required: ["file"]
        },
        run: (args, ctx) => listSymbols({
            filePath: resolveFilePath(ctx.workspaceRoot, args.file),
            documentRepository: ctx.documentRepository,
            kindFilter: args.kindFilter ?? null
        })
    },

    {
        annotations: READ_ONLY_ANNOTATIONS,
        name: "list_includes",
        description:
            "List #include directives in an Architect file. Set followIncludes=true for the full transitive include graph.",
        inputSchema: {
            type: "object",
            properties: {
                file: { type: "string" },
                followIncludes: { type: "boolean", default: false }
            },
            required: ["file"]
        },
        run: (args, ctx) => listIncludes({
            filePath: resolveFilePath(ctx.workspaceRoot, args.file),
            documentRepository: ctx.documentRepository,
            followIncludes: args.followIncludes === true,
            workspaceRoot: ctx.workspaceRoot
        })
    },

    {
        annotations: READ_ONLY_ANNOTATIONS,
        name: "lookup_symbol",
        description:
            "Resolve a symbol name to its declaration. Four-tier: function-local (if line given) → file-scope+BFS through includes → built-ins → field-handle registry. Without `file`, only built-ins and field handles are visible.",
        inputSchema: {
            type: "object",
            properties: {
                symbol: { type: "string" },
                file: { type: "string", description: "Optional — disambiguates which definition is visible." },
                line: { type: "integer", description: "Optional 1-based line number for function-local resolution." }
            },
            required: ["symbol"]
        },
        run: (args, ctx) => lookupSymbol({
            symbol: args.symbol,
            filePath: args.file ? resolveFilePath(ctx.workspaceRoot, args.file) : null,
            line: args.line ?? null,
            documentRepository: ctx.documentRepository,
            workspaceRoot: ctx.workspaceRoot
        })
    },

    {
        annotations: READ_ONLY_ANNOTATIONS,
        name: "find_references",
        description:
            "Find references to a symbol or file across the workspace. Symbol input → definition/call/read/write sites (filterable by kind; declaration sites returned as kind=\"definition\"). File input → every file that #includes it.",
        inputSchema: {
            type: "object",
            properties: {
                symbol: { type: "string" },
                file: { type: "string" },
                kind: {
                    type: "string",
                    enum: ["reads", "writes", "calls", "definitions", "all"],
                    default: "all"
                },
                scanRoots: {
                    type: "array",
                    items: { type: "string" },
                    description: "Optional override of the default scan roots (Reports, usercalcs)."
                }
            }
        },
        run: (args, ctx) => findReferences({
            symbol: args.symbol ?? null,
            file: args.file ?? null,
            kind: args.kind ?? "all",
            workspaceRoot: ctx.workspaceRoot,
            scanRoots: args.scanRoots,
            documentRepository: ctx.documentRepository
        })
    },

    {
        annotations: READ_ONLY_ANNOTATIONS,
        name: "find_impacts",
        description:
            "Impact analysis. Symbol input → file-deduped usage sites. File input → transitive reverse-include closure with per-file include chain and referenced symbols.",
        inputSchema: {
            type: "object",
            properties: {
                symbol: { type: "string" },
                file: { type: "string" },
                scanRoots: { type: "array", items: { type: "string" } }
            }
        },
        run: (args, ctx) => findImpacts({
            symbol: args.symbol ?? null,
            file: args.file ?? null,
            workspaceRoot: ctx.workspaceRoot,
            scanRoots: args.scanRoots,
            documentRepository: ctx.documentRepository
        })
    },

    {
        annotations: READ_ONLY_ANNOTATIONS,
        name: "list_literal_comparisons",
        description:
            "List comparisons between a symbol and a literal value (e.g. `STATUS = \"A\"`). Useful for surfacing business-rule checks against description-coded fields.",
        inputSchema: {
            type: "object",
            properties: {
                file: { type: "string" }
            },
            required: ["file"]
        },
        run: (args, ctx) => listLiteralComparisons({
            filePath: resolveFilePath(ctx.workspaceRoot, args.file),
            documentRepository: ctx.documentRepository
        })
    },

    {
        annotations: READ_ONLY_ANNOTATIONS,
        name: "validate_file",
        description:
            "Run the full diagnostic suite against a file using the CLI default profile. Returns normalised diagnostics (severity labels, 1-based line numbers).",
        inputSchema: {
            type: "object",
            properties: {
                file: { type: "string" }
            },
            required: ["file"]
        },
        run: (args, ctx) => validateFile({
            filePath: resolveFilePath(ctx.workspaceRoot, args.file),
            documentRepository: ctx.documentRepository,
            workspaceRoot: ctx.workspaceRoot
        })
    },

    {
        annotations: READ_ONLY_ANNOTATIONS,
        name: "lookup_description_code",
        description:
            "Look up a description code's human-readable meaning. Accepts either (table, type, code), (lookupCode, code), or — to enumerate all codes for a key — just (table, type) or just (lookupCode). Requires the server to have a populated description-codes cache.",
        inputSchema: {
            type: "object",
            properties: {
                table: { type: "string", description: "Table code (e.g. 'F1')." },
                type: { type: "string", description: "Type code (e.g. 'ST')." },
                lookupCode: { type: "string", description: "4-character combined key (alternative to table+type)." },
                code: { type: "string", description: "Specific code to look up. Omit to enumerate all codes for the key." }
            }
        },
        run: (args, ctx) => lookupDescriptionCode({
            table: args.table,
            type: args.type,
            lookupCode: args.lookupCode,
            code: args.code,
            descriptionCodesCache: ctx.descriptionCodesCache
        })
    },

    {
        annotations: READ_ONLY_ANNOTATIONS,
        name: "list_suppressions",
        description:
            "List all `// @rule-ignore ACU-XXX-NNN` suppressions in a file, with the suppressed line, rule IDs, and any REASON: clause. Malformed suppressions surface as unknowns.",
        inputSchema: {
            type: "object",
            properties: {
                file: { type: "string" }
            },
            required: ["file"]
        },
        run: (args, ctx) => listSuppressions({
            filePath: resolveFilePath(ctx.workspaceRoot, args.file),
            documentRepository: ctx.documentRepository
        })
    }
];

export { TOOLS };
