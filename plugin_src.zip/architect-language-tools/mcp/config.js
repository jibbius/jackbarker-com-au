/**
 * MCP server configuration.
 *
 * Reads environment variables and (optionally) an `.acurity.json` file to
 * assemble the runtime context shared across tool handlers. Fails loudly on
 * missing required config so the agent surface cannot start in a
 * half-configured state.
 */

import * as fs from "fs";
import * as path from "path";

function loadConfig() {
    const root = process.env.ARCH_LANG_ROOT;
    if (!root) {
        throw new Error(
            "ARCH_LANG_ROOT is required — set it to the absolute path of the Architect source tree."
        );
    }
    const workspaceRoot = path.resolve(root);
    if (!fs.existsSync(workspaceRoot) || !fs.statSync(workspaceRoot).isDirectory()) {
        throw new Error(`ARCH_LANG_ROOT is not an existing directory: ${workspaceRoot}`);
    }

    const configPath = resolveConfigPath(workspaceRoot);
    const acurityConfig = configPath ? readJsonOrNull(configPath) : null;

    return {
        workspaceRoot,
        configPath,
        acurityConfig,
        connection: {
            server: process.env.ARCH_LANG_CONN_SERVER ?? null,
            database: process.env.ARCH_LANG_CONN_DATABASE ?? null
        },
        descriptionCachePath: process.env.ARCH_LANG_DESCRIPTION_CACHE ?? null
    };
}

function resolveConfigPath(workspaceRoot) {
    if (process.env.ARCH_LANG_CONFIG) {
        const p = path.resolve(process.env.ARCH_LANG_CONFIG);
        return fs.existsSync(p) ? p : null;
    }
    const fallback = path.join(workspaceRoot, ".acurity.json");
    return fs.existsSync(fallback) ? fallback : null;
}

function readJsonOrNull(filePath) {
    try {
        return JSON.parse(fs.readFileSync(filePath, "utf8"));
    } catch {
        return null;
    }
}

export { loadConfig };
