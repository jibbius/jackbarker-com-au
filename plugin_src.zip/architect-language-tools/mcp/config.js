/**
 * MCP server configuration.
 *
 * Reads environment variables and (optionally) an `.architect.json` file to
 * assemble the runtime context shared across tool handlers. Fails loudly on
 * missing required config so the agent surface cannot start in a
 * half-configured state.
 */

import * as fs from "fs";
import * as path from "path";

function loadConfig() {
    const root = process.env.ARCH_LANG_ROOT;
    if (!root) {
        throw new Error(
            "ARCH_LANG_ROOT is required — set it to the absolute path of the Architect source tree."
        );
    }
    const workspaceRoot = path.resolve(root);
    if (!fs.existsSync(workspaceRoot) || !fs.statSync(workspaceRoot).isDirectory()) {
        throw new Error(`ARCH_LANG_ROOT is not an existing directory: ${workspaceRoot}`);
    }

    const configPath = resolveConfigPath(workspaceRoot);
    const architectConfig = configPath ? readJsonStrict(configPath) : null;

    return {
        workspaceRoot,
        configPath,
        architectConfig,
        connection: {
            server: process.env.ARCH_LANG_CONN_SERVER ?? null,
            database: process.env.ARCH_LANG_CONN_DATABASE ?? null
        },
        descriptionCachePath: process.env.ARCH_LANG_DESCRIPTION_CACHE ?? null
    };
}

function resolveConfigPath(workspaceRoot) {
    if (process.env.ARCH_LANG_CONFIG) {
        const p = path.resolve(process.env.ARCH_LANG_CONFIG);
        if (!fs.existsSync(p)) {
            // Explicit env var pointed at a missing file — this is always a
            // misconfiguration, not "no config present". Same loud-fail
            // contract as a missing ARCH_LANG_ROOT.
            throw new Error(
                `ARCH_LANG_CONFIG points at a file that does not exist: ${p}`
            );
        }
        return p;
    }
    const fallback = path.join(workspaceRoot, ".architect.json");
    return fs.existsSync(fallback) ? fallback : null;
}

/**
 * Read a JSON config file. Returns null only if the file is absent
 * (caller has already filtered for that — this guards against TOCTOU
 * deletes between existsSync and readFileSync). A *malformed* JSON file
 * throws — silently swallowing parse errors lets the server start with
 * partial config and is exactly the failure mode the loud-fail contract
 * is meant to prevent.
 */
function readJsonStrict(filePath) {
    let content;
    try {
        content = fs.readFileSync(filePath, "utf8");
    } catch (err) {
        if (err.code === "ENOENT") return null;
        throw err;
    }
    try {
        return JSON.parse(content);
    } catch (err) {
        throw new Error(`failed to parse ${filePath}: ${err.message}`);
    }
}

export { loadConfig };
