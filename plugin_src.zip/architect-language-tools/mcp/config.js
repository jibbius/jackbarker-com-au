/**
 * MCP server configuration.
 *
 * Reads environment variables and (optionally) an `.architect.json` file to
 * assemble the runtime context shared across tool handlers. Fails loudly on
 * missing required config so the agent surface cannot start in a
 * half-configured state.
 *
 * Resolution order for db* fields (Brief 9):
 *   1. ARCH_LANG_DBSERVER / ARCH_LANG_DBDATABASE env vars
 *   2. .architect.json fields
 *   3. CFG file values (CFG path resolvable from ARCH_LANG_CFG_FILE env var
 *      or .architect.json `pathToCfgFile`)
 *   4. Literal defaults from core/src/config/projectConfig.js
 *
 * Per-key env vars (ARCH_LANG_DBSERVER / ARCH_LANG_DBDATABASE) are slated
 * for deprecation once cfgParser v2 supports `${env_var}` substitution —
 * at which point `DBSERVER = ${ARCH_LANG_DBSERVER}` in CFG replaces the
 * env-var override path.
 */

import * as fs from "fs";
import * as path from "path";

import { loadProjectConfig } from "../core/src/config/projectConfig.js";

function loadConfig() {
    const root = process.env.ARCH_LANG_ROOT;
    if (!root) {
        throw new Error(
            "ARCH_LANG_ROOT is required — set it to the absolute path of the Architect source tree."
        );
    }
    const workspaceRoot = path.resolve(root);
    if (!fs.existsSync(workspaceRoot) || !fs.statSync(workspaceRoot).isDirectory()) {
        throw new Error(`ARCH_LANG_ROOT is not an existing directory: ${workspaceRoot}`);
    }

    const configPath = resolveConfigPath(workspaceRoot);
    const architectConfig = configPath ? readJsonStrict(configPath) : null;

    // Acurity.CFG path resolution. ARCH_LANG_CFG_FILE wins when set
    // (analogue of VS Code's `architect.pathToCfgFile`); otherwise fall
    // back to .architect.json's `pathToCfgFile`. Loud-fail semantics
    // inherited from `loadProjectConfig`.
    const cfgBaseDir = configPath ? path.dirname(configPath) : workspaceRoot;
    const envCfgPath = process.env.ARCH_LANG_CFG_FILE;
    const rawCfgPath = (typeof envCfgPath === "string" && envCfgPath.trim() !== "")
        ? envCfgPath
        : (architectConfig?.pathToCfgFile ?? null);
    const resolvedCfgPath = rawCfgPath
        ? (path.isAbsolute(rawCfgPath) ? rawCfgPath : path.resolve(cfgBaseDir, rawCfgPath))
        : null;

    // Per-key env-var overrides for dbServer/dbDatabase (tier 0). These do
    // not exist for dbEncrypt / dbTrustServerCertificate — booleans flow
    // through CFG / .architect.json only.
    const overrides = {
        reportDirectory: architectConfig?.reportDirectory,
        usrcalcDirectory: architectConfig?.usrcalcDirectory,
        dbServer: process.env.ARCH_LANG_DBSERVER ?? architectConfig?.dbServer,
        dbDatabase: process.env.ARCH_LANG_DBDATABASE ?? architectConfig?.dbDatabase,
        dbEncrypt: architectConfig?.dbEncrypt,
        dbTrustServerCertificate: architectConfig?.dbTrustServerCertificate
    };

    const projectConfig = loadProjectConfig({
        pathToCfgFile: resolvedCfgPath,
        overrides
    });

    return {
        workspaceRoot,
        configPath,
        architectConfig,
        projectConfig,
        descriptionCachePath: process.env.ARCH_LANG_DESCRIPTION_CACHE ?? null
    };
}

function resolveConfigPath(workspaceRoot) {
    if (process.env.ARCH_LANG_CONFIG) {
        const p = path.resolve(process.env.ARCH_LANG_CONFIG);
        if (!fs.existsSync(p)) {
            // Explicit env var pointed at a missing file — this is always a
            // misconfiguration, not "no config present". Same loud-fail
            // contract as a missing ARCH_LANG_ROOT.
            throw new Error(
                `ARCH_LANG_CONFIG points at a file that does not exist: ${p}`
            );
        }
        return p;
    }
    const fallback = path.join(workspaceRoot, ".architect.json");
    return fs.existsSync(fallback) ? fallback : null;
}

/**
 * Read a JSON config file. Returns null only if the file is absent
 * (caller has already filtered for that — this guards against TOCTOU
 * deletes between existsSync and readFileSync). A *malformed* JSON file
 * throws — silently swallowing parse errors lets the server start with
 * partial config and is exactly the failure mode the loud-fail contract
 * is meant to prevent.
 */
function readJsonStrict(filePath) {
    let content;
    try {
        content = fs.readFileSync(filePath, "utf8");
    } catch (err) {
        if (err.code === "ENOENT") return null;
        throw err;
    }
    try {
        return JSON.parse(content);
    } catch (err) {
        throw new Error(`failed to parse ${filePath}: ${err.message}`);
    }
}

export { loadConfig };
