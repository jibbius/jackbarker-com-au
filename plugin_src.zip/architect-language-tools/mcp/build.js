/**
 * Build the Architect MCP server bundle.
 *
 * Two output shapes, controlled by `ARCH_LANG_BUILD`:
 *
 * 1. Default ("vsix" shape) — `mcp/dist/architect-mcp.js`
 *    SDK-only bundle. First-party `../core/*` and `../connectors/*` stay
 *    external; the vsix ships those paths as siblings of `mcp/`. The
 *    plugin below rewrites the relative paths from `../foo/...` to
 *    `../../foo/...` so they resolve from `mcp/dist/`.
 *
 * 2. Standalone (`ARCH_LANG_BUILD=standalone`) —
 *    `mcp/dist/architect-mcp-standalone.js`
 *    Fully self-contained. `core/*` is bundled in. `connectors/*` is
 *    intercepted by a virtual-module stub (no SQL Server dep), and the
 *    runtime tool-capability filter in `index.js` drops the description-
 *    codes tools that depend on it. Used for the corporate POC hand-off
 *    bundle (see planning/specs/standalone-mcp-demo-bundle.md).
 *
 * The `release` flag (orthogonal to the above two modes) just disables
 * sourcemaps to halve the shipped vsix payload.
 */

import * as esbuild from "esbuild";
import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const STANDALONE = process.env.ARCH_LANG_BUILD === "standalone";

const externalRewriter = {
    name: "rewrite-firstparty-externals",
    setup(build) {
        // Only intercept relative imports of `../core/...` and
        // `../connectors/...` that originate from our own source —
        // bundled deps (e.g. zod) have their own internal paths matching
        // the same shape and must NOT be rewritten.
        build.onResolve({ filter: /^\.\.\/(core|connectors)\// }, (args) => {
            const importer = args.importer.replace(/\\/g, "/");
            if (importer.includes("/node_modules/")) {
                return null;
            }
            return {
                path: "../" + args.path,
                external: true
            };
        });
    }
};

// Standalone mode: replace `../connectors/index.js` (the only entry that
// imports the SQL layer) with a virtual module exporting null shims. Must
// be registered *before* externalRewriter so the standalone build doesn't
// accidentally externalise the connectors path. In the standalone build
// we omit externalRewriter entirely so `core/*` gets bundled in.
const stubConnectors = {
    name: "stub-connectors",
    setup(build) {
        build.onResolve({ filter: /^\.\.\/connectors\/index\.js$/ }, (args) => {
            const importer = args.importer.replace(/\\/g, "/");
            if (importer.includes("/node_modules/")) return null;
            return { path: args.path, namespace: "stub-connectors" };
        });
        build.onLoad({ filter: /.*/, namespace: "stub-connectors" }, () => ({
            contents: "export const DescriptionCodesCache = null;\nexport const queryDescriptionCodes = null;\n",
            loader: "js"
        }));
    }
};

const outfile = STANDALONE
    ? path.join(__dirname, "dist", "architect-mcp-standalone.js")
    : path.join(__dirname, "dist", "architect-mcp.js");

const plugins = STANDALONE
    ? [stubConnectors]
    : [externalRewriter];

await esbuild.build({
    entryPoints: [path.join(__dirname, "index.js")],
    outfile,
    bundle: true,
    format: "esm",
    platform: "node",
    target: "node20",
    // Sourcemaps are useful for maintainers but roughly double the bundle
    // size and ship in the vsix payload to no end-user benefit. Default on
    // for dev; opt out via ARCH_LANG_BUILD=release. Standalone always
    // ships with sourcemaps — the bundle is a hand-off artefact for a
    // developer who may need to debug it in situ.
    sourcemap: STANDALONE ? true : process.env.ARCH_LANG_BUILD !== "release",
    plugins,
    banner: {
        js: "// Architect MCP server — bundled. Third-party licences: see mcp/THIRD-PARTY-LICENCES.txt"
    },
    logLevel: "info"
});

// Copy the static hand-off README alongside the standalone bundle so the
// dist/ directory is the complete deliverable. Source lives outside dist/
// (which is gitignored) so it survives `git clean`.
if (STANDALONE) {
    fs.copyFileSync(
        path.join(__dirname, "HANDOFF.md"),
        path.join(__dirname, "dist", "HANDOFF.md")
    );
}
