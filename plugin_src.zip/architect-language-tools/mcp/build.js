/**
 * Build the Architect MCP server into a single ESM bundle at
 * `mcp/dist/architect-mcp.js`.
 *
 * Bundling shape (per planning/specs/extension-mcp-server-provider.md
 * Phase 3): SDK-only. The MCP SDK + its zod transitive are bundled in;
 * first-party `../core/*` and `../connectors/*` modules are kept as
 * external runtime imports so the bundle stays tiny inside the vsix
 * (which already ships those paths as siblings of `mcp/`).
 *
 * Externals path-rewrite: source imports look like `../core/...` from
 * `mcp/index.js`. The bundle lives one level deeper at
 * `mcp/dist/architect-mcp.js`, so those relative paths must become
 * `../../core/...` to resolve correctly at runtime. The plugin below
 * does that rewrite while marking the import external.
 */

import * as esbuild from "esbuild";
import * as path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const externalRewriter = {
    name: "rewrite-firstparty-externals",
    setup(build) {
        // Only intercept relative imports of `../core/...` and
        // `../connectors/...` that originate from our own source —
        // bundled deps (e.g. zod) have their own internal paths matching
        // the same shape and must NOT be rewritten.
        build.onResolve({ filter: /^\.\.\/(core|connectors)\// }, (args) => {
            const importer = args.importer.replace(/\\/g, "/");
            if (importer.includes("/node_modules/")) {
                return null;
            }
            return {
                path: "../" + args.path,
                external: true
            };
        });
    }
};

await esbuild.build({
    entryPoints: [path.join(__dirname, "index.js")],
    outfile: path.join(__dirname, "dist", "architect-mcp.js"),
    bundle: true,
    format: "esm",
    platform: "node",
    target: "node20",
    // Sourcemaps are useful for maintainers but roughly double the bundle
    // size and ship in the vsix payload to no end-user benefit. Default on
    // for dev; opt out via ARCH_LANG_BUILD=release.
    sourcemap: process.env.ARCH_LANG_BUILD !== "release",
    plugins: [externalRewriter],
    banner: {
        js: "// Architect MCP server — bundled. Third-party licences: see mcp/THIRD-PARTY-LICENCES.txt"
    },
    logLevel: "info"
});
