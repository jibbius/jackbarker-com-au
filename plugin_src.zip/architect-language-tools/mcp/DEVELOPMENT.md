# MCP Server — Development

Stdio-transport MCP server that exposes `core/src/agentTools/*` as
Model Context Protocol tools. Read [../../planning/specs/option-b-targeted-query-tools.md](../../planning/specs/option-b-targeted-query-tools.md)
before making surface changes.

## Layout

| File | Purpose |
|---|---|
| `index.js` | Entry point. Loads config → supplementary module → document repository → description-codes cache → binds stdio transport and registers tools. |
| `tools.js` | Single source of truth for tool descriptors. Each entry has `name`, `description`, `inputSchema`, and `run(args, ctx)`. |
| `config.js` | Env-var and `.acurity.json` loading. |
| `package.json` | Declares `@modelcontextprotocol/sdk` as the sole runtime dep (the one place repo rule 2 allows). |

## Configuration

| Env var | Purpose | Required |
|---|---|---|
| `ARCH_LANG_ROOT` | Absolute path to the Architect source tree. | Yes |
| `ARCH_LANG_CONFIG` | Absolute path to `.acurity.json`. Falls back to `$ARCH_LANG_ROOT/.acurity.json`. | No |
| `ARCH_LANG_CONN_SERVER` / `ARCH_LANG_CONN_DATABASE` | SQL Server connection — reserved for future direct refresh of the description-codes cache. Not wired yet; populate the cache via the VS Code extension or by pre-building the cache file. | No |
| `ARCH_LANG_DESCRIPTION_CACHE` | Absolute path to a pre-built description-codes cache JSON. Loaded at startup. | No |

## Ordering contract

`registerSupplementary()` MUST run before the first tool handler is invoked.
`GlobalScope` in `core/src/analysis/symbolTable.js` lazily populates from
`BuiltInFunctions` on first use; anything registered after that point sits in
the builtin maps but is invisible to the resolved symbol table. `index.js`
loads the supplementary module immediately after config and before
`server.connect()`.

## Running locally

```sh
# Install the SDK (first-time only; repo rule 2 explicitly permits this dep here)
npm --prefix architect-language-tools/mcp install

# Smoke-test with the MCP Inspector
ARCH_LANG_ROOT=/abs/path/to/architect/source \
  npx @modelcontextprotocol/inspector \
  node architect-language-tools/mcp/index.js
```

The Inspector should list the nine shipped tools:
`list_symbols`, `list_includes`, `lookup_symbol`, `find_references`,
`find_impacts`, `list_literal_comparisons`, `validate_file`,
`lookup_description_code`, `list_suppressions`.

## Adding or modifying a tool

1. Ship the underlying function under `core/src/agentTools/` with its
   golden-file tests (see `core/src/agentTools/*.js` for pattern).
2. Add an entry to `TOOLS` in `tools.js` — `inputSchema` must cover only
   agent-facing fields. Server-side context (`workspaceRoot`,
   `documentRepository`, `descriptionCodesCache`) is injected by the `run`
   adapter and must never appear in the schema.
3. Keep `description` punchy but specific — agents choose tools from this
   string. Say what the tool returns and what the key parameters mean.

## Deferred: review band

The five review-band tools (`get_changed_files`, `get_file_diff`,
`validate_diff`, `get_previous_signature`, and the `{ref?}` mode of
`list_suppressions`) are parked pending file-explanation POC feedback. When
they land, git access is via shelling out (`git show`, `git diff`) using
internals reused from `cli/diffFilter.js` — no JS git library dep.

## Rule compliance

- No `vscode` import anywhere in this workspace — `core/` and `mcp/` are
  both headless.
- One runtime dep (`@modelcontextprotocol/sdk`). Do not add others without
  explicit review.
- stdout is reserved for MCP JSON-RPC framing. All diagnostics go to stderr
  via `logStderr()`.
