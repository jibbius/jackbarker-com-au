# MCP Server — Development

Stdio-transport MCP server that exposes `core/src/agentTools/*` as
Model Context Protocol tools. Read [../../planning/specs/option-b-targeted-query-tools.md](../../planning/specs/option-b-targeted-query-tools.md)
before making surface changes.

## Layout

| File | Purpose |
|---|---|
| `index.js` | Entry point. Loads config → supplementary module → document repository → description-codes cache → binds stdio transport and registers tools. |
| `tools.js` | Single source of truth for tool descriptors. Each entry has `name`, `description`, `inputSchema`, and `run(args, ctx)`. |
| `config.js` | Env-var and `.architect.json` loading. |
| `build.js` | esbuild call producing `dist/architect-mcp.js` — single ESM bundle with the SDK + zod tree-shaken in; first-party `../core/*` and `../connectors/*` left external. |
| `dist/architect-mcp.js` | Built artefact; what the vsix ships and what the VS Code provider spawns. Gitignored — rebuild via `npm run build` or the `Build MCP Bundle` task. |
| `package.json` | SDK and esbuild are devDependencies. Runtime deps are intentionally empty (repo rule 2). |
| `THIRD-PARTY-LICENCES.txt` | MIT notices for the bundled SDK + zod. |

## Configuration

| Env var | Purpose | Required |
|---|---|---|
| `ARCH_LANG_ROOT` | Absolute path to the Architect source tree. | Yes |
| `ARCH_LANG_CONFIG` | Absolute path to `.architect.json`. Falls back to `$ARCH_LANG_ROOT/.architect.json`. | No |
| `ARCH_LANG_CONN_SERVER` / `ARCH_LANG_CONN_DATABASE` | SQL Server connection used by the `refresh_description_codes` tool to repopulate the description-codes cache via PowerShell + Windows Integrated Auth. Required only when an agent needs to refresh; lookup-only deployments can omit them and rely on a pre-built cache. | No |
| `ARCH_LANG_DESCRIPTION_CACHE` | Absolute path to the description-codes cache JSON. Loaded at startup; also the destination written by `refresh_description_codes`. | No |
| `ARCH_LANG_LOG_PATH` | Absolute path to a log file. When set, every `[architect-mcp]` stderr line is also appended (with ISO timestamp). The VS Code provider sets this only when `architect.logging` is enabled. | No |

## Ordering contract

`registerSupplementary()` MUST run before the first tool handler is invoked.
`GlobalScope` in `core/src/analysis/symbolTable.js` lazily populates from
`BuiltInFunctions` on first use; anything registered after that point sits in
the builtin maps but is invisible to the resolved symbol table. `index.js`
loads the supplementary module immediately after config and before
`server.connect()`.

## Running locally

The MCP server is normally consumed via the VS Code extension's
`mcpServerProvider.js` (which spawns the bundle from `dist/`). The
recommended dev loop is **F5 → Extension Development Host**: the
`Build MCP Bundle` preLaunchTask rebuilds `dist/architect-mcp.js` first,
then the EDH launches with the provider registered.

For headless inspection without VS Code, the `MCP: Inspect Agent Tools
Server` task in `.vscode/tasks.json` runs the MCP Inspector against the
bundle (and depends on the build task, so it's always fresh). To run by
hand:

```sh
# First time: install SDK + esbuild as devDependencies
npm --prefix architect-language-tools/mcp install

# Build the bundle
npm --prefix architect-language-tools/mcp run build

# Smoke-test with the MCP Inspector
ARCH_LANG_ROOT=/abs/path/to/architect/source \
  npx @modelcontextprotocol/inspector \
  node architect-language-tools/mcp/dist/architect-mcp.js
```

The Inspector should list the shipped tools:
`list_files`, `list_symbols`, `list_includes`, `lookup_symbol`,
`find_references`, `find_impacts`, `list_literal_comparisons`,
`validate_file`, `lookup_description_code`, `refresh_description_codes`,
`list_suppressions`.

## Adding or modifying a tool

1. Ship the underlying function under `core/src/agentTools/` with its
   golden-file tests (see `core/src/agentTools/*.js` for pattern).
2. Add an entry to `TOOLS` in `tools.js` — `inputSchema` must cover only
   agent-facing fields. Server-side context (`workspaceRoot`,
   `documentRepository`, `descriptionCodesCache`) is injected by the `run`
   adapter and must never appear in the schema.
3. Keep `description` punchy but specific — agents choose tools from this
   string. Say what the tool returns and what the key parameters mean.

## Deferred: review band

The five review-band tools (`get_changed_files`, `get_file_diff`,
`validate_diff`, `get_previous_signature`, and the `{ref?}` mode of
`list_suppressions`) are parked pending file-explanation POC feedback. When
they land, git access is via shelling out (`git show`, `git diff`) using
internals reused from `cli/diffFilter.js` — no JS git library dep.

## Rule compliance

- No `vscode` import anywhere in this workspace — `core/` and `mcp/` are
  both headless.
- Zero runtime deps. The SDK is bundled into `dist/architect-mcp.js`
  via esbuild (devDependency); first-party `../core/*` and
  `../connectors/*` are kept external. Do not add new runtime deps
  without explicit review.
- stdout is reserved for MCP JSON-RPC framing. All diagnostics go to
  stderr via `logStderr()` (which also appends to `$ARCH_LANG_LOG_PATH`
  when set).
