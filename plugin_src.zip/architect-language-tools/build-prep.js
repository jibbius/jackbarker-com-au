/**
 * Build preparation script - captures build timestamp
 * Runs before packaging to embed build metadata
 */

import { execSync } from "child_process";
import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { generateDiagnosticDocs } from "./tools/generate-diagnostic-docs.js";
import { generateComprehensiveDiagnosticReference } from "./tools/generate-comprehensive-diagnostic-reference.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const packageJson = JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8"));

const timestamp = new Date().toISOString();
const epochTime = Date.now();

const metadata = {
  buildTime: timestamp,
  buildTimeEpoch: epochTime,
  version: packageJson.version
};

const outputPath = path.join(__dirname, 'core', 'src', 'build-metadata.json');
fs.writeFileSync(outputPath, JSON.stringify(metadata, null, 2));

generateDiagnosticDocs(path.join(__dirname, 'README.md'));
generateComprehensiveDiagnosticReference(path.join(__dirname, 'dev-docs', 'DIAGNOSTICS_COMPREHENSIVE_REFERENCE.md'));

execSync("node build.js", { cwd: path.join(__dirname, "mcp"), stdio: "inherit" });

console.log(`✓ Build metadata written: ${timestamp}`);
console.log("✓ Diagnostic catalog table refreshed in README.md");
console.log("✓ Comprehensive diagnostics reference refreshed in dev-docs/");
console.log("✓ MCP server bundle built at mcp/dist/architect-mcp.js");
