# Connectors — Context

External-system bridges. Today this is a single bridge: a SQL Server query for
description codes plus an on-disk cache that lets the IDE and the MCP agent
tools resolve description codes (e.g. on hover) without re-hitting the database.

The package is consumed by **two processes**:

- the **VS Code extension** (`vscode-extension/src/connectors/`) — reads the
  cache for hover lookup; writes it via the
  `architect.connectors.updateDescriptionCodesCache` command.
- the **MCP server** (`mcp/tools.js` → `core/src/agentTools/refreshDescriptionCodes.js`)
  — exposes a `refresh_description_codes` agent tool that writes the same cache.

Architecture rationale: the "Refined A" decision in
`planning/ideas/mcp-cache-architecture-review.md`. Both processes own the cache;
the atomic-write contract on `build()` keeps them safe from each other.

---

## What Lives Here

```
connectors/
├── index.js                         ← Public re-exports (queryDescriptionCodes, DescriptionCodesCache)
├── package.json                     ← `architect-language-tools-connectors`, no runtime deps
└── src/
    ├── SqlServerConnector.js        ← Spawns PowerShell or sqlcmd; returns raw rows
    └── DescriptionCodesCache.js     ← Atomic-write JSON cache; in-memory lookup map
```

No `vscode` imports. No runtime dependencies. Tests live in
`test/unit/connectors/`.

---

## Public API

```js
import { queryDescriptionCodes, DescriptionCodesCache } from 'architect-language-tools-connectors';
```

### `queryDescriptionCodes(server, database, options?)`

Returns `Promise<Array<{ g, t, c, d, x }>>`. Each row carries:

| Field | Meaning |
|---|---|
| `g` | description-code group |
| `t` | description-code type |
| `c` | description code |
| `d` | description text |
| `x` | deprecated flag (`'Y'` / `'N'`) |

`g`, `t`, `c` are required and must be non-empty strings — `parseRows` throws
otherwise so a SQL projection drift fails loudly at the connector boundary
rather than producing `"undefinedundefined"` cache keys downstream.

`options` (all optional):

| Option | Default | Purpose |
|---|---|---|
| `timeoutMs` | `30000` | Per-spawn timeout. On expiry the child is sent SIGTERM, then SIGKILL after a 2 s grace; the promise rejects with a distinct timeout error. |
| `maxBufferBytes` | `33554432` (32 MiB) | Total stdout+stderr cap. Overflow drives the same kill chain and rejects with an overflow error. |

The connector tries PowerShell + `System.Data.SqlClient` first (handles Windows
Auth natively). On failure it falls back to `sqlcmd` with `FOR JSON PATH`. The
PS script sets `[Console]::OutputEncoding = [System.Text.Encoding]::UTF8` so
non-ASCII description text survives the pipe; sqlcmd is invoked with
`-h -1 -W -f 65001`. Both error streams are captured; non-zero exit produces an
error message containing both stderr and stdout (each tail-truncated).

### `DescriptionCodesCache`

```js
const cache = new DescriptionCodesCache();

await cache.load(filePath);     // -> { ok, age, reason }
await cache.build(rows, server, database, filePath);
cache.lookup('MDStatus');       // -> Array<{ code, description, deprecated }>
cache.getStatus();              // -> { populated, fetchedAt, server, database }
cache.clear();
```

`load()` returns a `reason` discriminator so the caller can log distinct
messages:

| reason | Cause |
|---|---|
| `loaded` | Success. `ok: true`. |
| `missing` | File does not exist (ENOENT). |
| `unreadable` | Read failed for another reason (permissions, etc). |
| `invalid` | File present but not valid JSON, or schema shape wrong. |
| `stale-version` | `version` field does not match the current `CACHE_VERSION`. |

### Atomic-write contract

`build()` writes to `${filePath}.tmp` then `rename`s it into place. On the
write failing, the temp file is best-effort `unlink`ed and the original cache
at `filePath` is unchanged. The `rename` is the durable commit point.

Concurrent writers (extension + MCP server) are safe: both will produce a valid
final file; last writer wins. See `test/unit/connectors/DescriptionCodesCache.test.js`
for the contract.

---

## Configuration

Server and database are sourced **per-process**:

| Process | Source |
|---|---|
| VS Code extension | resolved `projectConfig.dbServer` / `dbDatabase` / `dbEncrypt` / `dbTrustServerCertificate` (CFG → `.architect.json` → `architect.dbServer`/`architect.dbDatabase`/`architect.dbEncrypt`/`architect.dbTrustServerCertificate` settings) |
| MCP server / CLI | resolved `projectConfig` (CFG → `.architect.json` → env vars `ARCH_LANG_DBSERVER` / `ARCH_LANG_DBDATABASE`) |

Cache file path is `context.globalStorageUri/description-codes-cache.json`
in the extension and `ARCH_LANG_DESCRIPTION_CACHE` in the MCP server.

Two config sources for one logical setting is by design — the MCP server runs
outside any VS Code window and cannot read VS Code settings. The "Refined A"
discussion in `planning/ideas/mcp-cache-architecture-review.md` weighs the
alternatives.

---

## Adding a Connector

When adding a second external bridge (e.g. a different reference table):

1. New file in `connectors/src/`. No `vscode` imports. No runtime deps.
2. Re-export from `index.js`.
3. Add a `DEVELOPMENT.md` row above (Public API + Configuration sections).
4. Add unit tests under `test/unit/connectors/`. Mock `child_process` via
   `jest.unstable_mockModule` if the bridge spawns a subprocess
   (see `SqlServerConnector.test.js`).
5. If the bridge is exposed as an agent tool, wire it through
   `core/src/agentTools/` and `mcp/tools.js` — keep all `vscode` access
   in `vscode-extension/`.
