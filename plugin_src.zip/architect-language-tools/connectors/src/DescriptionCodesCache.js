import { readFile, writeFile, mkdir, rename, unlink } from 'fs/promises';
import { dirname } from 'path';

const CACHE_VERSION = 1;

class DescriptionCodesCache {
    constructor() {
        this._map = new Map();
        this._status = { populated: false, fetchedAt: null, server: null, database: null };
    }

    async load(filePath) {
        let raw;
        try {
            raw = await readFile(filePath, 'utf8');
        } catch (err) {
            if (err && err.code === 'ENOENT') return { ok: false, age: null, reason: 'missing' };
            return { ok: false, age: null, reason: 'unreadable' };
        }
        let parsed;
        try {
            parsed = JSON.parse(raw);
        } catch {
            return { ok: false, age: null, reason: 'invalid' };
        }
        if (parsed.version !== CACHE_VERSION) {
            return { ok: false, age: null, reason: 'stale-version' };
        }
        if (!parsed.data || typeof parsed.data !== 'object') {
            return { ok: false, age: null, reason: 'invalid' };
        }
        this._populateMap(parsed.data);
        this._status = {
            populated: true,
            fetchedAt: parsed.fetchedAt,
            server: parsed.server,
            database: parsed.database
        };
        return { ok: true, age: Date.now() - new Date(parsed.fetchedAt).getTime(), reason: 'loaded' };
    }

    async build(rows, server, database, filePath) {
        const data = {};
        for (const row of rows) {
            const key = row.g + row.t;
            if (!data[key]) data[key] = [];
            data[key].push({
                code: row.c,
                description: row.d,
                deprecated: row.x === 'Y'
            });
        }

        const fetchedAt = new Date().toISOString();
        const cacheFile = { version: CACHE_VERSION, fetchedAt, server, database, data };

        await mkdir(dirname(filePath), { recursive: true });
        const tmpPath = `${filePath}.tmp`;
        try {
            await writeFile(tmpPath, JSON.stringify(cacheFile), 'utf8');
            await rename(tmpPath, filePath);
        } catch (err) {
            try { await unlink(tmpPath); } catch { /* best-effort cleanup */ }
            throw err;
        }

        this._populateMap(data);
        this._status = { populated: true, fetchedAt, server, database };
    }

    lookup(lookupCode) {
        return this._map.get(lookupCode) ?? [];
    }

    getStatus() {
        return { ...this._status };
    }

    clear() {
        this._map.clear();
        this._status = { populated: false, fetchedAt: null, server: null, database: null };
    }

    _populateMap(data) {
        this._map.clear();
        for (const [key, entries] of Object.entries(data)) {
            this._map.set(key, entries);
        }
    }
}

export { DescriptionCodesCache };
