import { spawn } from 'child_process';

const QUERY = 'SELECT CDz_Group, CDz_Description_Type, CDz_Description_Code, CDz_Description, CDc_Deleted FROM Description_Codes';

const DEFAULT_TIMEOUT_MS = 30_000;
const DEFAULT_MAX_BUFFER_BYTES = 32 * 1024 * 1024;
const KILL_GRACE_MS = 2_000;
const ERROR_TAIL_BYTES = 4_096;

function buildPsScript() {
    return [
        "$ErrorActionPreference = 'Stop'",
        '[Console]::OutputEncoding = [System.Text.Encoding]::UTF8',
        '$builder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder',
        "$builder['Server']             = $env:ARCH_LANG_CONN_SERVER",
        "$builder['Database']           = $env:ARCH_LANG_CONN_DATABASE",
        "$builder['Integrated Security'] = $true",
        '$conn = New-Object System.Data.SqlClient.SqlConnection $builder.ConnectionString',
        '$conn.Open()',
        '$cmd = $conn.CreateCommand()',
        `$cmd.CommandText = '${QUERY}'`,
        '$reader = $cmd.ExecuteReader()',
        '$rows = [System.Collections.Generic.List[object]]::new()',
        'while ($reader.Read()) {',
        '    $rows.Add(@{',
        '        g = $reader["CDz_Group"].Trim()',
        '        t = $reader["CDz_Description_Type"].Trim()',
        '        c = $reader["CDz_Description_Code"].Trim()',
        '        d = $reader["CDz_Description"].Trim()',
        '        x = $reader["CDc_Deleted"].Trim()',
        '    })',
        '}',
        '$conn.Close()',
        '$rows | ConvertTo-Json -Compress -Depth 1',
    ].join('\n');
}

function buildSqlcmdQuery() {
    return `SELECT RTRIM(CDz_Group) AS g, RTRIM(CDz_Description_Type) AS t, RTRIM(CDz_Description_Code) AS c, RTRIM(CDz_Description) AS d, RTRIM(CDc_Deleted) AS x FROM Description_Codes FOR JSON PATH`;
}

function tailDecoded(chunks, limitBytes) {
    const buf = Buffer.concat(chunks);
    const text = buf.toString('utf8').trim();
    if (text.length <= limitBytes) return text;
    return '…' + text.slice(-limitBytes);
}

function formatExitError(command, code, stdoutChunks, stderrChunks) {
    const errTail = tailDecoded(stderrChunks, ERROR_TAIL_BYTES);
    const outTail = tailDecoded(stdoutChunks, ERROR_TAIL_BYTES);
    const parts = [];
    if (errTail) parts.push(`stderr: ${errTail}`);
    if (outTail) parts.push(`stdout: ${outTail}`);
    const detail = parts.length ? ` — ${parts.join(' | ')}` : '';
    return new Error(`${command} exited with code ${code}${detail}`);
}

function spawnProcess(command, args, options) {
    const env = options && options.env;
    const timeoutMs = (options && options.timeoutMs) || DEFAULT_TIMEOUT_MS;
    const maxBufferBytes = (options && options.maxBufferBytes) || DEFAULT_MAX_BUFFER_BYTES;

    return new Promise((resolve, reject) => {
        const proc = spawn(command, args, { env });
        const stdoutChunks = [];
        const stderrChunks = [];
        let totalBytes = 0;
        let settled = false;
        let timedOut = false;
        let overflowed = false;
        let killHandle = null;

        const startKillChain = () => {
            try { proc.kill('SIGTERM'); } catch (_) { /* already gone */ }
            killHandle = setTimeout(() => {
                try { proc.kill('SIGKILL'); } catch (_) { /* already gone */ }
            }, KILL_GRACE_MS);
        };

        const timeoutHandle = setTimeout(() => {
            timedOut = true;
            startKillChain();
        }, timeoutMs);

        const finish = fn => {
            if (settled) return;
            settled = true;
            clearTimeout(timeoutHandle);
            if (killHandle) clearTimeout(killHandle);
            fn();
        };

        const collect = (chunks, chunk) => {
            totalBytes += chunk.length;
            if (totalBytes > maxBufferBytes) {
                if (!overflowed) {
                    overflowed = true;
                    startKillChain();
                }
                return;
            }
            chunks.push(chunk);
        };

        proc.stdout.on('data', chunk => collect(stdoutChunks, chunk));
        proc.stderr.on('data', chunk => collect(stderrChunks, chunk));
        proc.on('error', err => finish(() => reject(err)));
        proc.on('close', code => finish(() => {
            if (timedOut) {
                reject(new Error(`${command} timed out after ${timeoutMs} ms`));
                return;
            }
            if (overflowed) {
                reject(new Error(`${command} output exceeded ${maxBufferBytes} bytes`));
                return;
            }
            if (code !== 0) {
                reject(formatExitError(command, code, stdoutChunks, stderrChunks));
                return;
            }
            resolve(Buffer.concat(stdoutChunks).toString('utf8'));
        }));
    });
}

function parseRows(stdout) {
    const text = stdout.trim();
    if (!text || text === 'null') return [];
    let parsed = JSON.parse(text);
    if (!Array.isArray(parsed)) parsed = [parsed];
    for (let i = 0; i < parsed.length; i++) {
        const row = parsed[i];
        if (!row || typeof row !== 'object') {
            throw new Error(`Row ${i} is not an object`);
        }
        for (const field of ['g', 't', 'c']) {
            const v = row[field];
            if (typeof v !== 'string' || v.length === 0) {
                throw new Error(`Row ${i} missing required field "${field}"`);
            }
        }
    }
    return parsed;
}

function stripSqlcmdFooter(stdout) {
    return stdout.replace(/\r?\n\(\d+ rows? affected\)\s*$/m, '');
}

async function queryDescriptionCodes(server, database, options = {}) {
    const env = { ...process.env, ARCH_LANG_CONN_SERVER: server, ARCH_LANG_CONN_DATABASE: database };
    const spawnOptions = {
        env,
        timeoutMs: options.timeoutMs || DEFAULT_TIMEOUT_MS,
        maxBufferBytes: options.maxBufferBytes || DEFAULT_MAX_BUFFER_BYTES
    };

    // Primary: PowerShell via System.Data.SqlClient (handles Windows Auth natively)
    try {
        const script = buildPsScript();
        const encoded = Buffer.from(script, 'utf16le').toString('base64');
        const stdout = await spawnProcess(
            'powershell',
            ['-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded],
            spawnOptions
        );
        return parseRows(stdout);
    } catch (psError) {
        // Fallback: sqlcmd with FOR JSON PATH (requires SQL Server 2016+)
        try {
            const query = buildSqlcmdQuery();
            const stdout = await spawnProcess(
                'sqlcmd',
                ['-S', server, '-d', database, '-E', '-Q', query, '-h', '-1', '-W', '-f', '65001'],
                spawnOptions
            );
            const stripped = stripSqlcmdFooter(stdout);
            const match = stripped.match(/^[ \t]*\[[\s\S]*\]\s*$/m);
            if (!match) throw new Error('sqlcmd returned no JSON output');
            return parseRows(match[0]);
        } catch (sqlcmdError) {
            throw new Error(`PowerShell: ${psError.message} | sqlcmd: ${sqlcmdError.message}`);
        }
    }
}

export { queryDescriptionCodes };
