import { spawn } from 'child_process';

const QUERY = 'SELECT CDz_Group, CDz_Description_Type, CDz_Description_Code, CDz_Description, CDc_Deleted FROM Description_Codes';

const DEFAULT_TIMEOUT_MS = 30_000;
const DEFAULT_MAX_BUFFER_BYTES = 32 * 1024 * 1024;
const KILL_GRACE_MS = 2_000;
const ERROR_TAIL_BYTES = 4_096;

// Defaults mirror the connector's historical internal-network posture
// (Encrypt=No, TrustServerCertificate=Yes). Exposed as options on
// queryDescriptionCodes so projectConfig can override per workspace.
const DEFAULT_ENCRYPT = false;
const DEFAULT_TRUST_SERVER_CERT = true;

function buildPsScript(encrypt, trustServerCertificate) {
    // TLS posture is now configurable via options (Brief 9). Defaults preserve
    // the connector's historical behaviour: internal-network SQL Server boxes
    // accessed via Windows Integrated auth, where the data on the wire
    // (description-code metadata) is non-sensitive and the server commonly
    // presents a self-signed cert. We pass JS booleans through to PowerShell
    // as $true / $false literals so the wire posture is explicit (not
    // dependent on a future System.Data.SqlClient default flip).
    const encryptLit = encrypt ? '$true' : '$false';
    const trustLit = trustServerCertificate ? '$true' : '$false';
    return [
        "$ErrorActionPreference = 'Stop'",
        '[Console]::OutputEncoding = [System.Text.Encoding]::UTF8',
        '$builder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder',
        // Internal JS↔PowerShell protocol; double-underscore prefix signals
        // private. Not the same as the external `ARCH_LANG_DBSERVER` env var.
        "$builder['Server']                  = $env:__ARCH_PS_SERVER",
        "$builder['Database']                = $env:__ARCH_PS_DATABASE",
        "$builder['Integrated Security']     = $true",
        `$builder['Encrypt']                 = ${encryptLit}`,
        `$builder['TrustServerCertificate']  = ${trustLit}`,
        '$conn = New-Object System.Data.SqlClient.SqlConnection $builder.ConnectionString',
        '$conn.Open()',
        '$cmd = $conn.CreateCommand()',
        `$cmd.CommandText = '${QUERY}'`,
        '$reader = $cmd.ExecuteReader()',
        '$rows = [System.Collections.Generic.List[object]]::new()',
        'while ($reader.Read()) {',
        '    $rows.Add(@{',
        '        g = $reader["CDz_Group"].Trim()',
        '        t = $reader["CDz_Description_Type"].Trim()',
        '        c = $reader["CDz_Description_Code"].Trim()',
        '        d = $reader["CDz_Description"].Trim()',
        '        x = $reader["CDc_Deleted"].Trim()',
        '    })',
        '}',
        '$conn.Close()',
        '$rows | ConvertTo-Json -Compress -Depth 1',
    ].join('\n');
}

function buildSqlcmdQuery() {
    return `SELECT RTRIM(CDz_Group) AS g, RTRIM(CDz_Description_Type) AS t, RTRIM(CDz_Description_Code) AS c, RTRIM(CDz_Description) AS d, RTRIM(CDc_Deleted) AS x FROM Description_Codes FOR JSON PATH`;
}

function buildSqlcmdArgs(server, database, query, options) {
    // Required argv first.
    const args = ['-S', server, '-d', database, '-E'];
    // -C trusts the server cert (ODBC Driver 18+ default is
    // TrustServerCertificate=No, so this is needed for self-signed certs on
    // internal boxes). Omit when caller has explicitly opted out.
    if (options.trustServerCertificate) {
        args.push('-C');
    }
    // Encrypt opt-out on sqlcmd is ambiguous across driver versions:
    // classic sqlcmd's `-N` enables encrypted login (a different semantic),
    // while go-sqlcmd's `-N false` controls connection encryption. Until
    // we can pin which sqlcmd ships with the deployment we leave the
    // encrypt flag unset on this fallback path — ODBC Driver 18 will
    // default to Encrypt=Yes, which is the safer wire posture. If the
    // caller explicitly requested encrypt=false and the fallback path is
    // taken, the connection will still encrypt; this is flagged for
    // runtime validation. See Brief 9 report.
    args.push('-Q', query, '-h', '-1', '-W', '-f', '65001');
    return args;
}

function tailDecoded(chunks, limitBytes) {
    const buf = Buffer.concat(chunks);
    const text = buf.toString('utf8').trim();
    if (text.length <= limitBytes) return text;
    return '…' + text.slice(-limitBytes);
}

function formatExitError(command, code, stdoutChunks, stderrChunks) {
    const errTail = tailDecoded(stderrChunks, ERROR_TAIL_BYTES);
    const outTail = tailDecoded(stdoutChunks, ERROR_TAIL_BYTES);
    const parts = [];
    if (errTail) parts.push(`stderr: ${errTail}`);
    if (outTail) parts.push(`stdout: ${outTail}`);
    const detail = parts.length ? ` — ${parts.join(' | ')}` : '';
    return new Error(`${command} exited with code ${code}${detail}`);
}

function spawnProcess(command, args, options) {
    const env = options && options.env;
    const timeoutMs = (options && options.timeoutMs) || DEFAULT_TIMEOUT_MS;
    const maxBufferBytes = (options && options.maxBufferBytes) || DEFAULT_MAX_BUFFER_BYTES;

    return new Promise((resolve, reject) => {
        const proc = spawn(command, args, { env });
        const stdoutChunks = [];
        const stderrChunks = [];
        let totalBytes = 0;
        let settled = false;
        let timedOut = false;
        let overflowed = false;
        let killHandle = null;

        const startKillChain = () => {
            try { proc.kill('SIGTERM'); } catch (_) { /* already gone */ }
            killHandle = setTimeout(() => {
                try { proc.kill('SIGKILL'); } catch (_) { /* already gone */ }
            }, KILL_GRACE_MS);
        };

        const timeoutHandle = setTimeout(() => {
            timedOut = true;
            startKillChain();
        }, timeoutMs);

        const finish = fn => {
            if (settled) return;
            settled = true;
            clearTimeout(timeoutHandle);
            if (killHandle) clearTimeout(killHandle);
            fn();
        };

        const collect = (chunks, chunk) => {
            totalBytes += chunk.length;
            if (totalBytes > maxBufferBytes) {
                if (!overflowed) {
                    overflowed = true;
                    startKillChain();
                }
                return;
            }
            chunks.push(chunk);
        };

        proc.stdout.on('data', chunk => collect(stdoutChunks, chunk));
        proc.stderr.on('data', chunk => collect(stderrChunks, chunk));
        proc.on('error', err => finish(() => reject(err)));
        proc.on('close', code => finish(() => {
            if (timedOut) {
                reject(new Error(`${command} timed out after ${timeoutMs} ms`));
                return;
            }
            if (overflowed) {
                reject(new Error(`${command} output exceeded ${maxBufferBytes} bytes`));
                return;
            }
            if (code !== 0) {
                reject(formatExitError(command, code, stdoutChunks, stderrChunks));
                return;
            }
            resolve(Buffer.concat(stdoutChunks).toString('utf8'));
        }));
    });
}

// Short keys (g/t/c/d/x) are used on the wire to keep the JSON payload small
// across the spawn boundary (~3000 rows in production). Map back to the
// underlying column names whenever a value flows out as a diagnostic, so
// nothing downstream has to recognise the shorthand.
const FIELD_NAMES = {
    g: 'CDz_Group',
    t: 'CDz_Description_Type',
    c: 'CDz_Description_Code',
    d: 'CDz_Description',
    x: 'CDc_Deleted'
};

function describeRowProblem(row, index) {
    if (!row || typeof row !== 'object') {
        return `row ${index}: not an object`;
    }
    // CDz_Group and CDz_Description_Type are mandatory. CDz_Description_Code
    // is allowed to be blank ('') — the DB has rows of that shape.
    for (const field of ['g', 't']) {
        const v = row[field];
        if (typeof v !== 'string' || v.length === 0) {
            return `row ${index}: missing required column ${FIELD_NAMES[field]}`;
        }
    }
    if (typeof row.c !== 'string') {
        return `row ${index}: column ${FIELD_NAMES.c} is not a string`;
    }
    return null;
}

function parseRows(stdout) {
    const text = stdout.trim();
    if (!text || text === 'null') return { rows: [], skipped: [] };
    let parsed = JSON.parse(text);
    if (!Array.isArray(parsed)) parsed = [parsed];
    const rows = [];
    const skipped = [];
    for (let i = 0; i < parsed.length; i++) {
        const problem = describeRowProblem(parsed[i], i);
        if (problem) {
            skipped.push(problem);
        } else {
            rows.push(parsed[i]);
        }
    }
    return { rows, skipped };
}

function stripSqlcmdFooter(stdout) {
    return stdout.replace(/\r?\n\(\d+ rows? affected\)\s*$/m, '');
}

/**
 * @param {string} server
 * @param {string} database
 * @param {object} [options]
 * @param {boolean} [options.encrypt=false]                 Encrypt the connection.
 * @param {boolean} [options.trustServerCertificate=true]   Trust self-signed certs.
 * @param {number}  [options.timeoutMs]
 * @param {number}  [options.maxBufferBytes]
 */
async function queryDescriptionCodes(server, database, options = {}) {
    const encrypt = typeof options.encrypt === 'boolean' ? options.encrypt : DEFAULT_ENCRYPT;
    const trustServerCertificate = typeof options.trustServerCertificate === 'boolean'
        ? options.trustServerCertificate
        : DEFAULT_TRUST_SERVER_CERT;

    // Internal JS↔PS env-var protocol. Double-underscore prefix signals
    // private; these are not the externally documented `ARCH_LANG_DBSERVER`
    // / `ARCH_LANG_DBDATABASE` env vars (those are MCP-tier overrides
    // that flow into projectConfig, not values consumed by the spawned
    // PowerShell process).
    const env = { ...process.env, __ARCH_PS_SERVER: server, __ARCH_PS_DATABASE: database };
    const spawnOptions = {
        env,
        timeoutMs: options.timeoutMs || DEFAULT_TIMEOUT_MS,
        maxBufferBytes: options.maxBufferBytes || DEFAULT_MAX_BUFFER_BYTES
    };

    // Primary: PowerShell via System.Data.SqlClient (handles Windows Auth natively)
    try {
        const script = buildPsScript(encrypt, trustServerCertificate);
        const encoded = Buffer.from(script, 'utf16le').toString('base64');
        const stdout = await spawnProcess(
            'powershell',
            ['-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded],
            spawnOptions
        );
        return parseRows(stdout);
    } catch (psError) {
        // Fallback: sqlcmd with FOR JSON PATH (requires SQL Server 2016+)
        try {
            const query = buildSqlcmdQuery();
            const args = buildSqlcmdArgs(server, database, query, { encrypt, trustServerCertificate });
            const stdout = await spawnProcess('sqlcmd', args, spawnOptions);
            const stripped = stripSqlcmdFooter(stdout);
            const match = stripped.match(/^[ \t]*\[[\s\S]*\]\s*$/m);
            if (!match) throw new Error('sqlcmd returned no JSON output');
            return parseRows(match[0]);
        } catch (sqlcmdError) {
            throw new Error(`PowerShell: ${psError.message} | sqlcmd: ${sqlcmdError.message}`);
        }
    }
}

export { queryDescriptionCodes };
