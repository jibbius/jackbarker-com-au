/**
 * Suppression comment parser for Architect diagnostic overrides.
 *
 * Supported syntax:
 *   // @rule-ignore ACU-XXX-NNN
 *   // @rule-ignore ACU-XXX-NNN ACU-YYY-NNN   (multiple IDs)
 *   // @rule-ignore ACU-XXX-NNN REASON: some explanation
 *
 * The comment must appear on the line IMMEDIATELY ABOVE the offending code.
 * Diagnostic IDs must follow the PREFIX-DOMAIN-NNN format (e.g. ACU-VAR-001,
 * EMP-STY-002). Core rules use the ACU- prefix; supplementary rules use any
 * other uppercase prefix.
 * The REASON: clause and any trailing text are ignored by the parser.
 */

/** @type {RegExp} Matches the opening of a `// @rule-ignore` comment; body is captured for downstream parsing. */
const RULE_IGNORE_OPEN_RE = /^\s*\/\/\s*@rule-ignore\b(.*)$/i;

/** @type {RegExp} Validates individual rule ID tokens (core ACU-* or supplementary PREFIX-*) */
const RULE_ID_RE = /^[A-Z]+-[A-Z]+-\d{3}$/i;

/** @type {RegExp} Splits a body into a token-list portion and a trailing REASON clause. */
const REASON_SPLIT_RE = /^(.*?)\bREASON\s*:\s*(.*?)\s*$/i;

/**
 * @typedef {object} SuppressionComment
 * @property {number} commentLineIndex 0-based line index of the `// @rule-ignore` comment.
 * @property {string[]} ruleIds Uppercased PREFIX-DOMAIN-NNN tokens that parsed cleanly.
 * @property {string[]} invalidTokens Tokens in the body that did not match the rule-id shape.
 * @property {string|null} reason Trailing REASON clause body, if present.
 */

/**
 * Scan a document for suppression comments and return a record per comment.
 * This is the structured form used by the agent surface; `buildSuppressionMap`
 * is a thin reduction over the same scan for runtime suppression checks.
 *
 * @param {import('vscode').TextDocument} document
 * @returns {SuppressionComment[]}
 */
function scanSuppressionComments(document) {
    const records = [];

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex++) {
        const lineText = document.lineAt(lineIndex).text;
        const match = RULE_IGNORE_OPEN_RE.exec(lineText);
        if (!match) {
            continue;
        }

        const body = (match[1] ?? "").trim();
        let tokensPart = body;
        let reason = null;
        const reasonSplit = REASON_SPLIT_RE.exec(body);
        if (reasonSplit) {
            tokensPart = reasonSplit[1].trim();
            reason = reasonSplit[2];
        }

        const tokens = tokensPart.length > 0
            ? tokensPart.split(/\s+/).filter((t) => t.length > 0)
            : [];
        const ruleIds = [];
        const invalidTokens = [];
        for (const tok of tokens) {
            if (RULE_ID_RE.test(tok)) {
                ruleIds.push(tok.toUpperCase());
            } else {
                invalidTokens.push(tok);
            }
        }

        records.push({ commentLineIndex: lineIndex, ruleIds, invalidTokens, reason });
    }

    return records;
}

/**
 * Parse suppression comments from a document and build a suppression map.
 * Each `// @rule-ignore ACU-XXX-NNN` on line N suppresses those rule IDs on line N+1.
 *
 * @param {import('vscode').TextDocument} document
 * @returns {Map<number, Set<string>>} Map of 0-based line index → set of suppressed messageIds
 */
function buildSuppressionMap(document) {
    const suppressions = new Map();

    for (const record of scanSuppressionComments(document)) {
        if (record.ruleIds.length === 0) {
            continue;
        }
        const targetLine = record.commentLineIndex + 1;
        if (targetLine >= document.lineCount) {
            continue;
        }
        if (!suppressions.has(targetLine)) {
            suppressions.set(targetLine, new Set());
        }
        record.ruleIds.forEach((id) => suppressions.get(targetLine).add(id));
    }

    return suppressions;
}

/**
 * Check whether a diagnostic should be suppressed.
 *
 * @param {string} messageId  - Diagnostic message ID, e.g. "ACU-IND-001"
 * @param {number} lineIndex  - 0-based line index of the diagnostic
 * @param {Map<number, Set<string>>} suppressionMap - From buildSuppressionMap()
 * @returns {boolean}
 */
function isSuppressed(messageId, lineIndex, suppressionMap) {
    const set = suppressionMap.get(lineIndex);
    return set !== undefined && set.has(messageId.toUpperCase());
}

export {
    buildSuppressionMap,
    isSuppressed,
    scanSuppressionComments
};
