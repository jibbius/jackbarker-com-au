/**
 * Whole-document scan for the names of every function call.
 *
 * Walks the document AST, parses each value-bearing token span, and visits
 * every CALL node to collect callee names. Duplicates are preserved (one
 * entry per occurrence) — callers that only want the unique set should
 * deduplicate themselves.
 *
 * Used by the discovery / Robodoc-precursor command to find call names
 * that are not already known builtins / declared functions / macros.
 *
 * Replaces the prior `parseFunctionCalls(text)` regex scan in lineParser.js.
 * The AST version makes "function name appearing inside a string literal"
 * structurally unrepresentable, instead of relying on a text-mask pre-pass.
 */

import { buildDocumentAst } from "../ast/documentAst.js";
import { parseExpression } from "../ast/expressionParser.js";
import { collectAllSpans, walkCalls } from "../ast/astHelpers.js";

/**
 * @param {object} document - TextDocument (VS Code, PlainTextDocument, or test shim)
 * @returns {string[]} callee names, in source order, with duplicates preserved
 */
function collectCallNames(document) {
    const { ast } = buildDocumentAst(document);
    const spans = collectAllSpans(ast.statements);
    const names = [];
    for (const { span } of spans) {
        const expr = parseExpression(span);
        walkCalls(expr, (call) => {
            const name = call.callee?.name;
            if (name) names.push(name);
        });
    }
    return names;
}

export { collectCallNames };
