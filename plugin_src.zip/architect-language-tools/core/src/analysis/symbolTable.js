/**
 * Symbol table and scope hierarchy for Architect.
 *
 * Two-phase analysis foundation:
 *   Phase 1 — build a scope chain populated with all declarations.
 *   Phase 2 — validators call symbolTable.resolve(name, lineIndex) instead
 *             of constructing flat-map lookup keys. Migration completed
 *             2026-04-14.
 *
 * Scope hierarchy per document:
 *   GlobalScope  — built-in functions and variables (singleton, shared across all docs)
 *     └── FileScope    — module-level variables, macros, and function definitions
 *           └── FunctionScope (one per FUNCTION...ENDFUNCTION)
 *
 * Limitations:
 *   resolve() does not traverse #include directives. Callers that need to
 *   see included symbols must consult facts.includedVariablesByLine and
 *   facts.includedFunctionsByLine separately.
 *
 * Usage:
 *   const table = buildSymbolTable(ast, document.lineCount);
 *   const sym = table.resolve('MY_VAR', lineIndex);
 */

import { NodeType } from '../ast/nodes.js';
import { walkStatements } from '../ast/astHelpers.js';
import { BuiltInFunctions } from '../builtins/functionsRegistry.js';
import { BuiltInGlobalVariables } from '../builtins/globalVariablesRegistry.js';

// ---------------------------------------------------------------------------
// Scope class
// ---------------------------------------------------------------------------

/**
 * A single scope in the symbol table chain.
 *
 * @property {'global'|'file'|'function'} kind
 * @property {Scope|null} parent
 * @property {Map<string, object>} symbols  — keyed by upper-case name
 */
class Scope {
    /**
     * @param {'global'|'file'|'function'} kind
     * @param {Scope|null} parent
     */
    constructor(kind, parent = null) {
        this.kind = kind;
        this.parent = parent;
        this.symbols = new Map();
    }

    /**
     * Registers a symbol in this scope and sets its back-reference.
     * First-write wins. When a symbol with the same upperName already exists,
     * returns that existing symbol (so callers can detect duplicates without
     * re-walking the AST). Otherwise returns the symbol just inserted.
     *
     * @param {object} symbol
     * @returns {object} the resident symbol for that upperName (existing on collision, else `symbol`)
     */
    define(symbol) {
        const existing = this.symbols.get(symbol.upperName);
        if (existing !== undefined) return existing;
        this.symbols.set(symbol.upperName, symbol);
        symbol.scope = this;
        return symbol;
    }

    /**
     * Resolves a name by walking up the parent chain.
     * Returns null when the name is not found in any enclosing scope.
     * @param {string} name
     * @returns {object|null}
     */
    resolve(name) {
        const upper = name.toUpperCase();
        const sym = this.symbols.get(upper);
        if (sym !== undefined) return sym;
        if (this.parent !== null) return this.parent.resolve(name);
        return null;
    }
}

// ---------------------------------------------------------------------------
// GlobalScope singleton
// ---------------------------------------------------------------------------

/** @type {Scope|null} */
let _globalScope = null;

/**
 * Returns the module-level GlobalScope, creating it on first call.
 * Populated from the built-in functions and global-variables registries.
 *
 * The result is cached. Call `resetGlobalScope()` after mutating the
 * registries (e.g. supplementary-module registration) or between tests
 * that mock the registries via `jest.unstable_mockModule`.
 * @returns {Scope}
 */
function getGlobalScope() {
    if (_globalScope !== null) return _globalScope;

    _globalScope = new Scope('global', null);

    for (const [name, sig] of Object.entries(BuiltInFunctions)) {
        const upperName = name.toUpperCase();
        _globalScope.define({
            upperName,
            declaredName: name,
            kind: 'builtin',
            type: sig.returns || null,
            scope: null,
            line: null,
            params: sig.params || [],
            varArgs: !!sig.varArgs,
            returnType: sig.returns || null,
            isParam: false,
        });
    }

    for (const [name, meta] of Object.entries(BuiltInGlobalVariables)) {
        const upperName = name.toUpperCase();
        _globalScope.define({
            upperName,
            declaredName: name,
            kind: 'builtin-var',
            type: meta.type || null,
            scope: null,
            line: null,
            params: null,
            returnType: null,
            isParam: false,
        });
    }

    return _globalScope;
}

/**
 * Clears the GlobalScope cache so the next `getGlobalScope()` call rebuilds
 * it from the current registry contents. Intended for tests and for the
 * supplementary-module loader after late registration.
 */
function resetGlobalScope() {
    _globalScope = null;
}

// ---------------------------------------------------------------------------
// FileScope / FunctionScope construction
// ---------------------------------------------------------------------------

/**
 * Locates the matching `EndFunctionStatement` for a `FunctionDeclaration`
 * sitting at `fnIndex` in `siblings`. Returns both the line and the column of
 * the ENDFUNCTION keyword. Falls back to `{ line: lineCount - 1, char: null }`
 * when no ENDFUNCTION is found in this sibling list (unclosed function).
 * @param {object[]} siblings
 * @param {number} fnIndex
 * @param {number} lineCount
 * @returns {{line:number, char:number|null}}
 */
function findFunctionEnd(siblings, fnIndex, lineCount) {
    for (let j = fnIndex + 1; j < siblings.length; j++) {
        if (siblings[j].type === NodeType.EndFunctionStatement) {
            return { line: siblings[j].line, char: siblings[j].keywordChar ?? null };
        }
    }
    return { line: lineCount - 1, char: null };
}

/**
 * Collects variable declarations from a statement list into a scope,
 * without crossing FunctionDeclaration boundaries. Records the parser's
 * identifier offset (`name.char`) onto each symbol so consumers don't have
 * to re-tokenise the declaration line.
 * @param {object[]} statements
 * @param {Scope} scope
 */
function collectVarsIntoScope(statements, scope) {
    walkStatements(statements, stmt => {
        if (stmt.type === NodeType.FunctionDeclaration) return false; // don't cross function boundaries
        if (stmt.type === NodeType.VarStatement) {
            for (const { name, char } of stmt.names) {
                scope.define({
                    upperName: name.toUpperCase(),
                    declaredName: name,
                    kind: 'variable',
                    type: stmt.varType || null,
                    scope: null,
                    line: stmt.line,
                    nameStart: char ?? null,
                    nameEnd: char != null ? char + name.length : null,
                    params: null,
                    returnType: null,
                    isParam: false,
                });
            }
        }
    });
}

/**
 * Populates a FileScope by walking the top-level AST statements. Recurses
 * into nested block bodies (IF / CASE / DO ...) so that declarations inside
 * `IF NOT SYMBOL("name")` guard patterns are still captured at module level.
 *
 * Also builds the canonical functionScopes array — one entry per FUNCTION
 * declaration. Each entry exposes both the symbol-table view (`scope`) and
 * the legacy documentFacts view (`id`, `params:Map`, `locals:Map`,
 * `returnType`) so a single record serves both consumer styles.
 *
 * @param {object[]} statements   — ast.statements or a nested block body
 * @param {Scope} fileScope
 * @param {Array} functionScopes
 * @param {number} lineCount      — total document lines (fallback for unclosed functions)
 */
function populateFileScope(statements, fileScope, functionScopes, lineCount) {
    walkStatements(statements, (stmt, i, siblings) => {
        if (stmt.type === NodeType.VarStatement) {
            for (const { name, char } of stmt.names) {
                fileScope.define({
                    upperName: name.toUpperCase(),
                    declaredName: name,
                    kind: 'variable',
                    type: stmt.varType || null,
                    scope: null,
                    line: stmt.line,
                    nameStart: char ?? null,
                    nameEnd: char != null ? char + name.length : null,
                    params: null,
                    returnType: null,
                    isParam: false,
                });
            }
            return; // VarStatement has no nested statement bodies
        }

        if (stmt.type === NodeType.MacroDeclaration) {
            fileScope.define({
                upperName: stmt.name.toUpperCase(),
                declaredName: stmt.name,
                kind: 'macro',
                type: null,
                scope: null,
                line: stmt.line,
                params: stmt.params || [],
                returnType: null,
                isParam: false,
            });
            return;
        }

        if (stmt.type === NodeType.FunctionDeclaration) {
            fileScope.define({
                upperName: stmt.name.toUpperCase(),
                declaredName: stmt.name,
                kind: 'function',
                type: stmt.returnType || null,
                scope: null,
                line: stmt.line,
                params: stmt.params || [],
                returnType: stmt.returnType || null,
                isParam: false,
            });

            const { line: endLine, char: endKeywordChar } = findFunctionEnd(siblings, i, lineCount);
            const fnScope = new Scope('function', fileScope);

            for (const param of (stmt.params || [])) {
                fnScope.define({
                    upperName: param.name.toUpperCase(),
                    declaredName: param.name,
                    kind: 'param',
                    type: param.type || null,
                    scope: null,
                    line: stmt.line,
                    nameStart: param.nameStart ?? null,
                    nameEnd: param.nameEnd ?? null,
                    params: null,
                    returnType: null,
                    isParam: true,
                });
            }

            collectVarsIntoScope(stmt.body || [], fnScope);

            // Derive Map views for legacy facts.functionScopes consumers.
            const paramsMap = new Map(
                (stmt.params || []).map(p => [p.name, p.type || null])
            );
            const localsMap = new Map();
            for (const sym of fnScope.symbols.values()) {
                if (sym.kind === 'variable') {
                    localsMap.set(sym.declaredName, sym.type);
                }
            }

            functionScopes.push({
                id: functionScopes.length,
                scope: fnScope,
                startLine: stmt.line,
                endLine,
                endKeywordChar,
                name: stmt.name,
                upperName: stmt.name.toUpperCase(),
                params: paramsMap,
                locals: localsMap,
                returnType: stmt.returnType || null,
            });

            return false; // function bodies are walked above; do not let walkStatements descend
        }

        // All other statement types: let walkStatements recurse into their nested bodies
        // so module-level guard patterns like `IF NOT SYMBOL(...) ... ENDIF` are captured.
    });
}

// ---------------------------------------------------------------------------
// Per-line lookup
// ---------------------------------------------------------------------------

/**
 * Returns the function-scope record whose [startLine, endLine] range contains
 * `lineIndex`, or `null` when the line is not inside any function. Uses
 * binary search — `functionScopes` is emitted in source order, so the array
 * is sorted by `startLine` and the ranges are non-overlapping (Architect
 * does not nest FUNCTION declarations).
 *
 * @param {Array<{startLine:number,endLine:number}>} functionScopes
 * @param {number} lineIndex
 * @returns {object|null}
 */
function findFunctionScopeAtLine(functionScopes, lineIndex) {
    let lo = 0;
    let hi = functionScopes.length - 1;
    while (lo <= hi) {
        const mid = (lo + hi) >> 1;
        const fs = functionScopes[mid];
        if (lineIndex < fs.startLine) {
            hi = mid - 1;
        } else if (lineIndex > fs.endLine) {
            lo = mid + 1;
        } else {
            return fs;
        }
    }
    return null;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Builds a symbol table for a parsed document AST.
 *
 * Returns an object with:
 *   globalScope     — the shared GlobalScope (read-only)
 *   fileScope       — the document's FileScope
 *   functionScopes  — array of {id, scope, startLine, endLine, name, upperName, params:Map, locals:Map, returnType}
 *   resolve(name, lineIndex) — resolves a name from the scope active at lineIndex
 *
 * @param {object} ast         — document AST from buildDocumentAst()
 * @param {number} lineCount   — document.lineCount
 * @returns {{
 *   globalScope: Scope,
 *   fileScope: Scope,
 *   functionScopes: Array,
 *   resolve: (name: string, lineIndex: number) => object|null
 * }}
 */
function buildSymbolTable(ast, lineCount) {
    const globalScope = getGlobalScope();
    const fileScope = new Scope('file', globalScope);
    const functionScopes = [];

    populateFileScope(ast.statements || [], fileScope, functionScopes, lineCount);

    return {
        globalScope,
        fileScope,
        functionScopes,

        /**
         * Resolves a name from the scope active at the given line.
         * Checks the enclosing FunctionScope first, then FileScope, then GlobalScope.
         * Does not traverse #include directives (see module Limitations).
         * @param {string} name
         * @param {number} lineIndex — 0-based
         * @returns {object|null}
         */
        resolve(name, lineIndex) {
            const entry = findFunctionScopeAtLine(functionScopes, lineIndex);
            const startScope = entry ? entry.scope : fileScope;
            return startScope.resolve(name);
        }
    };
}

export { Scope, getGlobalScope, resetGlobalScope, buildSymbolTable, findFunctionScopeAtLine };
