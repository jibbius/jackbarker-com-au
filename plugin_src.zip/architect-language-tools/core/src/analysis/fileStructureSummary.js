import { NodeType } from '../ast/nodes.js';
import { walkStatements } from '../ast/astHelpers.js';
import { TokenType } from '../lexer/tokenTypes.js';
import { getHelpPage } from '../builtins/helpRegistry.js';

// Matches field handle naming convention: two uppercase letters + type char + underscore
// e.g. MDc_Account_Status, ABz_Client_Name, CDl_Code
const FIELD_HANDLE_RE = /^[A-Z]{2}[A-Za-z]_/;

const COMPARISON_OPS = new Set([
    TokenType.EQUALS, TokenType.NOT_EQ,
    TokenType.LT, TokenType.GT, TokenType.LT_EQ, TokenType.GT_EQ
]);

function isFieldHandle(name) {
    return FIELD_HANDLE_RE.test(name);
}

function meaningfulTokens(span) {
    return (span?.tokens ?? []).filter(
        t => t.type !== TokenType.WHITESPACE && t.type !== TokenType.COMMENT
    );
}

function spansForStatement(stmt) {
    const spans = [];
    if (stmt.condition) spans.push(stmt.condition);
    if (stmt.value)     spans.push(stmt.value);
    return spans;
}

function extractFieldHandleUsages(ast, globalSymbols) {
    const handlesSeen = new Map(); // upperName → { handle, line }
    const comparisons = [];

    walkStatements(ast.statements, stmt => {
        // Assignment targets can also be field handles
        if (
            (stmt.type === NodeType.AssignStatement || stmt.type === NodeType.SetStatement) &&
            stmt.target && isFieldHandle(stmt.target) &&
            !globalSymbols?.has(stmt.target.toUpperCase())
        ) {
            const key = stmt.target.toUpperCase();
            if (!handlesSeen.has(key)) {
                handlesSeen.set(key, { handle: stmt.target, line: stmt.line + 1 });
            }
        }

        for (const span of spansForStatement(stmt)) {
            const tokens = meaningfulTokens(span);

            for (let i = 0; i < tokens.length; i++) {
                const tok = tokens[i];

                if (tok.type === TokenType.IDENTIFIER && isFieldHandle(tok.value)) {
                    // Exclude builtin functions/variables that happen to match the pattern
                    if (globalSymbols?.has(tok.value.toUpperCase())) continue;

                    const key = tok.value.toUpperCase();
                    if (!handlesSeen.has(key)) {
                        handlesSeen.set(key, { handle: tok.value, line: stmt.line + 1 });
                    }
                }

                if (COMPARISON_OPS.has(tok.type) && i > 0 && i < tokens.length - 1) {
                    const left  = tokens[i - 1];
                    const right = tokens[i + 1];

                    if (left.type === TokenType.IDENTIFIER && isFieldHandle(left.value) &&
                        !globalSymbols?.has(left.value.toUpperCase()) &&
                        right.type === TokenType.STRING_LITERAL) {
                        comparisons.push({
                            handle: left.value,
                            operator: tok.value,
                            value: right.value.replace(/^["']|["']$/g, ''),
                            line: stmt.line + 1
                        });
                    } else if (right.type === TokenType.IDENTIFIER && isFieldHandle(right.value) &&
                               !globalSymbols?.has(right.value.toUpperCase()) &&
                               left.type === TokenType.STRING_LITERAL) {
                        comparisons.push({
                            handle: right.value,
                            operator: tok.value,
                            value: left.value.replace(/^["']|["']$/g, ''),
                            line: stmt.line + 1
                        });
                    }
                }
            }
        }
    });

    return {
        fieldHandles: Array.from(handlesSeen.values()),
        literalComparisons: comparisons
    };
}

function extractBuiltinFunctionsCalled(ast, globalSymbols) {
    if (!globalSymbols) return [];

    const seen = new Set();
    const result = [];

    function record(name) {
        const upper = name.toUpperCase();
        if (seen.has(upper)) return;
        const sym = globalSymbols.get(upper);
        if (!sym || sym.kind !== 'builtin') return;
        seen.add(upper);
        result.push({ name: sym.declaredName, helpFile: getHelpPage(upper) ?? null });
    }

    walkStatements(ast.statements, stmt => {
        // Top-level standalone function call statements
        if (stmt.type === NodeType.FunctionCallStatement && stmt.name) {
            record(stmt.name);
        }

        // Function calls inside expression token spans (assignment RHS, conditions)
        for (const span of spansForStatement(stmt)) {
            const tokens = meaningfulTokens(span);
            for (let i = 0; i < tokens.length - 1; i++) {
                if (tokens[i].type === TokenType.IDENTIFIER &&
                    tokens[i + 1].type === TokenType.LPAREN) {
                    record(tokens[i].value);
                }
            }
        }
    });

    return result.sort((a, b) => a.name.localeCompare(b.name));
}

/**
 * Builds a human-readable structural summary of an Architect file from its
 * pre-computed document facts.
 *
 * Intended for agent tool calls and developer inspection — not for validation.
 *
 * @param {object} facts - Result of collectDocumentFacts()
 * @returns {object} Structural summary suitable for JSON serialisation
 */
function buildFileStructureSummary(facts) {
    const { ast, symbolTable, userDefinedFunctionCatalog, macroCatalog } = facts;
    const globalSymbols = symbolTable?.globalScope?.symbols;

    // File-scope variable declarations (excludes built-ins, params, and functions)
    const variables = [];
    if (symbolTable?.fileScope) {
        for (const sym of symbolTable.fileScope.symbols.values()) {
            if (sym.kind === 'variable') {
                variables.push({ name: sym.declaredName, type: sym.type, line: sym.line + 1 });
            }
        }
        variables.sort((a, b) => a.line - b.line);
    }

    // User-defined functions with full signatures
    const functions = Object.values(userDefinedFunctionCatalog)
        .map(fn => ({
            name: fn.declaredName,
            params: (fn.params || []).map(p => ({ name: p.name, type: p.type })),
            returnType: fn.returnType || null,
            line: fn.lineIndex + 1
        }))
        .sort((a, b) => a.line - b.line);

    // Macro declarations
    const macros = Object.values(macroCatalog)
        .map(m => ({
            name: m.declaredName,
            params: (m.params || []).map(p => (typeof p === 'string' ? p : p.name)),
            line: m.lineIndex + 1
        }))
        .sort((a, b) => a.line - b.line);

    // Include / require directives
    const includes = [];
    walkStatements(ast.statements, stmt => {
        if (stmt.type === NodeType.IncludeDirective) {
            includes.push({ filename: stmt.filename, kind: 'include', line: stmt.line + 1 });
        } else if (stmt.type === NodeType.RequireDirective) {
            includes.push({ filename: stmt.filename, kind: 'require', line: stmt.line + 1 });
        }
    });

    const { fieldHandles, literalComparisons } = extractFieldHandleUsages(ast, globalSymbols);
    const builtinFunctionsCalled = extractBuiltinFunctionsCalled(ast, globalSymbols);

    return {
        variables,
        functions,
        macros,
        includes,
        builtinFunctionsCalled,
        fieldHandlesReferenced: fieldHandles,
        literalComparisons
    };
}

export { buildFileStructureSummary };
