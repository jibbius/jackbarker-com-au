/**
 * String-context helpers — single source of truth for "scan a line while
 * skipping over string literals".
 *
 * BEFORE REACHING FOR THIS HELPER: consider whether the AST at
 * `core/src/ast/parser.js` would give you what you want directly. The
 * AST already understands string literals natively — a CallExpression
 * node knows which arguments are StringLiteral vs Identifier without
 * any masking, and an expression tree exposes identifier nodes. This
 * module exists to retrofit string-awareness onto regex-based scans
 * that don't have it; if you can route your check through the AST
 * instead, prefer that. See planning/ideas/ast-migration-of-string-mask-callers.md
 * for the catalogue of current callers and which could migrate.
 *
 * Legitimate uses (where the AST genuinely doesn't help):
 *   - Whitespace-sensitive checks (operator spacing) — the AST throws
 *     whitespace away.
 *   - Output-line interpolation scans — the AST doesn't model the
 *     content of `>>` output lines.
 *   - Quick-fix rename helpers that operate on the active document
 *     text rather than the analysed AST.
 *
 * Architect string-literal contract (locked in by the language spec):
 *   - Two delimiter forms: '...' and "..." (cannot nest the same kind).
 *   - No backslash escapes. A backslash is just a backslash.
 *   - No doubled-quote escaping (e.g. "" inside a "-string is two empty
 *     strings, not an escaped quote). Treated as out of scope until a
 *     real fixture says otherwise.
 *   - An unterminated quote masks to end of line — matches the historical
 *     behaviour of lineParser.stripQuotedStrings, which several callers
 *     rely on.
 *
 * Quote characters themselves are masked (replaced with a space) so that
 * downstream regexes don't accidentally match them as identifier
 * boundaries or operator characters.
 *
 * All exports here share one state machine — extending the contract
 * (e.g. doubled-quote escaping) means updating one place.
 */

/**
 * Replace string-literal characters (including the delimiters) with spaces.
 * Length-preserving: indices into the result line up with indices into
 * the input. Use this when the caller wants to scan a line for tokens
 * but ignore anything inside a string literal.
 *
 * @param {string} text
 * @returns {string}
 */
function maskStringLiterals(text) {
    let result = "";
    let inSingle = false;
    let inDouble = false;

    for (let i = 0; i < text.length; i += 1) {
        const ch = text[i];

        if (ch === "'" && !inDouble) {
            inSingle = !inSingle;
            result += " ";
            continue;
        }

        if (ch === '"' && !inSingle) {
            inDouble = !inDouble;
            result += " ";
            continue;
        }

        if (inSingle || inDouble) {
            result += " ";
        } else {
            result += ch;
        }
    }

    return result;
}

/**
 * Like maskStringLiterals, but additionally masks `//` line comments
 * (the `//` itself and everything after it on the line).
 *
 * Use when scanning for identifiers that should be replaced or matched
 * only in code — e.g. quick-fix renames that must not rewrite the
 * user's prose inside a comment.
 *
 * Quote state is tracked across the whole line, so `//` inside a string
 * literal is not treated as a comment, and a quote inside a comment is
 * not treated as opening a string. Length-preserving.
 *
 * @param {string} text
 * @returns {string}
 */
function maskStringLiteralsAndComments(text) {
    let result = "";
    let inSingle = false;
    let inDouble = false;

    for (let i = 0; i < text.length; i += 1) {
        const ch = text[i];

        if (!inSingle && !inDouble && ch === "/" && text[i + 1] === "/") {
            // Mask the rest of the line as comment.
            for (let j = i; j < text.length; j += 1) result += " ";
            return result;
        }

        if (ch === "'" && !inDouble) {
            inSingle = !inSingle;
            result += " ";
            continue;
        }

        if (ch === '"' && !inSingle) {
            inDouble = !inDouble;
            result += " ";
            continue;
        }

        if (inSingle || inDouble) {
            result += " ";
        } else {
            result += ch;
        }
    }

    return result;
}

export { maskStringLiterals, maskStringLiteralsAndComments };
