/**
 * Usercalc-context detection for the REQUIRE directive.
 *
 * REQUIRE is a Usercalc-only directive: the runtime accepts it only inside
 * the Usercalc reports directory (canonical name `USRCALCS`, per the
 * Acurity.CFG `USRCALCDIRECTORY` setting). Outside that directory the
 * runtime rejects REQUIRE with "Expected a line command keyword".
 *
 * This module classifies a file path by parent directory. The directory
 * name is exposed as a parameter so a future .CFG reader can substitute
 * the project's actual `USRCALCDIRECTORY` value (see
 * `planning/ideas/acurity-cfg-config-source.md`); for now the documented
 * default of `"USRCALCS"` (case-insensitive) is used.
 */

const DEFAULT_USRCALC_DIRECTORY = "USRCALCS";

/**
 * Returns true iff a segment of `filePath` equals `usrcalcDirectory`,
 * compared case-insensitively. Both `/` and `\` are accepted as
 * separators. Returns false for null/undefined/empty paths so editor
 * scratch buffers (no fileName) are treated as "unknown" rather than
 * raising a false positive.
 *
 * @param {string|null|undefined} filePath
 * @param {{ usrcalcDirectory?: string }} [options]
 * @returns {boolean}
 */
function isUsercalcReport(filePath, options = {}) {
    if (typeof filePath !== "string" || filePath.length === 0) return false;
    const target = (options.usrcalcDirectory ?? DEFAULT_USRCALC_DIRECTORY).toLowerCase();
    if (target.length === 0) return false;
    const segments = filePath.split(/[\\/]+/);
    for (const segment of segments) {
        if (segment.toLowerCase() === target) return true;
    }
    return false;
}

export { isUsercalcReport, DEFAULT_USRCALC_DIRECTORY };
