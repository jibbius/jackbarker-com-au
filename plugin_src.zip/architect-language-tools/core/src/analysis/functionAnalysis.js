/**
 * Shared function analysis helpers.
 *
 * Historical note: this module previously contained regex-based implementations
 * of buildFunctionScopes, buildUserDefinedFunctionCatalog, and
 * findDuplicateFunctionDeclarations. These have been superseded by the AST-based
 * equivalents in documentFacts.js and were removed in the v2 review remediation.
 *
 * What remains:
 *   getFunctionScopeAtLine      — pure lookup, no parsing dependency
 *   findBuiltinCollisionDeclarations — no AST equivalent yet; stays here until
 *                                      documentFacts.js grows a builtinCollisions fact
 */

import { parseFunctionDeclaration } from "../lineParser.js";
import { BuiltInFunctions } from "../builtins/functions.js";
import { NodeType } from "../ast/nodes.js";
import { findFunctionScopeAtLine } from "./symbolTable.js";

/**
 * If `condition` is an `IF NOT SYMBOL("name")` condition token list,
 * returns the upper-cased guarded name. Otherwise returns null.
 * @param {object|null} condition
 * @returns {string|null}
 */
function getSymbolGuardName(condition) {
    if (!condition || !condition.tokens) return null;
    const text = condition.tokens.map((t) => t.value).join("").replace(/\s+/g, " ").trim();
    const m = text.match(/^NOT\s*SYMBOL\s*\(\s*['"]([^'"]+)['"]\s*\)/i);
    return m ? m[1].toUpperCase() : null;
}

/**
 * Walks AST statements, passing an accumulated guard-name set downward through
 * `IF NOT SYMBOL("name")` blocks. The visitor receives (stmt, guardedNames).
 * Only the consequent of a guard IF inherits the guard name; the alternate does not.
 * @param {object[]} statements
 * @param {Set<string>} guardedNames  Upper-cased names currently guarded
 * @param {Function} visitor          (stmt: object, guardedNames: Set<string>) => void
 */
function walkWithGuardContext(statements, guardedNames, visitor) {
    for (const stmt of statements) {
        if (stmt.type === NodeType.IfStatement) {
            const guardName = getSymbolGuardName(stmt.condition);
            const innerGuarded = guardName ? new Set([...guardedNames, guardName]) : guardedNames;
            if (Array.isArray(stmt.consequent)) walkWithGuardContext(stmt.consequent, innerGuarded, visitor);
            if (Array.isArray(stmt.alternate))  walkWithGuardContext(stmt.alternate,  guardedNames, visitor);
        } else {
            visitor(stmt, guardedNames);
            if (Array.isArray(stmt.body))        walkWithGuardContext(stmt.body,      guardedNames, visitor);
            if (stmt.branches) {
                for (const b of stmt.branches) {
                    if (Array.isArray(b.body))   walkWithGuardContext(b.body,         guardedNames, visitor);
                }
            }
            if (Array.isArray(stmt.otherwise))   walkWithGuardContext(stmt.otherwise, guardedNames, visitor);
        }
    }
}

/**
 * Builds a map from line index to the set of built-in names guarded at that line
 * by an `IF NOT SYMBOL("name")` block. Only lines inside such a guard are included.
 *
 * @param {object} document
 * @returns {Map<number, Set<string>>} line index → Set of upper-cased guarded names
 */
function buildSymbolGuardedNamesByLine(document) {
    const guardedByLine = new Map();
    const symbolGuardStack = [];
    const controlFlowStack = [];

    for (let i = 0; i < document.lineCount; i++) {
        const trimmed = document.lineAt(i).text.trim();
        const guardMatch = trimmed.match(/^IF\s+NOT\s*SYMBOL\s*\(\s*['"]([^'"]+)['"]\s*\)/i);
        if (guardMatch) {
            symbolGuardStack.push(guardMatch[1].toUpperCase());
            controlFlowStack.push(true);
        } else if (/^IF\b/i.test(trimmed)) {
            controlFlowStack.push(false);
        } else if (/^ENDIF\b/i.test(trimmed)) {
            const wasGuard = controlFlowStack.pop();
            if (wasGuard && symbolGuardStack.length > 0) {
                symbolGuardStack.pop();
            }
        }
        if (symbolGuardStack.length > 0) {
            guardedByLine.set(i, new Set(symbolGuardStack));
        }
    }

    return guardedByLine;
}

/**
 * Gets the function scope that contains a line. Binary-search wrapper —
 * delegates to `findFunctionScopeAtLine` (kept here as a stable import for
 * existing callers).
 * @param {Array} functionScopes - Scope list (from facts.functionScopes)
 * @param {number} lineIndex - 0-based line index
 * @returns {object|null}
 */
function getFunctionScopeAtLine(functionScopes, lineIndex) {
    return findFunctionScopeAtLine(functionScopes, lineIndex);
}

/**
 * Finds user-defined function declarations that collide with built-in function names.
 * A declaration is exempt when it is wrapped in `IF NOT SYMBOL('name') ... ENDIF`
 * where 'name' matches the declared function name (case-insensitive).
 * @param {object} document
 * @returns {Array<{functionName:string,lineIndex:number,isCollision:boolean}>}
 */
function findBuiltinCollisionDeclarations(document) {
    const result = [];
    const guardedByLine = buildSymbolGuardedNamesByLine(document);

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex += 1) {
        const lineText = document.lineAt(lineIndex).text;
        const declaration = parseFunctionDeclaration(lineText);
        if (!declaration) continue;
        if (!(declaration.upperName in BuiltInFunctions)) continue;

        const guardedNames = guardedByLine.get(lineIndex);
        const isSymbolGuarded = guardedNames?.has(declaration.upperName) ?? false;

        result.push({
            functionName: declaration.upperName,
            lineIndex,
            isCollision: !isSymbolGuarded
        });
    }

    return result;
}

export {
    getFunctionScopeAtLine,
    findBuiltinCollisionDeclarations,
    buildSymbolGuardedNamesByLine,
    getSymbolGuardName,
    walkWithGuardContext
};
