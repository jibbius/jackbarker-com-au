/**
 * Output-positioning directive call-site checks.
 *
 * Output-positioning directives (CENTER, COL, FROM, TAB, TO) use function-call
 * syntax but are not functions — they are formatting instructions only valid
 * between OICC/CICC delimiters on output lines. The function-call scanner in
 * `validators/functionValidator.js` calls `validateOutputDirective` whenever a
 * resolved call has `kind === "output-directive"`.
 *
 * Lives in `analysis/` (not `validators/`) because it does not follow the
 * `(document, getRuleSeverity, options) → diagnostics[]` document-validator
 * shape — it is a per-call helper that mutates a diagnostics array passed in
 * by the caller.
 *
 * ACU-OUT-001  outputDirectiveInCodeContext
 *   Fires when a directive is called outside an output-line context.
 *
 * ACU-OUT-002  outputDirectiveArgumentCount
 *   Fires when the wrong number of arguments is supplied.
 *
 * ACU-OUT-003  outputDirectiveColumnRange
 *   Fires when the column argument is outside the valid range (1–16000).
 */

import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";
import { TokenType } from "../lexer/tokenTypes.js";

const COLUMN_MIN = 1;
const COLUMN_MAX_DEFAULT = 16000;

function addDiagnostic(diagnostics, range, messageId, params, getRuleSeverity) {
    const diag = createDiagnostic(range, { messageId, params }, getRuleSeverity);
    if (diag) diagnostics.push(diag);
}

/**
 * Validates argument count and column range for an output-positioning directive call.
 * Only called when the directive is in a valid output-line context.
 *
 * @param {boolean}       hasClosingParen - Whether the call has a matching closing paren
 * @param {number}        argCount        - Number of arguments passed
 * @param {object|null}   firstArgToken   - First argument token (for column range check), or null
 * @param {number}        lineIndex
 * @param {number}        actualCharPos   - Character offset of the directive name in the original line
 * @param {string}        functionName
 * @param {object}        signature       - Registry signature entry
 * @param {object[]}      diagnostics
 * @param {Function}      getRuleSeverity
 * @param {number}        [pagewidth]     - Active PAGEWIDTH setting (default: 16000)
 */
function validateOutputDirectiveShape(
    hasClosingParen,
    argCount,
    firstArgToken,
    lineIndex,
    actualCharPos,
    functionName,
    signature,
    diagnostics,
    getRuleSeverity,
    pagewidth
) {
    if (!hasClosingParen) {
        // Unclosed parentheses — the directive call is malformed; skip further checks.
        return;
    }

    const expectedCount = signature.params.length;
    // Range covers the directive name and its opening paren.
    const rangeEnd = actualCharPos + functionName.length + 1;

    if (argCount !== expectedCount) {
        addDiagnostic(
            diagnostics,
            { start: { line: lineIndex, character: actualCharPos }, end: { line: lineIndex, character: rangeEnd } },
            "ACU-OUT-002",
            { name: functionName.toUpperCase(), expected: expectedCount, actual: argCount },
            getRuleSeverity
        );
        return;
    }

    // Column/count range check: if the first argument is a plain integer literal,
    // verify it is within 1..pagewidth (defaults to PAGEWIDTH_MAX when not specified).
    if (firstArgToken?.type === TokenType.NUMBER_LITERAL && /^\d+$/.test(firstArgToken.value)) {
        const colValue = parseInt(firstArgToken.value, 10);
        const columnMax = (typeof pagewidth === "number" && pagewidth >= COLUMN_MIN) ? pagewidth : COLUMN_MAX_DEFAULT;
        if (colValue < COLUMN_MIN || colValue > columnMax) {
            addDiagnostic(
                diagnostics,
                { start: { line: lineIndex, character: actualCharPos }, end: { line: lineIndex, character: rangeEnd } },
                "ACU-OUT-003",
                { value: colValue, max: columnMax },
                getRuleSeverity
            );
        }
    }
}

/**
 * Validates an output-positioning directive call site.
 *
 * Call this from the function-call scanner whenever a token resolves to
 * kind === "output-directive". Handles both context-mismatch (ACU-OUT-001)
 * and shape validation (ACU-OUT-002/003) in one place.
 *
 * @param {boolean}     hasClosingParen  - Whether the call has a matching closing paren
 * @param {number}      argCount         - Number of arguments passed
 * @param {object|null} firstArgToken    - First argument token (for column range check)
 * @param {number}      lineIndex        - Zero-based line number
 * @param {number}      actualCharPos    - Character offset of the directive name in the original line
 * @param {string}      functionName     - The directive name as written in source
 * @param {object}      knownFunction    - Registry entry (kind, signature)
 * @param {boolean}     isFromOutputLine - Whether the call site is inside OICC/CICC delimiters
 * @param {object[]}    diagnostics      - Array to push diagnostics into
 * @param {Function}    getRuleSeverity  - Severity resolver
 * @param {number}      [pagewidth]      - Active PAGEWIDTH setting (default: 16000)
 */
function validateOutputDirective(
    hasClosingParen,
    argCount,
    firstArgToken,
    lineIndex,
    actualCharPos,
    functionName,
    knownFunction,
    isFromOutputLine,
    diagnostics,
    getRuleSeverity,
    pagewidth
) {
    if (!isFromOutputLine) {
        addDiagnostic(
            diagnostics,
            { start: { line: lineIndex, character: actualCharPos }, end: { line: lineIndex, character: actualCharPos + functionName.length } },
            "ACU-OUT-001",
            { name: functionName.toUpperCase() },
            getRuleSeverity
        );
        return;
    }
    validateOutputDirectiveShape(
        hasClosingParen, argCount, firstArgToken,
        lineIndex, actualCharPos,
        functionName, knownFunction.signature,
        diagnostics, getRuleSeverity, pagewidth
    );
}

export { validateOutputDirective };
