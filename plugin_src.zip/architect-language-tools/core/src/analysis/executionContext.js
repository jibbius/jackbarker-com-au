/**
 * Shared execution-context helpers for validators.
 */

import { stripTrailingComment, parseIncludeDirective } from "../lineParser.js";
import { maskStringLiterals } from "./stringContext.js";
import { NodeType } from "../ast/nodes.js";
import { TokenType } from "../lexer/tokenTypes.js";
import { walkStatements } from "../ast/astHelpers.js";

/**
 * Extracts output interpretation delimiters (OICC/CICC) from #OPTION lines.
 * Defaults to "@" when not specified.
 *
 * @param {import("vscode").TextDocument} document - The document to analyze
 * @returns {{oicc: string, cicc: string}}
 */
function extractOutputDelimiters(document) {
    let oicc = "@";
    let cicc = "@";

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex += 1) {
        const lineText = document.lineAt(lineIndex).text;
        const optionMatch = lineText.match(/^\s*#?\s*OPTION\s+OICC\s*=\s*["'](.?)["']\s*,\s*CICC\s*=\s*["'](.?)["']/i);
        if (optionMatch) {
            oicc = optionMatch[1];
            cicc = optionMatch[2];
            break;
        }
    }

    return { oicc, cicc };
}

function escapeRegexCharacter(character) {
    return character.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Extracts code content from an output line with position tracking.
 *
 * @param {string} lineText - The output line text
 * @param {string} oicc - Output interpretation open character
 * @param {string} cicc - Output interpretation close character
 * @returns {Array<{snippet: string, position: number}>}
 */
function extractCodeFromOutputLineWithPositions(lineText, oicc, cicc) {
    const codeSnippets = [];
    const escapedOicc = escapeRegexCharacter(oicc);
    const escapedCicc = escapeRegexCharacter(cicc);
    const regex = new RegExp(`${escapedOicc}([^${escapedOicc}${escapedCicc}]*)${escapedCicc}`, "g");
    let match;

    while ((match = regex.exec(lineText)) !== null) {
        if (match[1].trim()) {
            codeSnippets.push({
                snippet: match[1],
                position: match.index + 1
            });
        }
    }

    return codeSnippets;
}

/**
 * Text-pattern fallback: returns true when a raw line string looks like executable code.
 * Used only when no AST node is available for a line (e.g. lines before the first parsed
 * block, or lines the parser could not classify). For lines with AST nodes, prefer
 * node-specific classification instead of calling this function.
 *
 * @param {string} lineText - Line text with trailing comments removed
 * @returns {boolean}
 */
function hasCodePattern(lineText) {
    const trimmed = lineText.trim();
    if (!trimmed) {
        return false;
    }

    // Comments are executable (for classification purposes)
    if (trimmed.startsWith("//")) {
        return true;
    }

    if (/^(option|newinterpreter|var|set|if|else|endif|while|do|forever|until|enddo|case|value|otherwise|of|endcase|break|continue|return|macro|function|endfunction|include|includeonce|includetest|require|exit|end-of-code|header|body|footer|hash-on|hash-off)\b/i.test(trimmed)) {
        return true;
    }

    // Alternate variable declaration syntax: TYPE varName [, varName...]
    // Recognizes: STRING, SHORT, LONG, DATE, DOUBLE, BOOLEAN, TIME, INTEGER, BIGINT
    if (/^(string|short|long|date|double|boolean|time|integer|bigint)\s+[A-Za-z_][A-Za-z0-9_]*(\s*,\s*[A-Za-z_][A-Za-z0-9_]*)*\s*$/i.test(trimmed)) {
        return true;
    }

    if (/^[A-Za-z_][A-Za-z0-9_]*\s*(\+|-|\*|\/)?=/.test(trimmed)) {
        return true;
    }

    if (/\b[A-Za-z_][A-Za-z0-9_]*\s*\(/.test(trimmed)) {
        return true;
    }

    return false;
}

/**
 * Determines which code targets from a line should be function-validated.
 *
 * @param {string} lineText - Line text with trailing comments removed
 * @param {{oicc: string, cicc: string}} outputDelimiters - Active output delimiters
 * @returns {Array<{snippet:string, position:number}>}
 */
function getFunctionValidationTargetsForLine(lineText, outputDelimiters, options = {}) {
    const { oicc, cicc } = outputDelimiters;
    const { isOutputLine = false } = options;

    if (isOutputLine) {
        return extractCodeFromOutputLineWithPositions(lineText, oicc, cicc);
    }

    if (/^\s*#/.test(lineText)) {
        // NOTE-style comments (#NOTE / # NOTE) are comment text, not executable code.
        if (/^\s*#\s*NOTE\b/i.test(lineText)) {
            return [];
        }
        // INCLUDE-family lines: the argument is a filepath, not an expression.
        if (parseIncludeDirective(lineText)) {
            return [];
        }
        return [{ snippet: lineText, position: 0 }];
    }

    // INCLUDE-family lines in HASH-OFF mode.
    if (parseIncludeDirective(lineText)) {
        return [];
    }

    const codeSnippetsWithPos = extractCodeFromOutputLineWithPositions(lineText, oicc, cicc);
    if (codeSnippetsWithPos.length > 0) {
        return codeSnippetsWithPos;
    }

    if (hasCodePattern(lineText)) {
        return [{ snippet: lineText, position: 0 }];
    }

    return [];
}

/**
 * Pre-computes function-validation targets per line.
 *
 * @param {import("vscode").TextDocument} document - The document to analyze
 * @param {{oicc: string, cicc: string}} outputDelimiters - Active output delimiters
 * @returns {Array<Array<{snippet:string, position:number}>>}
 */
function buildFunctionValidationTargetsByLine(document, outputDelimiters, outputLineMap = null) {
    const targetsByLine = new Array(document.lineCount);
    const effectiveOutputLineMap = outputLineMap || buildOutputLineMap(document);

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex += 1) {
        const rawLineText = document.lineAt(lineIndex).text;
        const lineText = stripTrailingComment(rawLineText);
        targetsByLine[lineIndex] = getFunctionValidationTargetsForLine(lineText, outputDelimiters, {
            isOutputLine: effectiveOutputLineMap[lineIndex]
        });
    }

    return targetsByLine;
}

/**
 * Extracts interpolation targets from an output line.
 *
 * @param {string} lineText - Raw line text
 * @returns {Array<{variableName:string, startPos:number, endPos:number, hasClosing:boolean, isFunctionLike:boolean}>}
 */
function getInterpolationTargetsForLine(lineText, outputDelimiters = { oicc: "@", cicc: "@" }) {
    const targets = [];
    const seen = new Set();
    const { oicc, cicc } = outputDelimiters;
    const identifierPattern = /[A-Za-z_][A-Za-z0-9_]*/g;

    // Trailing `// …` on an output line is a comment — ignore it so delimiters inside
    // the comment text cannot accidentally pair with an unclosed opener.
    const scanText = stripTrailingComment(lineText);

    let cursor = 0;
    while (cursor < scanText.length) {
        const openIdx = scanText.indexOf(oicc, cursor);
        if (openIdx === -1) {
            break;
        }

        const contentStart = openIdx + oicc.length;

        // String-skipping is scoped to the interpolation content only.
        // Quote characters that appear in the surrounding output text are not
        // string-literal delimiters — only the ones inside the interpolation
        // are. Masking the whole line would obliterate `^...^` regions that
        // sit inside HTML-like attribute quoting (e.g. `content="^zVar^"`).
        // Using the shared state-machine stripper here keeps the scan
        // consistent with the other call sites (see extractCallArgBounds).
        const tail = scanText.substring(contentStart);
        const maskedTail = maskStringLiterals(tail);
        const closeRel = maskedTail.indexOf(cicc);

        if (closeRel === -1) {
            // Unclosed region — report the opener, using the first identifier (if any)
            // as the variableName for the diagnostic message.
            const idMatch = tail.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)/);
            if (idMatch) {
                const variableName = idMatch[1];
                const idStart = contentStart + idMatch[0].length - variableName.length;
                const endPos = idStart + variableName.length;
                const isFunctionLike = /^\s*\(/.test(maskedTail.substring(idStart - contentStart + variableName.length));
                targets.push({
                    variableName,
                    startPos: openIdx,
                    endPos,
                    hasClosing: false,
                    isFunctionLike
                });
            }
            break;
        }

        const closeIdx = contentStart + closeRel;

        // Closed region — extract identifiers from the masked content;
        // string-literal bodies are blanked so no in-string identifiers leak.
        const stripped = maskedTail.substring(0, closeRel);

        identifierPattern.lastIndex = 0;
        let idMatch;
        while ((idMatch = identifierPattern.exec(stripped)) !== null) {
            const variableName = idMatch[0];
            const startPos = contentStart + idMatch.index;
            const endPos = startPos + variableName.length;
            const isFunctionLike = /^\s*\(/.test(maskedTail.substring(idMatch.index + variableName.length));
            const key = `${startPos}:${endPos}:${variableName}`;
            if (seen.has(key)) {
                continue;
            }
            seen.add(key);
            targets.push({
                variableName,
                startPos,
                endPos,
                hasClosing: true,
                isFunctionLike
            });
        }

        cursor = closeIdx + cicc.length;
    }

    return targets;
}

/**
 * Pre-computes interpolation targets for output lines.
 * Non-output lines are returned as empty arrays for consistent indexing.
 *
 * @param {import("vscode").TextDocument} document - The document to analyze
 * @param {boolean[]} outputLineMap - Output-line flags by line index
 * @returns {Array<Array<{variableName:string, startPos:number, endPos:number, hasClosing:boolean, isFunctionLike:boolean}>>}
 */
function buildInterpolationTargetsByLine(document, outputLineMap, outputDelimiters = { oicc: "@", cicc: "@" }) {
    const targetsByLine = new Array(document.lineCount);

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex += 1) {
        if (!outputLineMap[lineIndex]) {
            targetsByLine[lineIndex] = [];
            continue;
        }

        const lineText = document.lineAt(lineIndex).text;
        targetsByLine[lineIndex] = getInterpolationTargetsForLine(lineText, outputDelimiters);
    }

    return targetsByLine;
}

/**
 * Checks if a line ends with `...` (multi-line continuation marker).
 * The `...` must appear before any comment.
 *
 * @param {string} lineText - The raw line text
 * @returns {boolean}
 */
function isLineWithContinuation(lineText) {
    const trimmed = lineText.trim();
    if (!trimmed) {
        return false;
    }

    // Strip trailing comment first to check for ... before comment
    let commentStart = lineText.indexOf("//");
    let inString = false;
    let stringChar = null;

    for (let i = 0; i < lineText.length; i++) {
        const char = lineText[i];
        if (char === '"' || char === "'") {
            if (!inString) {
                inString = true;
                stringChar = char;
            } else if (char === stringChar) {
                inString = false;
            }
        }
        if (!inString && char === "/" && i + 1 < lineText.length && lineText[i + 1] === "/") {
            commentStart = i;
            break;
        }
    }

    const beforeComment = commentStart >= 0 ? lineText.substring(0, commentStart) : lineText;
    return /\.\.\.\s*$/.test(beforeComment);
}

/**
 * Returns the language-default hash mode for reports.
 * Architect semantics: reports begin in HASH-ON until HASH-OFF is encountered.
 *
 * @returns {'HASH-ON'}
 */
function getDefaultHashMode() {
    return 'HASH-ON';
}

/**
 * Builds a map of lines that should be treated as output text.
 *
 * @param {import("vscode").TextDocument} document - The document to analyze
 * @returns {boolean[]}
 */
function buildOutputLineMap(document) {
    const outputLineMap = new Array(document.lineCount).fill(false);
    let isHashOn = getDefaultHashMode() === 'HASH-ON';

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex += 1) {
        const lineText = document.lineAt(lineIndex).text;
        const trimmed = lineText.trim();

        if (/^\s*#?\s*HASH-ON\b/i.test(lineText)) {
            isHashOn = true;
        } else if (/^\s*#?\s*HASH-OFF\b/i.test(lineText)) {
            isHashOn = false;
        }

        if (trimmed.length === 0 || trimmed.startsWith("//")) {
            outputLineMap[lineIndex] = false;
            continue;
        }

        if (trimmed.startsWith(">>")) {
            outputLineMap[lineIndex] = true;
            continue;
        }

        // DEBUG-mode output conventions in HASH-ON and HASH-OFF styles.
        if (trimmed.startsWith("??") || trimmed.startsWith("#??")) {
            outputLineMap[lineIndex] = true;
            continue;
        }

        outputLineMap[lineIndex] = isHashOn && !trimmed.startsWith("#");
    }

    return outputLineMap;
}

/**
 * Builds a comprehensive execution classification map for each line, using the
 * pre-parsed AST to determine line types instead of regex-based heuristics.
 *
 * Hash mode transitions are read from HashOnDirective / HashOffDirective AST nodes.
 * Executable vs invalid-executable is determined by node type: UnknownLine nodes
 * (lines the parser could not classify) map to isInvalidExecutable, everything else
 * to isExecutable.  The raw-text checks for >>, ??, #??, #NOTE, and #// are
 * preserved because the lexer emits these as OUTPUT_TEXT or code in ways that
 * depend on the current hash mode and they cannot be cleanly distinguished by node
 * type alone.
 *
 * @param {import("vscode").TextDocument} document - The document to analyze
 * @param {object} ast - Program AST from buildDocumentAst
 * @returns {Array<{
 *   isOutput: boolean,
 *   outputKind: 'explicit'|'debug'|'implicit'|null,
 *   isExecutable: boolean,
 *   isInvalidExecutable: boolean,
 *   isContinuationFollower: boolean,
 *   hashMode: 'HASH-ON'|'HASH-OFF',
 *   effectiveContent: string,
 *   hasHashPrefix: boolean,
 *   rawLine: string
 * }>}
 */
function buildExecutionClassificationMap(document, ast) {
    // Build line → first AST node map via a full recursive walk.
    const lineToNode = new Map();
    walkStatements(ast.statements, stmt => {
        if (typeof stmt.line === 'number' && !lineToNode.has(stmt.line)) {
            lineToNode.set(stmt.line, stmt);
        }
    });

    const classificationMap = new Array(document.lineCount);
    let currentHashMode = getDefaultHashMode();
    let prevLineEndedWithContinuation = false;

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex += 1) {
        const isFollower = prevLineEndedWithContinuation;
        const rawLine = document.lineAt(lineIndex).text;
        const rawTrimmed = rawLine.trim();
        const lineText = stripTrailingComment(rawLine);
        const trimmed = lineText.trim();
        const node = lineToNode.get(lineIndex);

        // Update hash mode from AST node type (replaces regex scan).
        if (node?.type === NodeType.HashOnDirective) {
            currentHashMode = 'HASH-ON';
        } else if (node?.type === NodeType.HashOffDirective) {
            currentHashMode = 'HASH-OFF';
        }

        // Determine whether this line can carry continuation to the next.
        // Only code lines carry '...' continuation — output and comment lines do not.
        const lineIsOutput =
            rawTrimmed.startsWith("//") ||
            rawTrimmed.startsWith(">>") ||
            rawTrimmed.startsWith("??") ||
            rawTrimmed.startsWith("#??") ||
            (currentHashMode === 'HASH-ON' && !rawTrimmed.startsWith("#"));
        prevLineEndedWithContinuation = !lineIsOutput && isLineWithContinuation(rawLine);

        const classification = {
            isOutput: false,
            outputKind: null,
            isExecutable: false,
            isInvalidExecutable: false,
            isContinuationFollower: false,
            hashMode: currentHashMode,
            effectiveContent: lineText,
            hasHashPrefix: /^\s*#/.test(lineText),
            rawLine
        };

        const hashStripped = trimmed.startsWith("#")
            ? trimmed.substring(1).trimStart()
            : lineText;

        // Hash mode directives are always executable control statements.
        if (node?.type === NodeType.HashOnDirective || node?.type === NodeType.HashOffDirective) {
            classification.isExecutable = true;
            classification.effectiveContent = hashStripped;
            classificationMap[lineIndex] = classification;
            continue;
        }

        // Empty or comment-only lines.
        if (trimmed.length === 0 || rawTrimmed.startsWith("//")) {
            classificationMap[lineIndex] = classification;
            continue;
        }

        // Explicit output (>>).
        if (trimmed.startsWith(">>")) {
            classification.isOutput = true;
            classification.outputKind = 'explicit';
            classification.effectiveContent = trimmed.substring(2).trimStart();
            classificationMap[lineIndex] = classification;
            continue;
        }

        // Debug output (?? or #??).
        if (trimmed.startsWith("??")) {
            classification.isOutput = true;
            classification.outputKind = 'debug';
            classification.effectiveContent = trimmed.substring(2).trimStart();
            classificationMap[lineIndex] = classification;
            continue;
        }
        if (trimmed.startsWith("#??")) {
            classification.isOutput = true;
            classification.outputKind = 'debug';
            classification.effectiveContent = trimmed.substring(3).trimStart();
            classificationMap[lineIndex] = classification;
            continue;
        }

        // HASH-ON NOTE directive — comment-like, not executable.
        if (currentHashMode === 'HASH-ON' && /^#\s*NOTE\b/i.test(trimmed)) {
            classificationMap[lineIndex] = classification;
            continue;
        }

        // HASH-ON hash-prefixed comments (e.g. #// comment).
        if (currentHashMode === 'HASH-ON' && /^#\s*\/\//.test(rawTrimmed)) {
            classificationMap[lineIndex] = classification;
            continue;
        }

        // Implicit output: OutputLine AST node (HASH-ON non-# lines, or >> in HASH-OFF).
        if (node?.type === NodeType.OutputLine) {
            classification.isOutput = true;
            classification.outputKind = 'implicit';
            classificationMap[lineIndex] = classification;
            continue;
        }

        // // comment lines captured by the AST as CommentLine nodes.
        if (node?.type === NodeType.CommentLine) {
            classificationMap[lineIndex] = classification;
            continue;
        }

        // HASH-ON mode: lone '#' with no content is treated as a blank line.
        if (currentHashMode === 'HASH-ON' && trimmed === '#') {
            classificationMap[lineIndex] = classification;
            continue;
        }

        classification.effectiveContent = hashStripped;
        classification.isContinuationFollower = isFollower;

        // --- Definitive executable AST node types ---
        // FunctionCallStatement (IDENTIFIER + LPAREN) is always valid. All other well-typed
        // nodes (IfStatement, WhileStatement, ReturnStatement, VarStatement, etc.) are similarly
        // definitive. The three ambiguous cases are handled explicitly below.
        if (node && node.type !== NodeType.UnknownLine &&
            node.type !== NodeType.ExpressionStatement &&
            node.type !== NodeType.AssignStatement) {
            classification.isExecutable = true;
            classificationMap[lineIndex] = classification;
            continue;
        }

        // --- AssignStatement ---
        // Simple `x = expr` is always valid. Compound `x += expr` is valid only when the
        // operator and `=` are adjacent (`+=`). A spaced form like `x + = y` is a syntax
        // error even though the parser accepts it as a compound AssignStatement.
        if (node?.type === NodeType.AssignStatement) {
            const validCompound = node.op === null || node.opAdjacent === true;
            classification.isExecutable = isFollower || validCompound;
            if (!classification.isExecutable) classification.isInvalidExecutable = true;
            classificationMap[lineIndex] = classification;
            continue;
        }

        // --- UnknownLine ---
        // Structural keywords emitted in the wrong block context (ELSE outside IF, VALUE/WHEN/
        // OTHERWISE outside CASE) carry a `keyword` field and are still executable statements.
        // Genuinely malformed lines (no keyword field) are invalid executables.
        if (node?.type === NodeType.UnknownLine) {
            classification.isExecutable = isFollower || node.keyword !== undefined;
            if (!classification.isExecutable) classification.isInvalidExecutable = true;
            classificationMap[lineIndex] = classification;
            continue;
        }

        // --- ExpressionStatement ---
        // Covers two sub-cases from the parser:
        //   (a) keywords that fall through the processKeywordLine switch (TO, BY, NOT, OF, …)
        //   (b) bare identifiers or identifier-led expressions that are not assignments/calls
        // A line is executable if it contains a function-call pattern (any token followed by
        // LPAREN) anywhere in its token stream.  All other ExpressionStatements are invalid.
        if (node?.type === NodeType.ExpressionStatement) {
            const tokens = node.value?.tokens ?? [];
            const hasCall = tokens.some((t, i) =>
                (t.type === TokenType.IDENTIFIER || t.type === TokenType.KEYWORD) &&
                tokens[i + 1]?.type === TokenType.LPAREN
            );
            classification.isExecutable = isFollower || hasCall;
            if (!classification.isExecutable) classification.isInvalidExecutable = true;
            classificationMap[lineIndex] = classification;
            continue;
        }

        // --- No AST node ---
        // Lines the parser produced no node for (e.g. lines outside any parsed block).
        // Fall back to text-pattern heuristic.
        classification.isExecutable = isFollower || hasCodePattern(hashStripped);
        if (!classification.isExecutable) {
            classification.isInvalidExecutable = true;
        }
        classificationMap[lineIndex] = classification;
    }

    return classificationMap;
}

export {
    extractOutputDelimiters,
    buildOutputLineMap,
    buildExecutionClassificationMap,
    getFunctionValidationTargetsForLine,
    buildFunctionValidationTargetsByLine,
    getInterpolationTargetsForLine,
    buildInterpolationTargetsByLine,
    getDefaultHashMode,
    isLineWithContinuation
};
