/**
 * Built-in global variables — loader and runtime registry.
 *
 * Source of truth: builtins-data/global-variables/<NAME>.json
 *   with schema     builtins-data/schemas/global-variable.schema.json
 *
 * Cold-start path: prefer the bundle (single readFile + JSON.parse) when
 * present; otherwise walk the directory. Every entry is validated against
 * the schema on load — bad data fails loud at startup.
 *
 * The exported `BuiltInGlobalVariables` is a Proxy over an internal mutable
 * store. External writes (assignment, delete, defineProperty) throw a
 * TypeError pointing the caller at the supported register API. Supplementary
 * registrations flow through `registerSupplementaryGlobalVariable`, which
 * validates the entry against the same schema and freezes it before storing
 * — so `BuiltInGlobalVariables[k]` always returns a frozen value, regardless
 * of whether `k` is a core or supplementary entry.
 *
 * Note on `Object.isFrozen`: the Proxy reflects the truth of its mutable
 * target, so `Object.isFrozen(BuiltInGlobalVariables)` returns false. The
 * functional guarantee — that no external code can mutate the registry — is
 * delivered by the trap, not by structural freezing. See the unit test in
 * `test/unit/globalVariablesRegistryFreeze.test.js` for the contract.
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { validateOrThrow } from "./_schemaValidator.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_ROOT   = path.resolve(__dirname, "..", "..", "..", "builtins-data");
const DATA_DIR    = path.join(DATA_ROOT, "global-variables");
const BUNDLE_FILE = path.join(DATA_ROOT, "global-variables.bundle.json");
const SCHEMA_FILE = path.join(DATA_ROOT, "schemas", "global-variable.schema.json");

const schema = JSON.parse(fs.readFileSync(SCHEMA_FILE, "utf8"));

function loadFromBundle() {
    const entries = JSON.parse(fs.readFileSync(BUNDLE_FILE, "utf8"));
    if (!Array.isArray(entries)) {
        throw new Error(`${BUNDLE_FILE}: expected an array of entries`);
    }
    return entries;
}

function loadFromDirectory() {
    const files = fs.readdirSync(DATA_DIR).filter(f => f.endsWith(".json")).sort();
    return files.map(f => {
        const full = path.join(DATA_DIR, f);
        const entry = JSON.parse(fs.readFileSync(full, "utf8"));
        const stem = f.slice(0, -".json".length);
        if (entry.name !== stem) {
            throw new Error(`${full}: "name" (${entry.name}) does not match file stem (${stem})`);
        }
        return entry;
    });
}

const _entries = {};
const _coreKeys = new Set();
const _displacedCoreEntries = new Map();

function _populate() {
    const entries = fs.existsSync(BUNDLE_FILE) ? loadFromBundle() : loadFromDirectory();
    for (const entry of entries) {
        const location = `global-variables/${entry.name ?? "<unknown>"}.json`;
        validateOrThrow(entry, schema, location);
        if (Object.prototype.hasOwnProperty.call(_entries, entry.name)) {
            throw new Error(`${location}: duplicate global variable "${entry.name}"`);
        }
        _entries[entry.name] = Object.freeze({
            type: entry.type,
            readOnly: entry.readOnly,
            description: entry.description
        });
        _coreKeys.add(entry.name);
    }
}

_populate();

const _MUTATION_ERROR =
    "BuiltInGlobalVariables is read-only — call registerSupplementaryGlobalVariable() to add or override entries.";

const BuiltInGlobalVariables = new Proxy(_entries, {
    set()            { throw new TypeError(_MUTATION_ERROR); },
    deleteProperty() { throw new TypeError(_MUTATION_ERROR); },
    defineProperty() { throw new TypeError(_MUTATION_ERROR); }
});

/**
 * Register a supplementary global variable at runtime.
 *
 * Mirrors `registerSupplementaryTable` in `tableRegistry.js`: the same
 * `{ added, replaced, skipped }` return shape and the same `preferCore`
 * collision policy.
 *
 * Validates the entry against `global-variable.schema.json`. The supplied
 * `entry` may omit the schema's `name` field — it is inferred from the
 * `name` argument and added to the candidate before validation. Throws a
 * descriptive Error if the entry is malformed.
 *
 * Collision policy (matches `registerSupplementaryTable`): when `preferCore`
 * is true and the name already exists, the call is a no-op and `skipped`
 * is true. Otherwise the new entry replaces the existing one and the
 * displaced *core* entry (if any) is captured for restoration via
 * `unregisterSupplementaryGlobalVariable`.
 *
 * @param {string} name - The all-caps identifier. Normalised to uppercase.
 * @param {{type: string, readOnly?: boolean, description?: string}} entry
 * @param {boolean} [preferCore=false]
 * @returns {{added: boolean, replaced: boolean, skipped: boolean}}
 */
function registerSupplementaryGlobalVariable(name, entry, preferCore = false) {
    if (typeof name !== "string" || name.length === 0) {
        throw new TypeError("registerSupplementaryGlobalVariable: name must be a non-empty string.");
    }
    if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
        throw new TypeError(`registerSupplementaryGlobalVariable("${name}"): entry must be a plain object.`);
    }
    const key = name.toUpperCase();
    const candidate = {
        name: key,
        type: entry.type,
        readOnly: entry.readOnly === undefined ? false : entry.readOnly,
        description: entry.description ?? ""
    };
    validateOrThrow(candidate, schema, `supplementary global-variable "${key}"`);

    const conflict = Object.prototype.hasOwnProperty.call(_entries, key);
    if (conflict && preferCore) {
        return { added: false, replaced: false, skipped: true };
    }
    if (conflict && _coreKeys.has(key) && !_displacedCoreEntries.has(key)) {
        _displacedCoreEntries.set(key, _entries[key]);
    }
    _entries[key] = Object.freeze({
        type: candidate.type,
        readOnly: candidate.readOnly,
        description: candidate.description
    });
    return { added: !conflict, replaced: conflict, skipped: false };
}

/**
 * Reverses a prior `registerSupplementaryGlobalVariable` call. Removes the
 * entry from the registry when the name was not part of the core registry;
 * otherwise restores the displaced core entry.
 *
 * Safe to call with a name that was never registered (no-op).
 *
 * @param {string} name - Global variable name (any casing).
 */
function unregisterSupplementaryGlobalVariable(name) {
    const key = name.toUpperCase();
    if (_displacedCoreEntries.has(key)) {
        _entries[key] = _displacedCoreEntries.get(key);
        _displacedCoreEntries.delete(key);
        return;
    }
    if (_coreKeys.has(key)) {
        // The supplementary call was a no-op (preferCore=true) — nothing to undo.
        return;
    }
    delete _entries[key];
}

export {
    BuiltInGlobalVariables,
    registerSupplementaryGlobalVariable,
    unregisterSupplementaryGlobalVariable
};
