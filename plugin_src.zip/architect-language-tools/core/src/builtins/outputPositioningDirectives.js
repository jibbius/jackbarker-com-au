/**
 * Output-positioning directives for Architect.
 *
 * These are NOT functions. They can only be used inside OICC/CICC delimiters
 * on output lines (e.g., >>@CENTER(40,"My Heading")@). Using them in a code
 * expression (assignment, function argument, condition) is a runtime error.
 *
 * Default OICC/CICC is "@". Overridden by: OPTION OICC="^", CICC="^"
 *
 * Treedata5 reference: section 0111 — Formatting: Locating output on the page.
 */

import { ArchitectTypes, ANY_EXPRESSION } from "../types/architectTypes.js";

/**
 * Registry of output-positioning directives.
 *
 * Format per entry:
 *   params        — positional parameter types (in order)
 *   description   — human-readable description shown in hover/completion
 *   paramNames    — parameter names shown in signature help
 */
const OutputPositioningDirectives = {
    CENTER: {
        params:     [ArchitectTypes.SHORT, ANY_EXPRESSION],
        paramNames: ["col", "expression"],
        description: "Centers the expression around the given column position. " +
                     "e.g. CENTER(40, \"My Heading\") centers on column 40 of an 80-column page."
    },
    COL: {
        params:     [ArchitectTypes.SHORT],
        paramNames: ["col"],
        description: "Moves the output cursor to the given column position. " +
                     "If the cursor is already past that column, output may overwrite preceding text."
    },
    FROM: {
        params:     [ArchitectTypes.SHORT, ANY_EXPRESSION],
        paramNames: ["col", "expression"],
        description: "Starts outputting the expression at the given column position."
    },
    TAB: {
        params:     [ArchitectTypes.SHORT],
        paramNames: ["count"],
        description: "Outputs the given number of spaces, advancing the output cursor."
    },
    TO: {
        params:     [ArchitectTypes.SHORT, ANY_EXPRESSION],
        paramNames: ["col", "expression"],
        description: "Ends outputting the expression at the given column position " +
                     "(i.e. the text is right-aligned to that column)."
    }
};

/**
 * Returns the directive entry for a name, or null if not an output-positioning directive.
 * @param {string} name - Directive name (case-insensitive)
 * @returns {object|null}
 */
function getOutputDirective(name) {
    return OutputPositioningDirectives[name.toUpperCase()] || null;
}

/**
 * Returns true if the name is a known output-positioning directive.
 * @param {string} name
 * @returns {boolean}
 */
function isOutputDirective(name) {
    return Object.prototype.hasOwnProperty.call(
        OutputPositioningDirectives,
        name.toUpperCase()
    );
}

export { OutputPositioningDirectives, getOutputDirective, isOutputDirective };
