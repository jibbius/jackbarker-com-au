/**
 * Closed enumeration of Usercalc calculation codes accepted by the
 * REQUIRE directive. Source: legacy documentation, transcribed
 * 2026-04-27 (see planning/specs/require-directive-usercalc.md).
 *
 * Codes are case-insensitive in source; canonical form is upper-case.
 * The Set below is the single source of truth for ACU-RQR-002.
 */

const USERCALC_CODES = Object.freeze(new Set([
    "ACC",   // Accumulation of accounts
    "NRD",   // Normal retirement date
    "BM",    // Benefit multiple
    "CONT",  // Contributions
    "DISB",  // Disablement benefit
    "DTHB",  // Death benefit
    "ERB",   // Early retirement benefit
    "FAS",   // Final average salary
    "GLSI",  // Death sum insured
    "GLP",   // Death premium
    "LRB",   // Late retirement benefit
    "RB",    // Retrenchment benefit
    "WB",    // Withdrawal benefit
    "ABM",   // Accrued benefit multiple
    "TPD",   // Disablement sum insured
    "TPDP",  // Disablement premium
    "SCB",   // Salary continuance benefit
    "SCBP",  // Salary continuance premium
    "MISC",  // Miscellaneous benefit
    "PFAS",  // Prospective final average salary
    "SICK"   // Ill health benefit
]));

function isKnownUsercalcCode(code) {
    if (typeof code !== "string") return false;
    return USERCALC_CODES.has(code.toUpperCase());
}

export { USERCALC_CODES, isKnownUsercalcCode };
