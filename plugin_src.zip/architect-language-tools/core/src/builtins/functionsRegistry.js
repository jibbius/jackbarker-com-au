/**
 * Built-in function signatures for Acurity Architect.
 */

import { ArchitectTypes } from "../types/architectTypes.js";

/**
 * Built-in function signatures.
 * Format: {
 * name: { -- function name
 *  params: [types...], -- parameter types in order
 *  paramModes: [modes...], -- "REF", "VAR", "VAR_init_not_required", "VAR_destroy" (optional, default all "REF")
 *  returns: type, -- return type
 *  varArgs: boolean, -- Function accepts variable number of arguments (optional, default false)
 *  description: string -- human-readable description of the function's behavior (optional)
 * } }
 */
const BuiltInFunctions = {
    // String functions
    GET_TOKEN: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.SHORT],
        paramLabels: ["inputString", "delimiter", "tokenIndex"],
        returns: ArchitectTypes.STRING,
        description: "Extracts a token from a string using a delimiter"
    },
    TRIM_ALL: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.STRING,
        description: "Removes leading and trailing whitespace"
    },
    GET_STR: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["expression"],
        returns: ArchitectTypes.STRING,
        description: "Returns a string value from an expression"
    },
    FORMAT: {
        params: [ArchitectTypes.STRING, [ArchitectTypes.SHORT, ArchitectTypes.LONG, ArchitectTypes.INTEGER, ArchitectTypes.DOUBLE]],
        paramLabels: ["formatString", "value"],
        returns: ArchitectTypes.STRING,
        description: "Formats a value according to a format string"
    },
    STR: {
        params: [[ArchitectTypes.SHORT, ArchitectTypes.LONG, ArchitectTypes.INTEGER, ArchitectTypes.DOUBLE, ArchitectTypes.DATE, ArchitectTypes.TIME, ArchitectTypes.BOOLEAN, ArchitectTypes.STRING, ArchitectTypes.BIGINT]],
        paramLabels: ["value"],
        returns: ArchitectTypes.STRING,
        description: "Converts a value to a string"
    },
    TO_LONG: {
        params: [[ArchitectTypes.SHORT, ArchitectTypes.INTEGER, ArchitectTypes.DOUBLE, ArchitectTypes.BIGINT]],
        paramLabels: ["value"],
        returns: ArchitectTypes.LONG,
        description: "Converts a value to LONG"
    },
    TO_SHORT: {
        params: [[ArchitectTypes.LONG, ArchitectTypes.INTEGER, ArchitectTypes.DOUBLE, ArchitectTypes.BIGINT]],
        paramLabels: ["value"],
        returns: ArchitectTypes.SHORT,
        description: "Converts a value to SHORT"
    },
    TO_DOUBLE: {
        params: [[ArchitectTypes.SHORT, ArchitectTypes.LONG, ArchitectTypes.INTEGER, ArchitectTypes.BIGINT]],
        paramLabels: ["value"],
        returns: ArchitectTypes.DOUBLE,
        description: "Converts a value to DOUBLE"
    },
    TO_BIGINT: {
        params: [[ArchitectTypes.SHORT, ArchitectTypes.LONG, ArchitectTypes.DOUBLE, ArchitectTypes.INTEGER]],
        paramLabels: ["value"],
        returns: ArchitectTypes.BIGINT,
        description: "Converts a value to BIGINT"
    },

    // Date functions
    DD: {
        params: [ArchitectTypes.DATE],
        paramLabels: ["date"],
        returns: ArchitectTypes.SHORT,
        description: "Extracts day from date"
    },
    MM: {
        params: [ArchitectTypes.DATE],
        paramLabels: ["date"],
        returns: ArchitectTypes.SHORT,
        description: "Extracts month from date"
    },
    YYYY: {
        params: [ArchitectTypes.DATE],
        paramLabels: ["date"],
        returns: ArchitectTypes.SHORT,
        description: "Extracts year from date"
    },

    // String functions (discovered from analysis)
    LENGTH: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.LONG,
        description: "Returns length of string"
    },
    REPEAT: {
        params: [ArchitectTypes.STRING, ArchitectTypes.SHORT],
        paramLabels: ["inputString", "count"],
        returns: ArchitectTypes.STRING,
        description: "Repeats string n times"
    },
    INSERT_STR: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.SHORT],
        paramLabels: ["inputString", "insertString", "position"],
        returns: ArchitectTypes.STRING,
        description: "Inserts string at position"
    },
    UPPER: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.STRING,
        description: "Converts string to uppercase"
    },
    STRIP: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.STRING,
        description: "Removes leading/trailing whitespace"
    },
    SEARCH: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING],
        paramLabels: ["inputString", "searchString"],
        returns: ArchitectTypes.LONG,
        description: "Searches for substring position"
    },
    // CENTER removed — it is an output-positioning directive, not a function.
    // See core/src/builtins/outputPositioningDirectives.js
    STR_TO_DOUBLE: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.DOUBLE,
        description: "Converts string to DOUBLE"
    },
    STR_TO_LONG: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.LONG,
        description: "Converts string to LONG"
    },
    SUBSTR: {
        params: [ArchitectTypes.STRING, ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["inputString", "startPosition", "length"],
        returns: ArchitectTypes.STRING,
        description: "Extracts substring starting at position for length"
    },
    TRIM: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.STRING,
        description: "Removes leading and trailing whitespace"
    },
    // FROM removed — it is an output-positioning directive, not a function.
    // See core/src/builtins/outputPositioningDirectives.js

    // Additional date functions (discovered from analysis)
    DDADD: {
        params: [ArchitectTypes.DATE, ArchitectTypes.SHORT],
        paramLabels: ["date", "days"],
        returns: ArchitectTypes.DATE,
        description: "Adds days to date"
    },
    YY: {
        params: [ArchitectTypes.DATE],
        paramLabels: ["date"],
        returns: ArchitectTypes.SHORT,
        description: "Extracts 2-digit year from date"
    },
    YYADD: {
        params: [ArchitectTypes.DATE, ArchitectTypes.SHORT],
        paramLabels: ["date", "years"],
        returns: ArchitectTypes.DATE,
        description: "Adds years to date"
    },
    FORMAT_TIME: {
        params: [ArchitectTypes.LONG],
        paramLabels: ["timeValue"],
        returns: ArchitectTypes.STRING,
        description: "Formats time value as string"
    },
    SYS_SECONDS: {
        params: [],
        returns: ArchitectTypes.DOUBLE,
        description: "Returns the current system time as elapsed seconds"
    },
    MONTH_ABV: {
        params: [ArchitectTypes.SHORT],
        paramLabels: ["monthNumber"],
        returns: ArchitectTypes.STRING,
        description: "Returns abbreviated month name"
    },
    RET_STR_TO_DATE: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.DATE,
        description: "Converts string to DATE"
    },
    STR_TO_DATE: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.DATE,
        description: "Converts string to DATE"
    },
    SYS_DATE: {
        params: [],
        returns: ArchitectTypes.DATE,
        description: "Returns current system date"
    },
    SYS_TIME: {
        params: [],
        returns: ArchitectTypes.STRING,
        description: "Returns current system time as a string"
    },

    // File I/O functions (discovered from analysis)
    FILE_WRITE: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.STRING],
        paramLabels: ["fileHandle", "content"],
        returns: ArchitectTypes.SHORT,
        description: "Writes string to file"
    },
    FILE_OPEN: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.STRING, ArchitectTypes.STRING],
        paramLabels: ["fileHandle", "filename", "mode"],
        paramModes:  ["VAR_init_not_required", "REF", "REF"],
        returns: ArchitectTypes.SHORT,
        description: "Opens file and returns a status code. Param 0: file handle variable (VAR_init_not_required) — written by function, need not be initialised. Param 1: filename (REF). Param 2: mode (REF) — e.g. 'R' for read, 'W' for write."
    },
    FILE_READ: {
        params: [ArchitectTypes.SHORT],
        paramLabels: ["fileHandle"],
        returns: ArchitectTypes.STRING,
        description: "Reads line from file"
    },
    FILE_CLOSE: {
        params: [ArchitectTypes.SHORT],
        paramLabels: ["fileHandle"],
        paramModes: ["VAR_destroy"],
        returns: ArchitectTypes.SHORT,
        description: "Closes file handle. Param 0: file handle (VAR_destroy) — treat as uninitialised after this call."
    },
    FILE_DELETE: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["filename"],
        returns: ArchitectTypes.SHORT,
        description: "Deletes file. Param 0: filename (REF)."
    },

    // Database/Index functions (discovered from analysis)
    INDEX_OPEN_STANDARD: {
        params:      [ArchitectTypes.STRING, ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["tableCode", "indexNumber", "handle"],
        paramModes:  ["REF",              "REF",              "VAR_init_not_required"],
        // arg 2 (handle) becomes bound to the table code supplied in arg 0
        bindsHandle: { handleParam: 2, tableCodeParam: 0 },
        returns: ArchitectTypes.SHORT,
        description: "Opens a standard index. Arg 0: table code (REF). Arg 1: index number (REF). Arg 2: handle variable — written by function, need not be initialised (VAR_init_not_required).",
        // Only the function name is pre-filled in the snippet so that the index-number
        // completion provider can offer choices after the user types the '('.
        // $0 places the final cursor inside the parens
        insertSnippet: "INDEX_OPEN_STANDARD$0"
    },
    INDEX_READ_BY_KEY: {
        params:      [ArchitectTypes.SHORT, ArchitectTypes.STRING],
        paramLabels: ["handle", "cursorDirection"],
        paramModes:  ["REF",              "REF"],
        // moves the cursor for the table that was bound to the handle in arg 0
        cursorTableFromHandle: 0,
        returns: ArchitectTypes.SHORT,
        description: "Reads the next record from an open index. Arg 0: handle (REF). Arg 1: cursor direction (REF). Advances the DB cursor for the table the handle is bound to."
    },
    INDEX_CLOSE: {
        params:      [ArchitectTypes.SHORT],
        paramLabels: ["handle"],
        paramModes:  ["VAR_destroy"],
        returns: ArchitectTypes.SHORT,
        description: "Closes an open index and invalidates the handle. Arg 0: handle (VAR_destroy) — treat as uninitialised after this call."
    },
    INDEX_SAVE_POSITION: {
        params:      [ArchitectTypes.STRING],
        paramLabels: ["tableCode"],
        paramModes:  ["REF"],
        returns: ArchitectTypes.SHORT,
        description: "Saves the current cursor position for a table. Arg 0: table code (REF)."
    },
    INDEX_RESTORE_POSITION: {
        params:      [ArchitectTypes.STRING],
        paramLabels: ["tableCode"],
        paramModes:  ["REF"],
        returns: ArchitectTypes.SHORT,
        description: "Restores a previously saved cursor position for a table. Arg 0: table code (REF)."
    },
    INDEX_LOAD_KEY_STRING: {
        params:      [ArchitectTypes.SHORT, ArchitectTypes.STRING, ArchitectTypes.SHORT],
        paramLabels: ["handle", "keyValue", "keyLength"],
        paramModes:  ["REF",              "REF",       "REF"],
        returns: ArchitectTypes.SHORT,
        description: "Loads a STRING key segment into an open index."
    },
    INDEX_LOAD_KEY_LONG: {
        params:      [ArchitectTypes.SHORT, ArchitectTypes.LONG],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: ArchitectTypes.SHORT,
        description: "Loads a LONG key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    INDEX_LOAD_KEY_SHORT: {
        params:      [ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: ArchitectTypes.SHORT,
        description: "Loads a SHORT key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    INDEX_LOAD_KEY_DATE: {
        params:      [ArchitectTypes.SHORT, ArchitectTypes.DATE],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: ArchitectTypes.SHORT,
        description: "Loads a DATE key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    INDEX_CLEAR_KEY: {
        params:      [ArchitectTypes.SHORT],
        paramLabels: ["handle"],
        paramModes:  ["REF"],
        returns: ArchitectTypes.SHORT,
        description: "Clears all loaded key segments for an open index. Arg 0: handle (REF)."
    },
    GET_DOUBLE_ARRAY: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["arrayHandle", "index"],
        returns: ArchitectTypes.DOUBLE,
        description: "Gets value from DOUBLE array"
    },
    PUT_DOUBLE_ARRAY: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT, ArchitectTypes.DOUBLE],
        paramLabels: ["arrayHandle", "index", "value"],
        returns: ArchitectTypes.SHORT,
        description: "Puts value into DOUBLE array"
    },
    DB_SET_COLUMN: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        returns: ArchitectTypes.SHORT,
        description: "Sets database column"
    },

    // Display/Message functions (discovered from analysis)
    SANITISE_XML: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["xmlContent"],
        returns: ArchitectTypes.STRING,
        description: "Sanitizes XML content"
    },
    CWB_ADD_MESSAGE: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["message"],
        returns: ArchitectTypes.SHORT,
        description: "Adds message to CWB"
    },

    // Array functions
    GET_UNUSED_ARRAY_HANDLE: {
        params: [ArchitectTypes.SHORT],
        paramLabels: ["handleVar"],
        paramModes:  ["VAR_init_not_required"],
        returns: ArchitectTypes.SHORT,
        description: "Gets an unused array handle"
    },
    NUM_SORTED_ARRAYS: {
        params: [ArchitectTypes.SHORT],
        returns: ArchitectTypes.SHORT,
        description: "Returns the number of sorted arrays"
    },
    INIT_SORTED_ARRAY: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT, ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["arrayHandle", "maxRecords", "keyLength", "numColumns"],
        returns: ArchitectTypes.SHORT,
        description: "Initializes a sorted array"
    },
    ADD_ARRAY_REC: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.STRING],
        paramLabels: ["arrayHandle", "key"],
        returns: ArchitectTypes.SHORT,
        description: "Adds a record to array"
    },
    PUT_STRING_SAY: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT, ArchitectTypes.STRING],
        paramLabels: ["arrayHandle", "columnIndex", "value"],
        returns: ArchitectTypes.SHORT,
        description: "Stores string value in array column"
    },
    PUT_DOUBLE_SAY: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT, ArchitectTypes.DOUBLE, ArchitectTypes.SHORT],
        paramLabels: ["arrayHandle", "columnIndex", "value", "precision"],
        returns: ArchitectTypes.SHORT,
        description: "Stores DOUBLE value in array column with precision"
    },
    GET_STRING_SAY: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["arrayHandle", "columnIndex"],
        returns: ArchitectTypes.STRING,
        description: "Retrieves string value from array"
    },
    GET_DOUBLE_SAY: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["arrayHandle", "columnIndex"],
        returns: ArchitectTypes.DOUBLE,
        description: "Retrieves DOUBLE value from array"
    },
    READ_ARRAY_REC: {
        params: [ArchitectTypes.STRING, ArchitectTypes.SHORT, ArchitectTypes.STRING],
        paramLabels:  ["readDirection", "arrayHandle", "arrayKey"],
        paramModes:  ["REF", "REF", "VAR"],
        returns: ArchitectTypes.SHORT,
        description: "Reads array record by key"
    },
    FIN_SORTED_ARRAY: {
        params: [],
        returns: ArchitectTypes.SHORT,
        description: "Finalizes sorted array"
    },
    FREE_SORTED_ARRAY: {
        params: [ArchitectTypes.SHORT],
        paramLabels: ["arrayHandle"],
        returns: ArchitectTypes.SHORT,
        description: "Frees a sorted array handle"
    },

    // Batch/Job functions
    RUN_BATCH_JOB: {
        params: [ArchitectTypes.STRING, ArchitectTypes.SHORT, ArchitectTypes.SHORT, ArchitectTypes.STRING],
        returns: ArchitectTypes.LONG,
        description: "Runs a batch job"
    },

    // Ledger/Database functions
    GET_NEXT_DAILY_SS_CF: {
        params: [ArchitectTypes.DATE, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.DOUBLE, ArchitectTypes.DOUBLE],
        returns: ArchitectTypes.SHORT,
        description: "Gets next daily cash flow record"
    },
    GET_DAILY_SS_ACC_CF: {
        params: [ArchitectTypes.DATE, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.DOUBLE, ArchitectTypes.DOUBLE],
        returns: ArchitectTypes.SHORT,
        description: "Gets daily account cash flow"
    },
    LEDGER_CHGE_KEY: {
        params: [ArchitectTypes.SHORT],
        returns: ArchitectTypes.SHORT,
        description: "Changes ledger key context"
    },
    READ_INVMGR: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING],
        returns: ArchitectTypes.SHORT,
        description: "Reads investment manager record"
    },
    GET_NEXT_EFF_DAY: {
        params: [ArchitectTypes.DATE],
        returns: ArchitectTypes.SHORT,
        description: "Gets next effective business day"
    },

    // Database read functions
    READ_ACCTHIST_MEM: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.DATE],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Reads account history record for member"
    },
    READ_ACCOUNT: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Reads account record"
    },
    READ_COMPANY: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Reads company record"
    },
    READ_INSURER: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Reads insurer record"
    },
    READ_BROKER: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Reads broker record"
    },
    READ_FEE_CODE: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Reads fee code record"
    },
    READ_FUND: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Reads fund record"
    },
    READ_MEMBER: {
        params:      [ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING],
        paramLabels: ["cursorDirection", "keyField1", "keyField2"],
        paramModes:  ["REF",              "VAR",               "VAR"],
        // arg 1 and 2 must be initialised before the call (VAR, not VAR_init_not_required)
        varArgs: true,
        cursorTables: ["MD", "D2"],
        returns: ArchitectTypes.SHORT,
        description: "Reads a member record. Arg 0: cursor direction (REF). Args 1+: key fields (VAR — must be initialised). Moves the DB cursor for tables MD and D2."
    },
    READ_MEMB: {
        params:      [ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING],
        paramLabels: ["cursorDirection", "keyField1", "keyField2"],
        paramModes:  ["REF",              "VAR",               "VAR"],
        varArgs: true,
        cursorTables: ["MD", "D2"],
        returns: ArchitectTypes.SHORT,
        description: "Reads a member record (short form). Arg 0: cursor direction (REF). Args 1+: key fields (VAR — must be initialised). Moves the DB cursor for tables MD and D2."
    },
    READ_FILE: {
        params: [ArchitectTypes.SHORT],
        returns: ArchitectTypes.STRING,
        description: "Reads line from file"
    },

    // Accounting/Balance functions
    FM_AC_BAL: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING],
        returns: ArchitectTypes.SHORT,
        description: "Fast method account balance"
    },
    AC_BAL_TYPE_DIV: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.STRING, ArchitectTypes.DATE, ArchitectTypes.DATE, ArchitectTypes.DATE, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.DOUBLE, ArchitectTypes.DOUBLE, ArchitectTypes.DOUBLE, ArchitectTypes.DOUBLE, ArchitectTypes.DOUBLE, ArchitectTypes.DOUBLE],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Account balance by type and division"
    },

    // Description/Lookup functions
    DESCRIPTION: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING],
        returns: ArchitectTypes.STRING,
        description: "Retrieves description for code"
    },
    // Utility/Math functions
    ROUND: {
        params: [ArchitectTypes.DOUBLE, ArchitectTypes.SHORT],
        paramLabels: ["value", "decimalPlaces"],
        returns: ArchitectTypes.DOUBLE,
        description: "Rounds value to specified decimal places"
    },
    RNDLO: {
        params: [ArchitectTypes.DOUBLE, ArchitectTypes.SHORT],
        paramLabels: ["value", "decimalPlaces"],
        returns: ArchitectTypes.DOUBLE,
        description: "Rounds value downward to specified decimal places"
    },
    INDEX: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.SHORT],
        paramLabels: ["inputString", "searchString", "startPosition"],
        returns: ArchitectTypes.LONG,
        description: "Finds position of substring in string"
    },
    // TO removed — it is an output-positioning directive, not a function.
    // See core/src/builtins/outputPositioningDirectives.js

    // Array retrieval functions
    PUT_SHORT_SAY: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["arrayHandle", "columnIndex", "value"],
        returns: ArchitectTypes.SHORT,
        description: "Stores SHORT value in array column"
    },
    GET_SHORT_SAY: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["arrayHandle", "columnIndex"],
        returns: ArchitectTypes.SHORT,
        description: "Retrieves SHORT value from array"
    },

    // Additional display/output functions
    DISPLAY_MESSAGE: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.STRING],
        paramLabels: ["messageType", "messageText"],
        returns: ArchitectTypes.SHORT,
        description: "Displays message to user"
    },

    // Corpus-derived legacy builtins (2026-03 classification pass)
    SYMBOL: {
        params: [ArchitectTypes.STRING],
        returns: ArchitectTypes.BOOLEAN,
        varArgs: true,
        description: "Checks whether a symbol/function is defined"
    },
    READ_PAYMENT: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads payment record"
    },
    READ_UNIT_PRICE: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads unit price record"
    },
    INITIALS: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["nameString"],
        returns: ArchitectTypes.STRING,
        description: "Returns initials from a name string"
    },
    ASSERT: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.BOOLEAN,
        varArgs: true,
        description: "Assertion helper"
    },
    READ_PERSONAL: {
        params: [],
        returns: ArchitectTypes.SHORT,
        description: "Reads current personal record"
    },
    WRITE_ERROR_MSG: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Writes an error message"
    },
    ZERO_DATE: {
        params: [ArchitectTypes.DATE],
        paramLabels: ["date"],
        returns: ArchitectTypes.BOOLEAN,
        description: "Checks whether a date is the zero date"
    },
    READ_INVMGR_RATE: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads investment manager rate"
    },
    READ_EXIT_DETAILS: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads member exit details"
    },
    READ_PERSONAL2: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads personal record with selector"
    },
    READ_CATEGORY: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads category record"
    },
    READ_PEN_HIST: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads pension history"
    },
    WRITE_HEADER_CODE_RECORD: {
        params: [ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Writes header code record"
    },
    READ_SUPPMEMB_HIST_TYP: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads supplementary member history by type"
    },
    GET_USR_DEF_CONTROL_PARAM: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.STRING,
        description: "Gets user-defined control parameter"
    },
    SQL_GET_STRING_COL: {
        params: [ArchitectTypes.LONG, ArchitectTypes.SHORT, ArchitectTypes.STRING],
        paramLabels: ["statementHandle", "columnIndex", "outputValue"],
        paramModes: ["REF", "REF", "VAR_init_not_required"],
        returns: ArchitectTypes.STRING,
        description: "Gets SQL column as STRING"
    },
    READ_ANR_HIST: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads ANR history"
    },
    READ_CATHIST2: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads category history variant 2"
    },
    READ_PAYHIST: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads payment history"
    },
    READ_TMP_CRTR: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads temporary contributor record"
    },
    RIGHT: {
        params: [ArchitectTypes.STRING, ArchitectTypes.SHORT],
        paramLabels: ["inputString", "length"],
        returns: ArchitectTypes.STRING,
        description: "Returns right-most characters from string"
    },
    INITIALISED_ARRAY: {
        params: [ArchitectTypes.SHORT],
        paramLabels: ["arrayHandle"],
        returns: ArchitectTypes.SHORT,
        description: "Checks whether an array handle is initialised"
    },
    MONTH_NAME: {
        params: [ArchitectTypes.SHORT],
        paramLabels: ["monthNumber"],
        returns: ArchitectTypes.STRING,
        description: "Returns full month name"
    },
    READ_ACCTHIST_1: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads account history variant 1"
    },
    READ_SHARECRT_5: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads share certificate variant 5"
    },
    GET_TRANSREF: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Gets transaction reference"
    },
    MMADD: {
        params: [ArchitectTypes.DATE, ArchitectTypes.SHORT],
        paramLabels: ["date", "months"],
        returns: ArchitectTypes.DATE,
        description: "Adds months to date"
    },
    LOWER: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.STRING,
        description: "Converts string to lowercase"
    },
    READ_TRANSREF_5: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads transaction reference variant 5"
    },
    READ_CONTACC: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads contribution account"
    },
    READ_BALANCES: {
        params: [],
        returns: ArchitectTypes.SHORT,
        description: "Reads balances"
    },
    PERIOD_RND: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.DOUBLE,
        description: "Rounds amount by period rules"
    },
    TABLE_VALUE_2: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.DOUBLE,
        description: "Returns table value variant 2"
    },
    UPD_SUPPMEMB_ALL: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Updates supplementary member record"
    },
    FILE_COPY: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING],
        paramLabels: ["sourceFilename", "destFilename"],
        returns: ArchitectTypes.SHORT,
        description: "Copies file"
    },
    DSPACE: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.STRING,
        description: "Returns de-spaced string"
    },
    REPORT_FILENAME: {
        params: [ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.STRING,
        description: "Returns report filename component"
    },
    FILE_EXISTS: {
        params: [ArchitectTypes.STRING, ArchitectTypes.UNKNOWN],
        paramLabels: ["filename"],
        returns: ArchitectTypes.BOOLEAN,
        varArgs: true,
        description: "Checks whether file exists"
    },
    READ_PAYEE: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads payee record"
    },
    READ_MEMDEPS: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads member dependants"
    },
    READ_FILE_REG: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads file register"
    },
    COUNT_ARRAY_RECS: {
        params: [ArchitectTypes.SHORT],
        paramLabels: ["arrayHandle"],
        returns: ArchitectTypes.SHORT,
        description: "Counts array records"
    },
    WRITE_FILE_REG1: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Writes file register variant 1"
    },
    GET_SHORT_ARRAY: {
        params: [ArchitectTypes.SHORT],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Reads SHORT from array"
    },
    GET_STRING_ARRAY: {
        params: [ArchitectTypes.SHORT],
        returns: ArchitectTypes.STRING,
        varArgs: true,
        description: "Reads STRING from array"
    },
    READ_BTCH_REF2: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads batch reference variant 2"
    },
    DATE_TO_STR: {
        params: [ArchitectTypes.DATE, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.STRING,
        varArgs: true,
        description: "Formats date as string"
    },
    READ_BAL: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads balance record"
    },
    CHECK_SYMBOL: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.BOOLEAN,
        description: "Checks whether symbol exists"
    },
    READ_MEMB5: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads member record variant 5"
    },
    READ_TMP_CONT_2A: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads temporary contribution variant 2A"
    },
    READ_TRANSREF_7: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads transaction reference variant 7"
    },
    CWB_TRANS_GET_FIELD_VALUE: {
        params: [ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.STRING,
        varArgs: true,
        description: "Gets transformed contribution field value"
    },
    READ_TRANSREF: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads transaction reference"
    },
    READ_TRANSREF_2: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads transaction reference variant 2"
    },
    UPD_SUPPMEMB_HIST: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Updates supplementary member history"
    },
    LEDGER_ACCOUNT_BAL: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.DOUBLE,
        description: "Returns ledger account balance"
    },
    MAX_VALUE: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.DOUBLE,
        description: "Returns maximum of supplied values"
    },
    READ_ROLLOVER: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads rollover record"
    },
    MEMBER_CHGE_KEY: {
        params: [ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Changes member key context"
    },
    READ_TRANSREF_4: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads transaction reference variant 4"
    },
    READ_AUDIT: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads audit record"
    },
    PERIOD: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Calculates period offset"
    },
    READ_NOTES: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads notes record"
    },
    READ_INVPROP: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads investment property"
    },
    REPLACE: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.STRING],
        paramLabels: ["inputString", "searchString", "replacementString"],
        returns: ArchitectTypes.STRING,
        description: "Replaces substring occurrences"
    },
    GET_CONFIGURATION_STRING: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.STRING,
        description: "Gets configuration value as string"
    },
    REGEX_MATCH_SIMPLE: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING],
        paramLabels: ["inputString", "pattern"],
        returns: ArchitectTypes.BOOLEAN,
        description: "Performs simple regex match"
    },
    IPATH: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["path"],
        returns: ArchitectTypes.STRING,
        description: "Normalizes/derives internal path"
    },
    SQL_GET_DOUBLE_COL: {
        params: [ArchitectTypes.LONG, ArchitectTypes.SHORT, ArchitectTypes.DOUBLE],
        paramLabels: ["statementHandle", "columnIndex", "outputValue"],
        paramModes: ["REF", "REF", "VAR_init_not_required"],
        returns: ArchitectTypes.DOUBLE,
        description: "Gets SQL column as DOUBLE"
    },
    SQL_GET_SHORT_COL: {
        params: [ArchitectTypes.LONG, ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["statementHandle", "columnIndex", "outputValue"],
        paramModes: ["REF", "REF", "VAR_init_not_required"],
        returns: ArchitectTypes.SHORT,
        description: "Gets SQL column as SHORT"
    },
    SMEMBER_READ: {
        params: [],
        returns: ArchitectTypes.SHORT,
        description: "Reads member into current context"
    },
    PUT_SHORT_ARRAY: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Writes SHORT into array"
    },
    TFN_VALIDATE: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["tfnValue"],
        returns: ArchitectTypes.BOOLEAN,
        description: "Validates TFN"
    },
    READ_FUND_SIG: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads fund signature"
    },
    READ_SURCHARGE: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads surcharge record"
    },
    STR_TO_SHORT: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["inputString"],
        returns: ArchitectTypes.SHORT,
        description: "Converts string to SHORT"
    },
    READ_ERRORMSG_2: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads error message variant 2"
    },
    READ_GLOBHIST: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads global history"
    },
    READ_ELEC_FILE: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads electronic file metadata"
    },
    READ_ERRORMSG: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads error message"
    },
    UNDEFINED: {
        params: [ArchitectTypes.UNKNOWN],
        paramLabels: ["value"],
        returns: ArchitectTypes.BOOLEAN,
        description: "Checks whether value is undefined"
    },
    AC_BAL_TYPE: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Account balance by type"
    },
    READ_ASCII_FILE: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["filename"],
        returns: ArchitectTypes.SHORT,
        description: "Reads an ASCII file"
    },
    DOS_COMMAND: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["command"],
        returns: ArchitectTypes.SHORT,
        description: "Executes DOS command"
    },
    READ_TMP_EXIT: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads temporary exit record"
    },
    CHEQUE_WORDS: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Converts amount to cheque words components"
    },
    CALC_PENSION_PER_PERIOD: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Calculates pension per period"
    },
    READ_BKGD_JOB_4: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads background job variant 4"
    },
    READ_INTEREST_RATE: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads interest rate"
    },
    NEXT_PENSION_PAYMENT: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Gets next pension payment date"
    },
    YEARS: {
        params: [ArchitectTypes.DATE, ArchitectTypes.DATE],
        paramLabels: ["fromDate", "toDate"],
        returns: ArchitectTypes.SHORT,
        description: "Returns full year difference between dates"
    },
    GET_FULL_NOTE: {
        params: [],
        returns: ArchitectTypes.STRING,
        description: "Returns full note text"
    },
    DB_GET_VALUE_BY_SQL_COLUMN_NAME: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.STRING],
        paramLabels: ["handle", "columnName"],
        returns: ArchitectTypes.STRING,
        description: "Gets SQL column value by column name"
    },
    VALIDATE_DATE: {
        params: [ArchitectTypes.DATE],
        paramLabels: ["date"],
        returns: ArchitectTypes.SHORT,
        description: "Validates date and returns status code"
    },
    VERIFY_FILE_REG_STATUS: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING, ArchitectTypes.LONG],
        returns: ArchitectTypes.BOOLEAN,
        description: "Checks file register status against invalid list"
    },
    CLEAR_DATABASE_RECORD: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["tableCode"],
        returns: ArchitectTypes.SHORT,
        description: "Clears current database record by table code"
    },
    SQL_SET_SHORT: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["statementHandle", "paramIndex", "value"],
        returns: ArchitectTypes.SHORT,
        description: "Sets SQL short parameter value"
    },
    WRITE_JOURNAL: {
        params: [],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Writes journal entry"
    },
    CREATE_SPECIAL_LEDGER: {
        params: [ArchitectTypes.STRING],
        returns: ArchitectTypes.SHORT,
        description: "Creates special ledger"
    },
    READ_SUPPMEMB_HIST: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads supplementary member history"
    },
    DESCR_STR: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.STRING,
        description: "Returns description as string"
    },
    READ_SAL_HIST: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads salary history"
    },
    AC_BAL_SET_ARRAY: {
        params: [ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Sets AC_BAL output array handle"
    },
    GET_BAL_SS_CF: {
        params: [],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        deprecated: true,
        description: "Gets balance cashflow details"
    },
    SEND_STATEMENT: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Sends statement"
    },
    UPDATE_LOST_MBR_DATE: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Updates lost-member date"
    },
    READ_SWIMLOG: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads SWIM log record"
    },
    WRITE_SWIMLOG: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Writes SWIM log record"
    },
    UPDATE_CHQREC: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Updates cheque record"
    },
    CALC_PENSION_AMTS_PERIOD: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Calculates pension amount components for a period"
    },
    MIN_VALUE: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Returns minimum value/status"
    },
    GET_BSB_NAME: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING],
        returns: ArchitectTypes.STRING,
        description: "Gets BSB bank/branch name"
    },
    TABLE_VALUE: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.BOOLEAN,
        description: "Reads table value"
    },
    READ_ACQUHIST: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads acquisition history"
    },
    READ_SHCRTHST: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads share certificate history"
    },
    READ_SHARECRT: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads share certificate"
    },
    READ_ERRORS_INDEX2: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads errors index 2"
    },
    WRITE_ERROR_MSG_BY_CDE_VAR: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Writes error message by code and variables"
    },
    CHECK_ZERO_DATE: {
        params: [ArchitectTypes.DATE],
        paramLabels: ["date"],
        returns: ArchitectTypes.BOOLEAN,
        description: "Checks whether date is zero date"
    },
    CWB_TRANS_READ_STATIC: {
        params: [ArchitectTypes.STRING, ArchitectTypes.LONG, ArchitectTypes.SHORT],
        returns: ArchitectTypes.SHORT,
        description: "Reads transformed static line"
    },
    TRANSLATE_CLICKSUPER_FILE: {
        params: [ArchitectTypes.LONG],
        returns: ArchitectTypes.LONG,
        description: "Translates ClickSuper file"
    },
    SCH_TRANSLATE_FILE: {
        params: [ArchitectTypes.LONG],
        returns: ArchitectTypes.LONG,
        description: "Translates SCH file"
    },
    WESTPAC_TRANSLATE_FILE: {
        params: [ArchitectTypes.LONG],
        returns: ArchitectTypes.LONG,
        description: "Translates Westpac file"
    },
    READ_FILE_REG1: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Reads file register variant 1"
    },
    NEXT_MESSAGE_ID: {
        params: [],
        returns: ArchitectTypes.LONG,
        description: "Returns next message ID"
    },
    DB_GET_SQL_COLUMN_VALUE: {
        params: [ArchitectTypes.SHORT, ArchitectTypes.SHORT],
        paramLabels: ["handle", "columnIndex"],
        returns: ArchitectTypes.STRING,
        description: "Gets SQL column value by ordinal"
    },
    OUTPUT_FILENAME_COMPONENTS: {
        params: [ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Parses output filename components"
    },
    PRINT_IMAGE: {
        params: [ArchitectTypes.STRING, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN, ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        description: "Prints image at given coordinates"
    },
    DISPLAY_MESSAGE_PROMPT: {
        params: [ArchitectTypes.STRING],
        paramLabels: ["message"],
        returns: ArchitectTypes.SHORT,
        description: "Displays message prompt"
    },
    SQL_GET_LONG_COL: {
        params: [ArchitectTypes.LONG, ArchitectTypes.SHORT, ArchitectTypes.LONG],
        paramLabels: ["statementHandle", "columnIndex", "outputValue"],
        paramModes: ["REF", "REF", "VAR_init_not_required"],
        returns: ArchitectTypes.SHORT,
        description: "Gets SQL LONG column into output variable"
    },
    SQL_GET_DATE_COL: {
        params: [ArchitectTypes.LONG, ArchitectTypes.SHORT, ArchitectTypes.DATE],
        paramLabels: ["statementHandle", "columnIndex", "outputValue"],
        paramModes: ["REF", "REF", "VAR_init_not_required"],
        returns: ArchitectTypes.SHORT,
        description: "Gets SQL DATE column into output variable"
    },
    READ_SUPPFUND_DETLS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads supplementary fund details"
    },
    READ_REP_VARS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads report variables"
    },
    AC_BAL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DOUBLE,
        description: "Returns account balance"
    },
    READ_PATH: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads path record"
    },
    WORDS_WITH_CAPITAL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
        description: "Converts string to title case"
    },
    WRITE_ERR_MSG_BY_CDE_VAR_SET: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Writes error message by code variable set"
    },
    TRANSREF_KEY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.UNKNOWN,
        description: "Returns transaction reference key"
    },
    READ_ACCTHIST_2: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads account history variant 2"
    },
    FILE_APPEND_DELETE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Appends then deletes a file"
    },
    GUI_GET_STRING_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
        description: "Gets string value from GUI control"
    },
    DB_GET_COLUMN_ID: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Gets database column ID"
    },
    DB_GET_SQL_TABLE_NUMBER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Gets SQL table number"
    },
    GUI_SET_FOCUSABLE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Sets GUI control focusable state"
    },
    LDM: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.UNKNOWN,
        description: "LDM system function"
    },
    READ_INSR_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads insurance history record"
    },
    SQL_FETCH: {
        params: [ArchitectTypes.LONG],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Fetches next row from SQL cursor"
    },
    WRITE_EXCEPTION_HISTORY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Writes exception history record"
    },
    BTCH_REF_KEY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.UNKNOWN,
        description: "Returns batch reference key"
    },
    CREATE_DIRECTORY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Creates a directory"
    },
    DATE_TO_JULIAN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
        description: "Converts a date to Julian day number"
    },
    DB_GET_SQL_COLUMN_NAME: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
        description: "Gets SQL column name"
    },
    INDEX_LOAD_HIGH_VALUES: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Loads high values into index"
    },
    PAYHIST_CHGE_KEY: {
        params: [ArchitectTypes.SHORT],
        returns: ArchitectTypes.SHORT,
        description: "Changes payment history key context"
    },
    PUT_STRING_ARRAY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Puts string value into array"
    },
    READ_BATCH_ERRORS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads batch error records"
    },
    READ_BTCH_REF_6: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads batch reference variant 6"
    },
    READ_CAT_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads category history record"
    },
    READ_EXIT_DETLS4: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads exit details variant 4"
    },
    READ_PAYHIST_1: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads payment history variant 1"
    },
    READ_WRKHIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads work history record"
    },
    RNDHI: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DOUBLE,
        description: "Rounds up (high)"
    },
    SHARECRT_CHGE_KEY: {
        params: [ArchitectTypes.SHORT],
        returns: ArchitectTypes.SHORT,
        description: "Changes share certificate key context"
    },
    FILE_COPY_DELETE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Copies then deletes a file"
    },
    GET_TIME: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
        description: "Returns current time as string"
    },
    INDEX_READ_BY_RRN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads index record by relative record number"
    },
    JAVA_CALL_MAIN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Calls a Java main method"
    },
    MEMEXIT_CHGE_KEY: {
        params: [ArchitectTypes.SHORT],
        returns: ArchitectTypes.SHORT,
        description: "Changes member exit key context"
    },
    READ_CONTRATES: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads contribution rates"
    },
    READ_INVMGR_EXT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads investment manager extended record"
    },
    READ_TRANSREF_6: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads transaction reference variant 6"
    },
    READ_USER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads user record"
    },
    SQL_EXEC_DIRECT: {
        params: [ArchitectTypes.LONG, ArchitectTypes.STRING],
        paramModes: ["VAR_init_not_required", "VAR_init_not_required"],
        returns: ArchitectTypes.SHORT,
        description: "Executes a SQL statement directly"
    },
    SQL_SET_STRING: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Sets a SQL parameter to a string value"
    },
    TMP_CONT_CHGE_KEY: {
        params: [ArchitectTypes.SHORT],
        returns: ArchitectTypes.SHORT,
        description: "Changes temporary contribution key context"
    },
    UPDATE_TRANSREF: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Updates transaction reference record"
    },
    WRITE_FILE_REG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Writes file register record"
    },
    AC_BAL_DIV: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DOUBLE,
        description: "Returns account balance for a division"
    },
    AC_BAL_IMGR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DOUBLE,
        description: "Returns account balance for an investment manager"
    },
    INDEX_CURRENT_RRN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Returns current relative record number of index"
    },
    INITIALISE_ARRAY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Initialises an array"
    },
    INTEGER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
        description: "Converts a value to integer (truncates)"
    },
    JULIAN_TO_DATE: {
        params: [ArchitectTypes.LONG],
        paramLabels: ["julianDayNumber"],
        returns: ArchitectTypes.DATE,
        description: "Converts a Julian day number to a date"
    },
    READ_BKGD_JOB: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads background job record"
    },
    READ_CORR_NO: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads correspondence number record"
    },
    READ_EXCEPTION_HISTORY_KEY1: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads exception history by key 1"
    },
    READ_RRECS_MBR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads rollover records for member"
    },
    READ_SAL_HIST_2: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads salary history variant 2"
    },
    READ_SHCRTHST_1: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads share certificate history variant 1"
    },
    REPORT_DESCRIPTION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
        description: "Returns report description string"
    },
    SPAN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Calculates span/range"
    },
    SQL_CONNECT: {
        params: [],
        returns: ArchitectTypes.SHORT,
        description: "Connects to a SQL database",
        deprecated: true
    },
    XPATHCONTEXT_COUNT_ELEMENTS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Counts elements matching an XPath expression"
    },
    EMAILX: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Sends an email"
    },
    FINALISE_ARRAY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Finalises and releases an array"
    },
    SHCRTHST_CHGE_KEY: {
        params: [ArchitectTypes.SHORT],
        returns: ArchitectTypes.SHORT,
        description: "Changes share certificate history key context"
    },
    SQL_DISCONNECT: {
        params: [],
        returns: ArchitectTypes.SHORT,
        description: "Disconnects from a SQL database",
        deprecated: true
    },
    BASE64_ENCODE: {
        params: [ArchitectTypes.STRING, ArchitectTypes.STRING],
        paramLabels: ["inputFile", "outputFile"],
        varArgs: true,
        returns: ArchitectTypes.STRING,
        description: "Base64-encodes a value"
    },
    COMPUTE_SOUNDEX: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
        description: "Computes Soundex phonetic code"
    },
    DAY_OF_WEEK: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Returns the day of the week for a date"
    },
    DELETE_ARRAY_REC: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Deletes a record from an array"
    },
    DELETE_CONTRIBUTION_LINE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Deletes a contribution line record"
    },
    DELETE_SPECIAL_LEDGER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Deletes a special ledger entry"
    },
    GUI_SET_STRING_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Sets string value on GUI control"
    },
    GUI_VAR_GET_LONG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
        description: "Gets LONG variable value from GUI context"
    },
    GUI_VAR_SET_LONG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Sets LONG variable value in GUI context"
    },
    HTTPS_POST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Performs an HTTPS POST request"
    },
    INDEX_LOAD_KEY_DOUBLE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Loads a DOUBLE key into index context"
    },
    INDEX_LOAD_KEY_TIME: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Loads a TIME key into index context"
    },
    INSERT_SPECIAL_LEDGER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Inserts a special ledger entry"
    },
    INVMGR_CHGE_KEY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Changes investment manager key context"
    },
    LEDGER_ACC_BAL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DOUBLE,
        description: "Returns ledger account balance"
    },
    PCL2PDF: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Converts PCL content to PDF"
    },
    RANDOM_NO: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
        description: "Returns a random number"
    },
    READ_BTCH_REF: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads batch reference record"
    },
    READ_BTCHCODE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads batch code record"
    },
    READ_CHQREC_NO: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads cheque record by number"
    },
    READ_INVMHIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads investment manager history"
    },
    READ_URL_TEMPLATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Reads URL template record"
    },
    REGEX_LAST_MATCHED_GROUP: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
        description: "Returns last regex matched group"
    },
    REGEX_MATCH: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.BOOLEAN,
        description: "Performs regex match"
    },
    REPAIR_FILENAME: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
        description: "Repairs/sanitizes filename"
    },
    SET_TIME_VAR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Sets a time variable"
    },
    SPECIAL_LEDGER_GET_FIRST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Gets first special ledger record"
    },
    SPECIAL_LEDGER_GET_NEXT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Gets next special ledger record"
    },
    SQL_EXECUTE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Executes prepared SQL statement"
    },
    SQL_FREE_HANDLE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Frees SQL statement handle"
    },
    SQL_PREPARE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Prepares SQL statement"
    },
    TFN_ENCRYPT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
        description: "Encrypts a TFN value"
    },
    TRANSACTION_LISTING: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Produces transaction listing output"
    },
    UPD_TMP_CRTR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Updates temporary contributor record"
    },
    UPDATE_ERROR_MSG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Updates error message record"
    },
    UPDATE_PAYMENT_DETAILS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Updates payment details"
    },
    WRITE_INSR_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Writes insurance history record"
    },
    WRITE_NOTES: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Writes notes record"
    },
    WRITE_PAYHIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Writes payment history record"
    },
    WRITE_WEB_USER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Writes web user record"
    },
    WRITE_WEB_USER_PASSWORD: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Writes web user password"
    },
    XMLDOCUMENT_CREATE_FROM_FILE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Creates XML document from file"
    },
    XMLDOCUMENT_CREATE_FROM_STRING: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Creates XML document from string"
    },
    XPATHCONTEXT_CHECK_XPATH: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Checks XPath expression in context"
    },
    XPATHCONTEXT_CREATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        description: "Creates XPath context"
    },
    XPATHCONTEXT_GET_STRING: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
        description: "Gets string value from XPath context"
    },
    // Additional system functions
    OCCURS: {
        params: [ArchitectTypes.UNKNOWN],
        returns: ArchitectTypes.SHORT,
        varArgs: true,
        description: "Returns occurrence count"
    },

    // ============================================================
    // Database (0202)
    // ============================================================
    AC_REC2: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    ALLOC_GCERT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    ASSET_PROFILE_SWITCHES: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    BALANCES_CHGE_KEY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    BATCH_PROCESS_ORDER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CALCULATE_CAPGAINS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CALC_CONTS_DUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CALC_MIN_MAX_AMTS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CALC_OR_SET_PURCHASE_PRICE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CALC_PENSION_AMTS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CALC_PENSION_AMTS_EXT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CALC_PENSION_AMTS_POST2007: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CALC_PEN_AMTS_PERIOD: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CALC_PEN_AMTS_POST2007: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CATCH_UP_PAYMENTS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CHEQUE_WORDS_MILL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CLEAR_CORR_REG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CLEAR_EXIT_TRANSREF_RBL_FLAG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    COMPARE_SHARECRT_LEDGER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CONFIRM_DOCUMENT_PUBLISHED: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CONFIRM_EXCEPTION_PUBLISHED: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    COPY_UNIT_ENTIT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CREATE_REVERSING_TRAN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    CREATE_TRANSACTION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DB_D: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DATE,
    },
    DB_F: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DOUBLE,
    },
    DB_L: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    DB_S: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DB_T: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.TIME,
    },
    DB_V: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    DB_Z: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    DELETE_CATEGORY_HISTORY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DELETE_ERROR_MSG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DELETE_FILE_REG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DELETE_NOTES: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DELETE_SUPERGATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DELETE_SUPPMEMB: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DETERMINE_NEXT_REVIEW: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DATE,
    },
    DET_SORT_ORDER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DV_D: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DV_F: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DV_L: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DV_S: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DV_T: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DV_V: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DV_Z: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    ENQ_MBR_CHGE_KEY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    FIRST_CONTRIBUTION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    FIRST_CONTRIBUTION_MBR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    FONT_FILE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GENERATE_AND_PUBLISH_KEYS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GET_CLOB: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GET_CURRENT_INDEX: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GET_DAILY_ACC_CF: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GET_LAST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GET_MEMBER_ID: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    GET_MSGCODE_BY_ID: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    GET_NEXT_DAILY_SSS_CF: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GET_NEXT_SSS_ACC_BAL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GET_NEXT_SS_ACC_BAL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GET_NEXT_SS_CF: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
        deprecated:true
    },
    INTEREST_CONTS_DUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    INVM_ASSET_ALLOC: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DOUBLE,
    },
    IsUserMemberOfGroup: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.BOOLEAN,
    },
    LAST_CONTRIBUTION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LAST_CONTRIBUTION_DATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LAST_CONTRIBUTION_MBR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LAST_PENSION_PAYMENT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LEDGER_ACCOUNT_TOT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LEDGER_ACC_BALS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LEDGER_CLEAR_POS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LEDGER_CONT_AC_BAL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LEDGER_RESTORE_POS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LEDGER_SAVE_POS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LINK_CHQ_BANK_RECS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    LINK_TRN_BANK_RECS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    LIST_SUPERGATE_LINES: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LOAD_EXCEPTION_DATA: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    NEXT_CHEQUE_ID: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    NEXT_DEPOSIT_ID: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    NEXT_EFT_ID: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    NEXT_FUND_CHEQUE_ID: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    NEXT_FUND_EFT_ID: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    NOTES: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    NUMBER_SUPER_PERIODS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    PAY_PERIOD_START_DATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    POLICY_CHGE_KEY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    POST_TRANSACTION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    PUBLISH_CURRENT_EXCEPTION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    PUBLISH_DOCUMENT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_ACCTHIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_ACCT_MEM_DIV: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_ANR_HIST_COPY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_ASCII_TABLE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DOUBLE,
    },
    READ_ASCII_TABLE2: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_AWOTE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_BAL1: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_BATCHIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_BTCH_DEF: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CAPGAINS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CAPGNS_R: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CAPGNS_R_KEY1: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CHQREC_TRAN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CHQR_STAT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CHQR_TYPE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_COMMISSION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_COMPHIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_COMP_LOC: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CONTRATES_UNPRES: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CONT_ADJ: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CONT_ADJ2: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CONT_ADJ_3: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CONT_VARIANCE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CORR_NO_RECTYPE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CORR_PAYROLL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CORR_STAT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_CORR_STAT_PAYROLL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_DATA_REG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_DIARY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_ELS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_ENQ_EMP: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_ENQ_MBR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_ENQ_MBR3: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_ENQ_MBR_TOT1: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_ENQ_MBR_TOTS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_EXIT_DETLS2: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_FUND_GROUP: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_FUND_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_GCERT_STAT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_GCERT_TYPE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_GROUP: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_INSDEFLT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_INSR_HIST_CLT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_INT_TABLE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_LAST_NO: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_MCHQS_REF: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_MCHQS_TRAN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_MED_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_MED_HIST_CLIENT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_MEMB4: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_MERGE_HISTORY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_NZEXCHGE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_PAST_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_PAYHIST_2: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_PAYHIST_4: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_PAY_REINSURER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_POLCOMM: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_POLICY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_POLICY_BEN_DTLS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_PRD_PAYMENT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_RCT_RFND: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_RCT_RFND_2: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_REFUND: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_RRECS_REP: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_SAL_HIST_RR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_SERVICE_REQUESTS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_SUPER_PERIOD: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_SUPPFUND_LABELS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_SUPPMEMB: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_SUPP_ADVISER_HIST_TYP: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_SUPP_INVMGR_HIST_TYP: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_SUPP_PAY_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_SURCHARGE2: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_TAXFLAG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_TAX_SAL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_TMP_CONT_3: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_TRANSREF_5_EFLG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_UNIT_ENTIT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_UNIT_ENTIT3: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_WHRSHIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    READ_WHRSHIST_TOT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    REPUBLISH_DOCUMENT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    REPUBLISH_EXCEPTION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    RESET_CLIENT_SYS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    RESET_REFUND: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    RES_INTEREST_CONTS_DUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    SET_CLIENT_SYS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    SORT_INVMGR_R: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    SORT_INVMGR_W: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    SQL_GET_TIME_COL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    SQL_INDEX_ADD_CONDITION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    SQL_INDEX_CLEAR_KEY: {
        params: [ArchitectTypes.LONG],
        returns: ArchitectTypes.SHORT,
    },
    SQL_INDEX_CLOSE: {
        params: [ArchitectTypes.LONG],
        returns: ArchitectTypes.SHORT,
    },
    SQL_INDEX_FIX_KEY: {
        params: [ArchitectTypes.LONG],
        returns: ArchitectTypes.SHORT,
    },
    SQL_INDEX_LOAD_KEY_STRING: {
        params:      [ArchitectTypes.LONG, ArchitectTypes.STRING, ArchitectTypes.SHORT],
        paramLabels: ["handle", "keyValue", "keyLength"],
        paramModes:  ["REF",              "REF",       "REF"],
        returns: ArchitectTypes.SHORT,
        description: "Loads a STRING key segment into an open index."
    },
    SQL_INDEX_LOAD_KEY_LONG: {
        params:      [ArchitectTypes.LONG, ArchitectTypes.LONG],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: ArchitectTypes.SHORT,
        description: "Loads a LONG key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    SQL_INDEX_LOAD_KEY_SHORT: {
        params:      [ArchitectTypes.LONG, ArchitectTypes.SHORT],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: ArchitectTypes.SHORT,
        description: "Loads a SHORT key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    SQL_INDEX_LOAD_KEY_DATE: {
        params:      [ArchitectTypes.LONG, ArchitectTypes.DATE],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: ArchitectTypes.SHORT,
        description: "Loads a DATE key segment into an open index. Arg 0: handle (REF). Arg 1: key value (REF)."
    },
    SQL_INDEX_LOAD_KEY_DOUBLE: {
        params:      [ArchitectTypes.LONG, ArchitectTypes.DOUBLE],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: ArchitectTypes.SHORT,
    },
    SQL_INDEX_LOAD_KEY_TIME: {
        params:      [ArchitectTypes.LONG, ArchitectTypes.TIME],
        paramLabels: ["handle", "keyValue"],
        paramModes:  ["REF",              "REF"],
        returns: ArchitectTypes.SHORT,
    },
    SQL_INDEX_OPEN_STANDARD: {
        params:      [ArchitectTypes.STRING, ArchitectTypes.SHORT, ArchitectTypes.LONG],
        paramLabels: ["tableCode", "indexNumber", "handle"],
        paramModes:  ["REF",              "REF",              "VAR_init_not_required"],
        // arg 2 (handle) becomes bound to the table code supplied in arg 0
        bindsHandle: { handleParam: 2, tableCodeParam: 0 },
        returns: ArchitectTypes.SHORT,
        description: "Opens a standard index. Arg 0: table code (REF). Arg 1: index number (REF). Arg 2: handle variable — written by function, need not be initialised (VAR_init_not_required).",
        // Only the function name is pre-filled in the snippet so that the index-number
        // completion provider can offer choices after the user types the '('.
        // $0 places the final cursor inside the parens
        insertSnippet: "SQL_INDEX_OPEN_STANDARD$0"
    },
    SQL_INDEX_READ_BY_KEY: {
        params:      [ArchitectTypes.LONG, ArchitectTypes.STRING],
        paramLabels: ["handle", "cursorDirection"],
        paramModes:  ["REF",              "REF"],
        // moves the cursor for the table that was bound to the handle in arg 0
        cursorTableFromHandle: 0,
        returns: ArchitectTypes.SHORT,
        description: "Reads the next record from an open index. Arg 0: handle (REF). Arg 1: cursor direction (REF). Advances the DB cursor for the table the handle is bound to."
    },
    SQL_SET_DATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    SQL_SET_DOUBLE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    SQL_SET_LONG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    SQL_SET_TIME: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    TABLE_DESC: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    TOT_ACC_AT_EFF: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    TRANSACTION_DESC: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    UNLOAD_EXCEPTION_DATA: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UNPOST_TRANSACTION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_AUDITAUTH: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_BROKER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_CLIENT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_CLIENT_ELS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_CLIENT_GROUPS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_CONTS_TO_BE_TAKEN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_DEDUCTIBLE_PERCENTAGE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_EMPLOYER_STATUS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_EXIT_CO_CONTRIBUTIONS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_EXIT_TAX: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_MAX_CALC: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_MEMBER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_MIN_MAX_CALC: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_RCT_RFND: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_ROLLOVER_ELS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_SHARECRT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_SHARECRT_REDN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_SHARE_CERTIFICATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_STATEMENT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_STATEMENT_BY_REPORT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPDATE_SUPER_MATCH: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_BTCH_REF: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_CONT_ADJ: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_CORR_REG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_CORR_REG_RECTYPE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_MBR_DETAILS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_MBR_ISSUED: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_MBR_NOTFD: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_PAID_CONTS_TO: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SHARECRT_EXITFEE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SUPPFUND_DETLS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SUPPMEMB: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SUPPMEMB_FLAGS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SUPP_ADVISER_ALL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SUPP_CLIENT_ALL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SUPP_CLIENT_FLAGS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SUPP_CLIENT_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SUPP_INVMGR_ALL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SUPP_PAY_ALL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SUPP_PAY_FLAGS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_SUPP_PAY_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_TMP_EXIT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UPD_USR_BTCH: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    USER_MD5_HASH: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    VALIDATE_WEBUSER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    WRITE_ADVISOR_AUTHORITY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_ADVISOR_PROPORTIONS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_ANRHIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_BANK_REC: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_CAT_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_CHQREC: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_CHQREC_LINE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_CHQREC_TYPE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_CHQREC_TYPE_LINE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_COMPHIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_CONTRATES: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_CONTRIBUTION_LINE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_CONT_VARIANCE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_DATA_REG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_DATA_REG2: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_ERROR_MSG_BY_CDE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_ERR_MSG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_ERR_MSG_BY_CDE_DESC: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_FILE_REG2: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_INSR_HIST_CLT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_INSR_HIST_CLT1: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_INVESTMENT_MANAGER_HISTORY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_INVPROP: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_INVPROP_CLT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_MED_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_NOTES_MBR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_NOTES_REG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_PAYMENT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_PAYMENT_OPTIONS_DEFAULTS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_PAY_REINSURER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_PENSION_HISTORY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_REFUND: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_REP_VARS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_ROLLOVER: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_SAL_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_SAL_HIST_EMP: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_STATEMENT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_SUPERGATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_TAXSAL_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_UNIT_ENTIT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_UNIT_ENTIT3: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_UNIT_PRICE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_WHRSHIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_WRK_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    WRITE_WRK_HRS_HIST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },

    // ============================================================
    // Date (0203)
    // ============================================================
    DAY_ABV: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    DAY_NAME: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    DAY_OF_YEAR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DAY_TO_DATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DATE,
    },
    ISLEAP: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.BOOLEAN,
    },

    // ============================================================
    // File (0204)
    // ============================================================
    DO_PRINT_FILE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    FILE_INSERT_DELETE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    FILE_SIZE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },

    // ============================================================
    // Numeric (0205)
    // ============================================================
    NUMBER_FRIDAYS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },

    // ============================================================
    // String (0206)
    // ============================================================
    NUMBER_OF_TOKENS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    RANK: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    UNSANITISE_XML: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },

    // ============================================================
    // Time (0207)
    // ============================================================
    ELAPSED_SECONDS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DOUBLE,
    },
    MILLISECONDS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },

    // ============================================================
    // Miscellaneous (0208)
    // ============================================================
    BARCODE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    BASE64_DECODE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    DOS_COMMAND_WAIT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    EMAIL: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    EMAILX_WARN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    FORM_EXTENSION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    FORM_NAME: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    FORM_OPTIONS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    GET_CONFIGURATION_STRING_BY_ID: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GET_TABLE_NAME: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    HTTPS_POST_AUTHENTICATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    HTTP_GET: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    HTTP_POST: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    HTTP_POST_SOAPACTION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    JAVA_EXECUTE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    LOG_STRING: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    NEXT_WORKING_DAY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.DATE,
    },
    NO_SWITCHES_SINCE_EOY: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    PAYROLL_ACCESS_DAYS: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    PRINT_CMD: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    REPORT_VARCHAR_PARAM: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    RUN_BATCH_JOB_EX: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },
    SAVE_AS_XLSX: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    SET_PURGE_FLAG: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    SYS_VERSION: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.STRING,
    },
    WORKING_DAYS_BETWEEN: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.LONG,
    },

    // ============================================================
    // GUI Extension (0209)
    // ============================================================
    GUI_GET_DATE_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_GET_DOUBLE_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_GET_FOCUSABLE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_GET_LONG_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_GET_SHORT_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_GET_TIME_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_GET_VALUE_REQUIRED: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_GET_VISIBLE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_POP_VALIDATION_ERROR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_PUSH_VALIDATION_ERROR: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_DATE_FIELD: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_DATE_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_DOUBLE_FIELD: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_DOUBLE_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_LONG_FIELD: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_LONG_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_SHORT_FIELD: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_SHORT_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_STRING_FIELD: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_TIME_FIELD: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_TIME_VALUE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_VALUE_REQUIRED: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_SET_VISIBLE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_VAR_GET_DATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_VAR_GET_DOUBLE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_VAR_GET_SHORT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_VAR_GET_STRING: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_VAR_GET_TIME: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_VAR_SET_DATE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_VAR_SET_DOUBLE: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_VAR_SET_SHORT: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_VAR_SET_STRING: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    GUI_VAR_SET_TIME: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
    PROMPT_FORM: {
        params: [],
        varArgs: true,
        returns: ArchitectTypes.SHORT,
    },
};

/**
 * Returns an array of all known built-in function names.
 */
function getAllKnownFunctions() {
    return Object.keys(BuiltInFunctions);
}

export {
    BuiltInFunctions,
    getAllKnownFunctions
};
