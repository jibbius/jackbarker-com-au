/**
 * Built-in function signatures — loader and runtime registry.
 *
 * Source of truth: builtins-data/functions/<NAME>.json
 *   with schema     builtins-data/schemas/function.schema.json
 *
 * Cold-start path: prefer the bundle (single readFile + JSON.parse) when
 * present; otherwise walk the directory. Every entry is validated against
 * the schema on load — bad data fails loud at startup.
 *
 * Each entry's `params` field is an array of inlined per-parameter objects
 * `{ type, label?, mode?, role? }`. `type` is a single ArchitectType string,
 * or an array of ArchitectType strings for union-typed parameters. `mode`
 * defaults to "REF" when omitted; `role` is omitted when no role applies.
 *
 * The exported `BuiltInFunctions` is a Proxy over an internal mutable store.
 * External writes (assignment, delete, defineProperty) throw a TypeError
 * pointing the caller at the supported register API. Supplementary
 * registrations flow through `registerSupplementaryFunction`, which
 * validates the entry against the same schema before storing — so reads
 * via `BuiltInFunctions[upperName]` continue to work uniformly across core
 * and supplementary entries.
 *
 * Mirrors the contract in `globalVariablesRegistry.js` and `tableRegistry.js`.
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { validateOrThrow } from "./_schemaValidator.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_ROOT   = path.resolve(__dirname, "..", "..", "..", "builtins-data");
const DATA_DIR    = path.join(DATA_ROOT, "functions");
const BUNDLE_FILE = path.join(DATA_ROOT, "functions.bundle.json");
const SCHEMA_FILE = path.join(DATA_ROOT, "schemas", "function.schema.json");

const schema = JSON.parse(fs.readFileSync(SCHEMA_FILE, "utf8"));

function loadFromBundle() {
    const entries = JSON.parse(fs.readFileSync(BUNDLE_FILE, "utf8"));
    if (!Array.isArray(entries)) {
        throw new Error(`${BUNDLE_FILE}: expected an array of entries`);
    }
    return entries;
}

function loadFromDirectory() {
    const files = fs.readdirSync(DATA_DIR).filter(f => f.endsWith(".json")).sort();
    return files.map(f => {
        const full = path.join(DATA_DIR, f);
        const entry = JSON.parse(fs.readFileSync(full, "utf8"));
        const stem = f.slice(0, -".json".length);
        if (entry.name !== stem) {
            throw new Error(`${full}: "name" (${entry.name}) does not match file stem (${stem})`);
        }
        return entry;
    });
}

const _entries = {};
const _coreKeys = new Set();
const _displacedCoreEntries = new Map();

function _buildStored(entry) {
    const stored = {
        params: entry.params,
        returns: entry.returns,
        varArgs: entry.varArgs ?? false
    };
    if (entry.deprecated)                                 stored.deprecated            = true;
    if (typeof entry.description           === "string")  stored.description           = entry.description;
    if (typeof entry.insertSnippet         === "string")  stored.insertSnippet         = entry.insertSnippet;
    if (entry.bindsHandle)                                stored.bindsHandle           = entry.bindsHandle;
    if (Array.isArray(entry.cursorTables))                stored.cursorTables          = entry.cursorTables;
    if (typeof entry.cursorTableFromHandle === "number")  stored.cursorTableFromHandle = entry.cursorTableFromHandle;
    return stored;
}

function _populate() {
    const entries = fs.existsSync(BUNDLE_FILE) ? loadFromBundle() : loadFromDirectory();
    for (const entry of entries) {
        const location = `functions/${entry.name ?? "<unknown>"}.json`;
        validateOrThrow(entry, schema, location);
        if (Object.prototype.hasOwnProperty.call(_entries, entry.name)) {
            throw new Error(`${location}: duplicate function "${entry.name}"`);
        }
        _entries[entry.name] = _buildStored(entry);
        _coreKeys.add(entry.name);
    }
}

_populate();

const _MUTATION_ERROR =
    "BuiltInFunctions is read-only — call registerSupplementaryFunction() to add or override entries.";

const BuiltInFunctions = new Proxy(_entries, {
    set()            { throw new TypeError(_MUTATION_ERROR); },
    deleteProperty() { throw new TypeError(_MUTATION_ERROR); },
    defineProperty() { throw new TypeError(_MUTATION_ERROR); }
});

/**
 * Register a supplementary function entry at runtime.
 *
 * Mirrors `registerSupplementaryGlobalVariable`: same `{ added, replaced,
 * skipped }` return shape and the same `preferCore` collision policy.
 *
 * Validates the entry against `function.schema.json`. The supplied `entry`
 * may omit the schema's `name` field — it is inferred from the `name`
 * argument and added to the candidate before validation. Throws a
 * descriptive Error if the entry is malformed.
 *
 * Collision policy: when `preferCore` is true and the name already exists,
 * the call is a no-op and `skipped` is true. Otherwise the new entry
 * replaces the existing one and the displaced *core* entry (if any) is
 * captured for restoration via `unregisterSupplementaryFunction`.
 *
 * @param {string} name - The all-caps function identifier. Normalised to uppercase.
 * @param {object} entry - The function entry (params, returns, etc.).
 * @param {boolean} [preferCore=false]
 * @returns {{added: boolean, replaced: boolean, skipped: boolean}}
 */
function registerSupplementaryFunction(name, entry, preferCore = false) {
    if (typeof name !== "string" || name.length === 0) {
        throw new TypeError("registerSupplementaryFunction: name must be a non-empty string.");
    }
    if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
        throw new TypeError(`registerSupplementaryFunction("${name}"): entry must be a plain object.`);
    }
    const key = name.toUpperCase();
    const candidate = { name: key, ...entry };
    validateOrThrow(candidate, schema, `supplementary function "${key}"`);

    const conflict = Object.prototype.hasOwnProperty.call(_entries, key);
    if (conflict && preferCore) {
        return { added: false, replaced: false, skipped: true };
    }
    if (conflict && _coreKeys.has(key) && !_displacedCoreEntries.has(key)) {
        _displacedCoreEntries.set(key, _entries[key]);
    }
    _entries[key] = _buildStored(candidate);
    return { added: !conflict, replaced: conflict, skipped: false };
}

/**
 * Reverses a prior `registerSupplementaryFunction` call. Removes the entry
 * when the name was not part of the core registry; otherwise restores the
 * displaced core entry.
 *
 * Safe to call with a name that was never registered (no-op).
 *
 * @param {string} name - Function name (any casing).
 */
function unregisterSupplementaryFunction(name) {
    const key = name.toUpperCase();
    if (_displacedCoreEntries.has(key)) {
        _entries[key] = _displacedCoreEntries.get(key);
        _displacedCoreEntries.delete(key);
        return;
    }
    if (_coreKeys.has(key)) {
        // The supplementary call was a no-op (preferCore=true) — nothing to undo.
        return;
    }
    delete _entries[key];
}

function getAllKnownFunctions() {
    return Object.keys(_entries);
}

export {
    BuiltInFunctions,
    getAllKnownFunctions,
    registerSupplementaryFunction,
    unregisterSupplementaryFunction
};
