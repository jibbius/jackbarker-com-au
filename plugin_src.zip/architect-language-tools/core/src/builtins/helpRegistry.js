/**
 * helpRegistry.js — contextual help page map for the Architect language.
 *
 * Source of truth: builtins-data/help-registry.json
 *   with schema    builtins-data/schemas/help-registry.schema.json
 *
 * Composite-file registry: a single JSON object whose keys are tokens
 * (operators or identifiers, uppercased) and whose values are help-page
 * filenames (optionally with #anchor). The file is loaded once at startup
 * and validated against the schema — bad data fails loud.
 *
 * The internal store (`HELP_REGISTRY`) is mutable but not exported; the
 * only external surface is `getHelpPage`, `registerSupplementaryHelpEntries`,
 * and `unregisterSupplementaryHelpEntries`. Field handles (hXXy_... /
 * hCRfName...) are NOT stored — getHelpPage() derives their page from the
 * table code at runtime.
 *
 * No Proxy is needed on `HELP_REGISTRY` itself: there is no consumer that
 * reads the registry directly (only `getHelpPage` does, internally), so the
 * register/unregister API is the only mutation surface and the read-only
 * invariant holds without a structural guard. This is the deliberate
 * counterpart to the Proxy-fronted `BuiltInGlobalVariables`,
 * `BuiltInFunctions`, `DeprecatedHandles`, and `TABLE_REGISTRY` exports —
 * those are exported for read access, so they need the trap.
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { validateOrThrow } from "./_schemaValidator.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_ROOT   = path.resolve(__dirname, "..", "..", "..", "builtins-data");
const DATA_FILE   = path.join(DATA_ROOT, "help-registry.json");
const SCHEMA_FILE = path.join(DATA_ROOT, "schemas", "help-registry.schema.json");

const schema = JSON.parse(fs.readFileSync(SCHEMA_FILE, "utf8"));

function _loadHelpRegistry() {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    validateOrThrow(raw, schema, "help-registry.json");
    const out = {};
    for (const [key, value] of Object.entries(raw)) {
        if (key === "$schema") continue;
        out[key] = value;
    }
    return out;
}

const HELP_REGISTRY = _loadHelpRegistry();

/** Field handle pattern — same as fieldRegistry generator. */
const FIELD_HANDLE_RE = /^h[A-Z][A-Z0-9][a-z]/i;

/**
 * Returns the help page filename (possibly with #anchor) for a token name,
 * or null if no documentation is available.
 *
 * Accepts any casing — lookup is case-insensitive.
 * The # prefix used in HASH-ON mode (e.g. #IF, #VAR) should be stripped
 * before calling; pass just the bare keyword.
 *
 * Field handles (e.g. hCAz_Account_Code) are handled by deriving the
 * table page from chars 1–2 of the handle (hCA.htm, hMM.htm, etc.).
 */
function getHelpPage(name) {
    if (!name) return null;
    const upper = name.toUpperCase();
    if (Object.prototype.hasOwnProperty.call(HELP_REGISTRY, upper)) {
        return HELP_REGISTRY[upper];
    }
    // Field handle fallback: hCAz_Account_Code → hCA.htm
    if (FIELD_HANDLE_RE.test(name)) {
        return `h${name.slice(1, 3).toUpperCase()}.htm`;
    }
    return null;
}

/**
 * Snapshot of HELP_REGISTRY entries that were overwritten by supplementary
 * registration, so they can be restored on unregister.
 * @type {Map<string, string>}
 */
const _displacedHelpEntries = new Map();

/**
 * Keys added (not replaced) by supplementary registration.
 * @type {Set<string>}
 */
const _injectedHelpKeys = new Set();

/**
 * Merges additional help entries into HELP_REGISTRY.
 * Keys are normalised to UPPERCASE. Existing entries are only replaced when
 * `preferCore` is false (the default — caller/employer wins).
 *
 * @param {{ [token: string]: string }} entries - Token → help page filename map
 * @param {boolean} [preferCore=false]
 */
function registerSupplementaryHelpEntries(entries, preferCore = false) {
    let added = 0;
    let replaced = 0;
    let skipped = 0;
    for (const [token, page] of Object.entries(entries)) {
        const key = token.toUpperCase();
        const conflict = Object.prototype.hasOwnProperty.call(HELP_REGISTRY, key);
        if (conflict && preferCore) {
            skipped++;
            continue;
        }
        if (conflict && !_displacedHelpEntries.has(key)) {
            _displacedHelpEntries.set(key, HELP_REGISTRY[key]);
        }
        if (!conflict) _injectedHelpKeys.add(key);
        HELP_REGISTRY[key] = page;
        if (conflict) replaced++;
        else added++;
    }
    return { added, replaced, skipped };
}

/**
 * Reverses prior `registerSupplementaryHelpEntries` calls for the listed keys.
 * Removes new keys, restores displaced core entries. Safe to call with unknown
 * keys.
 *
 * @param {Iterable<string>} tokens
 */
function unregisterSupplementaryHelpEntries(tokens) {
    for (const token of tokens) {
        const key = token.toUpperCase();
        if (_displacedHelpEntries.has(key)) {
            HELP_REGISTRY[key] = _displacedHelpEntries.get(key);
            _displacedHelpEntries.delete(key);
        } else if (_injectedHelpKeys.has(key)) {
            delete HELP_REGISTRY[key];
            _injectedHelpKeys.delete(key);
        }
    }
}

export { getHelpPage, registerSupplementaryHelpEntries, unregisterSupplementaryHelpEntries };
