/**
 * deprecatedSymbols.js — deprecated field handle aliases.
 *
 * Source of truth: builtins-data/deprecated-symbols.json
 *   with schema    builtins-data/schemas/deprecated-symbol.schema.json
 *
 * Maps old-style TABLE_FIELD handle names (the pre-h-prefix naming
 * convention) to their canonical replacement h-prefix names. Values
 * are normally replacement names but may be expression patterns
 * (e.g. SUBSTR(...)) for the handful of entries deprecated in favour
 * of a computed value.
 *
 * The exported `DeprecatedHandles` is a Proxy over an internal mutable
 * store. External writes (assignment, delete, defineProperty) throw a
 * TypeError pointing the caller at the supported register API.
 * Supplementary registrations flow through
 * `registerSupplementaryDeprecatedHandle` /
 * `unregisterSupplementaryDeprecatedHandle`.
 *
 * Mirrors the contract in `globalVariablesRegistry.js`,
 * `functionsRegistry.js`, and `tableRegistry.js`.
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { validateOrThrow } from "./_schemaValidator.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_ROOT   = path.resolve(__dirname, "..", "..", "..", "builtins-data");
const DATA_FILE   = path.join(DATA_ROOT, "deprecated-symbols.json");
const SCHEMA_FILE = path.join(DATA_ROOT, "schemas", "deprecated-symbol.schema.json");

const schema = JSON.parse(fs.readFileSync(SCHEMA_FILE, "utf8"));

const _entries = {};
const _coreKeys = new Set();
const _displacedCoreEntries = new Map();

function _populate() {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    validateOrThrow(raw, schema, "deprecated-symbols.json");
    for (const [key, value] of Object.entries(raw)) {
        if (key === "$schema") continue;
        _entries[key] = value;
        _coreKeys.add(key);
    }
}

_populate();

const _MUTATION_ERROR =
    "DeprecatedHandles is read-only — call registerSupplementaryDeprecatedHandle() to add or override entries.";

const DeprecatedHandles = new Proxy(_entries, {
    set()            { throw new TypeError(_MUTATION_ERROR); },
    deleteProperty() { throw new TypeError(_MUTATION_ERROR); },
    defineProperty() { throw new TypeError(_MUTATION_ERROR); }
});

/**
 * Register a supplementary deprecated-handle alias at runtime.
 *
 * Mirrors `registerSupplementaryGlobalVariable`: same `{ added, replaced,
 * skipped }` return shape and the same `preferCore` collision policy.
 *
 * Validates the replacement against the deprecated-symbol schema —
 * a non-empty string. Throws a descriptive Error if malformed.
 *
 * Collision policy: when `preferCore` is true and the name already exists,
 * the call is a no-op and `skipped` is true. Otherwise the new replacement
 * value overwrites the existing one and the displaced *core* entry (if
 * any) is captured for restoration via
 * `unregisterSupplementaryDeprecatedHandle`.
 *
 * @param {string} name        - Legacy TABLE_FIELD identifier. Normalised to uppercase.
 * @param {string} replacement - Canonical replacement (h-prefix name or expression).
 * @param {boolean} [preferCore=false]
 * @returns {{added: boolean, replaced: boolean, skipped: boolean}}
 */
function registerSupplementaryDeprecatedHandle(name, replacement, preferCore = false) {
    if (typeof name !== "string" || name.length === 0) {
        throw new TypeError("registerSupplementaryDeprecatedHandle: name must be a non-empty string.");
    }
    if (typeof replacement !== "string" || replacement.length === 0) {
        throw new TypeError(
            `registerSupplementaryDeprecatedHandle("${name}"): replacement must be a non-empty string.`
        );
    }
    const key = name.toUpperCase();

    const conflict = Object.prototype.hasOwnProperty.call(_entries, key);
    if (conflict && preferCore) {
        return { added: false, replaced: false, skipped: true };
    }
    if (conflict && _coreKeys.has(key) && !_displacedCoreEntries.has(key)) {
        _displacedCoreEntries.set(key, _entries[key]);
    }
    _entries[key] = replacement;
    return { added: !conflict, replaced: conflict, skipped: false };
}

/**
 * Reverses a prior `registerSupplementaryDeprecatedHandle` call. Removes
 * the entry when the name was not part of the core registry; otherwise
 * restores the displaced core entry.
 *
 * Safe to call with a name that was never registered (no-op).
 *
 * @param {string} name - Deprecated handle name (any casing).
 */
function unregisterSupplementaryDeprecatedHandle(name) {
    const key = name.toUpperCase();
    if (_displacedCoreEntries.has(key)) {
        _entries[key] = _displacedCoreEntries.get(key);
        _displacedCoreEntries.delete(key);
        return;
    }
    if (_coreKeys.has(key)) {
        // The supplementary call was a no-op (preferCore=true) — nothing to undo.
        return;
    }
    delete _entries[key];
}

export {
    DeprecatedHandles,
    registerSupplementaryDeprecatedHandle,
    unregisterSupplementaryDeprecatedHandle
};
