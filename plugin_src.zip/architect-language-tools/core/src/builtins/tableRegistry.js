/**
 * tableRegistry.js — registry for database table codes and structures.
 *
 * Single source of truth: builtins-data/tables/<CODE>.json (schema:
 * builtins-data/schemas/table.schema.json). Each JSON file carries the
 * 2-character code, human-readable name, and — when captured — the
 * recordLength, helpPage, indexes, and fields blocks.
 *
 * Two-phase loader:
 *
 *   Phase 1 (eager registry) — at module load, populate `_tableRegistry`
 *   from the lightweight `tables-registry.bundle.json` projection ({code →
 *   name} only). When the bundle is absent (dev/test), fall back to
 *   walking the directory and projecting `{code, name}` per entry while
 *   discarding the rest. Either way, every code is in the registry by the
 *   time the module finishes loading.
 *
 *   Phase 2 (lazy structure) — `getTableStructure(code)` and
 *   `getFieldByHandle(handle)` read `tables/<CODE>.json` on first access
 *   and cache the parsed structure in `_structureCache`. Subsequent calls
 *   are sync map hits (the async signature persists because the cold-miss
 *   branch genuinely awaits a file read).
 *
 * Note: D2 and T4 are edge-case codes containing a digit.
 *
 * The exported `TABLE_REGISTRY` is a Proxy over an internal mutable store.
 * External writes (assignment, delete, defineProperty) throw a TypeError
 * pointing the caller at `registerSupplementaryTable` /
 * `unregisterSupplementaryTable`. Supplementary registrations flow through
 * those functions, which validate the entry against the same schema and
 * freeze it before storing — so `TABLE_REGISTRY[code]` always returns a
 * frozen value, regardless of whether `code` is core or supplementary.
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { validateOrThrow } from "./_schemaValidator.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_ROOT            = path.resolve(__dirname, "..", "..", "..", "builtins-data");
const DATA_DIR             = path.join(DATA_ROOT, "tables");
const REGISTRY_BUNDLE_FILE = path.join(DATA_ROOT, "tables-registry.bundle.json");
const SCHEMA_FILE          = path.join(DATA_ROOT, "schemas", "table.schema.json");

const schema = JSON.parse(fs.readFileSync(SCHEMA_FILE, "utf8"));

const _tableRegistry = {};
const _structureCache = new Map();
const _CORE_TABLE_CODES = new Set();
const _displacedTableEntries = new Map();

function _populateRegistry() {
    if (fs.existsSync(REGISTRY_BUNDLE_FILE)) {
        // Fast path: read ~10KB lightweight projection in one syscall.
        const map = JSON.parse(fs.readFileSync(REGISTRY_BUNDLE_FILE, "utf8"));
        for (const [code, name] of Object.entries(map)) {
            if (typeof name !== "string" || name.length === 0) {
                throw new Error(`tables-registry.bundle.json: ${code}: name must be a non-empty string`);
            }
            if (Object.prototype.hasOwnProperty.call(_tableRegistry, code)) {
                throw new Error(`tables-registry.bundle.json: duplicate table code "${code}"`);
            }
            _tableRegistry[code] = Object.freeze({ name });
            _CORE_TABLE_CODES.add(code);
        }
        return;
    }
    // Dev fallback: walk per-file, extract {code, name}, discard the rest.
    // Validates each file against the full schema so dev errors fail loud.
    const files = fs.readdirSync(DATA_DIR).filter(f => f.endsWith(".json")).sort();
    const seenNames = new Map();
    for (const f of files) {
        const full = path.join(DATA_DIR, f);
        const entry = JSON.parse(fs.readFileSync(full, "utf8"));
        const stem = f.slice(0, -".json".length);
        if (entry.code !== stem) {
            throw new Error(`${full}: "code" (${entry.code}) does not match file stem (${stem})`);
        }
        validateOrThrow(entry, schema, `tables/${stem}.json`);
        if (Object.prototype.hasOwnProperty.call(_tableRegistry, entry.code)) {
            throw new Error(`tables/${stem}.json: duplicate table code "${entry.code}"`);
        }
        const existingCode = seenNames.get(entry.name);
        if (existingCode !== undefined) {
            throw new Error(
                `tables/${stem}.json: duplicate table name "${entry.name}" (already used by code "${existingCode}")`
            );
        }
        seenNames.set(entry.name, entry.code);
        _tableRegistry[entry.code] = Object.freeze({ name: entry.name });
        _CORE_TABLE_CODES.add(entry.code);
        // entry is now GC-eligible; structure fields not retained.
    }
}

_populateRegistry();

/**
 * Returns the registry entry for a table code, or undefined if not found.
 * @param {string} code
 * @returns {{ name: string } | undefined}
 */
function getTableEntry(code) {
    return _tableRegistry[code];
}

/**
 * Returns true if the given string is a valid table code.
 * @param {string} value
 * @returns {boolean}
 */
function isValidTableSynonym(value) {
    return Object.prototype.hasOwnProperty.call(_tableRegistry, value);
}

/**
 * If the value looks like an h-prefixed table code (e.g. "hMD"), returns the
 * bare code ("MD") if it is a valid table code. Otherwise returns null.
 * @param {string} value
 * @returns {string|null}
 */
function getHPrefixSuggestion(value) {
    if (value.length >= 2 && (value[0] === "h" || value[0] === "H")) {
        const bare = value.slice(1).toUpperCase();
        if (isValidTableSynonym(bare)) {
            return bare;
        }
    }
    return null;
}

/**
 * Returns true if the table code has a structure available — i.e. is a
 * known table. Registry membership is structure availability for any code
 * with a JSON file in tables/ (and supplementary registrations populate
 * `_structureCache` directly, so they qualify too).
 *
 * @param {string} code - 2-character table code (e.g. "CD", "MD").
 * @returns {boolean}
 */
function isKnownTableStructure(code) {
    return Object.prototype.hasOwnProperty.call(_tableRegistry, code);
}

/**
 * Returns the full structure object for a table, or null if no structure
 * is available for the code.
 *
 * On a cold-miss, reads `tables/<CODE>.json` from disk, validates it, and
 * caches the frozen result for subsequent sync hits via
 * `getLoadedTableStructure` or future async calls.
 *
 * The returned object has the shape:
 * {
 *   code:         string,
 *   name:         string,
 *   recordLength: number | null,
 *   helpPage:     string,
 *   indexes:      Array<{ name, modifiable, duplicates, segments: Array<{position, field, type, length}> }>,
 *   fields:       { [lowercaseFieldName]: { canonical, type, tableCode, lookupCode? } }
 * }
 *
 * @param {string} code - 2-character table code.
 * @returns {Promise<Object|null>}
 */
async function getTableStructure(code) {
    if (_structureCache.has(code)) return _structureCache.get(code);
    if (!Object.prototype.hasOwnProperty.call(_tableRegistry, code)) return null;
    const filepath = path.join(DATA_DIR, `${code}.json`);
    if (!fs.existsSync(filepath)) return null;  // supplementary code with no JSON file
    const raw = JSON.parse(await fs.promises.readFile(filepath, "utf8"));
    validateOrThrow(raw, schema, `tables/${code}.json`);
    const structure = Object.freeze({
        code:         raw.code,
        name:         raw.name,
        recordLength: raw.recordLength ?? null,
        helpPage:     raw.helpPage ?? `h${code}.htm`,
        indexes:      raw.indexes ?? [],
        fields:       raw.fields ?? {}
    });
    _structureCache.set(code, structure);
    return structure;
}

/**
 * Synchronous accessor: returns the structure if it has already been
 * loaded into the cache (by a prior `getTableStructure` call or a
 * supplementary registration), otherwise `undefined`. Callers that need a
 * structure unconditionally must `await getTableStructure(code)`.
 *
 * @param {string} code - 2-character table code.
 * @returns {Object|undefined}
 */
function getLoadedTableStructure(code) {
    return _structureCache.get(code);
}

/**
 * Looks up a field handle in its table's structure.
 *
 * The table code is derived from the handle itself: the two characters
 * immediately after the leading 'h' (e.g. "hMDz_Member" → "MD"). Triggers
 * a lazy structure load on cold miss. Returns null if the table has no
 * structure or the field is not found.
 *
 * @param {string} handle - Field handle in any casing (e.g. "hMDz_Member").
 * @returns {Promise<{ canonical: string, type: string, tableCode: string, lookupCode?: string }|null>}
 */
async function getFieldByHandle(handle) {
    const code = handle.slice(1, 3).toUpperCase();
    const structure = await getTableStructure(code);
    return structure?.fields[handle.toLowerCase()] ?? null;
}

/**
 * Registers a supplementary table at runtime.
 *
 * - Adds the table code and its registry entry to TABLE_REGISTRY so
 *   validators and completion providers recognise the code as valid.
 * - Pre-populates the structure cache so getTableStructure() returns the
 *   provided object immediately (no disk read for supplementary entries).
 *
 * The supplied `entry` may omit the schema's `code` field — it is inferred
 * from the `code` argument and added to the candidate before validation.
 * Throws a descriptive Error if the entry is malformed.
 *
 * When preferCore is true and the code already exists, the call is a no-op
 * (the existing entries are preserved). When preferCore is false (default),
 * the new entry replaces any existing one; for core codes, the original
 * registry entry is captured so unregister can restore it (and the lazy
 * loader can re-read the original structure on next access).
 *
 * @param {string} code       - 2-character table code (e.g. "ZZ"). Normalised to uppercase.
 * @param {{ name: string }} entry - TABLE_REGISTRY entry shape.
 * @param {object} structure  - Full table structure object.
 * @param {boolean} [preferCore=false]
 * @returns {{added: boolean, replaced: boolean, skipped: boolean}}
 */
function registerSupplementaryTable(code, entry, structure, preferCore = false) {
    if (typeof code !== "string" || code.length === 0) {
        throw new TypeError("registerSupplementaryTable: code must be a non-empty string.");
    }
    if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
        throw new TypeError(`registerSupplementaryTable("${code}"): entry must be a plain object.`);
    }
    const key = code.toUpperCase();
    const candidate = {
        code: key,
        name: entry.name
    };
    validateOrThrow(candidate, schema, `supplementary table "${key}"`);

    const conflict = Object.prototype.hasOwnProperty.call(_tableRegistry, key);
    if (conflict && preferCore) {
        return { added: false, replaced: false, skipped: true };
    }
    if (conflict && _CORE_TABLE_CODES.has(key) && !_displacedTableEntries.has(key)) {
        _displacedTableEntries.set(key, _tableRegistry[key]);
    }
    _tableRegistry[key] = Object.freeze({ name: candidate.name });
    _structureCache.set(key, Object.freeze(structure));
    return { added: !conflict, replaced: conflict, skipped: false };
}

/**
 * Reverses a prior `registerSupplementaryTable` call. Removes the entry
 * from TABLE_REGISTRY and the structure cache when the code was not part
 * of the core registry; otherwise restores the displaced core registry
 * entry and clears the structure cache so the next `getTableStructure`
 * call lazy-reloads the original structure from disk.
 *
 * Safe to call with a code that was never registered (no-op).
 *
 * @param {string} code - Table code (any casing).
 */
function unregisterSupplementaryTable(code) {
    const key = code.toUpperCase();
    if (_displacedTableEntries.has(key)) {
        _tableRegistry[key] = _displacedTableEntries.get(key);
        _displacedTableEntries.delete(key);
        _structureCache.delete(key);  // next access lazy-reloads the original
        return;
    }
    if (_CORE_TABLE_CODES.has(key)) {
        // The supplementary call was a no-op (preferCore) — nothing to undo.
        return;
    }
    delete _tableRegistry[key];
    _structureCache.delete(key);
}

/**
 * The exported `TABLE_REGISTRY` is a Proxy over the internal `_tableRegistry`
 * store. External writes (assignment, delete, defineProperty) throw a
 * TypeError pointing the caller at `registerSupplementaryTable` /
 * `unregisterSupplementaryTable`. Reads and live enumeration via
 * `Object.entries`/`Object.keys`/`for..in` continue to work and reflect
 * supplementary-injected keys, because the Proxy's mutable target is the
 * same object the registered API mutates internally.
 *
 * `Object.isFrozen(TABLE_REGISTRY)` returns false — a Proxy whose target
 * is non-frozen cannot truthfully report frozen status without violating
 * ECMAScript Proxy invariants. The functional contract is "external
 * mutation throws", asserted in `tableRegistryFreeze.test.js`.
 *
 * Mirrors the pattern in `globalVariablesRegistry.js`.
 */
const _MUTATION_ERROR =
    "TABLE_REGISTRY is read-only — call registerSupplementaryTable() / unregisterSupplementaryTable() to add or remove entries.";

const TABLE_REGISTRY = new Proxy(_tableRegistry, {
    set()            { throw new TypeError(_MUTATION_ERROR); },
    deleteProperty() { throw new TypeError(_MUTATION_ERROR); },
    defineProperty() { throw new TypeError(_MUTATION_ERROR); }
});

export {
    TABLE_REGISTRY,
    getTableEntry,
    isValidTableSynonym,
    getHPrefixSuggestion,
    isKnownTableStructure,
    getTableStructure,
    getLoadedTableStructure,
    getFieldByHandle,
    registerSupplementaryTable,
    unregisterSupplementaryTable,
};
