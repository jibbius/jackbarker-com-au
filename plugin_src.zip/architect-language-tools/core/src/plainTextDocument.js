/**
 * A plain-Node.js adapter that satisfies the narrow document interface
 * consumed by collectDiagnostics() and the validators underneath it.
 *
 * This lets the CLI and any future headless caller pass raw file content
 * without needing a VS Code host.  The VS Code extension continues to pass
 * real vscode.TextDocument objects — no change required there.
 */

import { pathToFileURL } from "url";
import { LANGUAGE_ID } from "./constants.js";

class PlainTextDocument {
    /**
     * @param {string} filePath  Absolute path to the file on disk.
     * @param {string} content   Raw UTF-8 content of the file.
     */
    constructor(filePath, content) {
        this._content = content;
        this._lines = content.split(/\r?\n/);
        this.fileName = filePath;
        this.languageId = LANGUAGE_ID;   // satisfies isArchitectDocument()
        this.uri = { fsPath: filePath, toString: () => pathToFileURL(filePath).href };
        this.version = 0;
        this.lineCount = this._lines.length;
    }

    /** @param {number} index Zero-based line index. */
    lineAt(index) {
        return { text: this._lines[index] ?? "" };
    }

    /** Returns the full source text of the document. */
    getText() {
        return this._content;
    }
}

export { PlainTextDocument };
