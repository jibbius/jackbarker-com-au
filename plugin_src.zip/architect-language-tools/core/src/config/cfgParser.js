/**
 * Parser for Acurity-style `.CFG` files.
 *
 * Format: line-oriented `KEY = VALUE` with `#`/`;` comments (line-leading and
 * inline) and optional double-quoted values for paths/strings with spaces.
 *
 *   REPORTDIRECTORY  = REPORTS              ; trailing comment
 *   USRCALCDIRECTORY = "C:\My Calcs\USRCALCS"
 *   # full-line comment
 *   DBSERVER         = LOCALHOST
 *
 * Behaviour
 * - Keys are upper-cased on store; lookup is the caller's responsibility.
 * - `${var}` markers are preserved literally (no env-var substitution in v1).
 * - Duplicate keys: last-value-wins; the prior value is reported via `errors`.
 * - Quoted values support `\"` and `\\` escape sequences; other backslashes
 *   pass through (Windows paths like `C:\Reports\…` work without escaping).
 * - Inline comments inside double-quoted values are NOT recognised — the
 *   `#` / `;` only delimits a comment when it appears outside of quotes.
 */

const COMMENT_CHARS = new Set(["#", ";"]);

/**
 * @typedef {{ line: number, message: string }} CfgParseError
 *
 * @param {string} text
 * @returns {{ values: Map<string, string>, errors: CfgParseError[] }}
 */
function parseCfg(text) {
    const values = new Map();
    const errors = [];

    if (typeof text !== "string") {
        return { values, errors };
    }

    const lines = text.split(/\r\n|\n|\r/);
    for (let i = 0; i < lines.length; i++) {
        const lineNo = i + 1;
        const raw = lines[i];
        const trimmed = raw.trim();
        if (trimmed.length === 0) continue;
        if (COMMENT_CHARS.has(trimmed[0])) continue;

        const eq = raw.indexOf("=");
        if (eq < 0) {
            errors.push({ line: lineNo, message: `expected KEY = VALUE: "${trimmed}"` });
            continue;
        }

        const rawKey = raw.slice(0, eq).trim();
        if (rawKey.length === 0) {
            errors.push({ line: lineNo, message: "missing key before '='" });
            continue;
        }

        const rest = raw.slice(eq + 1);
        const parsed = parseValue(rest, lineNo);
        if (parsed.error) {
            errors.push({ line: lineNo, message: parsed.error });
            continue;
        }

        const key = rawKey.toUpperCase();
        if (values.has(key)) {
            errors.push({
                line: lineNo,
                message: `duplicate key ${key} (previous value overwritten)`
            });
        }
        values.set(key, parsed.value);
    }

    return { values, errors };
}

/**
 * Parses the right-hand side of an assignment line. Strips leading whitespace,
 * recognises an optional double-quoted span (with `\"` / `\\` escapes), and
 * trims any trailing whitespace and `#` / `;` comment.
 *
 * @returns {{ value: string } | { error: string }}
 */
function parseValue(rest, _lineNo) {
    let i = 0;
    while (i < rest.length && (rest[i] === " " || rest[i] === "\t")) i++;

    if (rest[i] === '"') {
        let out = "";
        i++; // consume opening quote
        while (i < rest.length) {
            const ch = rest[i];
            if (ch === "\\" && i + 1 < rest.length) {
                const next = rest[i + 1];
                if (next === '"' || next === "\\") {
                    out += next;
                    i += 2;
                    continue;
                }
                // Preserve unrecognised escapes literally so `C:\Reports`
                // works without forcing the user to double-backslash.
                out += ch;
                i++;
                continue;
            }
            if (ch === '"') {
                i++; // consume closing quote
                // Skip trailing whitespace, then optionally a comment.
                while (i < rest.length && (rest[i] === " " || rest[i] === "\t")) i++;
                if (i < rest.length && !COMMENT_CHARS.has(rest[i])) {
                    return { error: `unexpected text after closing quote: "${rest.slice(i).trim()}"` };
                }
                return { value: out };
            }
            out += ch;
            i++;
        }
        return { error: "unterminated quoted value" };
    }

    // Unquoted: read up to first comment char, then trim trailing whitespace.
    let end = rest.length;
    for (let j = i; j < rest.length; j++) {
        if (COMMENT_CHARS.has(rest[j])) {
            end = j;
            break;
        }
    }
    const value = rest.slice(i, end).replace(/[ \t]+$/, "");
    return { value };
}

export { parseCfg };
