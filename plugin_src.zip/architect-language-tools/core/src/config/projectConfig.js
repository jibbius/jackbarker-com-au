/**
 * Project-config loader/resolver.
 *
 * Combines the three configuration tiers into a single frozen `ProjectConfig`
 * object that downstream code (validators, agent tools) reads off
 * `options.projectConfig`:
 *
 *   1. `overrides` — pre-merged IDE settings + `.architect.json` fields
 *      (the caller is responsible for merging the two surfaces; IDE wins).
 *   2. CFG file values — read from the file at `pathToCfgFile` if supplied.
 *   3. Literal defaults — declared in `DEFAULTS` below.
 *
 * The loader is vscode-free (no `import "vscode"`) so it works equally well
 * from CLI, MCP, and the language client.
 *
 * Loud-fail contract: if `pathToCfgFile` is a non-empty string and the file
 * is missing or parses with errors, `loadProjectConfig` throws. If the path
 * is null/undefined/empty, tier 3 is skipped silently.
 */

import * as fs from "fs";
import * as path from "path";

import { parseCfg } from "./cfgParser.js";

const DEFAULTS = Object.freeze({
    reportDirectory: "REPORTS",
    usrcalcDirectory: "USRCALCS",
    dbServer: "",
    dbDatabase: "",
    dbEncrypt: false,
    dbTrustServerCertificate: true
});

const KEY_TO_CFG_KEY = Object.freeze({
    reportDirectory: "REPORTDIRECTORY",
    usrcalcDirectory: "USRCALCDIRECTORY",
    dbServer: "DBSERVER",
    dbDatabase: "DBDATABASE",
    dbEncrypt: "DBENCRYPT",
    dbTrustServerCertificate: "DBTRUSTSERVERCERT"
});

// Keys whose runtime type is boolean. CFG values for these are strings (Y/N
// per the sample); the resolver coerces via parseYesNo. Override-tier values
// for these keys must already be booleans (validated by the schema layer).
const BOOLEAN_KEYS = Object.freeze(new Set(["dbEncrypt", "dbTrustServerCertificate"]));

const TRUTHY_YESNO = new Set(["Y", "YES", "TRUE", "1", "T"]);

/**
 * Coerce a CFG-style yes/no string to a boolean.
 * Accepts (case-insensitive, trimmed): Y, YES, TRUE, 1, T → true.
 * Anything else (N, NO, FALSE, 0, F, empty/whitespace, non-string) → false.
 * undefined / null returns the supplied default.
 *
 * @param {*} value
 * @param {boolean} defaultValue
 * @returns {boolean}
 */
function parseYesNo(value, defaultValue) {
    if (value === undefined || value === null) return defaultValue;
    if (typeof value !== "string") return false;
    const normalised = value.trim().toUpperCase();
    return TRUTHY_YESNO.has(normalised);
}

/**
 * @typedef {object} ProjectConfig
 * @property {string} reportDirectory
 * @property {string} usrcalcDirectory
 * @property {string} dbServer                    SQL Server instance (empty when unset).
 * @property {string} dbDatabase                  Database name (empty when unset).
 * @property {boolean} dbEncrypt                  Encrypt the SQL Server connection.
 * @property {boolean} dbTrustServerCertificate   Trust self-signed server certs.
 * @property {string|null} sourcePathToCfgFile    Resolved absolute path of the CFG
 *   file that supplied tier-3 values, or null when none was loaded. Useful for
 *   diagnostics ("which CFG was used?") and round-trips through tooling.
 *
 * @typedef {object} LoadProjectConfigInput
 * @property {string|null} [pathToCfgFile]
 * @property {{ reportDirectory?: string, usrcalcDirectory?: string,
 *             dbServer?: string, dbDatabase?: string,
 *             dbEncrypt?: boolean, dbTrustServerCertificate?: boolean }} [overrides]
 *
 * @param {LoadProjectConfigInput} [input]
 * @returns {ProjectConfig}
 */
function loadProjectConfig(input = {}) {
    const overrides = input.overrides ?? {};
    const cfgPath = (typeof input.pathToCfgFile === "string" && input.pathToCfgFile.trim() !== "")
        ? path.resolve(input.pathToCfgFile)
        : null;

    let cfgValues = null;
    if (cfgPath) {
        if (!fs.existsSync(cfgPath)) {
            throw new Error(`pathToCfgFile points at a file that does not exist: ${cfgPath}`);
        }
        let text;
        try {
            text = fs.readFileSync(cfgPath, "utf8");
        } catch (err) {
            throw new Error(`failed to read CFG file ${cfgPath}: ${err.message}`);
        }
        const parsed = parseCfg(text);
        if (parsed.errors.length > 0) {
            const detail = parsed.errors
                .map((e) => `  line ${e.line}: ${e.message}`)
                .join("\n");
            throw new Error(`malformed CFG file ${cfgPath}:\n${detail}`);
        }
        cfgValues = parsed.values;
    }

    const resolved = {};
    for (const [key, fallback] of Object.entries(DEFAULTS)) {
        const isBool = BOOLEAN_KEYS.has(key);
        const override = overrides[key];

        if (isBool) {
            if (typeof override === "boolean") {
                resolved[key] = override;
                continue;
            }
        } else if (typeof override === "string" && override.length > 0) {
            resolved[key] = override;
            continue;
        }

        const cfgKey = KEY_TO_CFG_KEY[key];
        if (cfgValues && cfgKey && cfgValues.has(cfgKey)) {
            const raw = cfgValues.get(cfgKey);
            resolved[key] = isBool ? parseYesNo(raw, fallback) : raw;
            continue;
        }
        resolved[key] = fallback;
    }
    resolved.sourcePathToCfgFile = cfgPath;

    return Object.freeze(resolved);
}

export { loadProjectConfig, DEFAULTS, KEY_TO_CFG_KEY, BOOLEAN_KEYS, parseYesNo };
