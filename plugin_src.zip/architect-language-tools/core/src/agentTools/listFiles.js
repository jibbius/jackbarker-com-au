/**
 * Agent tool: list_files
 *
 * Enumerates Architect source files under the configured scan roots.
 * Intended for agents that don't bring their own filesystem tools and need
 * a starting inventory of the workspace before calling the file-scoped tools
 * (list_symbols, list_includes, validate_file, etc.).
 *
 * Scope is deliberately narrow — scan-root-bounded, `.TXT` only, no recursion
 * outside the roots. Matches the worldview used by find_references and
 * find_impacts so results are consistent across tools.
 *
 * `lineCount` is opt-in (`includeLineCount: true`) — the default response is
 * a bare inventory because the caller usually only needs paths, and reading
 * every file from disk just to count newlines doubles the I/O over the
 * enumeration the tool exists to deliver.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as path from "path";
import * as fs from "fs/promises";

import { enumerateSourceFiles } from "../query/workspaceIndex.js";
import { DEFAULTS as PROJECT_CONFIG_DEFAULTS } from "../config/projectConfig.js";

/**
 * @param {object} params
 * @param {string} params.workspaceRoot
 * @param {string[]} [params.scanRoots]   Explicit override; otherwise derived from
 *   projectConfig (`reportDirectory`, `usrcalcDirectory`) or the literal defaults
 *   (`["REPORTS", "USRCALCS"]`) when no projectConfig is threaded.
 * @param {object} [params.projectConfig] Resolved ProjectConfig (optional).
 * @param {boolean}  [params.includeLineCount]   Opt-in disk re-read for line counts.
 */
async function listFiles({ workspaceRoot, scanRoots, projectConfig = null, includeLineCount = false }) {
    if (!workspaceRoot) {
        return {
            status: "unknown",
            reason: "workspace_root_missing",
            hint: "server context did not include workspaceRoot"
        };
    }

    const roots = (Array.isArray(scanRoots) && scanRoots.length > 0)
        ? scanRoots
        : (projectConfig
            ? [projectConfig.reportDirectory, projectConfig.usrcalcDirectory]
            : [PROJECT_CONFIG_DEFAULTS.reportDirectory, PROJECT_CONFIG_DEFAULTS.usrcalcDirectory]);

    // Single multi-root call — enumerateSourceFiles dedups internally, so we
    // don't need an outer per-root loop or our own seen-set. Per-file scanRoot
    // attribution is recovered by matching the absolute path's prefix.
    const allFiles = await enumerateSourceFiles(workspaceRoot, { scanRoots: roots });

    const rootPrefixes = roots.map((r) => ({
        root: r,
        absPrefix: path.resolve(workspaceRoot, r) + path.sep
    }));

    const files = [];
    for (const absPath of allFiles) {
        const match = rootPrefixes.find((p) => absPath.startsWith(p.absPrefix));
        const relPath = path.relative(workspaceRoot, absPath).split(path.sep).join("/");
        const entry = {
            path: relPath,
            scanRoot: match ? match.root : null
        };
        if (includeLineCount) {
            entry.lineCount = await countLines(absPath);
        }
        files.push(entry);
    }

    files.sort((a, b) => a.path.localeCompare(b.path));

    return {
        status: "ok",
        scanRoots: roots,
        count: files.length,
        files
    };
}

async function countLines(absPath) {
    try {
        const content = await fs.readFile(absPath, "utf8");
        if (content.length === 0) return 0;
        let n = 1;
        for (let i = 0; i < content.length; i++) {
            if (content.charCodeAt(i) === 10) n++;
        }
        if (content.charCodeAt(content.length - 1) === 10) n--;
        return n;
    } catch {
        return null;
    }
}

export { listFiles };
