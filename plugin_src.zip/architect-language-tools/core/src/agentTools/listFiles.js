/**
 * Agent tool: list_files
 *
 * Enumerates Architect source files under the configured scan roots.
 * Intended for agents that don't bring their own filesystem tools and need
 * a starting inventory of the workspace before calling the file-scoped tools
 * (list_symbols, list_includes, validate_file, etc.).
 *
 * Scope is deliberately narrow — scan-root-bounded, `.TXT` only, no recursion
 * outside the roots. Matches the worldview used by find_references and
 * find_impacts so results are consistent across tools.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as path from "path";
import * as fs from "fs/promises";

import { enumerateSourceFiles } from "../query/workspaceIndex.js";

const DEFAULT_SCAN_ROOTS = ["Reports", "usercalcs"];

/**
 * @param {object} params
 * @param {string} params.workspaceRoot
 * @param {string[]} [params.scanRoots]   Defaults to ["Reports", "usercalcs"].
 */
async function listFiles({ workspaceRoot, scanRoots }) {
    if (!workspaceRoot) {
        return {
            status: "unknown",
            reason: "workspace_root_missing",
            hint: "server context did not include workspaceRoot"
        };
    }

    const roots = Array.isArray(scanRoots) && scanRoots.length > 0 ? scanRoots : DEFAULT_SCAN_ROOTS;

    const seen = new Set();
    const files = [];
    for (const root of roots) {
        const rootFiles = await enumerateSourceFiles(workspaceRoot, { scanRoots: [root] });
        for (const absPath of rootFiles) {
            if (seen.has(absPath)) continue;
            seen.add(absPath);
            const relPath = path.relative(workspaceRoot, absPath).split(path.sep).join("/");
            files.push({
                path: relPath,
                scanRoot: root,
                lineCount: await countLines(absPath)
            });
        }
    }

    files.sort((a, b) => a.path.localeCompare(b.path));

    return {
        status: "ok",
        scanRoots: roots,
        count: files.length,
        files
    };
}

async function countLines(absPath) {
    try {
        const content = await fs.readFile(absPath, "utf8");
        if (content.length === 0) return 0;
        let n = 1;
        for (let i = 0; i < content.length; i++) {
            if (content.charCodeAt(i) === 10) n++;
        }
        if (content.charCodeAt(content.length - 1) === 10) n--;
        return n;
    } catch {
        return null;
    }
}

export { listFiles };
