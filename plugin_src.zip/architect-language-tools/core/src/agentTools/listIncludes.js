/**
 * Agent tool: list_includes
 *
 * Returns the INCLUDE / INCLUDEONCE / INCLUDETEST directives in an Architect
 * file. With `followIncludes: true`, walks the graph breadth-first and
 * returns every include reachable from the root.
 *
 * Stays narrow: directive-level facts only. Symbol-level include resolution
 * lives in lookup_symbol and find_references.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as path from "path";
import { parseInclude } from "../lineParser.js";
import { normalizePathKey, resolveIncludePath } from "../includeResolver/graph.js";
import { MAX_INCLUDE_RECURSION_DEPTH } from "../includeResolver/cache.js";
import { DEFAULT_SCAN_ROOTS } from "./defaultScanRoots.js";

/**
 * @typedef {Object} IncludeRecord
 * @property {string} filename         Filename as written in the directive.
 * @property {string|null} resolvedPath Absolute path, or null if unresolved.
 * @property {number} line             1-based line in the parent file.
 * @property {string} [fromFile]       Absolute path of the file containing the directive. Only set when followIncludes=true.
 */

/**
 * @typedef {Object} IncludeUnknown
 * @property {string} filename
 * @property {string} fromFile
 * @property {number} line
 * @property {string} reason           "unresolved_include" | "file_not_readable"
 * @property {string} [hint]
 */

/**
 * @param {object} params
 * @param {string} params.filePath
 * @param {{ openDocument: (p: string) => Promise<object|null> }} params.documentRepository
 * @param {boolean} [params.followIncludes]  — when true, walks the include graph breadth-first from the root
 * @param {string|null} [params.workspaceRoot]  — sandbox root passed to resolveIncludePath
 * @param {string[]} [params.scanRoots]  — scan roots used to key the cached include graph; defaults to DEFAULT_SCAN_ROOTS
 */
async function listIncludes({ filePath, documentRepository, followIncludes = false, workspaceRoot = null, scanRoots = DEFAULT_SCAN_ROOTS }) {
    const rootDoc = await documentRepository.openDocument(filePath);
    if (!rootDoc) {
        return {
            status: "unknown",
            file: filePath,
            reason: "file_not_readable",
            hint: "file does not exist or could not be read"
        };
    }

    const includes = [];
    const unknowns = [];

    // Pull the cached forward map when a workspaceRoot is available — every
    // file under scanRoots already has its include directives parsed, so BFS
    // can avoid re-walking each visited doc line-by-line.
    let forwardMap = null;
    if (workspaceRoot) {
        ({ forwardMap } = await documentRepository.getIncludeGraph(workspaceRoot, scanRoots));
    }

    if (!followIncludes) {
        collectDirectIncludes(rootDoc, workspaceRoot, forwardMap, includes, unknowns, /*includeFromFile*/ false);
        return { status: "ok", file: filePath, includes, unknowns };
    }

    // Follow includes: BFS from the root, deduplicating by normalized resolved path.
    const visited = new Set([normalizePathKey(rootDoc.uri.fsPath)]);
    const queue = [{ doc: rootDoc, depth: 0 }];

    while (queue.length > 0) {
        const { doc, depth } = queue.shift();
        if (depth >= MAX_INCLUDE_RECURSION_DEPTH) continue;

        const directLocal = [];
        collectDirectIncludes(doc, workspaceRoot, forwardMap, directLocal, unknowns, /*includeFromFile*/ true);

        for (const rec of directLocal) {
            includes.push(rec);
            if (!rec.resolvedPath) continue;
            const key = normalizePathKey(rec.resolvedPath);
            if (visited.has(key)) continue;
            visited.add(key);

            const childDoc = await documentRepository.openDocument(rec.resolvedPath);
            if (!childDoc) {
                unknowns.push({
                    filename: rec.filename,
                    fromFile: rec.fromFile,
                    line: rec.line,
                    reason: "file_not_readable",
                    hint: "resolved path exists in the include graph but could not be opened"
                });
                continue;
            }
            queue.push({ doc: childDoc, depth: depth + 1 });
        }
    }

    return { status: "ok", file: filePath, includes, unknowns };
}

/**
 * Appends each include directive in `doc` to `outIncludes` / `outUnknowns`.
 * Uses the cached forwardMap when the doc is indexed; otherwise falls back to
 * a per-line `parseInclude` scan. When `includeFromFile` is true, each
 * record/unknown carries a `fromFile` field (the doc's absolute path);
 * otherwise it is omitted.
 */
function collectDirectIncludes(doc, workspaceRoot, forwardMap, outIncludes, outUnknowns, includeFromFile) {
    const docPath = doc.uri.fsPath;
    const cached = forwardMap?.get(normalizePathKey(docPath));
    if (cached) {
        for (const directive of cached) {
            const rec = {
                filename: directive.filename,
                resolvedPath: directive.resolvedPath,
                line: directive.line
            };
            if (includeFromFile) rec.fromFile = docPath;
            outIncludes.push(rec);

            if (!directive.resolvedPath) {
                outUnknowns.push({
                    filename: directive.filename,
                    fromFile: docPath,
                    line: directive.line,
                    reason: "unresolved_include",
                    hint: "no matching file found on the include search path"
                });
            }
        }
        return;
    }

    const baseDir = path.dirname(docPath);
    for (let lineIndex = 0; lineIndex < doc.lineCount; lineIndex++) {
        const lineText = doc.lineAt(lineIndex).text;
        const parsed = parseInclude(lineText);
        if (!parsed) continue;

        const resolved = resolveIncludePath(baseDir, parsed.filename, workspaceRoot);
        const rec = {
            filename: parsed.filename,
            resolvedPath: resolved ?? null,
            line: lineIndex + 1
        };
        if (includeFromFile) rec.fromFile = docPath;
        outIncludes.push(rec);

        if (!resolved) {
            outUnknowns.push({
                filename: parsed.filename,
                fromFile: docPath,
                line: lineIndex + 1,
                reason: "unresolved_include",
                hint: "no matching file found on the include search path"
            });
        }
    }
}

export { listIncludes };
