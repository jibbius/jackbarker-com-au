/**
 * Agent tool: list_symbols
 *
 * Returns the symbols declared in an Architect file — file-scope variables,
 * user-defined functions, macros, plus per-function locals and parameters.
 *
 * Stays deliberately narrow: one file, structural facts only, no include
 * traversal. Agents that need cross-file resolution call lookup_symbol or
 * find_references instead.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import { collectDocumentFacts } from "../analysis/documentFacts.js";

const ALL_KINDS = ["variable", "function", "macro", "parameter"];

/**
 * @typedef {Object} SymbolRecord
 * @property {string} name            Declared identifier (original casing where known).
 * @property {'variable'|'function'|'macro'|'parameter'} kind
 * @property {string|null} type       Declared type (e.g. "STRING", "SHORT") or null.
 * @property {number} line            1-based line number.
 * @property {string} scope           "file" | "function:<upperName>"
 */

/**
 * @typedef {Object} ListSymbolsOk
 * @property {'ok'} status
 * @property {string} file
 * @property {SymbolRecord[]} symbols
 */

/**
 * @typedef {Object} ListSymbolsUnknown
 * @property {'unknown'} status
 * @property {string} file
 * @property {string} reason
 * @property {string} [hint]
 */

/**
 * @param {object} params
 * @param {string} params.filePath                     Absolute path of the file to inspect.
 * @param {{ openDocument: (p: string) => Promise<object|null> }} params.documentRepository
 * @param {('variable'|'function'|'macro'|'parameter')|null} [params.kindFilter]
 * @returns {Promise<ListSymbolsOk|ListSymbolsUnknown>}
 */
async function listSymbols({ filePath, documentRepository, kindFilter = null }) {
    if (kindFilter !== null && !ALL_KINDS.includes(kindFilter)) {
        return {
            status: "unknown",
            file: filePath,
            reason: "invalid_kind_filter",
            hint: `kindFilter must be one of: ${ALL_KINDS.join(", ")}`
        };
    }

    const doc = await documentRepository.openDocument(filePath);
    if (!doc) {
        return {
            status: "unknown",
            file: filePath,
            reason: "file_not_readable",
            hint: "file does not exist or could not be read"
        };
    }

    const facts = collectDocumentFacts(doc);
    const symbols = [];

    // File-scope symbols (variables declared at the top level).
    if (facts.symbolTable?.fileScope) {
        for (const sym of facts.symbolTable.fileScope.symbols.values()) {
            if (sym.kind !== "variable") continue;
            symbols.push({
                name: sym.declaredName,
                kind: "variable",
                type: sym.type ?? null,
                line: sym.line + 1,
                scope: "file"
            });
        }
    }

    // User-defined functions.
    const udfCatalog = facts.userDefinedFunctionCatalog ?? {};
    for (const fn of Object.values(udfCatalog)) {
        symbols.push({
            name: fn.declaredName,
            kind: "function",
            type: fn.returnType ?? null,
            line: fn.lineIndex + 1,
            scope: "file"
        });
    }

    // Macros.
    const macroCatalog = facts.macroCatalog ?? {};
    for (const macro of Object.values(macroCatalog)) {
        symbols.push({
            name: macro.declaredName,
            kind: "macro",
            type: null,
            line: macro.lineIndex + 1,
            scope: "file"
        });
    }

    // Function-local variables and parameters.
    const functionScopes = facts.symbolTable?.functionScopes ?? [];
    for (const fs of functionScopes) {
        const scopeTag = `function:${fs.upperName}`;
        for (const sym of fs.scope.symbols.values()) {
            // Symbol table uses kind:'param' — agent-facing vocabulary is "parameter".
            if (sym.kind === "param") {
                symbols.push({
                    name: sym.declaredName,
                    kind: "parameter",
                    type: sym.type ?? null,
                    line: sym.line + 1,
                    scope: scopeTag
                });
            } else if (sym.kind === "variable") {
                symbols.push({
                    name: sym.declaredName,
                    kind: "variable",
                    type: sym.type ?? null,
                    line: sym.line + 1,
                    scope: scopeTag
                });
            }
        }
    }

    // Stable ordering: line number, then name (for ties at the same line).
    symbols.sort((a, b) => a.line - b.line || a.name.localeCompare(b.name));

    const filtered = kindFilter ? symbols.filter((s) => s.kind === kindFilter) : symbols;

    return { status: "ok", file: filePath, symbols: filtered };
}

export { listSymbols };
