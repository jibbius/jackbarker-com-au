/**
 * Agent tool: find_references
 *
 * Accepts either a `symbol` or a `file` — not neither. When both are
 * given, `file` acts as disambiguation context (the agent is asking
 * about the specific definition of `symbol` visible from `file`), and
 * the primary input is still the symbol.
 *
 * Symbol input → every definition / call / read / write site across the
 * workspace, scoped by `kind`. Declaration sites are returned as hits with
 * `kind: "definition"` (filterable via `kind: "definitions"`).
 *
 * File input → every `#include <file>` directive across the workspace.
 * This is the reverse of `list_includes` and answers "who uses this
 * file?" — important for side-effect files like `letterHead.TXT` that
 * are consumed by inclusion alone.
 *
 * Scan scope defaults to `["Reports", "usercalcs"]` under
 * `workspaceRoot`, matching the organisation's canonical layout.
 * Overridable via `scanRoots`. `workspaceRoot` is required.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as path from "path";
import { TokenType } from "../lexer/tokenTypes.js";
import { parseIncludeDirective } from "../lineParser.js";
import { normalizePathKey, resolveIncludePath } from "../includeResolver/graph.js";
import { findOccurrences } from "../query/referenceLookup.js";
import { collectDocumentFacts } from "../analysis/documentFacts.js";
import { lookupSymbol } from "./lookupSymbol.js";
import { DEFAULT_SCAN_ROOTS } from "./defaultScanRoots.js";

const VALID_KINDS = ["reads", "writes", "calls", "definitions", "all"];

/**
 * @param {object} params
 * @param {string} [params.symbol]
 * @param {string} [params.file]
 * @param {string} [params.kind]                      "reads"|"writes"|"calls"|"all" (default "all")
 * @param {string} params.workspaceRoot
 * @param {string[]} [params.scanRoots]
 * @param {{ openDocument: (p: string) => Promise<object|null> }} params.documentRepository
 */
async function findReferences({
    symbol = null,
    file = null,
    kind = "all",
    workspaceRoot,
    scanRoots,
    documentRepository
}) {
    if (!symbol && !file) {
        return {
            status: "unknown",
            reason: "invalid_input",
            hint: "provide either `symbol` (find usages), `file` (find includers), or `symbol` + `file` (find usages of a specific definition)"
        };
    }
    if (!workspaceRoot) {
        return {
            status: "unknown",
            reason: "workspace_root_required",
            hint: "a workspaceRoot is required to scan the workspace for references"
        };
    }
    if (!VALID_KINDS.includes(kind)) {
        return {
            status: "unknown",
            reason: "invalid_kind",
            hint: `kind must be one of: ${VALID_KINDS.join(", ")}`
        };
    }

    const roots = scanRoots ?? DEFAULT_SCAN_ROOTS;
    const files = await documentRepository.getWorkspaceFiles(workspaceRoot, roots);

    if (symbol) {
        return await findSymbolReferences({ symbol, file, kind, workspaceRoot, files, documentRepository });
    }
    return await findFileIncluders({ file, workspaceRoot, scanRoots: roots, documentRepository });
}

async function findSymbolReferences({ symbol, file, kind, workspaceRoot, files, documentRepository }) {
    // Disambiguation: if `file` is provided, resolve the symbol via
    // lookup_symbol so we know the *specific* definition the agent means.
    // We still scan every file for local definitions so workspace-wide
    // queries (no `file` hint) surface declaration sites as explicit hits.
    let declaration = null;
    if (file) {
        const hit = await lookupSymbol({
            symbol,
            filePath: file,
            documentRepository,
            workspaceRoot
        });
        if (hit.status === "ok" && hit.definedIn) {
            declaration = {
                filePathKey: normalizePathKey(hit.definedIn),
                line0: hit.definedAtLine - 1,
                kindAtDefinition: hit.kind
            };
        }
    }

    const upperName = symbol.toUpperCase();
    const wantDefinitions = kind === "definitions" || kind === "all";
    const wantCalls = kind === "calls" || kind === "all";
    const wantNonCalls = kind === "reads" || kind === "writes" || kind === "all";

    const references = [];

    for (const absPath of files) {
        const doc = await documentRepository.openDocument(absPath);
        if (!doc) continue;

        const fileDefinitionLines = findFileDefinitionLines(doc, upperName);

        if (wantDefinitions) {
            for (const def of fileDefinitionLines) {
                references.push(makeReference(absPath, doc, { line: def.line0, char: 0 }, "definition"));
            }
        }

        if (!wantCalls && !wantNonCalls) continue;

        // Pull tokens from the per-document facts cache rather than running
        // the lexer again — collectDocumentFacts memoises by (uri, version).
        const tokens = collectDocumentFacts(doc).tokens;
        const definitionLines0 = new Set(fileDefinitionLines.map((d) => d.line0));
        // Also respect an explicit declaration coming from a `file`-anchored
        // lookup_symbol call (it may have resolved via include chain to a
        // different file than the current one).
        if (declaration && normalizePathKey(absPath) === declaration.filePathKey) {
            definitionLines0.add(declaration.line0);
        }

        if (wantCalls) {
            const hits = findOccurrences(tokens, symbol, true, {
                includeDeclaration: false,
                declarationLine: -1,
                lineRange: null
            });
            for (const h of hits) {
                if (definitionLines0.has(h.line)) continue;
                references.push(makeReference(absPath, doc, h, "call"));
            }
        }

        if (wantNonCalls) {
            const hits = findOccurrences(tokens, symbol, false, {
                includeDeclaration: false,
                declarationLine: -1,
                lineRange: null
            });
            // Build a position-keyed index over identifiers once per file so
            // classifyVariableUsage doesn't run findIndex per occurrence.
            let identifierIndex = null;
            const ensureIndex = () => {
                if (identifierIndex) return identifierIndex;
                identifierIndex = new Map();
                for (let i = 0; i < tokens.length; i++) {
                    const t = tokens[i];
                    if (t.type !== TokenType.IDENTIFIER) continue;
                    identifierIndex.set(`${t.line}:${t.char}`, i);
                }
                return identifierIndex;
            };
            for (const h of hits) {
                if (definitionLines0.has(h.line)) continue;
                const usageKind = classifyVariableUsage(tokens, h, ensureIndex());
                if (kind === "reads" && usageKind !== "read") continue;
                if (kind === "writes" && usageKind !== "write") continue;
                references.push(makeReference(absPath, doc, h, usageKind));
            }
        }
    }

    // Stable order: path, then line, then char.
    references.sort((a, b) => a.file.localeCompare(b.file) || a.line - b.line || a.char - b.char);

    return {
        status: "ok",
        inputKind: "symbol",
        symbol,
        file: file ?? null,
        filterKind: kind,
        references,
        unknowns: []
    };
}

async function findFileIncluders({ file, workspaceRoot, scanRoots, documentRepository }) {
    const target = path.isAbsolute(file) ? file : path.join(workspaceRoot, file);
    const targetKey = normalizePathKey(target);
    const targetBase = path.basename(target).toLowerCase();
    const references = [];
    const unknowns = [];

    // The include graph (cached on the documentRepository) tells us which
    // files cleanly resolve to the target — most files are eliminated before
    // we open them. We still need a per-line walk on the includers to recover
    // line numbers and column offsets, plus a separate pass for unresolved-
    // include name-matches (those don't show up in the reverse map).
    const { reverseMap } = await documentRepository.getIncludeGraph(workspaceRoot, scanRoots);
    const directIncluderKeys = reverseMap.get(targetKey) ?? new Set();
    const allFiles = await documentRepository.getWorkspaceFiles(workspaceRoot, scanRoots);

    for (const absPath of allFiles) {
        const key = normalizePathKey(absPath);
        const isResolvedIncluder = directIncluderKeys.has(key);

        const doc = await documentRepository.openDocument(absPath);
        if (!doc) continue;

        const baseDir = path.dirname(absPath);
        for (let lineIndex = 0; lineIndex < doc.lineCount; lineIndex++) {
            const lineText = doc.lineAt(lineIndex).text;
            const parsed = parseIncludeDirective(lineText);
            if (!parsed) continue;

            const resolved = resolveIncludePath(baseDir, parsed.filepath, workspaceRoot);
            if (resolved && normalizePathKey(resolved) === targetKey) {
                references.push({
                    file: absPath,
                    line: lineIndex + 1,
                    char: parsed.filepathStart,
                    context: lineText.trim(),
                    kind: "include"
                });
            } else if (!resolved && !isResolvedIncluder
                && parsed.filepath.toLowerCase().includes(targetBase)) {
                unknowns.push({
                    file: absPath,
                    line: lineIndex + 1,
                    filename: parsed.filepath,
                    reason: "unresolved_include",
                    hint: "include directive could not be resolved; possible match but not verified"
                });
            }
        }
    }
    references.sort((a, b) => a.file.localeCompare(b.file) || a.line - b.line);

    return {
        status: "ok",
        inputKind: "file",
        file,
        references,
        unknowns
    };
}

/**
 * Classifies a non-call identifier occurrence as "write" or "read".
 * Heuristic: the occurrence is a write when the next meaningful token is
 * `=` AND the identifier is at the head of its effective statement —
 * i.e. no meaningful tokens before it on the line other than an optional
 * `HASH_PREFIX` or a `SET` keyword.
 */
function classifyVariableUsage(tokens, hit, identifierIndex) {
    const idx = identifierIndex.get(`${hit.line}:${hit.char}`);
    if (idx === undefined) return "read";

    const next = firstMeaningful(tokens, idx + 1, /*direction*/ 1);
    if (!next || next.type !== TokenType.EQUALS) return "read";

    // Walk back to see whether anything meaningful precedes us on this line.
    for (let j = idx - 1; j >= 0; j--) {
        const t = tokens[j];
        if (t.line !== hit.line) break; // crossed into a previous line
        if (t.type === TokenType.WHITESPACE || t.type === TokenType.NEWLINE) continue;
        if (t.type === TokenType.HASH_PREFIX) continue;
        if (t.type === TokenType.KEYWORD && t.value.toUpperCase() === "SET") continue;
        // Anything else (operator, identifier, paren) means we're on the RHS.
        return "read";
    }
    return "write";
}

function firstMeaningful(tokens, from, direction) {
    for (let j = from; j >= 0 && j < tokens.length; j += direction) {
        const t = tokens[j];
        if (t.type === TokenType.WHITESPACE || t.type === TokenType.NEWLINE) continue;
        return t;
    }
    return null;
}

function makeReference(absPath, doc, hit, usageKind) {
    const lineText = doc.lineAt(hit.line).text;
    return {
        file: absPath,
        line: hit.line + 1,
        char: hit.char,
        context: lineText.trim(),
        kind: usageKind
    };
}

/**
 * Per-file declaration detection using the same sources as lookup_symbol's
 * file-scope pass: file-scope variables, user-defined functions, and macros.
 * Returns 0-based line numbers so the caller can suppress duplicate hits.
 */
function findFileDefinitionLines(doc, upperName) {
    const facts = collectDocumentFacts(doc);
    const lines = [];

    const fileScopeSym = facts.symbolTable?.fileScope?.symbols.get(upperName);
    if (fileScopeSym && fileScopeSym.kind === "variable") {
        lines.push({ line0: fileScopeSym.line, kind: "variable" });
    }

    const udf = facts.userDefinedFunctionCatalog?.[upperName];
    if (udf) {
        lines.push({ line0: udf.lineIndex, kind: "function" });
    }

    const macro = facts.macroCatalog?.[upperName];
    if (macro) {
        lines.push({ line0: macro.lineIndex, kind: "macro" });
    }
    return lines;
}

export { findReferences };
