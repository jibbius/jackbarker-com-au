/**
 * Agent tool: lookup_symbol
 *
 * The primary disambiguator. Given a symbol name and (optionally) a file
 * and line, answers: what is this name, where is it defined, and how did
 * the query file get visibility of it?
 *
 * When the resolved symbol is a function (UDF or built-in), the envelope
 * also carries `params: [{name, type}]` — this subsumes what was originally
 * drafted as a separate `get_function_signature` tool.
 *
 * Resolution order:
 *   1. If `line` provided, check the enclosing function scope at that line
 *      (parameters and locals). Function-local hits win silently — shadowing
 *      a file-scope name inside a function is a language feature, not an
 *      ambiguity to warn about.
 *   2. File-scope of the query file, then BFS through the include graph.
 *      Collect every match; the first in BFS order wins. Remaining matches
 *      become `shadowed_definition` entries in `unknowns[]`.
 *   3. Field-handle registry — names matching `hXXy_...` or `XXy_...` are
 *      database field handles. Resolves via the generated table-structure
 *      registry; emits `kind: "field_handle"` with the table metadata and,
 *      where available, the constraint `lookupCode` the agent can feed to
 *      `lookup_description_code` to enumerate valid values.
 *   4. Fall through to the built-in catalogue.
 *   5. Unknown.
 *
 * Called without `file`: only the built-in catalogue is visible. User
 * symbols require file context (the agent is directed to provide one).
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as path from "path";
import { collectDocumentFacts } from "../analysis/documentFacts.js";
import { getGlobalScope, findFunctionScopeAtLine } from "../analysis/symbolTable.js";
import { getHelpPage } from "../builtins/helpRegistry.js";
import { getFieldByHandle, getTableStructure } from "../builtins/tableRegistry.js";
import { parseIncludeDirective } from "../lineParser.js";
import { normalizePathKey, resolveIncludePath } from "../includeResolver/graph.js";
import { MAX_INCLUDE_RECURSION_DEPTH } from "../includeResolver/cache.js";
import { DEFAULTS as PROJECT_CONFIG_DEFAULTS } from "../config/projectConfig.js";

const AGENT_KIND_BY_TABLE_KIND = {
    variable: "variable",
    param: "parameter",
    function: "function",
    macro: "macro"
};

/**
 * @param {object} params
 * @param {string} params.symbol                             Identifier to look up.
 * @param {string|null} [params.filePath]                    File context; null = builtins-only query.
 * @param {number|null} [params.line]                        1-based line for function-scope disambiguation.
 * @param {{ openDocument: (p: string) => Promise<object|null>, getIncludeGraph?: Function }} params.documentRepository
 * @param {string|null} [params.workspaceRoot]               Sandbox root passed to resolveIncludePath.
 * @param {string[]} [params.scanRoots]                      Explicit override of the scan roots used to key the cached include graph. When omitted, derived from `projectConfig` or the literal defaults (`["REPORTS", "USRCALCS"]`).
 * @param {object} [params.projectConfig]                    Resolved ProjectConfig (optional).
 */
async function lookupSymbol({ symbol, filePath = null, line = null, documentRepository, workspaceRoot = null, scanRoots = null, projectConfig = null }) {
    const resolvedScanRoots = (Array.isArray(scanRoots) && scanRoots.length > 0)
        ? scanRoots
        : (projectConfig
            ? [projectConfig.reportDirectory, projectConfig.usrcalcDirectory]
            : [PROJECT_CONFIG_DEFAULTS.reportDirectory, PROJECT_CONFIG_DEFAULTS.usrcalcDirectory]);
    // No file: only globally-visible names are resolvable — built-ins and
    // database field handles (the latter live in the generated registry, not
    // in any user file).
    if (!filePath) {
        const fieldHandle = await resolveFieldHandle(symbol);
        if (fieldHandle) return fieldHandleEnvelope({ file: null, symbol, fieldHandle });
        const builtin = resolveBuiltin(symbol);
        if (builtin) return builtinEnvelope({ file: null, symbol, builtin });
        return {
            status: "unknown",
            file: null,
            symbol,
            reason: "file_required_for_user_symbol",
            hint: `${symbol} is not a built-in or a recognised database field handle; provide file to search user code and its includes, or call find_references for a workspace-wide scan`
        };
    }

    const rootDoc = await documentRepository.openDocument(filePath);
    if (!rootDoc) {
        return {
            status: "unknown",
            file: filePath,
            symbol,
            reason: "file_not_readable",
            hint: "file does not exist or could not be read"
        };
    }

    const upperName = symbol.toUpperCase();

    // Step 1: function-local scope if a line is given.
    if (line !== null) {
        const rootFacts = collectDocumentFacts(rootDoc);
        const localHit = findFunctionLocalMatch(rootFacts, upperName, line);
        if (localHit) {
            return {
                status: "ok",
                file: filePath,
                symbol,
                kind: localHit.kind,
                type: localHit.type ?? null,
                definedIn: filePath,
                definedAtLine: localHit.line,
                scope: `function:${localHit.functionUpperName}`,
                fromInclude: [],
                unknowns: []
            };
        }
    }

    // Step 2: BFS the file-scope of rootDoc, then its include graph. Collect
    // all matches so we can emit shadows.
    const matches = [];
    collectFileScopeMatch(rootDoc, upperName, /*chain*/ [], matches);

    // Pull the cached forward map when a workspaceRoot is available — every
    // file under scanRoots already has its include directives parsed, so BFS
    // can avoid re-walking each visited doc line-by-line.
    let forwardMap = null;
    if (workspaceRoot) {
        ({ forwardMap } = await documentRepository.getIncludeGraph(workspaceRoot, resolvedScanRoots));
    }

    const visited = new Set([normalizePathKey(rootDoc.uri.fsPath)]);
    const queue = [{ doc: rootDoc, chain: [], depth: 0 }];

    while (queue.length > 0) {
        const { doc, chain, depth } = queue.shift();
        if (depth >= MAX_INCLUDE_RECURSION_DEPTH) continue;

        const directives = getDocIncludes(doc, forwardMap, workspaceRoot);
        for (const directive of directives) {
            if (!directive.resolvedPath) continue;
            const key = normalizePathKey(directive.resolvedPath);
            if (visited.has(key)) continue;
            visited.add(key);

            const childDoc = await documentRepository.openDocument(directive.resolvedPath);
            if (!childDoc) continue;

            const childChain = [...chain, directive.filename];
            collectFileScopeMatch(childDoc, upperName, childChain, matches);
            queue.push({ doc: childDoc, chain: childChain, depth: depth + 1 });
        }
    }

    if (matches.length > 0) {
        const [winner, ...shadows] = matches;
        const envelope = {
            status: "ok",
            file: filePath,
            symbol,
            kind: winner.kind,
            type: winner.type ?? null,
            definedIn: winner.definedIn,
            definedAtLine: winner.line,
            scope: "file",
            fromInclude: winner.chain,
            unknowns: shadows.map((s) => ({
                reason: "shadowed_definition",
                definedIn: s.definedIn,
                definedAtLine: s.line,
                fromInclude: s.chain,
                hint: "another definition exists at a later BFS position and is shadowed by the winner"
            }))
        };
        if (winner.kind === "function") envelope.params = winner.params ?? [];
        return envelope;
    }

    // Step 3: field-handle recognition.
    const fieldHandle = await resolveFieldHandle(symbol);
    if (fieldHandle) return fieldHandleEnvelope({ file: filePath, symbol, fieldHandle });

    // Step 4: built-ins.
    const builtin = resolveBuiltin(symbol);
    if (builtin) return builtinEnvelope({ file: filePath, symbol, builtin });

    // Step 5: not found anywhere.
    return {
        status: "unknown",
        file: filePath,
        symbol,
        reason: "symbol_not_found",
        hint: "not declared in this file, any followed include, the field-handle registry, or the built-in catalogue"
    };
}

/**
 * Returns the include directives for `doc`, preferring the cached forwardMap
 * when the doc is indexed and falling back to a per-line `parseIncludeDirective` scan
 * when it is not.
 *
 * @returns {Array<{filename: string, resolvedPath: string|null, line: number}>}
 */
function getDocIncludes(doc, forwardMap, workspaceRoot) {
    const docPath = doc.uri.fsPath;
    const cached = forwardMap?.get(normalizePathKey(docPath));
    if (cached) return cached;

    const baseDir = path.dirname(docPath);
    const out = [];
    for (let lineIndex = 0; lineIndex < doc.lineCount; lineIndex++) {
        const parsed = parseIncludeDirective(doc.lineAt(lineIndex).text);
        if (!parsed) continue;
        const resolved = resolveIncludePath(baseDir, parsed.filepath, workspaceRoot);
        out.push({
            filename: parsed.filepath,
            resolvedPath: resolved ?? null,
            line: lineIndex + 1
        });
    }
    return out;
}

function findFunctionLocalMatch(facts, upperName, line1Based) {
    const lineIndex = line1Based - 1;
    const scopes = facts.symbolTable?.functionScopes ?? [];
    const owning = findFunctionScopeAtLine(scopes, lineIndex);
    if (!owning) return null;
    const sym = owning.scope.symbols.get(upperName);
    if (!sym) return null;
    const agentKind = AGENT_KIND_BY_TABLE_KIND[sym.kind];
    if (!agentKind) return null;
    return {
        kind: agentKind,
        type: sym.type ?? null,
        line: sym.line + 1,
        functionUpperName: owning.upperName
    };
}

function collectFileScopeMatch(doc, upperName, chain, outMatches) {
    const facts = collectDocumentFacts(doc);
    const filePath = doc.uri.fsPath;

    // Collect every same-name definition at file scope. A file may declare
    // (e.g.) `STRING nzFoo` and `MACRO nzFoo(...)` — both are real symbols and
    // the BFS shadow surface should expose the second instead of silently
    // dropping it. Ordering within a single file: variable, then UDF, then
    // macro — preserved so callers' "first match wins" rule is stable.
    const fileScopeSym = facts.symbolTable?.fileScope?.symbols.get(upperName);
    if (fileScopeSym && fileScopeSym.kind === "variable") {
        outMatches.push({
            kind: "variable",
            type: fileScopeSym.type ?? null,
            line: fileScopeSym.line + 1,
            definedIn: filePath,
            chain
        });
    }

    const udf = facts.userDefinedFunctionCatalog?.[upperName];
    if (udf) {
        outMatches.push({
            kind: "function",
            type: udf.returnType ?? null,
            line: udf.lineIndex + 1,
            definedIn: filePath,
            chain,
            params: normaliseUdfParams(udf.params)
        });
    }

    const macro = facts.macroCatalog?.[upperName];
    if (macro) {
        outMatches.push({
            kind: "macro",
            type: null,
            line: macro.lineIndex + 1,
            definedIn: filePath,
            chain
        });
    }
}

/**
 * Returns a field-handle descriptor when `symbol` matches the handle
 * patterns (`hXXy_...` or `XXy_...`) and the derived table code has a
 * structure file in the registry, and the specific field exists there.
 */
async function resolveFieldHandle(symbol) {
    if (typeof symbol !== "string") return null;

    let tableCode = null;
    let handleForLookup = null;
    // Table codes are two characters; the first is always a letter, the
    // second may be a digit (e.g. D2, T4). The third character is the
    // lowercase type indicator or an underscore.
    if (/^h[A-Z][A-Z0-9][a-z_]/.test(symbol)) {
        tableCode = symbol.slice(1, 3).toUpperCase();
        handleForLookup = symbol;
    } else if (/^[A-Z][A-Z0-9][a-z_]/.test(symbol)) {
        // Raw index-segment form (e.g. `MDz_Member`). The registry keys the
        // field by its handle form (with leading 'h'), so prepend one for
        // the lookup.
        tableCode = symbol.slice(0, 2).toUpperCase();
        handleForLookup = "h" + symbol;
    } else {
        return null;
    }

    const field = await getFieldByHandle(handleForLookup);
    if (!field) return null;

    const structure = await getTableStructure(tableCode);
    return {
        canonical: field.canonical,
        type: field.type ?? null,
        tableCode,
        tableName: structure?.name ?? null,
        lookupCode: field.lookupCode ?? null
    };
}

function fieldHandleEnvelope({ file, symbol, fieldHandle }) {
    return {
        status: "ok",
        file,
        symbol,
        kind: "field_handle",
        type: fieldHandle.type,
        definedIn: null,
        definedAtLine: null,
        scope: "database_field",
        fromInclude: [],
        tableCode: fieldHandle.tableCode,
        tableName: fieldHandle.tableName,
        canonical: fieldHandle.canonical,
        lookupCode: fieldHandle.lookupCode,
        unknowns: []
    };
}

function resolveBuiltin(symbol) {
    const sym = getGlobalScope().resolve(symbol);
    if (!sym) return null;
    if (sym.kind === "builtin") {
        return {
            kind: "function",
            type: sym.returnType ?? null,
            params: normaliseBuiltinParams(sym)
        };
    }
    if (sym.kind === "builtin-var") {
        return { kind: "variable", type: sym.type ?? null };
    }
    return null;
}

function builtinEnvelope({ file, symbol, builtin }) {
    const envelope = {
        status: "ok",
        file,
        symbol,
        kind: builtin.kind,
        type: builtin.type,
        definedIn: null,
        definedAtLine: null,
        scope: "builtin",
        fromInclude: [],
        helpFile: getHelpPage(symbol.toUpperCase()) ?? null,
        unknowns: []
    };
    if (builtin.kind === "function") envelope.params = builtin.params ?? [];
    return envelope;
}

/**
 * Normalises a UDF's params (from userDefinedFunctionCatalog) into the
 * agent-facing shape `[{name, type}]`.
 * @param {Array<{name: string, type?: string|null}>|undefined} params
 */
function normaliseUdfParams(params) {
    if (!Array.isArray(params)) return [];
    return params.map((p) => ({
        name: p.name,
        type: p.type ?? null
    }));
}

/**
 * Normalises a built-in function's signature into the same agent-facing shape.
 * Built-in params are an array of inlined per-parameter objects
 * `{type, label?, mode?, role?}`; `type` is a single ArchitectType string or
 * an array of strings for unions. Some entries also set `varArgs: true` —
 * represented here as a final `{name: "...", type: null}` sentinel with
 * `rest: true`.
 *
 * @param {{ params?: Array<{type: string|string[], label?: string}>, varArgs?: boolean }} sig
 */
function normaliseBuiltinParams(sig) {
    const params = Array.isArray(sig.params) ? sig.params : [];
    const out = params.map((p, i) => ({
        name: p.label ?? `arg${i + 1}`,
        type: Array.isArray(p.type) ? p.type : (p.type ?? null)
    }));
    if (sig.varArgs) out.push({ name: "...rest", type: null, rest: true });
    return out;
}

export { lookupSymbol };
