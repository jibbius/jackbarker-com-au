/**
 * Agent tool: list_suppressions
 *
 * Returns every `// @rule-ignore ACU-XXX-NNN` suppression comment in a
 * file, paired with the line it suppresses and any trailing REASON
 * clause.
 *
 * This is the git-free half of the original spec's `list_suppressions`
 * tool. The `{ref}` mode — comparing suppressions at two git refs to
 * flag those added by a PR — is parked with the rest of the review
 * band pending feedback, and will layer cleanly on top of this tool
 * once a `gitSnapshot` helper exists.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

/**
 * Matches any line that opens a `// @rule-ignore` comment. The remainder
 * is validated after the fact so malformed suppressions (no IDs, typo'd
 * IDs) can be surfaced to the agent as unknowns rather than silently
 * dropped.
 */
const RULE_IGNORE_RE = /^\s*\/\/\s*@rule-ignore\b(.*)$/i;

/** Individual ACU rule ID. */
const ACU_ID_RE = /^ACU-[A-Z]+-\d{3}$/i;

/** Optional `REASON: <text>` trailing the rule-id list. */
const REASON_RE = /^\s*REASON\s*:\s*(.*?)\s*$/i;

/**
 * @param {object} params
 * @param {string} params.filePath
 * @param {{ openDocument: (p: string) => Promise<object|null> }} params.documentRepository
 */
async function listSuppressions({ filePath, documentRepository }) {
    const doc = await documentRepository.openDocument(filePath);
    if (!doc) {
        return {
            status: "unknown",
            file: filePath,
            reason: "file_not_readable",
            hint: "file does not exist or could not be read"
        };
    }

    const suppressions = [];
    const unknowns = [];

    for (let lineIndex = 0; lineIndex < doc.lineCount; lineIndex++) {
        const lineText = doc.lineAt(lineIndex).text;
        const match = RULE_IGNORE_RE.exec(lineText);
        if (!match) continue;

        // Split the body into rule-id tokens (before any REASON:) and an
        // optional reason string.
        const body = (match[1] ?? "").trim();
        let tokensPart = body;
        let reason = null;
        const reasonSplit = body.match(/^(.*?)\bREASON\s*:\s*(.*?)\s*$/i);
        if (reasonSplit) {
            tokensPart = reasonSplit[1].trim();
            reason = reasonSplit[2];
        } else {
            // Honour the older REASON_RE form too (leading-anchored).
            const leadingReason = REASON_RE.exec(body);
            if (leadingReason) {
                tokensPart = "";
                reason = leadingReason[1];
            }
        }

        const tokens = tokensPart.length > 0
            ? tokensPart.split(/\s+/).filter((t) => t.length > 0)
            : [];
        const ruleIds = [];
        const invalid = [];
        for (const tok of tokens) {
            if (ACU_ID_RE.test(tok)) ruleIds.push(tok.toUpperCase());
            else invalid.push(tok);
        }

        const commentLine = lineIndex + 1;
        const suppressedLine = lineIndex + 2;
        if (suppressedLine > doc.lineCount) {
            unknowns.push({
                reason: "suppression_at_eof",
                commentLine,
                hint: "@rule-ignore comment has no following line to suppress"
            });
            continue;
        }

        if (ruleIds.length === 0) {
            unknowns.push({
                reason: "no_valid_rule_ids",
                commentLine,
                hint: "@rule-ignore comment present but no ACU-XXX-NNN tokens parsed",
                invalidTokens: invalid
            });
            continue;
        }

        suppressions.push({
            commentLine,
            suppressedLine,
            ruleIds,
            reason,
            ...(invalid.length > 0 ? { invalidTokens: invalid } : {})
        });
    }

    return {
        status: "ok",
        file: filePath,
        suppressions,
        unknowns
    };
}

export { listSuppressions };
