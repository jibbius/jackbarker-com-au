/**
 * Agent tool: list_suppressions
 *
 * Returns every `// @rule-ignore PREFIX-DOMAIN-NNN` suppression comment in
 * a file, paired with the line it suppresses and any trailing REASON
 * clause. Supports core (`ACU-`) and supplementary (`EMP-`, etc.) rule
 * prefixes — the underlying scan lives in `suppressionParser.js` so the
 * agent surface and the runtime suppression check stay in lockstep.
 *
 * The `{ref}` mode — comparing suppressions at two git refs to flag
 * those added by a PR — is parked with the rest of the review band
 * pending feedback, and will layer cleanly on top of this tool once a
 * `gitSnapshot` helper exists.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import { scanSuppressionComments } from "../suppressionParser.js";

/**
 * @param {object} params
 * @param {string} params.filePath
 * @param {{ openDocument: (p: string) => Promise<object|null> }} params.documentRepository
 */
async function listSuppressions({ filePath, documentRepository }) {
    const doc = await documentRepository.openDocument(filePath);
    if (!doc) {
        return {
            status: "unknown",
            file: filePath,
            reason: "file_not_readable",
            hint: "file does not exist or could not be read"
        };
    }

    const suppressions = [];
    const unknowns = [];

    for (const record of scanSuppressionComments(doc)) {
        const commentLine = record.commentLineIndex + 1;
        const suppressedLine = commentLine + 1;

        if (suppressedLine > doc.lineCount) {
            unknowns.push({
                reason: "suppression_at_eof",
                commentLine,
                hint: "@rule-ignore comment has no following line to suppress"
            });
            continue;
        }

        if (record.ruleIds.length === 0) {
            unknowns.push({
                reason: "no_valid_rule_ids",
                commentLine,
                hint: "@rule-ignore comment present but no PREFIX-DOMAIN-NNN tokens parsed",
                invalidTokens: record.invalidTokens
            });
            continue;
        }

        suppressions.push({
            commentLine,
            suppressedLine,
            ruleIds: record.ruleIds,
            reason: record.reason,
            ...(record.invalidTokens.length > 0 ? { invalidTokens: record.invalidTokens } : {})
        });
    }

    return {
        status: "ok",
        file: filePath,
        suppressions,
        unknowns
    };
}

export { listSuppressions };
