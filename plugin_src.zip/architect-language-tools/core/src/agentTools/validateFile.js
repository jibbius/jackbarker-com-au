/**
 * Agent tool: validate_file
 *
 * Runs the full Architect diagnostic pipeline against a file and returns
 * the resulting diagnostics as plain JSON (no VS Code types).
 *
 * Severity defaults come from the diagnosticCatalog "default" profile,
 * the same baseline the CLI uses. Suppressions (`// @rule-ignore ...`)
 * are honoured upstream by collectDiagnostics before we see the results.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import { collectDiagnosticsAsync } from "../collectDiagnostics.js";
import { getProfileRuleSeverities } from "../diagnostics/diagnosticCatalog.js";
import { getSupplementarySeverityOverrides } from "../supplementaryLoader.js";

const SEVERITY_NUMBER_TO_LABEL = {
    0: "error",
    1: "warning",
    2: "info",
    3: "hint"
};
const SEVERITY_LABEL_TO_NUMBER = { error: 0, warning: 1, information: 2, info: 2, hint: 3 };

// Pre-compute the default profile once per process. Supplementary overrides
// are resolved per call so hot-reloaded modules are honoured.
const _profileSeverities = getProfileRuleSeverities("default");

function defaultGetRuleSeverity(ruleId) {
    const overrides = getSupplementarySeverityOverrides();
    const raw = overrides?.[ruleId] ?? _profileSeverities[ruleId] ?? "warning";
    if (raw === "off") return null;
    return SEVERITY_LABEL_TO_NUMBER[raw] ?? 1;
}

/**
 * @param {object} params
 * @param {string} params.filePath
 * @param {{ openDocument: (p: string) => Promise<object|null> }} params.documentRepository
 * @param {string|null} [params.workspaceRoot]
 */
async function validateFile({ filePath, documentRepository, workspaceRoot = null }) {
    const doc = await documentRepository.openDocument(filePath);
    if (!doc) {
        return {
            status: "unknown",
            file: filePath,
            reason: "file_not_readable",
            hint: "file does not exist or could not be read"
        };
    }

    const raw = await collectDiagnosticsAsync(doc, defaultGetRuleSeverity, { workspaceRoot });
    const diagnostics = raw.map(normaliseDiagnostic);
    diagnostics.sort((a, b) => a.line - b.line || a.startChar - b.startChar);

    return {
        status: "ok",
        file: filePath,
        diagnostics,
        unknowns: []
    };
}

function normaliseDiagnostic(d) {
    const start = d.range?.start ?? { line: 0, character: 0 };
    const end = d.range?.end ?? start;
    return {
        ruleId: d.data?.messageId ?? null,
        severity: SEVERITY_NUMBER_TO_LABEL[d.severity] ?? "warning",
        message: d.message ?? "",
        line: start.line + 1,
        endLine: end.line + 1,
        startChar: start.character,
        endChar: end.character
    };
}

export { validateFile };
