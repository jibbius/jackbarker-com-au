/**
 * Agent tool: find_impacts
 *
 * Impact analysis with input-aware semantics:
 *
 *   - **Symbol input** — file-deduped set of actual usage sites. Narrow,
 *     honest answer to "what breaks if I change this?".
 *   - **File input** — transitive reverse-include closure. Every file
 *     that (directly or transitively) `#includes` the target. Wide,
 *     because inclusion is the consumption for side-effect files
 *     (e.g. `letterHead.TXT`: no named symbol to reference, yet every
 *     includer is affected by a change to it). Each entry carries the
 *     include chain and the list of the target's symbols the includer
 *     actually references.
 *
 * When both `symbol` and `file` are given, `file` disambiguates which
 * definition of `symbol` the agent means (same pattern as
 * `find_references`).
 *
 * Scan scope defaults are derived from `projectConfig` (`reportDirectory`,
 * `usrcalcDirectory`) when one is supplied, otherwise the literal defaults
 * (`["REPORTS", "USRCALCS"]`).
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as path from "path";
import { TokenType } from "../lexer/tokenTypes.js";
import { collectDocumentFacts } from "../analysis/documentFacts.js";
import { normalizePathKey } from "../includeResolver/graph.js";
import { getReverseReachableSet } from "../query/workspaceIndex.js";
import { findReferences } from "./findReferences.js";
import { DEFAULTS as PROJECT_CONFIG_DEFAULTS } from "../config/projectConfig.js";

/**
 * @param {object} params
 * @param {string} [params.symbol]
 * @param {string} [params.file]
 * @param {string} params.workspaceRoot
 * @param {string[]} [params.scanRoots]
 * @param {{ openDocument: (p: string) => Promise<object|null> }} params.documentRepository
 */
async function findImpacts({
    symbol = null,
    file = null,
    workspaceRoot,
    scanRoots,
    projectConfig = null,
    documentRepository
}) {
    if (!symbol && !file) {
        return {
            status: "unknown",
            reason: "invalid_input",
            hint: "provide either `symbol` (usage-site impact), `file` (transitive reverse-include closure), or `symbol` + `file` (symbol impact with file as disambiguator)"
        };
    }
    if (!workspaceRoot) {
        return {
            status: "unknown",
            reason: "workspace_root_required",
            hint: "a workspaceRoot is required to walk the include graph"
        };
    }

    const roots = (Array.isArray(scanRoots) && scanRoots.length > 0)
        ? scanRoots
        : (projectConfig
            ? [projectConfig.reportDirectory, projectConfig.usrcalcDirectory]
            : [PROJECT_CONFIG_DEFAULTS.reportDirectory, PROJECT_CONFIG_DEFAULTS.usrcalcDirectory]);

    if (symbol) {
        return await affectsBySymbol({ symbol, file, workspaceRoot, scanRoots: roots, projectConfig, documentRepository });
    }
    return await affectsByFile({ file, workspaceRoot, scanRoots: roots, documentRepository });
}

async function affectsBySymbol({ symbol, file, workspaceRoot, scanRoots, projectConfig, documentRepository }) {
    const refResult = await findReferences({
        symbol,
        file,
        kind: "all",
        workspaceRoot,
        scanRoots,
        projectConfig,
        documentRepository
    });
    if (refResult.status !== "ok") return refResult;

    const byFile = new Map();
    for (const ref of refResult.references) {
        let entry = byFile.get(ref.file);
        if (!entry) {
            entry = { file: ref.file, usageKinds: new Set(), count: 0 };
            byFile.set(ref.file, entry);
        }
        entry.usageKinds.add(ref.kind);
        entry.count += 1;
    }

    const affectedFiles = [...byFile.values()]
        .map((e) => ({
            file: e.file,
            usageKinds: [...e.usageKinds].sort(),
            count: e.count
        }))
        .sort((a, b) => a.file.localeCompare(b.file));

    return {
        status: "ok",
        inputKind: "symbol",
        symbol,
        file: file ?? null,
        affectedFiles,
        unknowns: []
    };
}

async function affectsByFile({ file, workspaceRoot, scanRoots, documentRepository }) {
    const targetAbs = path.isAbsolute(file) ? file : path.join(workspaceRoot, file);
    const targetKey = normalizePathKey(targetAbs);

    const { reverseMap, actualPaths } = await documentRepository.getIncludeGraph(workspaceRoot, scanRoots);

    // Build parent pointers for the reverse BFS so each affected file can
    // report the chain it uses to reach the target.
    const parent = new Map();
    parent.set(targetKey, null);
    const queue = [targetKey];
    while (queue.length > 0) {
        const current = queue.shift();
        const includers = reverseMap.get(current);
        if (!includers) continue;
        for (const includer of includers) {
            if (parent.has(includer)) continue;
            parent.set(includer, current);
            queue.push(includer);
        }
    }

    // Reachable set excluding the target file itself.
    const reachable = getReverseReachableSet(targetAbs, reverseMap, actualPaths)
        .filter((abs) => normalizePathKey(abs) !== targetKey);

    // Enumerate the symbols declared in the target file so we can annotate
    // each affected file with the ones it actually uses.
    const targetDoc = await documentRepository.openDocument(targetAbs);
    const targetSymbols = targetDoc ? enumerateDeclaredSymbols(targetDoc) : [];
    const upperTargetSymbols = new Set(targetSymbols.map((s) => s.toUpperCase()));

    const affectedFiles = [];
    for (const abs of reachable) {
        const key = normalizePathKey(abs);
        const chain = buildChain(key, parent, actualPaths, targetKey);
        const doc = await documentRepository.openDocument(abs);
        const references = doc && upperTargetSymbols.size > 0
            ? findUsedTargetSymbols(doc, upperTargetSymbols, targetSymbols)
            : [];
        affectedFiles.push({
            file: abs,
            includedVia: chain,
            references
        });
    }

    affectedFiles.sort((a, b) => a.file.localeCompare(b.file));

    return {
        status: "ok",
        inputKind: "file",
        file,
        affectedFiles,
        unknowns: []
    };
}

function buildChain(startKey, parent, actualPaths, targetKey) {
    // Chain excludes the affected file itself; includes everything down to
    // and including the target. Each element is the file's basename — the
    // agent wants the filename it would see in an #include directive, not
    // the absolute path.
    const chain = [];
    let node = parent.get(startKey);
    while (node) {
        const abs = actualPaths.get(node) ?? node;
        chain.push(path.basename(abs));
        if (node === targetKey) break;
        node = parent.get(node);
    }
    return chain;
}

function enumerateDeclaredSymbols(doc) {
    const facts = collectDocumentFacts(doc);
    const names = [];
    // File-scope variables.
    if (facts.symbolTable?.fileScope) {
        for (const sym of facts.symbolTable.fileScope.symbols.values()) {
            if (sym.kind === "variable") names.push(sym.declaredName);
        }
    }
    // UDFs and macros.
    for (const udf of Object.values(facts.userDefinedFunctionCatalog ?? {})) {
        names.push(udf.declaredName);
    }
    for (const macro of Object.values(facts.macroCatalog ?? {})) {
        names.push(macro.declaredName);
    }
    return names;
}

function findUsedTargetSymbols(doc, upperTargetSymbols, originalCaseSymbols) {
    const tokens = collectDocumentFacts(doc).tokens;
    const used = new Set();
    for (const tok of tokens) {
        if (tok.type !== TokenType.IDENTIFIER) continue;
        const upper = tok.value.toUpperCase();
        if (upperTargetSymbols.has(upper)) used.add(upper);
    }
    if (used.size === 0) return [];
    // Re-map to original casing for the output.
    const caseMap = new Map();
    for (const name of originalCaseSymbols) caseMap.set(name.toUpperCase(), name);
    return [...used].map((u) => caseMap.get(u) ?? u).sort();
}

export { findImpacts };
