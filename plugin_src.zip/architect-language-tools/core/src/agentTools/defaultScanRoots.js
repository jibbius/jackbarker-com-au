/**
 * Canonical default scan-root list shared across agent tools.
 *
 * The Architect workspace layout puts user-authored source under
 * `Reports/` and `usercalcs/`. Each agent tool that walks the workspace
 * defaults to those roots when the caller does not override `scanRoots`.
 *
 * This is organisation-specific; ultimately it should be MCP-config-driven
 * so a deployment can override per-organisation. Until then, having a
 * single source of truth keeps the value consistent across tools.
 */
const DEFAULT_SCAN_ROOTS = ["Reports", "usercalcs"];

export { DEFAULT_SCAN_ROOTS };
