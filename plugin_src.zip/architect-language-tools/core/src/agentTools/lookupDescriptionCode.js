/**
 * Agent tool: lookup_description_code
 *
 * Looks up description codes from the SQL-backed description-codes
 * cache. The cache is populated by `connectors/src/SqlServerConnector.js`
 * and surfaced as a `DescriptionCodesCache` instance; the MCP server
 * owns when/how to refresh it (credentials, scheduling). This tool just
 * reads.
 *
 * Two input styles (equivalent):
 *   - `{ table, type, code? }`   — domain vocabulary
 *   - `{ lookupCode, code? }`    — the 4-char cache key as a single string
 *                                  (first 2 chars = group, next 2 = type);
 *                                  this is the form the field registry
 *                                  stores against each constrained field
 *                                  (e.g. hMDc_Account_Status → "QQMN")
 *
 * Two modes:
 *   - `code` provided → single-code lookup; returns one description.
 *   - `code` omitted  → enumerate mode; returns every valid code for
 *                       the group/type pair.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

/**
 * Minimal interface the tool expects from an injected cache. Real code
 * uses `connectors/src/DescriptionCodesCache.js`; tests pass a stub.
 *
 * @typedef {Object} DescriptionCodesCacheLike
 * @property {(lookupCode: string) => Array<{code: string, description: string, deprecated: boolean}>} lookup
 * @property {() => { populated: boolean, fetchedAt: string|null, server: string|null, database: string|null }} getStatus
 */

/**
 * @param {object} params
 * @param {string} [params.table]                               Description group (e.g. "QQ"). Pair with `type`.
 * @param {string} [params.type]                                Description type within the group. Pair with `table`.
 * @param {string} [params.lookupCode]                          4-char key combining group + type (e.g. "QQMN"). Alternative to `{table, type}`.
 * @param {string} [params.code]                                Specific code to resolve. Omit to enumerate all codes.
 * @param {DescriptionCodesCacheLike} params.descriptionCodesCache
 */
async function lookupDescriptionCode({ table, type, lookupCode, code, descriptionCodesCache }) {
    // Normalise input styles: (table, type) and lookupCode are equivalent.
    if (lookupCode) {
        if (table || type) {
            return {
                status: "unknown",
                reason: "invalid_input",
                hint: "provide either `lookupCode` OR `(table, type)`, not both"
            };
        }
        if (typeof lookupCode !== "string" || lookupCode.length !== 4) {
            return {
                status: "unknown",
                reason: "invalid_input",
                hint: "lookupCode must be a 4-character string combining group + type (e.g. 'QQMN')"
            };
        }
        table = lookupCode.slice(0, 2);
        type = lookupCode.slice(2, 4);
    }

    if (!table || !type) {
        return {
            status: "unknown",
            reason: "invalid_input",
            hint: "provide either `lookupCode` (e.g. 'QQMN') or both `table` and `type`"
        };
    }
    if (!descriptionCodesCache || typeof descriptionCodesCache.lookup !== "function") {
        return {
            status: "unknown",
            reason: "cache_unavailable",
            hint: "a DescriptionCodesCache instance must be provided; the MCP server is responsible for constructing and populating it"
        };
    }

    const status = descriptionCodesCache.getStatus?.() ?? { populated: false };
    if (!status.populated) {
        return {
            status: "unknown",
            reason: "cache_not_populated",
            hint: "description codes cache has not been populated; refresh it from the SQL source before calling this tool"
        };
    }

    const resolvedLookupCode = `${table}${type}`;
    const entries = descriptionCodesCache.lookup(resolvedLookupCode);
    const cacheStatus = {
        fetchedAt: status.fetchedAt ?? null,
        server: status.server ?? null,
        database: status.database ?? null
    };
    const base = { table, type, lookupCode: resolvedLookupCode, cacheStatus };

    // Group/type has no entries at all.
    if (!Array.isArray(entries) || entries.length === 0) {
        return {
            status: "ok",
            ...base,
            ...(code ? { code, description: null, deprecated: null } : { codes: [] }),
            unknowns: [{
                reason: "group_type_not_found",
                hint: `no description codes exist for table="${table}", type="${type}" — possible typo, or this group/type is not populated in the source database`
            }]
        };
    }

    // Enumerate mode: agent wants every valid code for this group/type.
    if (!code) {
        return {
            status: "ok",
            ...base,
            codes: entries.map((e) => ({
                code: e.code,
                description: e.description,
                deprecated: e.deprecated === true
            })),
            unknowns: []
        };
    }

    // Single-code mode.
    const match = entries.find((e) => e.code === code);
    if (!match) {
        return {
            status: "ok",
            ...base,
            code,
            description: null,
            deprecated: null,
            unknowns: [{
                reason: "code_not_found",
                hint: `group/type exists (${entries.length} codes), but code="${code}" is not among them`,
                availableCount: entries.length
            }]
        };
    }

    return {
        status: "ok",
        ...base,
        code,
        description: match.description,
        deprecated: match.deprecated === true,
        unknowns: []
    };
}

export { lookupDescriptionCode };
