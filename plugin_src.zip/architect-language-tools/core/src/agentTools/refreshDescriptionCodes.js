/**
 * Agent tool: refresh_description_codes
 *
 * Populates the description-codes cache from SQL Server. Counterpart to
 * `lookupDescriptionCode.js` (which reads): this one writes. Both processes
 * (the VS Code extension and the MCP server) can refresh through the shared
 * `connectors/` library — see `planning/ideas/mcp-cache-architecture-review.md`
 * for the "Refined A" decision.
 *
 * Inputs are server-side context only — the tool takes no agent-facing
 * arguments. Server, database, and cache file path come from MCP config
 * (`ARCH_LANG_CONN_SERVER`, `ARCH_LANG_CONN_DATABASE`, `ARCH_LANG_DESCRIPTION_CACHE`).
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

/**
 * @param {object} params
 * @param {string|null} params.server                              SQL Server host (from config).
 * @param {string|null} params.database                            Database name (from config).
 * @param {string|null} params.cachePath                           Absolute path to write the cache JSON to (from config).
 * @param {(server: string, database: string) => Promise<Array<{g:string,t:string,c:string,d:string,x:string}>>} params.queryDescriptionCodes
 * @param {{ build: (rows: any[], server: string, database: string, filePath: string) => Promise<void>, getStatus: () => any }} params.descriptionCodesCache
 */
async function refreshDescriptionCodes({ server, database, cachePath, queryDescriptionCodes, descriptionCodesCache }) {
    if (!server || !database) {
        return {
            status: "unknown",
            reason: "config_missing",
            hint: "ARCH_LANG_CONN_SERVER and ARCH_LANG_CONN_DATABASE must both be set on the MCP server before refresh_description_codes can run"
        };
    }
    if (!cachePath) {
        return {
            status: "unknown",
            reason: "config_missing",
            hint: "ARCH_LANG_DESCRIPTION_CACHE must be set on the MCP server so the refreshed cache can be written to a known path"
        };
    }

    let rows;
    try {
        rows = await queryDescriptionCodes(server, database);
    } catch (err) {
        return {
            status: "unknown",
            reason: "sql_error",
            hint: err?.message ?? String(err)
        };
    }

    try {
        await descriptionCodesCache.build(rows, server, database, cachePath);
    } catch (err) {
        return {
            status: "unknown",
            reason: "cache_write_failed",
            hint: err?.message ?? String(err)
        };
    }

    const status = descriptionCodesCache.getStatus?.() ?? {};
    return {
        status: "ok",
        rowCount: Array.isArray(rows) ? rows.length : 0,
        fetchedAt: status.fetchedAt ?? null,
        server,
        database
    };
}

export { refreshDescriptionCodes };
