/**
 * Agent tool: refresh_description_codes
 *
 * Populates the description-codes cache from SQL Server. Counterpart to
 * `lookupDescriptionCode.js` (which reads): this one writes. Both processes
 * (the VS Code extension and the MCP server) can refresh through the shared
 * `connectors/` library — see `planning/ideas/mcp-cache-architecture-review.md`
 * for the "Refined A" decision.
 *
 * Inputs are server-side context only — the tool takes no agent-facing
 * arguments. Server, database, encrypt and trust flags come from the
 * resolved projectConfig (CFG / .architect.json / env-var overrides);
 * the cache file path comes from MCP config (`ARCH_LANG_DESCRIPTION_CACHE`).
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

/**
 * @param {object} params
 * @param {object} params.projectConfig                              Resolved projectConfig (frozen).
 * @param {string|null} params.cachePath                             Absolute path to write the cache JSON to (from config).
 * @param {(server: string, database: string, options?: {encrypt?:boolean,trustServerCertificate?:boolean}) => Promise<{rows: Array<{g:string,t:string,c:string,d:string,x:string}>, skipped: string[]}>} params.queryDescriptionCodes
 * @param {{ build: (rows: any[], server: string, database: string, filePath: string) => Promise<void>, getStatus: () => any }} params.descriptionCodesCache
 */
async function refreshDescriptionCodes({ projectConfig, cachePath, queryDescriptionCodes, descriptionCodesCache }) {
    const server = projectConfig?.dbServer ?? "";
    const database = projectConfig?.dbDatabase ?? "";
    if (!server || !database) {
        return {
            status: "unknown",
            reason: "config_missing",
            hint: "dbServer and dbDatabase must both be resolvable (set ARCH_LANG_DBSERVER/ARCH_LANG_DBDATABASE, or DBSERVER/DBDATABASE in Acurity.CFG, or dbServer/dbDatabase in .architect.json) before refresh_description_codes can run"
        };
    }
    if (!cachePath) {
        return {
            status: "unknown",
            reason: "config_missing",
            hint: "ARCH_LANG_DESCRIPTION_CACHE must be set on the MCP server so the refreshed cache can be written to a known path"
        };
    }

    let rows;
    let skipped;
    try {
        ({ rows, skipped } = await queryDescriptionCodes(server, database, {
            encrypt: projectConfig?.dbEncrypt ?? false,
            trustServerCertificate: projectConfig?.dbTrustServerCertificate ?? true
        }));
    } catch (err) {
        return errorEnvelope("sql_error", err);
    }

    try {
        await descriptionCodesCache.build(rows, server, database, cachePath);
    } catch (err) {
        return errorEnvelope("cache_write_failed", err);
    }

    const status = descriptionCodesCache.getStatus?.() ?? {};
    return {
        status: "ok",
        rowCount: Array.isArray(rows) ? rows.length : 0,
        skippedCount: Array.isArray(skipped) ? skipped.length : 0,
        skipped: Array.isArray(skipped) ? skipped : [],
        fetchedAt: status.fetchedAt ?? null,
        server,
        database
    };
}

/**
 * Builds the unknown-status envelope for a thrown error, preserving the
 * stack and any chained `cause` so an agent (or a human reading the MCP
 * transcript) can diagnose the failure without rerunning under a debugger.
 * `hint` keeps the human-readable message; `errStack` and `errCause` are
 * present only when the underlying error supplied them.
 */
function errorEnvelope(reason, err) {
    const envelope = {
        status: "unknown",
        reason,
        hint: err?.message ?? String(err)
    };
    if (err?.stack) envelope.errStack = err.stack;
    if (err?.cause) {
        envelope.errCause = err.cause?.message ?? String(err.cause);
    }
    return envelope;
}

export { refreshDescriptionCodes };
