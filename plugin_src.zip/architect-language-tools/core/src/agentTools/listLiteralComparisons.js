/**
 * Agent tool: list_literal_comparisons
 *
 * Returns the set of field-handle-to-string-literal comparisons in the
 * file. Surfaces the existing `literalComparisons` field from
 * `buildFileStructureSummary` without re-deriving it.
 *
 * Each entry:
 *   { handle, operator, value, line }
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import { collectDocumentFacts } from "../analysis/documentFacts.js";
import { buildFileStructureSummary } from "../analysis/fileStructureSummary.js";

/**
 * @param {object} params
 * @param {string} params.filePath
 * @param {{ openDocument: (p: string) => Promise<object|null> }} params.documentRepository
 */
async function listLiteralComparisons({ filePath, documentRepository }) {
    const doc = await documentRepository.openDocument(filePath);
    if (!doc) {
        return {
            status: "unknown",
            file: filePath,
            reason: "file_not_readable",
            hint: "file does not exist or could not be read"
        };
    }
    const facts = collectDocumentFacts(doc);
    const summary = buildFileStructureSummary(facts);
    return {
        status: "ok",
        file: filePath,
        literalComparisons: summary.literalComparisons ?? [],
        unknowns: []
    };
}

export { listLiteralComparisons };
