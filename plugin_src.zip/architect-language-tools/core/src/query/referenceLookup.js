/**
 * Headless reference-lookup primitives.
 *
 * Pure functions used by both the VS Code references provider and the
 * headless MCP server. No vscode imports — enforced by CLAUDE.md rule 1.
 *
 *   - getFunctionBlockRange(document, targetLine):
 *       Determines whether a line sits inside a FUNCTION block and, if so,
 *       returns the { start, end } 0-based inclusive line range of the
 *       innermost enclosing block. Returns null when the line is at file scope.
 *
 *   - findOccurrences(tokens, symbol, isFunction, options):
 *       Returns all IDENTIFIER tokens in the stream that match the target
 *       symbol, applying call/non-call discrimination and optional filters
 *       (declaration-line exclusion, function-local line range).
 */

import { TokenType } from "../lexer/tokenTypes.js";
import { NodeType } from "../ast/nodes.js";
import { buildDocumentAst } from "../ast/documentAst.js";

/**
 * Returns the inclusive line range of the innermost FUNCTION block enclosing
 * `targetLine`, or null if the target is at file scope.
 *
 * Implementation walks the AST: each FUNCTION block in the parser is paired
 * with a sibling EndFunctionStatement in the same statement list (the parser
 * pops the function scope at ENDFUNCTION before pushing the end node). For
 * each FunctionDeclaration we look forward through its siblings for that
 * matching end node, and recurse into its body to find nested functions.
 *
 * @param {object} document - TextDocument-like (lineCount, lineAt, getText, uri, version).
 * @param {number} targetLine - 0-based line number to check.
 * @returns {{ start: number, end: number }|null}
 */
function getFunctionBlockRange(document, targetLine) {
    const { ast } = buildDocumentAst(document);

    let best = null;
    function visit(siblings) {
        for (let i = 0; i < siblings.length; i++) {
            const stmt = siblings[i];
            if (stmt.type === NodeType.FunctionDeclaration) {
                let endLine = -1;
                for (let j = i + 1; j < siblings.length; j++) {
                    if (siblings[j].type === NodeType.EndFunctionStatement) {
                        endLine = siblings[j].line;
                        break;
                    }
                }
                if (endLine !== -1 && targetLine >= stmt.line && targetLine <= endLine) {
                    const range = { start: stmt.line, end: endLine };
                    if (!best || (range.end - range.start) < (best.end - best.start)) {
                        best = range;
                    }
                }
                if (Array.isArray(stmt.body)) visit(stmt.body);
                continue;
            }
            // Defensive recursion: no language construct currently nests a
            // FUNCTION inside an IF/DO/CASE branch, but if one ever did we'd
            // still want to find it rather than silently miss the scope.
            if (Array.isArray(stmt.body))       visit(stmt.body);
            if (Array.isArray(stmt.consequent)) visit(stmt.consequent);
            if (Array.isArray(stmt.alternate))  visit(stmt.alternate);
            if (Array.isArray(stmt.otherwise))  visit(stmt.otherwise);
            if (Array.isArray(stmt.branches)) {
                for (const b of stmt.branches) {
                    if (Array.isArray(b.body)) visit(b.body);
                }
            }
        }
    }
    visit(ast.statements);
    return best;
}

/**
 * @param {Array<{type:string,value:string,line:number,char:number}>} tokens
 * @param {string} symbol - Identifier to search for (case-insensitive match).
 * @param {boolean} isFunction - When true, only match sites where the IDENTIFIER
 *   is immediately followed by LPAREN (call sites). When false, only match sites
 *   NOT followed by LPAREN (variable references).
 * @param {object} options
 * @param {boolean} options.includeDeclaration - Include the declaration line.
 * @param {number} options.declarationLine - 0-based line of the declaration in
 *   this file, or -1 if the declaration is in a different file.
 * @param {{ start: number, end: number }|null} options.lineRange - When set,
 *   restrict results to tokens within [start, end] inclusive (function-local scope).
 * @returns {Array<{line:number,char:number,value:string}>}
 */
function findOccurrences(tokens, symbol, isFunction, options) {
    const { includeDeclaration, declarationLine, lineRange } = options;
    const upperSymbol = symbol.toUpperCase();
    const results = [];

    for (let i = 0; i < tokens.length; i++) {
        const tok = tokens[i];

        if (tok.type !== TokenType.IDENTIFIER) continue;
        if (tok.value.toUpperCase() !== upperSymbol) continue;

        // Function-local line range filter.
        if (lineRange !== null && lineRange !== undefined) {
            if (tok.line < lineRange.start || tok.line > lineRange.end) continue;
        }

        // Declaration line exclusion.
        if (!includeDeclaration && tok.line === declarationLine) continue;

        // Find the next meaningful (non-whitespace, non-newline) token.
        let nextMeaningful = null;
        for (let j = i + 1; j < tokens.length; j++) {
            const t = tokens[j];
            if (t.type === TokenType.WHITESPACE || t.type === TokenType.NEWLINE) continue;
            nextMeaningful = t;
            break;
        }

        const isCall = nextMeaningful?.type === TokenType.LPAREN;

        if (isFunction && !isCall) continue;
        if (!isFunction && isCall) continue;

        results.push({ line: tok.line, char: tok.char, value: tok.value });
    }

    return results;
}

export { getFunctionBlockRange, findOccurrences };
