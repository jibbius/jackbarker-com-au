/**
 * Headless reference-lookup primitives.
 *
 * Pure functions used by both the VS Code references provider and the
 * headless MCP server. No vscode imports — enforced by CLAUDE.md rule 1.
 *
 *   - getFunctionBlockRange(lines, targetLine):
 *       Determines whether a line sits inside a FUNCTION block and, if so,
 *       returns the { start, end } 0-based inclusive line range of the
 *       innermost enclosing block. Returns null when the line is at file scope.
 *
 *   - findOccurrences(tokens, symbol, isFunction, options):
 *       Returns all IDENTIFIER tokens in the stream that match the target
 *       symbol, applying call/non-call discrimination and optional filters
 *       (declaration-line exclusion, function-local line range).
 */

import { TokenType } from "../lexer/tokenTypes.js";

/**
 * @param {string[]} lines - All lines of the file (0-indexed).
 * @param {number} targetLine - 0-based line number to check.
 * @returns {{ start: number, end: number }|null}
 */
function getFunctionBlockRange(lines, targetLine) {
    // Walk backwards to find the innermost enclosing FUNCTION.
    let depth = 0;
    let functionStart = -1;

    for (let i = targetLine; i >= 0; i--) {
        const text = lines[i];
        if (/^\s*(?:#\s*)?ENDFUNCTION\b/i.test(text)) {
            depth++;
        } else if (/^\s*(?:#\s*)?FUNCTION\b/i.test(text)) {
            if (depth === 0) {
                functionStart = i;
                break;
            }
            depth--;
        }
    }

    if (functionStart === -1) return null;

    // Walk forwards from functionStart to find the matching ENDFUNCTION.
    depth = 0;
    for (let i = functionStart; i < lines.length; i++) {
        const text = lines[i];
        if (/^\s*(?:#\s*)?FUNCTION\b/i.test(text)) {
            depth++;
        } else if (/^\s*(?:#\s*)?ENDFUNCTION\b/i.test(text)) {
            depth--;
            if (depth === 0) {
                return { start: functionStart, end: i };
            }
        }
    }

    return null; // unclosed FUNCTION — treat as file scope to avoid false negatives
}

/**
 * @param {Array<{type:string,value:string,line:number,char:number}>} tokens
 * @param {string} symbol - Identifier to search for (case-insensitive match).
 * @param {boolean} isFunction - When true, only match sites where the IDENTIFIER
 *   is immediately followed by LPAREN (call sites). When false, only match sites
 *   NOT followed by LPAREN (variable references).
 * @param {object} options
 * @param {boolean} options.includeDeclaration - Include the declaration line.
 * @param {number} options.declarationLine - 0-based line of the declaration in
 *   this file, or -1 if the declaration is in a different file.
 * @param {{ start: number, end: number }|null} options.lineRange - When set,
 *   restrict results to tokens within [start, end] inclusive (function-local scope).
 * @returns {Array<{line:number,char:number,value:string}>}
 */
function findOccurrences(tokens, symbol, isFunction, options) {
    const { includeDeclaration, declarationLine, lineRange } = options;
    const upperSymbol = symbol.toUpperCase();
    const results = [];

    for (let i = 0; i < tokens.length; i++) {
        const tok = tokens[i];

        if (tok.type !== TokenType.IDENTIFIER) continue;
        if (tok.value.toUpperCase() !== upperSymbol) continue;

        // Function-local line range filter.
        if (lineRange !== null && lineRange !== undefined) {
            if (tok.line < lineRange.start || tok.line > lineRange.end) continue;
        }

        // Declaration line exclusion.
        if (!includeDeclaration && tok.line === declarationLine) continue;

        // Find the next meaningful (non-whitespace, non-newline) token.
        let nextMeaningful = null;
        for (let j = i + 1; j < tokens.length; j++) {
            const t = tokens[j];
            if (t.type === TokenType.WHITESPACE || t.type === TokenType.NEWLINE) continue;
            nextMeaningful = t;
            break;
        }

        const isCall = nextMeaningful?.type === TokenType.LPAREN;

        if (isFunction && !isCall) continue;
        if (!isFunction && isCall) continue;

        results.push({ line: tok.line, char: tok.char, value: tok.value });
    }

    return results;
}

export { getFunctionBlockRange, findOccurrences };
