/**
 * Headless reverse include index.
 *
 * Pure build + query for the reverse include map — "which files transitively
 * include a given file?". No caching, no file watchers — callers (LSP, MCP
 * server) layer their own cache policy on top.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as fs from "fs";
import * as path from "path";
import {
    parseIncludeFilename,
    resolveIncludePath,
    normalizePathKey
} from "../includeResolver/graph.js";

const DEFAULT_EXTENSIONS = [".txt"];
const DEFAULT_IGNORE_DIRS = new Set([".git", "node_modules", ".vscode", ".claude"]);

/**
 * Recursively walks `root` collecting every file whose extension matches
 * `extensions` (lower-cased comparison). Skips any directory name in
 * `ignoreDirs`.
 *
 * @param {string} root - Absolute directory to walk.
 * @param {object} options
 * @param {string[]} options.extensions - Extensions to include (lower-case, with leading dot).
 * @param {Set<string>} options.ignoreDirs - Directory names to skip.
 * @param {string[]} out - Accumulator for matches.
 */
async function walkDirectory(root, options, out) {
    let entries;
    try {
        entries = await fs.promises.readdir(root, { withFileTypes: true });
    } catch {
        return;
    }

    for (const entry of entries) {
        const entryPath = path.join(root, entry.name);
        if (entry.isDirectory()) {
            if (options.ignoreDirs.has(entry.name)) continue;
            await walkDirectory(entryPath, options, out);
        } else if (entry.isFile()) {
            const ext = path.extname(entry.name).toLowerCase();
            if (options.extensions.includes(ext)) {
                out.push(entryPath);
            }
        }
    }
}

/**
 * Enumerates all Architect source files under the given scan roots.
 *
 * @param {string} workspaceRoot - Absolute path of the workspace root.
 * @param {object} [options]
 * @param {string[]} [options.scanRoots] - Relative-to-workspace directory paths
 *   to scan. Defaults to ["."] (the whole workspace). MCP deployments pass
 *   ["Reports", "Usercalcs"] (or similar) from .acurity.json.
 * @param {string[]} [options.extensions] - File extensions to include.
 *   Defaults to [".txt"].
 * @param {Set<string>} [options.ignoreDirs] - Directory names to skip.
 *   Defaults to .git / node_modules / .vscode / .claude.
 * @returns {Promise<string[]>} Absolute filesystem paths.
 */
async function enumerateSourceFiles(workspaceRoot, options = {}) {
    const scanRoots = options.scanRoots ?? ["."];
    const extensions = (options.extensions ?? DEFAULT_EXTENSIONS).map((e) => e.toLowerCase());
    const ignoreDirs = options.ignoreDirs ?? DEFAULT_IGNORE_DIRS;

    const collected = [];
    for (const rel of scanRoots) {
        const absolute = path.resolve(workspaceRoot, rel);
        await walkDirectory(absolute, { extensions, ignoreDirs }, collected);
    }

    // Dedup at the file level so overlapping scanRoots (e.g. [".", "Reports"])
    // don't produce duplicate entries.
    const seen = new Set();
    const out = [];
    for (const file of collected) {
        const key = normalizePathKey(file);
        if (seen.has(key)) continue;
        seen.add(key);
        out.push(file);
    }
    return out;
}

/**
 * Builds a reverse include map from a set of file paths and a content source.
 *
 * The caller is responsible for supplying file content — this lets the LSP
 * prefer in-memory open-document content over disk, while headless callers
 * (MCP, tests) just read from disk.
 *
 * @param {string[]} filePaths - Absolute paths to scan for INCLUDE directives.
 * @param {(filePath: string) => Promise<string|null>} readContent - Async
 *   content reader. Return null to skip a file.
 * @param {string|null} workspaceRoot - Path sandboxing root passed to the
 *   include resolver. null disables the check.
 * @returns {Promise<{
 *   reverseMap: Map<string, Set<string>>,
 *   actualPaths: Map<string, string>
 * }>}
 *   reverseMap  — normalizedPath → Set of normalized paths that directly include it
 *   actualPaths — normalizedPath → real filesystem path
 */
async function buildReverseMap(filePaths, readContent, workspaceRoot) {
    const reverseMap = new Map();
    const actualPaths = new Map();

    for (const actualPath of filePaths) {
        const normalizedPath = normalizePathKey(actualPath);
        actualPaths.set(normalizedPath, actualPath);

        const content = await readContent(actualPath);
        if (content == null) continue;

        const fileDir = path.dirname(actualPath);
        const lines = content.split(/\r?\n/);

        for (const lineText of lines) {
            const filename = parseIncludeFilename(lineText)?.filename;
            if (!filename) continue;

            const resolved = resolveIncludePath(fileDir, filename, workspaceRoot);
            if (!resolved) continue;

            const normalizedResolved = normalizePathKey(resolved);

            if (!reverseMap.has(normalizedResolved)) {
                reverseMap.set(normalizedResolved, new Set());
            }
            reverseMap.get(normalizedResolved).add(normalizedPath);

            if (!actualPaths.has(normalizedResolved)) {
                actualPaths.set(normalizedResolved, resolved);
            }
        }
    }

    return { reverseMap, actualPaths };
}

/**
 * BFS over a reverse include map returning every file that transitively
 * includes `definingFilePath` (plus the file itself).
 *
 * @param {string} definingFilePath - Absolute path of the file declaring the symbol.
 * @param {Map<string, Set<string>>} reverseMap - From buildReverseMap.
 * @param {Map<string, string>} actualPaths - From buildReverseMap.
 * @returns {string[]} Absolute filesystem paths.
 */
function getReverseReachableSet(definingFilePath, reverseMap, actualPaths) {
    const startNormalized = normalizePathKey(definingFilePath);
    const paths = new Map(actualPaths);
    if (!paths.has(startNormalized)) {
        paths.set(startNormalized, definingFilePath);
    }

    const visited = new Set();
    const queue = [startNormalized];

    while (queue.length > 0) {
        const current = queue.pop();
        if (visited.has(current)) continue;
        visited.add(current);

        const parents = reverseMap.get(current);
        if (parents) {
            for (const parent of parents) {
                if (!visited.has(parent)) queue.push(parent);
            }
        }
    }

    return [...visited].map((n) => paths.get(n) ?? n);
}

export {
    enumerateSourceFiles,
    buildReverseMap,
    getReverseReachableSet,
    DEFAULT_EXTENSIONS,
    DEFAULT_IGNORE_DIRS
};
