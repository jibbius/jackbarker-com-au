/**
 * Headless document repository.
 *
 * Filesystem-backed analogue of vscode.workspace — open/read a path as a
 * PlainTextDocument, with a small in-memory cache keyed by mtime so repeated
 * reads of the same file (common in the MCP server's tool handlers) don't
 * re-read from disk.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as fs from "fs";
import { PlainTextDocument } from "../plainTextDocument.js";
import { normalizePathKey } from "../includeResolver/graph.js";

/**
 * Creates a new document repository. Each repository owns its own cache, so
 * callers that want cache invalidation can simply construct a fresh one.
 *
 * @returns {{
 *   openDocument: (filePath: string) => Promise<PlainTextDocument|null>,
 *   openDocumentSync: (filePath: string) => PlainTextDocument|null,
 *   invalidate: (filePath?: string) => void
 * }}
 */
function createDocumentRepository() {
    /** @type {Map<string, { mtimeMs: number, doc: PlainTextDocument }>} */
    const cache = new Map();

    async function openDocument(filePath) {
        const key = normalizePathKey(filePath);
        let stat;
        try {
            stat = await fs.promises.stat(filePath);
        } catch {
            return null;
        }

        const cached = cache.get(key);
        if (cached && cached.mtimeMs === stat.mtimeMs) {
            return cached.doc;
        }

        let content;
        try {
            content = await fs.promises.readFile(filePath, "utf8");
        } catch {
            return null;
        }

        const doc = new PlainTextDocument(filePath, content);
        cache.set(key, { mtimeMs: stat.mtimeMs, doc });
        return doc;
    }

    function openDocumentSync(filePath) {
        const key = normalizePathKey(filePath);
        let stat;
        try {
            stat = fs.statSync(filePath);
        } catch {
            return null;
        }

        const cached = cache.get(key);
        if (cached && cached.mtimeMs === stat.mtimeMs) {
            return cached.doc;
        }

        let content;
        try {
            content = fs.readFileSync(filePath, "utf8");
        } catch {
            return null;
        }

        const doc = new PlainTextDocument(filePath, content);
        cache.set(key, { mtimeMs: stat.mtimeMs, doc });
        return doc;
    }

    function invalidate(filePath) {
        if (filePath === undefined) {
            cache.clear();
            return;
        }
        cache.delete(normalizePathKey(filePath));
    }

    return { openDocument, openDocumentSync, invalidate };
}

export { createDocumentRepository };
