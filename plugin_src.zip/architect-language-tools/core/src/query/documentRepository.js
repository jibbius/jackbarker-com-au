/**
 * Headless document repository.
 *
 * Filesystem-backed analogue of vscode.workspace — open/read a path as a
 * PlainTextDocument, with a small in-memory cache keyed by mtime so repeated
 * reads of the same file (common in the MCP server's tool handlers) don't
 * re-read from disk.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as fs from "fs";
import { PlainTextDocument } from "../plainTextDocument.js";
import { normalizePathKey } from "../includeResolver/graph.js";
import {
    enumerateSourceFiles,
    buildReverseMap
} from "./workspaceIndex.js";

/**
 * Creates a new document repository. Each repository owns its own cache, so
 * callers that want cache invalidation can simply construct a fresh one.
 *
 * Beyond per-file content caching, the repository also memoises two
 * workspace-level structures used by every agent tool that walks the
 * workspace: the source-file enumeration, and the reverse include graph.
 * These are keyed by `(workspaceRoot, sortedScanRoots)` and live for the
 * lifetime of the repository — the MCP server creates one repository per
 * process, so a `find_definition` → `find_references` → `find_impacts`
 * chain pays the workspace walk once instead of three times.
 *
 * @returns {{
 *   openDocument: (filePath: string) => Promise<PlainTextDocument|null>,
 *   openDocumentSync: (filePath: string) => PlainTextDocument|null,
 *   getWorkspaceFiles: (workspaceRoot: string, scanRoots: string[]) => Promise<string[]>,
 *   getIncludeGraph: (workspaceRoot: string, scanRoots: string[]) => Promise<{
 *     files: string[],
 *     reverseMap: Map<string, Set<string>>,
 *     forwardMap: Map<string, Array<{filename: string, resolvedPath: string|null, line: number}>>,
 *     actualPaths: Map<string, string>
 *   }>,
 *   invalidate: (filePath?: string) => void
 * }}
 */
function createDocumentRepository() {
    /** @type {Map<string, { mtimeMs: number, doc: PlainTextDocument }>} */
    const cache = new Map();
    /** @type {Map<string, Promise<string[]>>} */
    const filesCache = new Map();
    /** @type {Map<string, Promise<{ files: string[], reverseMap: Map<string, Set<string>>, forwardMap: Map<string, Array<{filename: string, resolvedPath: string|null, line: number}>>, actualPaths: Map<string, string> }>>} */
    const graphCache = new Map();

    async function openDocument(filePath) {
        const key = normalizePathKey(filePath);
        let stat;
        try {
            stat = await fs.promises.stat(filePath);
        } catch {
            return null;
        }

        const cached = cache.get(key);
        if (cached && cached.mtimeMs === stat.mtimeMs) {
            return cached.doc;
        }

        let content;
        try {
            content = await fs.promises.readFile(filePath, "utf8");
        } catch {
            return null;
        }

        const doc = new PlainTextDocument(filePath, content);
        cache.set(key, { mtimeMs: stat.mtimeMs, doc });
        return doc;
    }

    function openDocumentSync(filePath) {
        const key = normalizePathKey(filePath);
        let stat;
        try {
            stat = fs.statSync(filePath);
        } catch {
            return null;
        }

        const cached = cache.get(key);
        if (cached && cached.mtimeMs === stat.mtimeMs) {
            return cached.doc;
        }

        let content;
        try {
            content = fs.readFileSync(filePath, "utf8");
        } catch {
            return null;
        }

        const doc = new PlainTextDocument(filePath, content);
        cache.set(key, { mtimeMs: stat.mtimeMs, doc });
        return doc;
    }

    function workspaceCacheKey(workspaceRoot, scanRoots) {
        const sorted = [...scanRoots].sort();
        return `${normalizePathKey(workspaceRoot)}::${sorted.join("|")}`;
    }

    async function getWorkspaceFiles(workspaceRoot, scanRoots) {
        const key = workspaceCacheKey(workspaceRoot, scanRoots);
        let pending = filesCache.get(key);
        if (!pending) {
            pending = enumerateSourceFiles(workspaceRoot, { scanRoots });
            filesCache.set(key, pending);
        }
        return pending;
    }

    async function getIncludeGraph(workspaceRoot, scanRoots) {
        const key = workspaceCacheKey(workspaceRoot, scanRoots);
        let pending = graphCache.get(key);
        if (!pending) {
            pending = (async () => {
                const files = await getWorkspaceFiles(workspaceRoot, scanRoots);
                const readContent = async (p) => {
                    const doc = await openDocument(p);
                    if (!doc) return null;
                    const lines = [];
                    for (let i = 0; i < doc.lineCount; i++) lines.push(doc.lineAt(i).text);
                    return lines.join("\n");
                };
                const { reverseMap, forwardMap, actualPaths } = await buildReverseMap(files, readContent, workspaceRoot);
                return { files, reverseMap, forwardMap, actualPaths };
            })();
            graphCache.set(key, pending);
        }
        return pending;
    }

    function invalidate(filePath) {
        if (filePath === undefined) {
            cache.clear();
            filesCache.clear();
            graphCache.clear();
            return;
        }
        cache.delete(normalizePathKey(filePath));
        // A single-file change can rewire the include graph; drop the
        // workspace-scope caches rather than try to surgically patch them.
        filesCache.clear();
        graphCache.clear();
    }

    return {
        openDocument,
        openDocumentSync,
        getWorkspaceFiles,
        getIncludeGraph,
        invalidate
    };
}

export { createDocumentRepository };
