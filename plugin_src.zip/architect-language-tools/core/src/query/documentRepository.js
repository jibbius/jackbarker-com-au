/**
 * Headless document repository.
 *
 * Filesystem-backed analogue of vscode.workspace — open/read a path as a
 * PlainTextDocument, with a small in-memory cache keyed by mtime so repeated
 * reads of the same file (common in the MCP server's tool handlers) don't
 * re-read from disk.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as fs from "fs";
import { PlainTextDocument } from "../plainTextDocument.js";
import { normalizePathKey } from "../includeResolver/graph.js";
import {
    enumerateSourceFiles,
    buildReverseMap
} from "./workspaceIndex.js";

/**
 * Creates a new document repository. Each repository owns its own cache, so
 * callers that want cache invalidation can simply construct a fresh one.
 *
 * Beyond per-file content caching, the repository also memoises two
 * workspace-level structures used by every agent tool that walks the
 * workspace: the source-file enumeration, and the reverse include graph.
 * These are keyed by `(workspaceRoot, sortedScanRoots)` and live for the
 * lifetime of the repository — the MCP server creates one repository per
 * process, so a `find_definition` → `find_references` → `find_impacts`
 * chain pays the workspace walk once instead of three times.
 *
 * @returns {{
 *   openDocument: (filePath: string) => Promise<PlainTextDocument|null>,
 *   getWorkspaceFiles: (workspaceRoot: string, scanRoots: string[]) => Promise<string[]>,
 *   getIncludeGraph: (workspaceRoot: string, scanRoots: string[]) => Promise<{
 *     files: string[],
 *     reverseMap: Map<string, Set<string>>,
 *     forwardMap: Map<string, Array<{filename: string, resolvedPath: string|null, line: number}>>,
 *     actualPaths: Map<string, string>
 *   }>,
 *   invalidate: (filePath?: string) => void
 * }}
 */
// Insertion-ordered LRU cap on the per-file content cache. The MCP server
// runs as a long-lived process, so an unbounded cache pins every visited
// file's bytes into RSS for the agent session — a 256-entry cap keeps the
// hot working set resident without growing without bound. Map preserves
// insertion order, so the oldest key is the first one yielded by keys().
const DOCUMENT_CACHE_MAX = 256;

function createDocumentRepository() {
    /** @type {Map<string, { mtimeMs: number, doc: PlainTextDocument }>} */
    const cache = new Map();
    /** @type {Map<string, Promise<string[]>>} */
    const filesCache = new Map();
    /** @type {Map<string, Promise<{ files: string[], reverseMap: Map<string, Set<string>>, forwardMap: Map<string, Array<{filename: string, resolvedPath: string|null, line: number}>>, actualPaths: Map<string, string> }>>} */
    const graphCache = new Map();

    function recordCacheEntry(key, entry) {
        cache.delete(key);
        cache.set(key, entry);
        while (cache.size > DOCUMENT_CACHE_MAX) {
            const oldest = cache.keys().next().value;
            cache.delete(oldest);
        }
    }

    async function openDocument(filePath) {
        const key = normalizePathKey(filePath);
        let handle;
        try {
            handle = await fs.promises.open(filePath, "r");
        } catch {
            return null;
        }
        try {
            // Read first, then fstat the same handle. Order matters: if we
            // stat first and read second, an atomic-replace racing between
            // the two calls can leave us caching pre-replace bytes under
            // post-replace mtime — and a real edit at that mtime then
            // wouldn't invalidate. Read-then-fstat binds the cached mtime
            // to the bytes we actually observed.
            const buf = await handle.readFile();
            const stat = await handle.stat();

            const cached = cache.get(key);
            if (cached && cached.mtimeMs === stat.mtimeMs) {
                recordCacheEntry(key, cached);
                return cached.doc;
            }

            const doc = new PlainTextDocument(filePath, buf.toString("utf8"));
            recordCacheEntry(key, { mtimeMs: stat.mtimeMs, doc });
            return doc;
        } catch {
            return null;
        } finally {
            try { await handle.close(); } catch { /* already closed / unlinked */ }
        }
    }

    function workspaceCacheKey(workspaceRoot, scanRoots) {
        const sorted = [...scanRoots].sort();
        return `${normalizePathKey(workspaceRoot)}::${sorted.join("|")}`;
    }

    async function getWorkspaceFiles(workspaceRoot, scanRoots) {
        const key = workspaceCacheKey(workspaceRoot, scanRoots);
        let pending = filesCache.get(key);
        if (!pending) {
            pending = enumerateSourceFiles(workspaceRoot, { scanRoots });
            filesCache.set(key, pending);
        }
        return pending;
    }

    async function getIncludeGraph(workspaceRoot, scanRoots) {
        const key = workspaceCacheKey(workspaceRoot, scanRoots);
        let pending = graphCache.get(key);
        if (!pending) {
            pending = (async () => {
                const files = await getWorkspaceFiles(workspaceRoot, scanRoots);
                const readContent = async (p) => {
                    const doc = await openDocument(p);
                    if (!doc) return null;
                    const lines = [];
                    for (let i = 0; i < doc.lineCount; i++) lines.push(doc.lineAt(i).text);
                    return lines.join("\n");
                };
                const { reverseMap, forwardMap, actualPaths } = await buildReverseMap(files, readContent, workspaceRoot);
                return { files, reverseMap, forwardMap, actualPaths };
            })();
            graphCache.set(key, pending);
        }
        return pending;
    }

    function invalidate(filePath) {
        if (filePath === undefined) {
            cache.clear();
            filesCache.clear();
            graphCache.clear();
            return;
        }
        cache.delete(normalizePathKey(filePath));
        // A single-file change can rewire the include graph; drop the
        // workspace-scope caches rather than try to surgically patch them.
        filesCache.clear();
        graphCache.clear();
    }

    return {
        openDocument,
        getWorkspaceFiles,
        getIncludeGraph,
        invalidate
    };
}

export { createDocumentRepository };
