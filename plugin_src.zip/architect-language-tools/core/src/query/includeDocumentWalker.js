/**
 * Headless include-document walker.
 *
 * Depth-first traversal of an include graph starting from a root document.
 * The mechanism for opening an included file is injected via an `openDocument`
 * callback so that both the VS Code extension (which prefers open editor
 * documents) and headless surfaces (MCP, CLI) can share the walker.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as path from "path";
import { parseIncludeDirective } from "../lineParser.js";
import { MAX_INCLUDE_RECURSION_DEPTH } from "../includeResolver/cache.js";
import { normalizePathKey, resolveIncludePath } from "../includeResolver/graph.js";

/**
 * Walks reachable include files depth-first, calling `visitor(doc, depth)` for
 * each opened document. Returns as soon as the visitor returns a non-null/
 * non-undefined value (early exit). Handles cycles and depth limits.
 *
 * @template T
 * @param {object} params
 * @param {{ lineCount: number, lineAt: (i: number) => { text: string }, uri: { fsPath: string } }} params.rootDocument
 * @param {number} params.maxLine  — only include directives before this line are followed from the root
 * @param {string|null} params.workspaceRoot  — for path sandboxing; null = no restriction
 * @param {{ isCancellationRequested?: boolean }|null} [params.token]
 * @param {(filePath: string) => Promise<object|null>} params.openDocument  — injected file opener
 * @param {(doc: object, depth: number) => (T|null|undefined|Promise<T|null|undefined>)} params.visitor
 * @param {{ increment: (key: string, n?: number) => void }|null} [params.telemetry]
 * @returns {Promise<T|null>}
 */
async function walkIncludeDocuments({ rootDocument, maxLine, workspaceRoot, token, openDocument, visitor, telemetry = null }) {
    const visitedIncludePaths = new Set();
    const pending = [{ doc: rootDocument, maxLine, depth: 0 }];

    while (pending.length > 0) {
        if (token?.isCancellationRequested) return null;

        const current = pending.pop();
        if (current.depth >= MAX_INCLUDE_RECURSION_DEPTH) continue;

        const includes = [];
        const baseDir = path.dirname(current.doc.uri.fsPath);

        for (let lineIndex = 0; lineIndex < current.maxLine && lineIndex < current.doc.lineCount; lineIndex++) {
            const lineText = current.doc.lineAt(lineIndex).text;
            const includeFilename = parseIncludeDirective(lineText)?.filepath;
            if (!includeFilename) continue;
            const includePath = resolveIncludePath(baseDir, includeFilename, workspaceRoot);
            if (includePath) includes.push(includePath);
        }

        telemetry?.increment("includes.blocksScanned");
        telemetry?.increment("includes.candidates", includes.length);

        for (let idx = includes.length - 1; idx >= 0; idx--) {
            if (token?.isCancellationRequested) return null;

            const includePath = includes[idx];
            const normalizedIncludePath = normalizePathKey(includePath);
            if (visitedIncludePaths.has(normalizedIncludePath)) {
                telemetry?.increment("includes.skippedVisited");
                continue;
            }

            try {
                const includeDoc = await openDocument(includePath);
                if (!includeDoc) {
                    // Don't mark visited — a transient FS error here shouldn't
                    // permanently skip this include if it's reached via another
                    // path later in the walk.
                    telemetry?.increment("includes.openErrors");
                    continue;
                }
                visitedIncludePaths.add(normalizedIncludePath);
                telemetry?.increment("includes.visited");

                if (token?.isCancellationRequested) return null;

                const result = await visitor(includeDoc, current.depth + 1);
                if (result !== null && result !== undefined) return result;

                pending.push({ doc: includeDoc, maxLine: includeDoc.lineCount, depth: current.depth + 1 });
                telemetry?.increment("includes.pushed");
            } catch {
                telemetry?.increment("includes.openErrors");
            }
        }
    }

    return null;
}

export { walkIncludeDocuments };
