/**
 * Headless include-document walker.
 *
 * Depth-first traversal of an include graph starting from a root document.
 * The mechanism for opening an included file is injected via an `openDocument`
 * callback so that both the VS Code extension (which prefers open editor
 * documents) and headless surfaces (MCP, CLI) can share the walker.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import * as path from "path";
import { parseIncludeDirective } from "../lineParser.js";
import { MAX_INCLUDE_RECURSION_DEPTH } from "../includeResolver/cache.js";
import { normalizePathKey, resolveIncludePath } from "../includeResolver/graph.js";

/**
 * Walks reachable include files depth-first, calling `visitor(doc, depth)` for
 * each opened document. Handles cycles and depth limits.
 *
 * Visitor contract: return `undefined` to keep walking; return any other
 * value (including `null`, `0`, `false`) to stop the walk and surface that
 * value as the result. The previous contract leaked truthiness — a visitor
 * returning a falsy-but-defined sentinel would have continued the walk
 * unintentionally; now only `undefined` continues.
 *
 * @template T
 * @param {object} params
 * @param {{ lineCount: number, lineAt: (i: number) => { text: string }, uri: { fsPath: string } }} params.rootDocument
 * @param {number} params.maxLine  — only include directives before this line are followed from the root
 * @param {string|null} params.workspaceRoot  — for path sandboxing; null = no restriction
 * @param {{ isCancellationRequested?: boolean }|null} [params.token]
 * @param {(filePath: string) => Promise<object|null>} params.openDocument  — injected file opener
 * @param {(doc: object, depth: number) => (T|undefined|Promise<T|undefined>)} params.visitor  — return undefined to continue
 * @param {{ increment: (key: string, n?: number) => void }|null} [params.telemetry]
 * @returns {Promise<T|undefined>}
 */
async function walkIncludeDocuments({ rootDocument, maxLine, workspaceRoot, token, openDocument, visitor, telemetry = null }) {
    const visitedIncludePaths = new Set();
    const pending = [{ doc: rootDocument, maxLine, depth: 0 }];

    while (pending.length > 0) {
        if (token?.isCancellationRequested) return undefined;

        const current = pending.pop();
        if (current.depth >= MAX_INCLUDE_RECURSION_DEPTH) continue;

        const includes = [];
        const baseDir = path.dirname(current.doc.uri.fsPath);

        for (let lineIndex = 0; lineIndex < current.maxLine && lineIndex < current.doc.lineCount; lineIndex++) {
            const lineText = current.doc.lineAt(lineIndex).text;
            const includeFilename = parseIncludeDirective(lineText)?.filepath;
            if (!includeFilename) continue;
            const includePath = resolveIncludePath(baseDir, includeFilename, workspaceRoot);
            if (includePath) includes.push(includePath);
        }

        telemetry?.increment("includes.blocksScanned");
        telemetry?.increment("includes.candidates", includes.length);

        for (let idx = includes.length - 1; idx >= 0; idx--) {
            if (token?.isCancellationRequested) return undefined;

            const includePath = includes[idx];
            const normalizedIncludePath = normalizePathKey(includePath);
            if (visitedIncludePaths.has(normalizedIncludePath)) {
                telemetry?.increment("includes.skippedVisited");
                continue;
            }

            // Open errors stay swallowed (the include may resolve via another
            // path later in the walk). Visitor exceptions, by contrast, are
            // caller bugs and propagate so they aren't silently miscounted as
            // I/O failures.
            let includeDoc = null;
            try {
                includeDoc = await openDocument(includePath);
            } catch {
                telemetry?.increment("includes.openErrors");
                continue;
            }
            if (!includeDoc) {
                telemetry?.increment("includes.openErrors");
                continue;
            }
            visitedIncludePaths.add(normalizedIncludePath);
            telemetry?.increment("includes.visited");

            if (token?.isCancellationRequested) return undefined;

            const result = await visitor(includeDoc, current.depth + 1);
            if (result !== undefined) return result;

            pending.push({ doc: includeDoc, maxLine: includeDoc.lineCount, depth: current.depth + 1 });
            telemetry?.increment("includes.pushed");
        }
    }

    return undefined;
}

export { walkIncludeDocuments };
