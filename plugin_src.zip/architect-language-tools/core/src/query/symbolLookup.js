/**
 * Headless symbol-declaration lookup.
 *
 * Algorithm lifted from vscode-extension/src/definitionProvider.js, split
 * from the VS Code-specific result construction (vscode.Location, Position,
 * Range) so the same code can back the LSP, the CLI, and the MCP server.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import { parseVarDeclaration, parseFunctionDeclaration } from "../lineParser.js";
import { walkIncludeDocuments } from "./includeDocumentWalker.js";

/**
 * @typedef {Object} DeclarationHit
 * @property {string} filePath       Absolute path of the declaring file.
 * @property {number} line           0-based line index of the declaration.
 * @property {number} character      0-based column of the identifier.
 * @property {number} length         Identifier length.
 */

/**
 * Finds a variable declaration (VAR statement or function parameter) within a
 * single document. Returns null when not found.
 *
 * @param {{ lineCount: number, lineAt: (i: number) => { text: string }, uri: { fsPath: string } }} document
 * @param {string} variableName
 * @returns {DeclarationHit|null}
 */
function findVariableDeclaration(document, variableName) {
    // VAR declarations.
    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex++) {
        const lineText = document.lineAt(lineIndex).text;
        const declaration = parseVarDeclaration(lineText);
        if (declaration && declaration.variables.includes(variableName)) {
            const varIndex = lineText.indexOf(variableName);
            if (varIndex !== -1) {
                return { filePath: document.uri.fsPath, line: lineIndex, character: varIndex, length: variableName.length };
            }
        }
    }

    // Function parameters.
    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex++) {
        const lineText = document.lineAt(lineIndex).text;
        const funcDecl = parseFunctionDeclaration(lineText);
        if (!funcDecl) continue;

        for (const param of funcDecl.params) {
            if (param.name === variableName) {
                const paramIndex = lineText.indexOf(variableName);
                if (paramIndex !== -1) {
                    return { filePath: document.uri.fsPath, line: lineIndex, character: paramIndex, length: variableName.length };
                }
            }
        }
    }

    return null;
}

/**
 * Finds a function definition (case-insensitive name match) within a single
 * document. Returns null when not found.
 *
 * @param {{ lineCount: number, lineAt: (i: number) => { text: string }, uri: { fsPath: string } }} document
 * @param {string} functionName
 * @returns {DeclarationHit|null}
 */
function findFunctionDeclaration(document, functionName) {
    const upperFunctionName = functionName.toUpperCase();

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex++) {
        const lineText = document.lineAt(lineIndex).text;
        const funcDecl = parseFunctionDeclaration(lineText);
        if (!funcDecl || funcDecl.name.toUpperCase() !== upperFunctionName) continue;

        const funcIndex = lineText.toLowerCase().indexOf("function");
        if (funcIndex === -1) continue;

        const nameStart = funcIndex + "function".length;
        const nameMatch = lineText.substring(nameStart).match(/\s*([a-zA-Z_][a-zA-Z0-9_]*)/);
        if (!nameMatch) continue;

        const actualNameStart = nameStart + nameMatch.index + nameMatch[0].indexOf(nameMatch[1]);
        return { filePath: document.uri.fsPath, line: lineIndex, character: actualNameStart, length: funcDecl.name.length };
    }

    return null;
}

/**
 * Locates where a symbol is declared — current document first, then walks
 * reachable includes depth-first. Returns null when unresolved.
 *
 * @param {object} params
 * @param {{ lineCount: number, lineAt: (i: number) => { text: string }, uri: { fsPath: string } }} params.document
 *   The document the lookup starts from (usually the file the caller is in).
 * @param {string} params.symbol          Identifier to locate.
 * @param {boolean} params.isFunction     true for call sites, false for variable references.
 * @param {number} params.line            0-based line the symbol appears on (bounds include-scan).
 * @param {string|null} params.workspaceRoot
 * @param {(filePath: string) => Promise<object|null>} params.openDocument  Injected file opener.
 * @param {{ isCancellationRequested?: boolean }|null} [params.token]
 * @param {{ increment: (key: string, n?: number) => void }|null} [params.telemetry]
 * @returns {Promise<DeclarationHit|null>}
 */
async function findDeclaration({ document, symbol, isFunction, line, workspaceRoot, openDocument, token = null, telemetry = null }) {
    // Local file first.
    const local = isFunction
        ? findFunctionDeclaration(document, symbol)
        : findVariableDeclaration(document, symbol);
    if (local) return local;

    // Then reachable includes.
    return walkIncludeDocuments({
        rootDocument: document,
        maxLine: line,
        workspaceRoot,
        token,
        openDocument,
        visitor: (includeDoc) => isFunction
            ? findFunctionDeclaration(includeDoc, symbol)
            : findVariableDeclaration(includeDoc, symbol),
        telemetry
    });
}

export { findDeclaration, findVariableDeclaration, findFunctionDeclaration };
