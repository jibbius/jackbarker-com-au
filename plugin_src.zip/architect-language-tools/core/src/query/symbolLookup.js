/**
 * Headless symbol-declaration lookup.
 *
 * Algorithm lifted from vscode-extension/src/definitionProvider.js, split
 * from the VS Code-specific result construction (vscode.Location, Position,
 * Range) so the same code can back the LSP, the CLI, and the MCP server.
 *
 * No vscode imports — enforced by CLAUDE.md rule 1.
 */

import { parseVarDeclaration, parseFunctionDeclaration } from "../lineParser.js";
import { walkIncludeDocuments } from "./includeDocumentWalker.js";
import { getFunctionBlockRange } from "./referenceLookup.js";

/**
 * @typedef {Object} DeclarationHit
 * @property {string} filePath       Absolute path of the declaring file.
 * @property {number} line           0-based line index of the declaration.
 * @property {number} character      0-based column of the identifier.
 * @property {number} length         Identifier length.
 */

function findParamDeclarationIn(document, variableName, blockRange) {
    const start = blockRange ? blockRange.start : 0;
    const end = blockRange ? blockRange.end : document.lineCount - 1;
    for (let lineIndex = start; lineIndex <= end; lineIndex++) {
        const lineText = document.lineAt(lineIndex).text;
        const funcDecl = parseFunctionDeclaration(lineText);
        if (!funcDecl) continue;

        for (const param of funcDecl.params) {
            if (param.name === variableName) {
                return {
                    filePath: document.uri.fsPath,
                    line: lineIndex,
                    character: param.nameOffset,
                    length: variableName.length
                };
            }
        }
    }
    return null;
}

/**
 * Finds a variable declaration (VAR statement or function parameter) within a
 * single document. Returns null when not found.
 *
 * When `callsiteLine` is provided, an enclosing FUNCTION parameter at that
 * call site is preferred over a same-named file-scope VAR (correct shadowing
 * semantics). Without a call site, the lookup falls back to file order:
 * VAR declarations, then parameters anywhere in the file.
 *
 * @param {{ lineCount: number, lineAt: (i: number) => { text: string }, uri: { fsPath: string } }} document
 * @param {string} variableName
 * @param {number} [callsiteLine]
 * @returns {DeclarationHit|null}
 */
function findVariableDeclaration(document, variableName, callsiteLine) {
    // Scope-aware: prefer an enclosing FUNCTION parameter over a file-scope VAR.
    if (typeof callsiteLine === "number" && callsiteLine >= 0 && callsiteLine < document.lineCount) {
        const blockRange = getFunctionBlockRange(document, callsiteLine);
        if (blockRange) {
            const paramHit = findParamDeclarationIn(document, variableName, blockRange);
            if (paramHit) return paramHit;
        }
    }

    // VAR declarations.
    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex++) {
        const lineText = document.lineAt(lineIndex).text;
        const declaration = parseVarDeclaration(lineText);
        if (!declaration) continue;
        const idx = declaration.variables.indexOf(variableName);
        if (idx === -1) continue;
        return {
            filePath: document.uri.fsPath,
            line: lineIndex,
            character: declaration.variableOffsets[idx],
            length: variableName.length
        };
    }

    // Function parameters (fallback, e.g. when no call-site line was supplied).
    return findParamDeclarationIn(document, variableName, null);
}

/**
 * Finds a function definition (case-insensitive name match) within a single
 * document. Returns null when not found.
 *
 * @param {{ lineCount: number, lineAt: (i: number) => { text: string }, uri: { fsPath: string } }} document
 * @param {string} functionName
 * @returns {DeclarationHit|null}
 */
function findFunctionDeclaration(document, functionName) {
    const upperFunctionName = functionName.toUpperCase();

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex++) {
        const lineText = document.lineAt(lineIndex).text;
        const funcDecl = parseFunctionDeclaration(lineText);
        if (!funcDecl || funcDecl.upperName !== upperFunctionName) continue;

        return {
            filePath: document.uri.fsPath,
            line: lineIndex,
            character: funcDecl.nameOffset,
            length: funcDecl.name.length
        };
    }

    return null;
}

/**
 * Locates where a symbol is declared — current document first, then walks
 * reachable includes depth-first. Returns null when unresolved.
 *
 * @param {object} params
 * @param {{ lineCount: number, lineAt: (i: number) => { text: string }, uri: { fsPath: string } }} params.document
 *   The document the lookup starts from (usually the file the caller is in).
 * @param {string} params.symbol          Identifier to locate.
 * @param {boolean} params.isFunction     true for call sites, false for variable references.
 * @param {number} params.line            0-based line the symbol appears on (bounds include-scan AND
 *                                        scopes parameter lookup to its enclosing FUNCTION).
 * @param {string|null} params.workspaceRoot
 * @param {(filePath: string) => Promise<object|null>} params.openDocument  Injected file opener.
 * @param {{ isCancellationRequested?: boolean }|null} [params.token]
 * @param {{ increment: (key: string, n?: number) => void }|null} [params.telemetry]
 * @returns {Promise<DeclarationHit|null>}
 */
async function findDeclaration({ document, symbol, isFunction, line, workspaceRoot, openDocument, token = null, telemetry = null }) {
    // Local file first.
    const local = isFunction
        ? findFunctionDeclaration(document, symbol)
        : findVariableDeclaration(document, symbol, line);
    if (local) return local;

    // Then reachable includes. The walker treats `undefined` as "keep
    // walking" — coerce a null miss into undefined so the search continues
    // past include files that don't declare the symbol.
    const hit = await walkIncludeDocuments({
        rootDocument: document,
        maxLine: line,
        workspaceRoot,
        token,
        openDocument,
        visitor: (includeDoc) => {
            const found = isFunction
                ? findFunctionDeclaration(includeDoc, symbol)
                : findVariableDeclaration(includeDoc, symbol);
            return found ?? undefined;
        },
        telemetry
    });
    return hit ?? null;
}

export { findDeclaration, findVariableDeclaration, findFunctionDeclaration };
