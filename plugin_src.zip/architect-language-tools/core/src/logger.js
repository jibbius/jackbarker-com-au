/**
 * Sink-based diagnostic logger.
 *
 * Core formats the line; consumers (extension, CLI, tests) wire sinks.
 * No vscode / fs dependency at module level — keeps `core` portable.
 *
 * Default state: empty sink list, verbose off. Until `setSinks()` is
 * called, all log calls are silent. The VS Code extension wires the
 * `[Architect]` output channel sink at activation; the CLI wires
 * stdout; tests wire memory arrays.
 *
 * Verbose flag mirrors the legacy `architect.logging` setting:
 * - off (default): only ERROR-level lines reach the sinks.
 * - on:            all levels (DEBUG / LOG / WARN / ERROR) reach the sinks.
 */

let sinks = [];
let verbose = false;

const LEVEL_RANK = { DEBUG: 0, LOG: 1, WARN: 2, ERROR: 3 };

function format(level, message, data) {
    const timestamp = new Date().toISOString();
    const head = `[${timestamp}] [${level}] ${message}`;
    return data === undefined ? head : `${head} ${JSON.stringify(data)}`;
}

function emit(level, message, data) {
    if (!verbose && LEVEL_RANK[level] < LEVEL_RANK.ERROR) return;
    const line = format(level, message, data);
    for (const sink of sinks) sink(line);
}

/**
 * Replace the active sink list. Each sink is `(line: string) => void`.
 * Pass an empty array to silence the logger entirely.
 */
function setSinks(nextSinks) {
    sinks = Array.isArray(nextSinks) ? nextSinks.slice() : [];
}

/**
 * Toggle verbose mode. When false, only ERROR lines are emitted.
 */
function setVerbose(enabled) {
    verbose = !!enabled;
}

/**
 * Read the current verbose flag — used by gated emitters (e.g. telemetry)
 * that want to skip work entirely when nobody will see the output.
 */
function isVerbose() {
    return verbose;
}

const debug = (msg, data) => emit("DEBUG", msg, data);
const log   = (msg, data) => emit("LOG",   msg, data);
const warn  = (msg, data) => emit("WARN",  msg, data);
const error = (msg, data) => emit("ERROR", msg, data);

export { setSinks, setVerbose, isVerbose, debug, log, warn, error };
