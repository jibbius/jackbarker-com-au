/**
 * supplementaryLoader — manages the sibling plugin injection contract.
 *
 * A sibling plugin (companion VS Code extension or employer supplementary module)
 * may call registerSupplementary() at startup to provide additional validators
 * and builtins. This module holds those registrations and exposes them to the
 * validation pipeline in collectDiagnostics.js.
 *
 * ---
 *
 * ## Supplementary module shape
 *
 * The module's default export (or the module object itself for CJS) must be:
 *
 * ```js
 * {
 *   contractVersion?: number,
 *   validators?: Array<SupplementaryValidator>,
 *   catalogEntries?: { [messageId: string]: CatalogEntry },
 *   severityOverrides?: { [ruleId: string]: "error"|"warning"|"information"|"hint"|"off" },
 *   builtins?: {
 *     functions?:         { [UPPER_NAME: string]: FunctionEntry },
 *     globalVariables?:   { [UPPER_NAME: string]: GlobalVariableEntry },
 *     tables?:            { [TWO_CHAR_CODE: string]: { entry: TableEntry, structure: TableStructure } },
 *     help?:              { [UPPER_TOKEN: string]: string },   // token → help page filename
 *     deprecatedSymbols?: { [UPPER_OLD_NAME: string]: string } // old name → replacement name/expression
 *   }
 * }
 * ```
 *
 * ## severityOverrides
 *
 * Maps ACU-XXX-NNN messageIds to a desired severity level. Positioned at **layer 2**
 * in the resolution chain — above catalog defaults but below all project, workspace,
 * file, and line tailoring. This means any `.architect.json`, VS Code workspace setting,
 * `@mode:` annotation, or `@rule-ignore` can override the supplementary setting.
 *
 * The messageIds are translated to camelCase ruleIds at registration time (using
 * `getCatalogEntry`). Unknown messageIds are skipped with a warning. Applies only
 * to core diagnostics; supplementary validators set their own severity directly.
 *
 * ```js
 * severityOverrides: {
 *   "ACU-INT-002": "warning",   // organisation baseline: downgrade from error
 *   "ACU-TODO-001": "off"       // suppress entirely at organisation level
 * }
 * ```
 *
 * "off" suppresses the rule unless overridden by a higher-priority layer.
 * Overrides cannot restore a rule suppressed to null at the workspace/catalog layer —
 * those diagnostics are never produced in the first place.
 *
 * ## SupplementaryValidator signature
 *
 * ```js
 * function myValidator(document, context) {
 *   // document — VS Code TextDocument or PlainTextDocument
 *   // context.facts            — full documentFacts object
 *   // context.filePath         — absolute path to the file being validated
 *   // context.config           — .architect.json config object, or null
 *   // context.getRuleSeverity  — (ruleId) => number|null, resolves severity for a rule
 *   // context.createDiagnostic — (range, { messageId, params }) => diagnostic|null;
 *   //                            preferred emission path — severity is resolved through
 *   //                            the full catalog/profile/override pipeline and the
 *   //                            diagnostic participates in @rule-ignore suppression.
 *   //                            Requires the messageId to be registered via catalogEntries.
 *   return [/* diagnostic[] *\/];
 * }
 * ```
 *
 * ## Diagnostic shape
 *
 * Each supplementary validator must return an array of plain objects:
 *
 * ```js
 * {
 *   range:    { start: { line, character }, end: { line, character } },
 *   message:  string,
 *   severity: 0 | 1 | 2 | 3,   // Error=0, Warning=1, Information=2, Hint=3
 *   code:     string,            // employer rule ID — must NOT start with 'ACU-'
 *   source:   string             // recommended: 'architect-ext'
 * }
 * ```
 *
 * ## FunctionEntry shape
 *
 * Same as entries in core/src/builtins/functionsRegistry.js — see the
 * authoritative schema at builtins-data/schemas/function.schema.json:
 *
 * ```js
 * {
 *   params:      Array<{ type: ArchitectType | ArchitectType[], label?, mode?, role? }>,
 *   returns:     ArchitectType,
 *   varArgs?:    boolean,
 *   description?: string
 * }
 * ```
 *
 * ## GlobalVariableEntry shape
 *
 * ```js
 * { type: ArchitectTypes, description?: string }
 * ```
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import {
    BuiltInFunctions,
    registerSupplementaryFunction,
    unregisterSupplementaryFunction
} from "./builtins/functionsRegistry.js";
import {
    BuiltInGlobalVariables,
    registerSupplementaryGlobalVariable,
    unregisterSupplementaryGlobalVariable
} from "./builtins/globalVariablesRegistry.js";
import {
    DeprecatedHandles,
    registerSupplementaryDeprecatedHandle,
    unregisterSupplementaryDeprecatedHandle
} from "./builtins/deprecatedSymbols.js";
import { registerSupplementaryTable, unregisterSupplementaryTable } from "./builtins/tableRegistry.js";
import { registerSupplementaryHelpEntries, unregisterSupplementaryHelpEntries } from "./builtins/helpRegistry.js";
import { validateOrThrow } from "./builtins/_schemaValidator.js";
import { DIAGNOSTIC_CATALOG, getCatalogEntry, KNOWN_PROFILES } from "./diagnostics/diagnosticCatalog.js";
import { resetGlobalScope } from "./analysis/symbolTable.js";
import * as logger from "./logger.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const _SCHEMAS_DIR = path.resolve(__dirname, "..", "..", "builtins-data", "schemas");
const _functionSchema         = JSON.parse(fs.readFileSync(path.join(_SCHEMAS_DIR, "function.schema.json"),         "utf8"));
const _globalVariableSchema   = JSON.parse(fs.readFileSync(path.join(_SCHEMAS_DIR, "global-variable.schema.json"),  "utf8"));
const _tableSchema            = JSON.parse(fs.readFileSync(path.join(_SCHEMAS_DIR, "table.schema.json"),            "utf8"));
const _helpRegistrySchema     = JSON.parse(fs.readFileSync(path.join(_SCHEMAS_DIR, "help-registry.schema.json"),    "utf8"));
const _deprecatedSymbolSchema = JSON.parse(fs.readFileSync(path.join(_SCHEMAS_DIR, "deprecated-symbol.schema.json"), "utf8"));

/** @type {Array<Function>} */
const _supplementaryValidators = [];

/**
 * Supplementary severity overrides keyed by camelCase ruleId (not messageId).
 * Values are severity strings ("error"|"warning"|"information"|"hint"|"off").
 * Stored in this form so they slot directly into the getRuleSeverity resolution
 * chain at layer 2 — between catalog defaults and project/workspace tailoring.
 * @type {{ [ruleId: string]: string }}
 */
const _severityOverrides = {};

/**
 * Keys injected into BuiltInFunctions and BuiltInGlobalVariables by the current
 * supplementary registration. Tracked so clearSupplementary can reverse them.
 */
const _injectedFunctionKeys = new Set();
const _injectedGlobalVariableKeys = new Set();
const _injectedDeprecatedSymbolKeys = new Set();

/**
 * Table codes and help-entry keys mutated by `_mergeBuiltins`. Tracked so
 * `clearSupplementary` can drive the matching unregister APIs.
 */
const _injectedTableCodes = new Set();
const _injectedHelpKeys = new Set();

/**
 * MessageIds injected into DIAGNOSTIC_CATALOG by the current supplementary
 * registration. Tracked so clearSupplementary can remove them.
 */
const _injectedCatalogMessageIds = new Set();

/**
 * MessageIds for catalog entries displaced (overwritten) by a supplementary
 * registration, with their original values, so clearSupplementary can restore
 * them.
 */
const _displacedCatalogEntries = new Map();

/**
 * Cached presence flag for `_severityOverrides`. Recomputed at register/clear
 * time so the hot `getSupplementarySeverityOverrides()` path on every
 * diagnostic does not need an `Object.keys(...).length` call.
 */
let _hasSeverityOverrides = false;

/**
 * Tracks whether either of the registries fed into GlobalScope has been
 * mutated since the last reset. Used so we only call `resetGlobalScope`
 * when the snapshot is actually stale.
 */
let _globalScopeDirty = false;

const _VALID_SEVERITY_STRINGS = new Set(["error", "warning", "information", "hint", "off"]);
const _VALID_SURFACES = new Set(["ide", "cicd"]);
const _VALID_CATEGORIES = new Set(["validity", "standards", "advisory"]);

// ---------------------------------------------------------------------------
// Schema validation
// ---------------------------------------------------------------------------

/**
 * Validates the shape of a supplementary module object.
 * Throws an Error with a clear message on any violation.
 * @param {*} mod
 */
function validateSupplementaryModule(mod) {
    if (typeof mod !== "object" || mod === null || Array.isArray(mod)) {
        throw new Error("Supplementary module must export a plain object.");
    }

    if (mod.contractVersion !== undefined) {
        // Reserved field — accepted (and validated as a number) but not yet
        // consumed. Once the schema tightens in a non-backwards-compatible
        // way, the loader will key migration logic on this number so older
        // employer VSIXes have a path forward instead of throwing at load.
        if (typeof mod.contractVersion !== "number" || !Number.isFinite(mod.contractVersion)) {
            throw new Error('"contractVersion" must be a finite number.');
        }
    }

    if (mod.validators !== undefined) {
        if (!Array.isArray(mod.validators)) {
            throw new Error('"validators" must be an array.');
        }
        for (let i = 0; i < mod.validators.length; i++) {
            if (typeof mod.validators[i] !== "function") {
                throw new Error(`validators[${i}] must be a function.`);
            }
        }
    }

    if (mod.catalogEntries !== undefined) {
        if (typeof mod.catalogEntries !== "object" || mod.catalogEntries === null || Array.isArray(mod.catalogEntries)) {
            throw new Error('"catalogEntries" must be an object.');
        }
        for (const [messageId, entry] of Object.entries(mod.catalogEntries)) {
            if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
                throw new Error(`catalogEntries["${messageId}"] must be an object.`);
            }
            if (typeof entry.ruleId !== "string" || entry.ruleId.length === 0) {
                throw new Error(`catalogEntries["${messageId}"].ruleId must be a non-empty string.`);
            }
            if (typeof entry.message !== "string" || entry.message.length === 0) {
                throw new Error(`catalogEntries["${messageId}"].message must be a non-empty string.`);
            }
            if (messageId.startsWith("ACU-")) {
                throw new Error(`catalogEntries["${messageId}"]: messageIds starting with "ACU-" are reserved for the core catalog.`);
            }
            if (entry.severity === undefined || typeof entry.severity !== "object" || entry.severity === null) {
                throw new Error(`catalogEntries["${messageId}"].severity must be an object with profile keys.`);
            }
            for (const profile of KNOWN_PROFILES) {
                const sev = entry.severity[profile];
                if (sev !== undefined && !_VALID_SEVERITY_STRINGS.has(sev)) {
                    throw new Error(`catalogEntries["${messageId}"].severity.${profile} must be one of: error, warning, information, hint, off.`);
                }
            }
            if (entry.surfaces !== undefined) {
                if (!Array.isArray(entry.surfaces)) {
                    throw new Error(`catalogEntries["${messageId}"].surfaces must be an array.`);
                }
                for (const s of entry.surfaces) {
                    if (!_VALID_SURFACES.has(s)) {
                        throw new Error(`catalogEntries["${messageId}"].surfaces entry "${s}" must be one of: ide, cicd.`);
                    }
                }
            }
            if (entry.category !== undefined && !_VALID_CATEGORIES.has(entry.category)) {
                throw new Error(`catalogEntries["${messageId}"].category must be one of: validity, standards, advisory.`);
            }
            if (entry.suppressable !== undefined && typeof entry.suppressable !== "boolean") {
                throw new Error(`catalogEntries["${messageId}"].suppressable must be a boolean.`);
            }
            if (entry.paramKeys !== undefined && !Array.isArray(entry.paramKeys)) {
                throw new Error(`catalogEntries["${messageId}"].paramKeys must be an array.`);
            }
        }
    }

    if (mod.severityOverrides !== undefined) {
        if (typeof mod.severityOverrides !== "object" || mod.severityOverrides === null || Array.isArray(mod.severityOverrides)) {
            throw new Error('"severityOverrides" must be an object.');
        }
        for (const [messageId, severity] of Object.entries(mod.severityOverrides)) {
            if (!_VALID_SEVERITY_STRINGS.has(severity)) {
                throw new Error(`severityOverrides["${messageId}"] must be one of: error, warning, information, hint, off.`);
            }
            // Cross-field smoke test: a severityOverrides key must reference
            // either a core ACU- messageId or a messageId declared in this
            // module's own catalogEntries. Catches typos at load time instead
            // of degrading to a quiet "not found in catalog" warning at
            // registration. We *warn* rather than throw — catalog membership
            // is checked again at registration with full context.
            const isCoreCandidate = messageId.startsWith("ACU-");
            const isOwnCatalog = mod.catalogEntries
                && Object.prototype.hasOwnProperty.call(mod.catalogEntries, messageId);
            if (!isCoreCandidate && !isOwnCatalog) {
                logger.warn(
                    `supplementaryLoader: severityOverrides["${messageId}"] does not match an "ACU-*" core messageId nor any catalogEntries key in this module — likely a typo.`
                );
            }
        }
    }

    if (mod.builtins !== undefined) {
        if (typeof mod.builtins !== "object" || mod.builtins === null || Array.isArray(mod.builtins)) {
            throw new Error('"builtins" must be an object.');
        }

        if (mod.builtins.functions !== undefined) {
            if (
                typeof mod.builtins.functions !== "object" ||
                mod.builtins.functions === null ||
                Array.isArray(mod.builtins.functions)
            ) {
                throw new Error('"builtins.functions" must be an object.');
            }
            for (const [name, entry] of Object.entries(mod.builtins.functions)) {
                if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
                    throw new Error(`builtins.functions["${name}"] must be an object.`);
                }
                const candidate = { name: name.toUpperCase(), ...entry };
                validateOrThrow(candidate, _functionSchema, `supplementary builtins.functions["${name}"]`);
            }
        }

        if (mod.builtins.globalVariables !== undefined) {
            if (
                typeof mod.builtins.globalVariables !== "object" ||
                mod.builtins.globalVariables === null ||
                Array.isArray(mod.builtins.globalVariables)
            ) {
                throw new Error('"builtins.globalVariables" must be an object.');
            }
            for (const [name, entry] of Object.entries(mod.builtins.globalVariables)) {
                if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
                    throw new Error(`builtins.globalVariables["${name}"] must be an object.`);
                }
                const candidate = {
                    name: name.toUpperCase(),
                    type: entry.type,
                    readOnly: entry.readOnly === undefined ? false : entry.readOnly,
                    description: entry.description ?? ""
                };
                validateOrThrow(candidate, _globalVariableSchema, `supplementary builtins.globalVariables["${name}"]`);
            }
        }

        if (mod.builtins.tables !== undefined) {
            if (
                typeof mod.builtins.tables !== "object" ||
                mod.builtins.tables === null ||
                Array.isArray(mod.builtins.tables)
            ) {
                throw new Error('"builtins.tables" must be an object.');
            }
            for (const [code, reg] of Object.entries(mod.builtins.tables)) {
                if (typeof reg !== "object" || reg === null || Array.isArray(reg)) {
                    throw new Error(`builtins.tables["${code}"] must be an object.`);
                }
                if (typeof reg.entry !== "object" || reg.entry === null || Array.isArray(reg.entry)) {
                    throw new Error(`builtins.tables["${code}"].entry must be an object.`);
                }
                if (typeof reg.structure !== "object" || reg.structure === null || Array.isArray(reg.structure)) {
                    throw new Error(`builtins.tables["${code}"].structure must be an object.`);
                }
                // Re-assemble the entry+structure pair into a candidate matching
                // table.schema.json (post-Brief-10 unified shape) and validate.
                const s = reg.structure;
                const candidate = {
                    code: code.toUpperCase(),
                    name: reg.entry.name
                };
                if (s.recordLength !== undefined) candidate.recordLength = s.recordLength;
                if (s.helpPage     !== undefined) candidate.helpPage     = s.helpPage;
                if (s.indexes      !== undefined) candidate.indexes      = s.indexes;
                if (s.fields       !== undefined) candidate.fields       = s.fields;
                validateOrThrow(candidate, _tableSchema, `supplementary builtins.tables["${code}"]`);
            }
        }

        if (mod.builtins.help !== undefined) {
            validateOrThrow(mod.builtins.help, _helpRegistrySchema, "supplementary builtins.help");
        }

        if (mod.builtins.deprecatedSymbols !== undefined) {
            validateOrThrow(mod.builtins.deprecatedSymbols, _deprecatedSymbolSchema, "supplementary builtins.deprecatedSymbols");
        }
    }
}

// ---------------------------------------------------------------------------
// Builtin merging
// ---------------------------------------------------------------------------

/**
 * Merges supplementary builtins into the live core registries.
 * Call once at startup — mutates shared registry objects.
 *
 * @param {object}  builtins
 * @param {boolean} preferCore  When true, core entries win on conflict (logged as
 *                              a warning). When false (default), employer entries
 *                              overwrite core entries (logged at debug level).
 */
function _mergeBuiltins(builtins, preferCore) {
    let mutatedGlobalScope = false;

    if (builtins.functions) {
        let added = 0;
        let overwritten = 0;
        let skipped = 0;
        for (const [name, entry] of Object.entries(builtins.functions)) {
            const key = name.toUpperCase();
            const result = registerSupplementaryFunction(key, entry, preferCore);
            if (result.added)         { _injectedFunctionKeys.add(key); mutatedGlobalScope = true; added++; }
            else if (result.replaced) { _injectedFunctionKeys.add(key); mutatedGlobalScope = true; overwritten++; }
            else                       { skipped++; }
        }
        if (added > 0)       logger.log(`supplementaryLoader: merged ${added} new supplementary function(s).`);
        if (overwritten > 0) logger.log(`supplementaryLoader: overrode ${overwritten} core function(s) with employer definitions.`);
        if (skipped > 0)     logger.warn(`supplementaryLoader: kept ${skipped} core function(s) on conflict (preferCore=true).`);
    }

    if (builtins.globalVariables) {
        let added = 0;
        let overwritten = 0;
        let skipped = 0;
        for (const [name, entry] of Object.entries(builtins.globalVariables)) {
            const key = name.toUpperCase();
            const result = registerSupplementaryGlobalVariable(key, entry, preferCore);
            if (result.added)        { _injectedGlobalVariableKeys.add(key); mutatedGlobalScope = true; added++; }
            else if (result.replaced) { _injectedGlobalVariableKeys.add(key); mutatedGlobalScope = true; overwritten++; }
            else                      { skipped++; }
        }
        if (added > 0)       logger.log(`supplementaryLoader: merged ${added} new supplementary global variable(s).`);
        if (overwritten > 0) logger.log(`supplementaryLoader: overrode ${overwritten} core global variable(s) with employer definitions.`);
        if (skipped > 0)     logger.warn(`supplementaryLoader: kept ${skipped} core global variable(s) on conflict (preferCore=true).`);
    }

    if (builtins.tables) {
        let added = 0;
        let overwritten = 0;
        let skipped = 0;
        for (const [code, reg] of Object.entries(builtins.tables)) {
            const key = code.toUpperCase();
            const result = registerSupplementaryTable(key, reg.entry, reg.structure, preferCore);
            if (result.added)        { _injectedTableCodes.add(key); added++; }
            else if (result.replaced) { _injectedTableCodes.add(key); overwritten++; }
            else                      { skipped++; }
        }
        if (added > 0)       logger.log(`supplementaryLoader: merged ${added} new supplementary table(s).`);
        if (overwritten > 0) logger.log(`supplementaryLoader: overrode ${overwritten} core table(s) with employer definitions.`);
        if (skipped > 0)     logger.warn(`supplementaryLoader: kept ${skipped} core table(s) on conflict (preferCore=true).`);
    }

    if (builtins.help) {
        const result = registerSupplementaryHelpEntries(builtins.help, preferCore);
        for (const key of Object.keys(builtins.help)) {
            _injectedHelpKeys.add(key.toUpperCase());
        }
        if (result.added > 0)     logger.log(`supplementaryLoader: merged ${result.added} new supplementary help entry(ies).`);
        if (result.replaced > 0)  logger.log(`supplementaryLoader: overrode ${result.replaced} core help entry(ies) with employer definitions.`);
        if (result.skipped > 0)   logger.warn(`supplementaryLoader: kept ${result.skipped} core help entry(ies) on conflict (preferCore=true).`);
    }

    if (builtins.deprecatedSymbols) {
        let added = 0;
        let overwritten = 0;
        let skipped = 0;
        for (const [name, replacement] of Object.entries(builtins.deprecatedSymbols)) {
            const key = name.toUpperCase();
            const result = registerSupplementaryDeprecatedHandle(key, replacement, preferCore);
            if (result.added)         { _injectedDeprecatedSymbolKeys.add(key); added++; }
            else if (result.replaced) { _injectedDeprecatedSymbolKeys.add(key); overwritten++; }
            else                       { skipped++; }
        }
        if (added > 0)       logger.log(`supplementaryLoader: merged ${added} new supplementary deprecated symbol(s).`);
        if (overwritten > 0) logger.log(`supplementaryLoader: overrode ${overwritten} core deprecated symbol(s) with employer definitions.`);
        if (skipped > 0)     logger.warn(`supplementaryLoader: kept ${skipped} core deprecated symbol(s) on conflict (preferCore=true).`);
    }

    if (mutatedGlobalScope) {
        _globalScopeDirty = true;
    }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Registers a supplementary module.
 *
 * Validates the module shape and — on success — merges builtins into the live
 * registries and appends validators to the pipeline. Call once at startup.
 *
 * The default export is unwrapped automatically, so both CJS and ESM modules
 * work without the caller needing to access `.default`:
 *
 *   // VS Code companion extension (CJS):
 *   core.registerSupplementary(require('./supplementary'));
 *
 *   // CLI (ESM):
 *   const mod = await import('./supplementary/index.js');
 *   registerSupplementary(mod);
 *
 * @param {object}  mod              - The supplementary module (or its default export)
 * @param {object}  [options]
 * @param {boolean} [options.preferCore=false]
 *   When false (default), employer builtin entries overwrite core entries on conflict —
 *   the employer's registry is treated as authoritative. When true, core entries win and
 *   the conflict is logged as a warning. Set to true in tests that rely on the exact
 *   core function signatures, or when integrating a module whose entries are not yet
 *   fully validated against the production function set.
 * @throws {Error} if the module shape is invalid
 */
function registerSupplementary(mod, options = {}) {
    const preferCore = options.preferCore === true;

    // Unwrap default export so both `require()` and `import()` callers work.
    const resolved = mod && mod.default !== undefined ? mod.default : mod;

    validateSupplementaryModule(resolved);

    if (resolved.catalogEntries) {
        let added = 0;
        let overwritten = 0;
        for (const [messageId, entry] of Object.entries(resolved.catalogEntries)) {
            const conflict = Object.prototype.hasOwnProperty.call(DIAGNOSTIC_CATALOG, messageId);
            if (conflict && preferCore) {
                logger.warn(`supplementaryLoader: catalogEntries["${messageId}"] conflicts with an existing entry — keeping existing (preferCore=true).`);
                continue;
            }
            if (conflict) {
                if (!_displacedCatalogEntries.has(messageId)) {
                    _displacedCatalogEntries.set(messageId, DIAGNOSTIC_CATALOG[messageId]);
                }
                logger.warn(`supplementaryLoader: catalogEntries["${messageId}"] overrides an existing entry (preferCore=false).`);
                overwritten++;
            } else {
                _injectedCatalogMessageIds.add(messageId);
                added++;
            }
            DIAGNOSTIC_CATALOG[messageId] = entry;
        }
        if (added > 0)       logger.log(`supplementaryLoader: registered ${added} supplementary catalog entry(ies).`);
        if (overwritten > 0) logger.log(`supplementaryLoader: overrode ${overwritten} existing catalog entry(ies) with supplementary definitions.`);
    }

    if (resolved.validators && resolved.validators.length > 0) {
        _supplementaryValidators.push(...resolved.validators);
        logger.log(`supplementaryLoader: registered ${resolved.validators.length} supplementary validator(s).`);
    }

    if (resolved.severityOverrides) {
        let count = 0;
        let skipped = 0;
        for (const [messageId, severity] of Object.entries(resolved.severityOverrides)) {
            const entry = getCatalogEntry(messageId);
            if (!entry) {
                logger.warn(`supplementaryLoader: severityOverrides["${messageId}"] — messageId not found in catalog, skipped.`);
                skipped++;
                continue;
            }
            _severityOverrides[entry.ruleId] = severity;
            count++;
        }
        if (count > 0) {
            _hasSeverityOverrides = true;
            logger.log(`supplementaryLoader: registered ${count} severity override(s).`);
        }
        if (skipped > 0) logger.warn(`supplementaryLoader: skipped ${skipped} unrecognised severity override(s).`);
    }

    if (resolved.builtins) {
        _mergeBuiltins(resolved.builtins, preferCore);
    }

    // Symbol resolution snapshots BuiltInFunctions / BuiltInGlobalVariables on
    // first call to getGlobalScope(). If the host has already triggered that
    // snapshot (e.g. VS Code main extension activating before the companion),
    // the supplementary entries sit in the registries but are invisible to the
    // resolved symbol table. Reset on every successful mutating registration
    // so the next resolve rebuilds the scope from current registry contents.
    if (_globalScopeDirty) {
        resetGlobalScope();
        _globalScopeDirty = false;
    }
}

/**
 * Returns a snapshot of the currently registered supplementary validators.
 * @returns {Function[]}
 */
function getSupplementaryValidators() {
    return _supplementaryValidators.slice();
}

/**
 * Returns the registered severity overrides as a plain object mapping
 * camelCase ruleId → severity string ("error"|"warning"|"information"|"hint"|"off").
 * Returns null when no overrides have been registered.
 *
 * These overrides sit at layer 2 in the resolution chain — above catalog defaults
 * but below all project, workspace, file, and line tailoring. Callers incorporate
 * them as a fallback between catalog profile severity and any higher-priority source:
 *
 *   workspaceOverride ?? supplementaryOverrides?.[ruleId] ?? profileRules[ruleId]
 *
 * @returns {{ [ruleId: string]: string }|null}
 */
function getSupplementarySeverityOverrides() {
    if (!_hasSeverityOverrides) return null;
    // Defensive copy — caller mutation must not pollute future resolution.
    return { ..._severityOverrides };
}

/**
 * Clears all supplementary registrations: validators, severity overrides, and
 * every entry injected into the live registries (functions, globalVariables,
 * deprecated symbols, tables, help entries, catalog entries). Restores any
 * core entries that were displaced (overwritten) by a prior registration.
 *
 * Intended for use in tests — reverses every mutation made by
 * registerSupplementary, including the GlobalScope cache.
 */
function clearSupplementary() {
    _supplementaryValidators.length = 0;
    for (const key of Object.keys(_severityOverrides)) {
        delete _severityOverrides[key];
    }
    _hasSeverityOverrides = false;
    for (const key of _injectedFunctionKeys) {
        unregisterSupplementaryFunction(key);
    }
    _injectedFunctionKeys.clear();
    for (const key of _injectedGlobalVariableKeys) {
        unregisterSupplementaryGlobalVariable(key);
    }
    _injectedGlobalVariableKeys.clear();
    for (const key of _injectedDeprecatedSymbolKeys) {
        unregisterSupplementaryDeprecatedHandle(key);
    }
    _injectedDeprecatedSymbolKeys.clear();
    for (const code of _injectedTableCodes) {
        unregisterSupplementaryTable(code);
    }
    _injectedTableCodes.clear();
    if (_injectedHelpKeys.size > 0) {
        unregisterSupplementaryHelpEntries(_injectedHelpKeys);
        _injectedHelpKeys.clear();
    }
    for (const messageId of _injectedCatalogMessageIds) {
        delete DIAGNOSTIC_CATALOG[messageId];
    }
    _injectedCatalogMessageIds.clear();
    for (const [messageId, original] of _displacedCatalogEntries) {
        DIAGNOSTIC_CATALOG[messageId] = original;
    }
    _displacedCatalogEntries.clear();
    // Always reset the GlobalScope snapshot — even if this clear didn't
    // touch BuiltInFunctions/BuiltInGlobalVariables, an earlier register may
    // have. A test that clears between registrations relies on this.
    resetGlobalScope();
    _globalScopeDirty = false;
}

export { registerSupplementary, getSupplementaryValidators, getSupplementarySeverityOverrides, clearSupplementary };
