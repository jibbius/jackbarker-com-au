/**
 * Diagnostic message catalog for Architect.
 * 
 * All user-facing diagnostic messages are assigned stable IDs (ACU-DOMAIN-NNN).
 * This enables:
 * - Robust test matching (ID + params instead of substring)
 * - Future localization without code changes
 * - Per-diagnostic suppression and configuration
 * 
 * Format: ACU-<domain>-<nnn>
 * Domains: INT, KWD, TYPE, FNC, BLK, NMG, VAR, INC, SYN, IND, ARR, TODO, ARG, DIR, RQR
 *
 * Each entry carries a `category` field:
 *   "validity"  — will fail or produce wrong results at runtime
 *   "standards" — interpreter-indifferent; pure coding convention
 *   "advisory"  — likely problematic in practice but not guaranteed to error
 */

const DIAGNOSTIC_CATALOG = {
  // ============================================================================
  // ACU-INT: Interpolation validation (^variable^ syntax in output lines)
  // ============================================================================
  "ACU-INT-001": {
    ruleId: "interpolationUndefined",
    message: "Variable '{variableName}' is not defined.",
    paramKeys: ["variableName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Interpolated variables (^variable^) are resolved at output time. A name that was never declared causes a runtime error or silent empty substitution depending on the Architect version.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-INT-002": {
    ruleId: "interpolationCaseMismatch",
    message: "Variable '{variableName}' capitalisation differs from declared variable '{declaredName}'.",
    paramKeys: ["variableName", "declaredName"],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "Architect resolves interpolated variable names by exact case-sensitive comparison. A capitalisation mismatch silently produces an empty substitution at runtime instead of the intended value.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-INT-003": {
    ruleId: "interpolationUnclosed",
    message: "Unclosed string interpolation for '{variableName}'. Expected '^{variableName}^'.",
    paramKeys: ["variableName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "An unclosed interpolation delimiter causes the parser to consume the rest of the output line as part of the variable name, producing a runtime lookup failure and incorrect output.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },

  // ============================================================================
  // ACU-KWD: Keyword capitalization (IF, VAR, SET, etc. must be uppercase)
  // ============================================================================
  "ACU-KWD-001": {
    ruleId: "keywordCapitalization",
    message: "Keyword '{keyword}' should be capitalized as '{uppercase}'.",
    paramKeys: ["keyword", "uppercase"],
    surfaces: ["ide"],
    category: "standards",
    rationale: "Writing keywords in uppercase (IF, SET, VAR) distinguishes structural control flow from variable names and string values. This is universally followed in Architect codebases and makes code significantly easier to scan.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "error"
    }
  },

  // ============================================================================
  // ACU-TYPE: Type validation (type keywords and type checking)
  // ============================================================================
  "ACU-TYPE-001": {
    ruleId: "typeKeywordCapitalization",
    message: "Type keyword '{keyword}' should be capitalized as '{uppercase}'.",
    paramKeys: ["keyword", "uppercase"],
    surfaces: ["ide"],
    category: "standards",
    rationale: "Type keywords (STRING, LONG, DATE, BOOLEAN, DOUBLE) are written in uppercase by convention to distinguish them from user-defined identifiers. Mixed-case type keywords are accepted by the runtime but violate the visual contract that readers rely on.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-TYPE-002": {
    ruleId: "typeMismatch",
    message: "Type mismatch: Cannot assign {sourceType} to {targetType} variable '{target}'.",
    paramKeys: ["sourceType", "targetType", "target"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Architect is statically typed. Assigning a value of the wrong type to a variable is rejected by the runtime. The declared type of a variable determines what values it can hold.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-TYPE-003": {
    ruleId: "discouragedIntegerType",
    message: "Type 'INTEGER' is discouraged. Use 'LONG' instead.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "INTEGER is a 16-bit signed type (max 32,767) retained from early Architect. Most modern usage requires LONG (32-bit). Using INTEGER risks silent overflow on any value above 32,767, which produces wrong results with no runtime error.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "error"
    }
  },

  "ACU-TYPE-004": {
    ruleId: "notOperandTypeMismatch",
    message: "NOT requires a BOOLEAN operand, but '{operandType}' was given.",
    paramKeys: ["operandType"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "The NOT operator is a logical operator that requires a BOOLEAN expression. Applying it to a non-BOOLEAN type is a type error that causes a runtime exception.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },

  "ACU-TYPE-005": {
    ruleId: "unaryMinusTypeMismatch",
    message: "Unary minus requires a numeric operand, but '{operandType}' was given.",
    paramKeys: ["operandType"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "The unary minus operator negates a numeric value. Applying it to a non-numeric type (STRING, DATE, BOOLEAN) is a type error that causes a runtime exception.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-TYPE-006": {
    ruleId: "binaryOperatorTypeMismatch",
    message: "Operator '{op}' cannot be applied to '{leftType}' and '{rightType}'.",
    paramKeys: ["op", "leftType", "rightType"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Binary operators require operands of compatible types. Applying an arithmetic or logical operator to incompatible types (e.g. adding a STRING to a LONG) causes a runtime type error.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-TYPE-009": {
    ruleId: "binaryOperandTypeMismatch",
    message: "Operator '{op}' cannot be applied to '{leftType}' and '{rightType}'.",
    paramKeys: ["op", "leftType", "rightType"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Comparing or combining operands of incompatible types is a likely logic error. Both sides of a binary expression must resolve to types the operator supports.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "error"
    }
  },

  // ============================================================================
  // ACU-FNC: Function validation (calls, declarations, signatures)
  // ============================================================================
  "ACU-FNC-001": {
    ruleId: "functionUndefined",
    message: "Function '{functionName}' is not defined.",
    paramKeys: ["functionName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Calling a function that is not declared anywhere in the script or its includes causes a runtime error. All functions must be declared with FUNCTION...ENDFUNC before they can be called.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-FNC-002": {
    ruleId: "functionOutOfScope",
    message: "Function '{functionName}' is not yet defined at this point.",
    paramKeys: ["functionName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Architect processes function declarations as the file is read top-to-bottom. Calling a function before its FUNCTION declaration in the file can fail at runtime in single-pass compilation modes. Move the declaration above its call site, or use an INCLUDE.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-FNC-003": {
    ruleId: "functionRedeclared",
    message: "Function '{functionName}' is declared multiple times. Functions cannot be redeclared.",
    paramKeys: ["functionName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Each function name must be unique across the script and all its includes. Redeclaring a function name causes a compile-time error; Architect does not support overloading.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-FNC-004": {
    ruleId: "functionConstantUsage",
    message: "'{functionName}' is a system constant and should be used without parentheses.",
    paramKeys: ["functionName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "System constants (e.g. TRUE, FALSE, NULL, MIN_DATE) are values, not callable functions. Using them with parentheses as though they were function calls produces a runtime error.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-FNC-005": {
    ruleId: "functionCallUnclosed",
    message: "Unclosed function call for '{functionName}'.",
    paramKeys: ["functionName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "An unclosed function call causes the parser to consume subsequent tokens as arguments, producing cryptic runtime errors far from the actual problem. Every opening parenthesis must have a matching closing parenthesis.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-FNC-006": {
    ruleId: "functionSignature",
    message: "Function signature error: {errorDetail}",
    paramKeys: ["errorDetail"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "The FUNCTION declaration syntax requires parameter names with type annotations and a return type. A malformed signature causes a compile-time parse error and the function cannot be called.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-FNC-007": {
    ruleId: "functionCaseMismatch",
    message: "Function '{functionName}' capitalisation differs from declared function '{declaredName}'.",
    paramKeys: ["functionName", "declaredName"],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "Architect resolves function names by exact case comparison in some runtime configurations. A capitalisation mismatch between a call site and the function declaration can cause a runtime 'function not found' error. Consistency also aids readability.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-FNC-008": {
    ruleId: "functionReturnValueUnused",
    message: "Function '{functionName}' return value is unused. Consider assigning function return to a variable.",
    paramKeys: ["functionName"],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "Built-in functions that return a status code (e.g. INDEX_OPEN, INDEX_READ_BY_KEY) signal success or failure through that return value. Discarding it silently masks errors that would otherwise be detectable and handleable.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-FNC-009": {
    ruleId: "functionArgumentType",
    message: "Argument {n} to '{function}': expected {expectedType}, got {actualType}.",
    paramKeys: ["n", "function", "expectedType", "actualType"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Passing an argument of the wrong type to a built-in function causes a runtime type error. Architect performs type checking at call sites for functions with known signatures.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-FNC-010": {
    ruleId: "functionReturnTypeMismatch",
    message: "Return type mismatch in '{functionName}': declared return type is {expectedType}, but '{expression}' is {actualType}.",
    paramKeys: ["functionName", "expectedType", "expression", "actualType"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "The value in a RETURN statement must match the declared return type of the function. A mismatch causes a runtime type error at the call site, often far from the declaration.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-FNC-011": {
    ruleId: "functionMissingReturn",
    message: "Function '{functionName}' declares return type {returnType} but contains no RETURN statement.",
    paramKeys: ["functionName", "returnType"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "A function that declares a non-void return type but has no RETURN statement will cause a runtime error when the caller attempts to use the return value. Every code path through the function must reach a RETURN.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-FNC-012": {
    ruleId: "functionCallWhitespace",
    message: "Whitespace is not allowed between '{name}' and '('.",
    paramKeys: ["name"],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "The Architect convention requires no space between a function name and its opening parenthesis. Some runtime versions are sensitive to this and may fail to parse the call with a space present.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "error"
    }
  },

  "ACU-FNC-013": {
    ruleId: "functionBuiltinCollision",
    message: "'{functionName}' is a built-in function. User-defined functions cannot shadow built-in names. Wrap in IF NOT SYMBOL('{functionName}') ... ENDIF to define a conditional polyfill.",
    paramKeys: ["functionName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Architect does not support user-defined functions that shadow built-in names. Attempting to define one causes a compile-time error. The only exception is a conditional polyfill using IF NOT SYMBOL(), which defines the function only when the built-in is absent.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  "ACU-FNC-014": {
    ruleId: "functionDeclarationMissingParamType",
    message: "Parameter '{paramName}' in function '{functionName}' is missing a type annotation. Each parameter must be declared as 'paramName : TYPE'.",
    paramKeys: ["paramName", "functionName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Architect's function declaration syntax requires each parameter to have an explicit type annotation (e.g. 'zName : STRING'). A parameter without a type annotation causes a parse error; the function cannot be compiled.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  "ACU-FNC-015": {
    ruleId: "functionDeclarationMissingReturnType",
    message: "Function '{functionName}' is missing a return type. Add ': TYPE' after the closing parenthesis (e.g., ': STRING').",
    paramKeys: ["functionName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "All Architect functions must declare a return type after the closing parenthesis. Without it the compiler cannot type-check return values or call sites, and parsing fails in strict compilation modes.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  "ACU-FNC-016": {
    ruleId: "functionDeprecated",
    message: "'{functionName}' is a deprecated/legacy function.",
    paramKeys: ["functionName"],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "This function is marked as deprecated in the built-in registry. It may be removed in a future Architect version or may have known behavioural issues. Migrate to the recommended replacement to future-proof the script.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },

  "ACU-FNC-017": {
    ruleId: "functionDuplicateParameter",
    message: "Parameter '{paramName}' is already declared in function '{functionName}'.",
    paramKeys: ["paramName", "functionName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Each parameter in a function declaration must have a unique name. Duplicate parameter names are a compile-time error; only one would be accessible inside the function body, hiding the other.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  "ACU-FNC-018": {
    ruleId: "functionResultDiscarded",
    message: "Result of '{functionName}' is discarded. Assign the return value to a variable.",
    paramKeys: ["functionName"],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "This user-defined function returns a value that is not being captured. If the return value conveys success or failure or a computed result, discarding it silently masks errors or loses data.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "error"
    }
  },

  // ============================================================================
  // ACU-OUT:Output-formatting directives (CENTER, COL, FROM, TAB, TO) and
  //          OPTION directive output configuration (OICC, CICC)
  // ============================================================================
  "ACU-OUT-001": {
    ruleId: "outputDirectiveInCodeContext",
    message: "'{name}' is an output-positioning directive, not a function. It can only be used between OICC/CICC delimiters on output lines (e.g., >>@{name}(...)@).",
    paramKeys: ["name"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Output-positioning directives (CENTER, COL, FROM, TAB, TO) are only valid inside output line interpolation delimiters (>> @...@). Using them in executable code context is a parse error — they are not functions and cannot be called.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-OPT-001": {
    ruleId: "invalidOptionCharacter",
    message: "'{char}' is not a valid OICC/CICC character. Allowed characters are: {allowed}.",
    paramKeys: ["char", "allowed"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "The OICC/CICC directive defines the interpolation delimiter character used in output lines. Only specific characters are accepted. An invalid character causes the directive to be rejected and output interpolation to fail.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-OUT-002": {
    ruleId: "outputDirectiveArgumentCount",
    message: "'{name}' expects {expected} argument(s) but was called with {actual}.",
    paramKeys: ["name", "expected", "actual"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Output-positioning directives require a specific number of arguments. Too few or too many arguments cause a runtime error and incorrect output positioning.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-OUT-003": {
    ruleId: "outputDirectiveColumnRange",
    message: "Column value {value} is out of the valid range (1 to {max}).",
    paramKeys: ["value", "max"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Column position values must be within the valid page width range. An out-of-range column value causes unpredictable output positioning and may be silently clamped or rejected at runtime.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-OPT-003": {
    ruleId: "invalidDateformValue",
    message: "'{value}' is not a valid DATEFORM. Allowed values are: DMY, MDY, YMD.",
    paramKeys: ["value"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "DATEFORM controls how date values are formatted in report output. An invalid value is rejected by the runtime and defaults to the system date format, which may differ from the intended output.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-OPT-004": {
    ruleId: "invalidTimeformValue",
    message: "'{value}' is not a valid TIMEFORM. Allowed values are: HMSC, HMS, HM.",
    paramKeys: ["value"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "TIMEFORM controls how time values are formatted in report output. An invalid value is rejected by the runtime, causing the time format to fall back to a system default that may not match the intended format.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-OPT-005": {
    ruleId: "invalidPagewidthValue",
    message: "'{value}' is not a valid PAGEWIDTH. Must be an integer between 1 and 16000.",
    paramKeys: ["value"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "PAGEWIDTH sets the report output width. Values outside the 1–16000 range are rejected by the runtime, causing the output to fall back to the default width and potentially corrupting report column alignment.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-OPT-006": {
    ruleId: "unrecognisedOptionKeyword",
    message: "'{key}' is not a recognised OPTION setting.",
    paramKeys: ["key"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "The OPTION directive accepts only a defined set of settings. An unrecognised key is silently ignored in some runtime versions and rejected in others, making the intended configuration unreliable.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  // ============================================================================
  // ACU-DIR: Directive misclassified as output text
  //          (bare compiler-directive keyword on an implicit HASH-ON output line)
  // ============================================================================
  "ACU-DIR-001": {
    ruleId: "directiveMisclassifiedAsOutput",
    message: "'{directive}' looks like a compiler directive but is missing its '#' prefix — in HASH-ON mode this becomes literal output text. Did you mean '#{directive}'?",
    paramKeys: ["directive"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "In HASH-ON mode (the default), any line not starting with '#' is treated as output text. A line that consists solely of a compiler-directive keyword (NEWINTERPRETER, HASH-OFF, HASH-ON) is almost certainly a missing-prefix bug: the directive silently becomes printed output, the mode flip or interpreter switch the author expected never happens, and there is no other diagnostic that catches it.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "warning"
    }
  },

  // ============================================================================
  // ACU-MAC: Macro validation (declarations, invocations, parameter counts)
  // ============================================================================
  "ACU-MAC-001": {
    ruleId: "macroRedeclared",
    message: "Macro '{macroName}' is declared multiple times. Macros cannot be redeclared.",
    paramKeys: ["macroName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Macro names must be unique. Redeclaring a macro name is a compile-time error; Architect does not support macro overloading or overriding.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-MAC-002": {
    ruleId: "macroCaseMismatch",
    message: "Macro '{usedName}' capitalisation differs from declared macro '{declaredName}'.",
    paramKeys: ["usedName", "declaredName"],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "Macro names are resolved by exact case comparison. A capitalisation mismatch between a call site and the macro declaration can cause a 'macro not found' error at runtime. Consistent casing also aids readability.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-MAC-003": {
    ruleId: "macroUnexpectedParameters",
    message: "Macro '{macroName}' expects no parameters but was called with {actualCount}.",
    paramKeys: ["macroName", "actualCount"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "This macro is declared without parameters. Calling it with arguments is a syntax error — the extra arguments cannot be bound to anything and cause a runtime failure.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-MAC-004": {
    ruleId: "macroMissingParameters",
    message: "Macro '{macroName}' expects {expectedCount} parameter(s) but was called without parentheses.",
    paramKeys: ["macroName", "expectedCount"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "This macro is declared with required parameters but was called without parentheses. The runtime cannot resolve the parameters, causing the macro to execute with empty or undefined argument values.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-MAC-005": {
    ruleId: "macroParameterCountMismatch",
    message: "Macro '{macroName}' expects {expectedCount} parameter(s) but was called with {actualCount}.",
    paramKeys: ["macroName", "expectedCount", "actualCount"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "The number of arguments passed to a macro must match its declaration exactly. Architect requires a strict parameter count match — extra arguments are ignored and missing ones are empty, both producing incorrect macro expansion.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  // ============================================================================
  "ACU-BLK-001": {
    ruleId: "blockStructure",
    message: "Unexpected {closeKeyword} without matching {openKeyword}.",
    paramKeys: ["closeKeyword", "openKeyword"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Control flow blocks (IF/ENDIF, DO/ENDDO, CASE/ENDCASE) must be properly paired. An unexpected close keyword with no matching open indicates a structural imbalance that causes a compile-time error.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-BLK-002": {
    ruleId: "blockStructure",
    message: "{closeKeyword} does not match {openKeyword} at line {lineNumber}.",
    paramKeys: ["closeKeyword", "openKeyword", "lineNumber"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Each block close keyword must match its corresponding open keyword exactly (e.g. ENDIF closes IF, not DO). A mismatched pair is a structural error that causes a compile-time failure.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-BLK-003": {
    ruleId: "blockStructure",
    message: "'{openKeyword}' at line {lineNumber} is not closed with '{closeKeyword}'.",
    paramKeys: ["openKeyword", "lineNumber", "closeKeyword"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Every opened control flow block must be closed before the end of the function or file. An unclosed block causes a compile-time structural error.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-BLK-004": {
    ruleId: "blockIndentation",
    message: "'{keyword}' indentation ({column}) does not match '{openKeyword}' at line {lineNumber} (indentation {openColumn}).",
    paramKeys: ["keyword", "column", "openKeyword", "lineNumber", "openColumn"],
    surfaces: ["ide"],
    category: "standards",
    rationale: "Block delimiters are expected to align vertically with their opening keyword. Mismatched indentation makes it harder to visually identify block boundaries and often signals a copy-paste or structural alignment error.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "warning"
    }
  },
  "ACU-BLK-005": {
    ruleId: "elseIfMisuse",
    message: "'ELSE IF' is not a conditional — the IF condition is ignored and the ELSE branch always executes. Restructure with nested IF or CASE.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "In Architect, 'ELSE IF' is parsed as an ELSE branch containing an independent IF statement. The outer ELSE always executes — the IF condition inside it has no guard effect on the ELSE branch. This is a common misunderstanding from other languages. Use nested IF or CASE instead.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-BLK-006": {
    ruleId: "duplicateElse",
    message: "Duplicate ELSE branch — an IF block may only have one ELSE.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "An IF block may have at most one ELSE branch. A second ELSE is a syntax error. The second ELSE will either be rejected at compile time or will silently shadow the first.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  // ============================================================================
  // ACU-NAM: Naming conventions (prefix validation)
  // ============================================================================
  "ACU-NAM-001": {
    ruleId: "namingDatabaseFieldDeclaration",
    message: "ERROR: Declaring variables with an 'h' prefix is strongly discouraged, as variables may be confused with database fields.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "The 'h' prefix is reserved for database field handles returned by INDEX_READ. A local variable named hXxx looks identical to a field handle, misleading readers into assuming a database source where none exists.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-NAM-002": {
    ruleId: "namingPrefixScope",
    message: "Naming convention (scope): '{variableName}' has scope prefix '{actualPrefix}' ({actualScope}) but is {expectedScope}. Consider '{recommendedName}'.",
    paramKeys: ["variableName", "actualPrefix", "actualScope", "expectedScope", "recommendedName"],
    surfaces: ["ide"],
    category: "standards",
    rationale: "Scope prefixes (g for global, l for local) communicate variable lifetime at a glance. A mismatched prefix misleads readers about whether a variable is shared across functions or confined to the current scope, which is critical for understanding multi-function scripts.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "error"
    }
  },
  "ACU-NAM-003": {
    ruleId: "namingPrefixType",
    message: "Naming convention (type): '{variableName}' has type prefix suggesting {expectedType} but is declared as {actualType}. Consider '{recommendedName}'.",
    paramKeys: ["variableName", "expectedType", "actualType", "recommendedName"],
    surfaces: ["ide"],
    category: "standards",
    rationale: "Type prefixes (z for STRING, n for LONG, d for DATE, f for DOUBLE, b for BOOLEAN) allow readers to infer a variable's type without tracing its declaration. A mismatched prefix hides type-reasoning errors and can mask potential type mismatch bugs.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "error"
    }
  },

  // ============================================================================
  // ACU-VAR: Variable validation (declaration, usage, scope)
  // ============================================================================
  "ACU-VAR-001": {
    ruleId: "undefinedVariable",
    message: "{variableName} is not defined.",
    paramKeys: ["variableName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Using a variable that has not been declared with VAR will cause a runtime error. Architect requires all variables to be explicitly declared before use.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-VAR-002": {
    ruleId: "unsetVariable",
    message: "{variableName} is not set.",
    paramKeys: ["variableName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Reading a variable before assigning it a value is likely a logic error. Architect initialises variables to type-specific defaults, but relying on those defaults is fragile and often indicates a missing assignment or incorrect control flow.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "error"
    }
  },
  "ACU-VAR-003": {
    ruleId: "unclosedString",
    message: "String is unclosed.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "An unclosed string literal causes the parser to consume the rest of the line as part of the string, producing unexpected runtime behaviour. Every opening quote must have a matching closing quote on the same line.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-VAR-004": {
    ruleId: "pseudoConstantMultipleAssignment",
    message: "Pseudo-constant '{variableName}' is assigned multiple times. First assigned on line {firstLine}.",
    paramKeys: ["variableName", "firstLine"],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "Variables assigned only once behave as pseudo-constants and callers often rely on that stability. Assigning them more than once violates this implied contract and can cause logic errors in code that reads the value multiple times.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-VAR-005": {
    ruleId: "nearMissConstantName",
    message: "'{variableName}' is not defined. Did you mean '{suggestion}'?",
    paramKeys: ["variableName", "suggestion"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "A variable name that closely resembles a known built-in is likely a typo. Using the wrong name silently references an undefined variable instead of the intended constant, causing a runtime error.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-VAR-006": {
    ruleId: "readOnlyGlobalVariableAssignment",
    message: "'{variableName}' is a read-only built-in global variable and cannot be assigned.",
    paramKeys: ["variableName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Certain built-in globals (e.g. TODAY, CURRENT_USER) are managed by the runtime and cannot be changed by script code. Assigning them has no effect in some runtime versions and raises an error in others.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-VAR-007": {
    ruleId: "declaredButNeverUsedVariable",
    message: "'{variableName}' is declared but never used.",
    paramKeys: ["variableName"],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "Declaring a variable that is never read wastes memory and suggests either a logic error (wrong variable referenced elsewhere) or leftover code from a refactor that should be cleaned up.",
    severity: {
      default: "off",
      legacy: "off",
      strict: "warning"
    }
  },

  // ============================================================================
  // ACU-INC: Include resolution diagnostics
  // ============================================================================
  "ACU-INC-001": {
    ruleId: "includeCircular",
    message: "Circular include detected for '{includeFilename}'.",
    paramKeys: ["includeFilename"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "A circular include creates an infinite resolution loop. Architect detects the cycle and breaks it, but the include that would close the loop is silently omitted — meaning symbols from that file may be missing at runtime.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-INC-002": {
    ruleId: "includeFilenameCaseMismatch",
    message: "Include filename case differs from actual file '{actualFilename}' for '{includeFilename}'.",
    paramKeys: ["includeFilename", "actualFilename"],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "Include filenames are resolved case-insensitively on Windows but case-sensitively on Linux. A case mismatch that works in a Windows development environment will fail silently or with a 'file not found' error when the script runs on a Linux server.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-INC-003": {
    ruleId: "includeFileNotFound",
    message: "INCLUDE: File '{filename}' not found.",
    paramKeys: ["filename"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "An INCLUDE that references a missing file causes a runtime error. All included files must exist and be accessible at the specified path at the time the script runs. Symbols defined in the missing file will be undefined.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },

  // ============================================================================
  // ACU-SYN: Syntax and style recommendations
  // ============================================================================
  "ACU-SYN-001": {
    ruleId: "redundantHashOn",
    message: "Redundant '#HASH-ON' directive. Reports are HASH-ON by default until HASH-OFF is encountered.",
    paramKeys: [],
    surfaces: ["ide"],
    category: "standards",
    rationale: "#HASH-ON is the default output mode. Explicitly enabling it when it is already active adds noise without changing behaviour, and suggests the author may have misunderstood the default state.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "error"
    }
  },
  "ACU-SYN-002": {
    ruleId: "invalidExecutableLine",
    message: "Unexpected token or unrecognized statement in executable context. Use '//' for comments or '>>' for output text.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "In executable context, every line must begin with a recognised statement keyword or assignment. Unrecognised lines cause a parse error. Use '//' for code comments and '>>' for literal output text.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-SYN-003": {
    ruleId: "preferSlashSlashComments",
    message: "Prefer '//' comments over legacy '#NOTE' directives.",
    paramKeys: [],
    surfaces: ["ide"],
    category: "standards",
    rationale: "#NOTE is a legacy comment directive from early Architect. The '//' form is the modern equivalent, is universally recognised in the codebase, and aligns with comment syntax in C-family languages that developers are familiar with.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-SYN-004": {
    ruleId: "doIteratorMissingClause",
    message: "DO iterator '{variable}' has no TO or BY clause. Use 'DO {variable} = start TO end' or 'DO {variable} = start TO end BY step'.",
    paramKeys: ["variable"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "A DO iterator loop requires a TO clause to define the upper bound for iteration. Without it the loop has undefined termination behaviour and the variable may not be usable as expected.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-SYN-005": {
    ruleId: "doIteratorNoUpperBound",
    message: "DO {variable}: This loop runs indefinitely (no BREAK / TO / UNTIL / WHILE).",
    paramKeys: ["variable"],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "A DO loop with no TO clause, UNTIL condition, WHILE condition, or BREAK statement has no defined termination. This is almost always unintentional and will cause the script to hang until the process is killed.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-SYN-006": {
    ruleId: "incompleteAssignment",
    message: "Assignment statement is incomplete — no value on the right-hand side.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "An assignment statement with nothing on the right-hand side of '=' is a parse error. The interpreter requires a value expression after the assignment operator.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-SYN-007": {
    ruleId: "invalidContinuation",
    message: "The continuation operator '...' must appear at the end of a line, before any comment. Code cannot follow '...' on the same line.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "The '...' line continuation operator signals that the logical statement continues on the next line. Anything following it on the same physical line is silently ignored or causes a parse error.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-SYN-008": {
    ruleId: "unexpectedTokensAfterStatement",
    message: "Unexpected tokens after {keyword} statement — expected end of line.",
    paramKeys: ["keyword"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Certain statements (BREAK, CONTINUE, EXIT, bare RETURN) must be the only content on the line. Any trailing tokens are not part of those statements and constitute a parse error.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  "ACU-SYN-009": {
    ruleId: "untilMissingCondition",
    message: "'UNTIL' requires a condition expression. Unexpected end of line.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "UNTIL is a loop termination condition that requires a boolean expression to evaluate. A bare UNTIL with no expression is a parse error; the loop has no termination condition.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  "ACU-SYN-010": {
    ruleId: "keywordUsedAsVariableName",
    message: "'{name}' is a reserved keyword and cannot be used as a variable name.",
    paramKeys: ["name"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Reserved keywords (IF, ENDIF, VAR, RETURN, etc.) have fixed meaning in the Architect grammar. Using one as a variable name creates an ambiguity the parser cannot resolve, causing a compile-time error.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  "ACU-SYN-011": {
    ruleId: "breakContinueLevelExceeded",
    message: "'{keyword} {level}' exits {level} loop(s) but only {depth} are in scope.",
    paramKeys: ["keyword", "level", "depth"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "BREAK and CONTINUE accept an optional numeric level indicating how many nested loops to exit. A level greater than the current loop nesting depth references a non-existent scope and causes a runtime error.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  // ============================================================================
  // ACU-RBD: ROBODOC validation
  // ============================================================================
  "ACU-RBD-001": {
    ruleId: "robodocMissingStart",
    message: "Missing ROBODOC start marker. Expected '//@docStart*...* ...'.",
    paramKeys: [],
    surfaces: ["ide"],
    category: "standards",
    rationale: "Robodoc documentation blocks require a specific opening marker to be recognised by the documentation generator. Without it the function is omitted from generated documentation output.",
    severity: {
      default: "information",
      legacy: "off",
      strict: "warning"
    }
  },
  "ACU-RBD-002": {
    ruleId: "robodocMissingEnd",
    message: "Missing ROBODOC end marker. Expected '//@docEnd'.",
    paramKeys: [],
    surfaces: ["ide"],
    category: "standards",
    rationale: "Robodoc blocks must be closed with the end marker. Without it the documentation generator may consume subsequent code lines as documentation text, corrupting the generated output.",
    severity: {
      default: "information",
      legacy: "off",
      strict: "warning"
    }
  },
  "ACU-RBD-003": {
    ruleId: "robodocKindMismatch",
    message: "ROBODOC kind mismatch. Expected {expectedKind} tag '{expectedTag}' but found '{actualTag}'.",
    paramKeys: ["expectedKind", "expectedTag", "actualTag"],
    surfaces: ["ide"],
    category: "standards",
    rationale: "The Robodoc header tag type (function, module, etc.) must match the type of the construct being documented. A mismatch causes the documentation generator to categorise the entry incorrectly in the output.",
    severity: {
      default: "information",
      legacy: "off",
      strict: "warning"
    }
  },
  "ACU-RBD-004": {
    ruleId: "robodocTargetMismatch",
    message: "ROBODOC header target mismatch. Expected '{expectedTarget}' but found '{actualTarget}'.",
    paramKeys: ["expectedTarget", "actualTarget"],
    surfaces: ["ide"],
    category: "standards",
    rationale: "The Robodoc header target must match the name of the function or construct immediately below it. A mismatch means the documentation is attributed to the wrong entity in the generated output.",
    severity: {
      default: "information",
      legacy: "off",
      strict: "warning"
    }
  },
  "ACU-RBD-005": {
    ruleId: "robodocMissingSection",
    message: "ROBODOC section '{sectionName}' is missing from the doc block.",
    paramKeys: ["sectionName"],
    surfaces: ["ide"],
    category: "standards",
    rationale: "Robodoc requires specific sections (NAME, SYNOPSIS, INPUTS, RESULT, etc.) to produce complete documentation. A missing required section results in incomplete entries in the generated documentation.",
    severity: {
      default: "information",
      legacy: "off",
      strict: "warning"
    }
  },

  // ============================================================================
  // ACU-IND: Index-cursor usage patterns
  // ============================================================================
  "ACU-IND-001": {
    ruleId: "indexUsageMissingClose",
    message: "Index cursor operations detected without an INDEX_CLOSE call in the same scope.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "INDEX_OPEN allocates a server-side cursor that consumes resources. Failing to call INDEX_CLOSE leaks the cursor, potentially exhausting the connection pool or causing lock contention on the database.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-IND-002": {
    ruleId: "indexUsageSaveRestorePair",
    message: "INDEX_SAVE_POSITION and INDEX_RESTORE_POSITION should be used as a pair in the same scope.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "INDEX_SAVE_POSITION and INDEX_RESTORE_POSITION must be paired. Using SAVE without RESTORE leaves the cursor position unreliable for subsequent reads; using RESTORE without SAVE attempts to restore an undefined position.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-IND-003": {
    ruleId: "indexUsageSaveRestoreRecommendation",
    message: "Consider wrapping index cursor movement with INDEX_SAVE_POSITION and INDEX_RESTORE_POSITION.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "Moving the cursor position inside a read loop (e.g. a nested index operation) invalidates the outer loop's current position. Wrapping with INDEX_SAVE_POSITION and INDEX_RESTORE_POSITION preserves the outer read position across the inner operation.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-IND-004": {
    ruleId: "indexReadBeforeLoad",
    message: "INDEX_READ_BY_KEY should occur after INDEX_LOAD_KEY_* in standard flow.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "INDEX_READ_BY_KEY uses the key segments loaded by INDEX_LOAD_KEY_* to locate the record. Reading before loading leaves the key buffer empty or stale, causing the read to return wrong or no results.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-IND-005": {
    ruleId: "indexReadBeforeOpen",
    message: "INDEX_READ_BY_KEY should occur after INDEX_OPEN_* in standard flow.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "The index cursor must be opened with INDEX_OPEN_* before any read operations. Attempting to read from an cursor that has not been opened causes a runtime error.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-IND-006": {
    ruleId: "indexCloseBeforeRead",
    message: "INDEX_CLOSE should occur after cursor operations (LOAD/READ) in standard flow.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Closing the index cursor before completing all load and read operations terminates the cursor session early. Subsequent read operations against the closed cursor produce runtime errors.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-IND-007": {
    ruleId: "staleIndexHandle",
    message: "'{handle}' was passed to INDEX_CLOSE and may no longer refer to a valid index cursor.",
    paramKeys: ["handle"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Calling INDEX_CLOSE on a handle that was already closed attempts to release resources that no longer exist. This can cause a runtime error or corrupt the cursor pool state.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-IND-008": {
    ruleId: "indexRestoreWithoutSave",
    message: "INDEX_RESTORE_POSITION('{tableCode}'): no active save for this table code.",
    paramKeys: ["tableCode"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "INDEX_RESTORE_POSITION must be preceded by INDEX_SAVE_POSITION for the same table code. Restoring a position that was never saved attempts to restore an undefined cursor position, producing unpredictable read results.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-IND-009": {
    ruleId: "indexLoadKeyTypeMismatch",
    message: "Index key at position {pos} expects type {expected} but '{callName}' loads a {actual} value.",
    paramKeys: ["pos", "expected", "callName", "actual"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Index key segments have specific types defined by the table schema. Loading a value of the wrong type into a key segment produces a key that does not match the schema, causing INDEX_READ_BY_KEY to return wrong or no results.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-IND-010": {
    ruleId: "indexLoadKeyCountExceeded",
    message: "Index '{indexName}' on table '{tableCode}' has {total} key segment(s). This load exceeds that count.",
    paramKeys: ["indexName", "tableCode", "total"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Loading more key segments than the index defines is silently ignored by the runtime, but indicates a misunderstanding of the index structure — typically that the wrong index is being used, which produces incorrect query results.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-IND-011": {
    ruleId: "indexHandleOverwrite",
    message: "Assigning to '{handle}' will overwrite an active index cursor handle.",
    paramKeys: ["handle"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Assigning a new value to a variable that holds an active index cursor handle destroys the handle value. The cursor can no longer be closed with INDEX_CLOSE, permanently leaking the server-side cursor resource.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-IND-012": {
    ruleId: "indexLoadKeyStringTooLong",
    message: "Length argument {length} exceeds the maximum width of segment {pos} ('{field}', max: {maxWidth}).",
    paramKeys: ["length", "pos", "field", "maxWidth"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "The length argument to INDEX_LOAD_KEY_STRING controls how many characters are used for matching. Exceeding the field's maximum width means the key overshoots the segment definition, which may produce no match or a runtime error.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },

  // ============================================================================
  // ACU-ARR: Sorted-array usage patterns
  // ============================================================================
  "ACU-ARR-001": {
    ruleId: "arrayOpsWithoutInit",
    message: "Array record operations on '{handle}' detected without an INIT_SORTED_ARRAY call in the same scope.",
    paramKeys: ["handle"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Sorted array handles must be initialised with INIT_SORTED_ARRAY before any read or write operations. Operating on an uninitialised handle references unallocated memory and produces undefined results.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-ARR-002": {
    ruleId: "arrayInitWithoutFree",
    message: "INIT_SORTED_ARRAY called without a corresponding FREE_SORTED_ARRAY or FIN_SORTED_ARRAY.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "INIT_SORTED_ARRAY allocates memory. Failing to call FREE_SORTED_ARRAY or FIN_SORTED_ARRAY when the array is no longer needed leaks that allocation for the lifetime of the script execution.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-ARR-003": {
    ruleId: "arrayFreeBeforeOps",
    message: "Array record operation on '{handle}' after FREE_SORTED_ARRAY. Free the handle only after all operations are complete.",
    paramKeys: ["handle"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "FREE_SORTED_ARRAY releases the handle's memory allocation. Performing operations on a freed handle references deallocated memory, producing undefined behaviour or a runtime error.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-ARR-004": {
    ruleId: "getUnusedHandleOverwrite",
    message: "'{variable}' is used as both the assignment target and the argument to GET_UNUSED_ARRAY_HANDLE, overwriting the handle with the status code.",
    paramKeys: ["variable"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "GET_UNUSED_ARRAY_HANDLE returns the handle via the argument (by reference) and the status code as the function return value. Using the same variable for both overwrites the handle with the status code, making the handle irrecoverable.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-ARR-005": {
    ruleId: "consecutiveGetUnusedHandle",
    message: "GET_UNUSED_ARRAY_HANDLE called again before INIT_SORTED_ARRAY was called for the previous handle. Both calls will return the same handle value.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "GET_UNUSED_ARRAY_HANDLE marks a handle as in-use only after INIT_SORTED_ARRAY is called. Calling GET_UNUSED_ARRAY_HANDLE twice consecutively without an intervening INIT returns the same handle value both times, causing both array operations to collide.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },

  // ============================================================================
  // ACU-STY: Strict coding-style rules (active only in // @mode:strict files)
  // ============================================================================
  "ACU-STY-003": {
    ruleId: "emptyDateLiteral",
    message: "Date literal '00/00/0000' is discouraged. Use MIN_DATE instead.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "'00/00/0000' is a common placeholder for 'no date' but is not guaranteed to be handled consistently across all Architect date comparison and formatting functions. MIN_DATE is the canonical constant for the minimum valid date and is handled correctly by all date functions.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "error"
    }
  },
  "ACU-STY-004": {
    ruleId: "operatorSpacing",
    message: "Operator '{operator}' must have a single space on each side.",
    paramKeys: ["operator"],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "Consistent spacing around operators makes expressions easier to scan and prevents accidental visual ambiguity between compound tokens (e.g. 'a=-b' could be read as 'a = -b' or 'a =- b'). This rule is strict-mode only.",
    severity: {
      default: "off",
      legacy: "off",
      strict: "warning"
    }
  },
  "ACU-STY-005": {
    ruleId: "discouragedHardcodedArrayHandle",
    message: "Hard-coded integer '{handle}' used as an array handle. Obtain the handle via GET_UNUSED_ARRAY_HANDLE() instead.",
    paramKeys: ["handle"],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "Hard-coded integer array handles can collide with handles allocated by other parts of the script, causing data corruption. GET_UNUSED_ARRAY_HANDLE() allocates a handle that is guaranteed unique within the current execution context.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "warning"
    }
  },
  "ACU-STY-008": {
    ruleId: "exitTerminatorIssue",
    message: "'{keyword}' {issue}.",
    paramKeys: ["keyword", "issue"],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "EXIT and END-OF-CODE terminate script execution. Redundant terminator statements after the natural end of the script add confusion. END-OF-CODE is a legacy directive; EXIT is the preferred modern form.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "warning"
    }
  },

  // ============================================================================
  // ACU-TODO: TODO/FIXME/HACK tag tracking
  // ============================================================================
  "ACU-TODO-001": {
    ruleId: "todoItem",
    message: "TODO: {description}",
    paramKeys: ["description"],
    surfaces: ["ide"],
    category: "advisory",
    severity: {
      default: "information",
      legacy: "information",
      strict: "information"
    }
  },
  "ACU-TODO-002": {
    ruleId: "fixmeItem",
    message: "FIXME: {description}",
    paramKeys: ["description"],
    surfaces: ["ide"],
    category: "advisory",
    severity: {
      default: "information",
      legacy: "information",
      strict: "information"
    }
  },
  "ACU-TODO-003": {
    ruleId: "hackItem",
    message: "HACK: {description}",
    paramKeys: ["description"],
    surfaces: ["ide"],
    category: "advisory",
    severity: {
      default: "information",
      legacy: "information",
      strict: "information"
    }
  },

  // ============================================================================
  // ACU-ARG: Argument validation (constrained string literals and field handle identifiers)
  // ============================================================================
  "ACU-ARG-001": {
    ruleId: "invalidDateStringFormat",
    message: "Invalid date string '{value}'. Expected format DD/MM/YYYY (e.g. '31/12/2026').",
    paramKeys: ["value"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Date string literals passed to date functions must follow DD/MM/YYYY format. An incorrectly formatted string causes the function to return an error value or incorrect date, which then propagates silently through downstream comparisons.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-ARG-002": {
    ruleId: "invalidDateStringOutOfRange",
    message: "Date string '{value}' is out of the valid range (00/00/0000 to 31/12/9998).",
    paramKeys: ["value"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Architect's date handling is bounded to the range 00/00/0000 to 31/12/9998. Dates outside this range may cause runtime errors or silent wraparound depending on the function being called.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-ARG-003": {
    ruleId: "invalidCursorDirection",
    message: "Invalid cursor direction '{value}'. Valid directions: >=, >, +, =, -, <, <=.",
    paramKeys: ["value"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "INDEX_READ_BY_KEY requires a valid direction argument to determine how to navigate the index. An invalid direction string is rejected at runtime or causes unpredictable cursor movement.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-ARG-004": {
    ruleId: "invalidCursorDirection",
    message: "Invalid cursor direction '{value}'. Did you mean '{suggestion}'?",
    paramKeys: ["value", "suggestion"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "INDEX_READ_BY_KEY requires a valid direction argument. This value closely resembles a valid direction but is not an exact match — likely a typo. An invalid direction causes unpredictable cursor movement or a runtime error.",
    severity: {
      default: "error",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-ARG-005": {
    ruleId: "invalidTableSynonym",
    message: "Invalid table synonym '{value}'. Expected a valid 2-letter table code (e.g. 'MD', 'PH').",
    paramKeys: ["value"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Table synonym arguments must be valid 2-letter codes recognised by the Architect runtime. An invalid code causes the index operation to fail at runtime with no useful error message.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },
  "ACU-VAR-008": {
    ruleId: "invalidFieldHandle",
    message: "'{name}' does not match any known database field handle.",
    paramKeys: ["name"],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "Field handles reference specific database fields returned by INDEX_READ. An unrecognised handle name likely means the field does not exist in the loaded table schema, which produces empty or error values at runtime with no visible diagnostic.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },
  "ACU-VAR-009": {
    ruleId: "fieldHandleCapitalization",
    message: "Field handle '{name}' should be '{canonical}'.",
    paramKeys: ["name", "canonical"],
    surfaces: ["ide", "cicd"],
    category: "standards",
    rationale: "Field handle names are matched by exact string comparison at runtime. Using the wrong capitalisation fails to match the field, returning an empty value silently.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },

  "ACU-VAR-010": {
    ruleId: "variableNameCollidesWithCallable",
    message: "'{name}' is already declared as a {kind}. Variable names must not shadow {kind} names.",
    paramKeys: ["name", "kind"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Architect resolves names in a unified namespace. A variable sharing its name with a function or macro creates ambiguity for both the runtime and human readers, and may shadow the callable in certain evaluation contexts.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  "ACU-VAR-011": {
    ruleId: "variableDeclaresReservedName",
    message: "'{name}' is a built-in name and cannot be used as a variable. Rename this variable.",
    paramKeys: ["name"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Built-in names (system functions, globals, type keywords) are reserved by the runtime. Declaring a variable with the same name can shadow the built-in or cause a parse/runtime error depending on the Architect version.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "error"
    }
  },

  "ACU-ARG-008": {
    ruleId: "literalForVarParam",
    message: "'{paramLabel}' argument of {functionName}() requires a variable, not a literal.",
    paramKeys: ["paramLabel", "functionName"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "Some function parameters are pass-by-reference (VAR parameters) — the function writes a result back into the caller's variable. Passing a literal value has no memory address to write back to, causing a compile-time error.",
    severity: {
      default: "error",
      legacy: "error",
      strict: "error"
    }
  },

  "ACU-ARG-009": {
    ruleId: "pathSeparatorHardcoded",
    message: "Path literal in {functionName}() hardcodes '{separator}'. Use SEP_FOLDER for portability (e.g. \"a\" + SEP_FOLDER + \"b\").",
    paramKeys: ["functionName", "separator"],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "The Architect runtime exposes the global SEP_FOLDER, which expands to the platform path separator ('/' on legacy platforms, '\\' on modern). A hardcoded '/' or '\\' inside a path argument works on whichever platform matches the literal but is non-portable across deployments.",
    severity: {
      default: "information",
      legacy: "off",
      strict: "warning"
    }
  },

  // ============================================================================
  // ACU-SQL: SQL direct usage warnings
  // ============================================================================
  "ACU-SQL-001": {
    ruleId: "sqlDirectMutation",
    message: "{function} executes a {verb} statement directly, bypassing Architect core logic. Ensure audit, cascade, and business-rule implications have been reviewed.",
    paramKeys: ["function", "verb"],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "Direct SQL INSERT, UPDATE, or DELETE operations bypass the Architect core layer, which enforces business rules, cascade logic, and audit trails. Any direct mutation should be reviewed to confirm that bypassing these layers is intentional and the implications are understood.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "error"
    }
  },
  "ACU-SQL-002": {
    ruleId: "sqlDynamicString",
    message: "{function} is called with a dynamic SQL string. If this string incorporates user-supplied data, use SQL_PREPARE + SQL_SET_* to parameterise the query.",
    paramKeys: ["function"],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "Building SQL strings dynamically from user-controlled or external data creates SQL injection risk. Use SQL_PREPARE with SQL_SET_* bind parameters to separate the query structure from the data, preventing injection vulnerabilities.",
    severity: {
      default: "warning",
      legacy: "information",
      strict: "warning"
    }
  },

  // ============================================================================
  // ACU-SYM: Deprecated symbol usage (pre-h-prefix field handle aliases)
  // ============================================================================
  "ACU-SYM-001": {
    ruleId: "deprecatedSymbolUsage",
    message: "'{name}' is deprecated. Use '{replacement}' instead.",
    paramKeys: ["name", "replacement"],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "This symbol is a legacy alias that was superseded by a newer name (typically the h-prefixed field handle form). The deprecated alias may be removed in a future Architect version. Migrating to the replacement now prevents future compatibility issues.",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  },

  // ============================================================================
  // ACU-RQR: REQUIRE directive (Usercalc prerequisite calculation codes)
  // ============================================================================
  "ACU-RQR-001": {
    ruleId: "requireOutsideUsercalc",
    message: "REQUIRE is only valid inside the Usercalc reports directory (USRCALCS).",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "REQUIRE is a Usercalc-only directive. Outside the USRCALCS directory the runtime rejects it with 'Expected a line command keyword'. The check is skipped when the document path is unknown (editor scratch buffers, in-memory fixtures) to avoid false positives on documents that have no on-disk location.",
    severity: {
      default: "error",
      legacy: "off",
      strict: "error"
    }
  },
  "ACU-RQR-002": {
    ruleId: "requireUnknownCalcCode",
    message: "'{code}' is not a known Usercalc calculation code.",
    paramKeys: ["code"],
    surfaces: ["ide", "cicd"],
    category: "validity",
    rationale: "REQUIRE accepts a closed vocabulary of 21 prerequisite calculation codes (ACC, NRD, BM, FAS, etc.). A code outside that set is silently ignored or rejected by the runtime, so the prerequisite the author intended is never executed. Treating it as an error matches the validity-class convention used by peer 'unknown identifier' rules (e.g. ACU-OPT-006).",
    severity: {
      default: "error",
      legacy: "off",
      strict: "error"
    }
  },
  "ACU-RQR-003": {
    ruleId: "requireDuplicateCalcCode",
    message: "Duplicate Usercalc calculation code '{code}' on the same REQUIRE line.",
    paramKeys: ["code"],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "Listing the same prerequisite calc code twice on a REQUIRE line is redundant — the runtime executes the prerequisite once regardless. The duplicate is almost always an editing mistake (copy-paste, merge artefact). Diagnostics fire on the second and subsequent occurrences only; the first occurrence is silent.",
    severity: {
      default: "warning",
      legacy: "off",
      strict: "warning"
    }
  },
  "ACU-RQR-004": {
    ruleId: "requireEmpty",
    message: "REQUIRE has no calculation codes. Provide at least one Usercalc code.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    rationale: "A bare REQUIRE keyword with no codes is meaningless — there is no prerequisite to perform. The runtime accepts this without error but the directive has no effect, so it is almost certainly an editing accident (deleted code, stray trailing comma).",
    severity: {
      default: "warning",
      legacy: "warning",
      strict: "warning"
    }
  }
};

/**
 * Get a catalog entry by message ID.
 * @param {string} messageId - The message ID (e.g., 'ACU-INT-001')
 * @returns {Object|null} - The catalog entry or null if not found
 */
function getCatalogEntry(messageId) {
  return DIAGNOSTIC_CATALOG[messageId] || null;
}

/**
 * Check if a message ID exists in the catalog.
 * @param {string} messageId - The message ID to check
 * @returns {boolean} - True if ID exists
 */
function isValidMessageId(messageId) {
  return messageId in DIAGNOSTIC_CATALOG;
}

/**
 * Get all message IDs for a given rule ID.
 * @param {string} ruleId - The rule ID (e.g., 'keywordCapitalization')
 * @returns {string[]} - Array of message IDs that use this rule
 */
function getMessageIdsForRule(ruleId) {
  return Object.entries(DIAGNOSTIC_CATALOG)
    .filter(([_, entry]) => entry.ruleId === ruleId)
    .map(([id, _]) => id);
}

/** Profile names recognised by the catalog. */
const KNOWN_PROFILES = ["default", "legacy", "strict"];

/**
 * Get rule severities for a standards profile name.
 * Derived from per-entry severity blocks in DIAGNOSTIC_CATALOG.
 * @param {string} profileName - Profile name ("default", "legacy", "strict")
 * @returns {Object} - Rule -> severity map
 */
function getProfileRuleSeverities(profileName) {
  const result = {};
  for (const entry of Object.values(DIAGNOSTIC_CATALOG)) {
    const sev = entry.severity;
    if (!sev) continue;
    result[entry.ruleId] = sev[profileName] ?? sev.default ?? "warning";
  }
  return result;
}

/**
 * Returns true if a diagnostic's messageId is valid for the given surface.
 * If the catalog entry has no surfaces field, it is treated as visible on all surfaces.
 * @param {string} messageId - e.g. "ACU-VAR-001"
 * @param {string} surface - e.g. "cicd" or "ide"
 * @returns {boolean}
 */
function isOnSurface(messageId, surface) {
  const entry = getCatalogEntry(messageId);
  if (!entry || !entry.surfaces) return true;
  return entry.surfaces.includes(surface);
}

/**
 * Returns true if a diagnostic can be suppressed via `// @rule-ignore ACU-XXX-NNN`.
 *
 * All diagnostics are suppressable by default. Set `suppressable: false` on a catalog
 * entry to prevent suppression — reserved for errors so fundamental that silencing them
 * would mask broken code (e.g. block-structure mismatches).
 *
 * @param {string} messageId - e.g. "ACU-VAR-001"
 * @returns {boolean}
 */
function isSuppressable(messageId) {
  const entry = getCatalogEntry(messageId);
  if (!entry) return false;
  return entry.suppressable !== false;
}

export {
  DIAGNOSTIC_CATALOG,
  KNOWN_PROFILES,
  getCatalogEntry,
  isValidMessageId,
  getMessageIdsForRule,
  getProfileRuleSeverities,
  isSuppressable,
  isOnSurface
};
