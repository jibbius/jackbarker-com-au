/**
 * Canonical quick-fix metadata for diagnostics.
 *
 * `actionCount` and `kinds` are authored here. `messageId` is resolved
 * from the diagnostic catalog at module load so the two cannot drift —
 * if a ruleId stops mapping to exactly one messageId, this module
 * throws on import rather than silently lying.
 */

import { getMessageIdsForRule } from "./diagnosticCatalog.js";

const QUICK_FIX_RULES = {
    keywordCapitalization:               { actionCount: 1, kinds: ["quickfix"] },
    typeKeywordCapitalization:           { actionCount: 1, kinds: ["quickfix"] },
    interpolationUnclosed:               { actionCount: 1, kinds: ["quickfix"] },
    interpolationCaseMismatch:           { actionCount: 2, kinds: ["quickfix"] },
    functionCaseMismatch:                { actionCount: 2, kinds: ["quickfix"] },
    namingDatabaseFieldDeclaration:      { actionCount: 1, kinds: ["quickfix"] },
    namingPrefixType:                    { actionCount: 1, kinds: ["quickfix"] },
    namingPrefixScope:                   { actionCount: 1, kinds: ["quickfix"] },
    unclosedString:                      { actionCount: 1, kinds: ["quickfix"] },
    indexUsageSaveRestorePair:           { actionCount: 1, kinds: ["quickfix"] },
    indexUsageSaveRestoreRecommendation: { actionCount: 2, kinds: ["quickfix"] },
    exitTerminatorIssue:                 { actionCount: 1, kinds: ["quickfix"] },
    discouragedIntegerType:              { actionCount: 1, kinds: ["quickfix"] },
    declaredButNeverUsedVariable:        { actionCount: 1, kinds: ["quickfix"] },
    functionCallWhitespace:              { actionCount: 1, kinds: ["quickfix"] },
    pathSeparatorHardcoded:              { actionCount: 1, kinds: ["quickfix"] }
};

function buildCatalog() {
    const out = {};
    for (const [ruleId, meta] of Object.entries(QUICK_FIX_RULES)) {
        const messageIds = getMessageIdsForRule(ruleId);
        if (messageIds.length !== 1) {
            throw new Error(
                `quickFixCatalog: rule '${ruleId}' must map to exactly one messageId in DIAGNOSTIC_CATALOG (found ${messageIds.length}).`
            );
        }
        out[ruleId] = Object.freeze({ ...meta, messageId: messageIds[0] });
    }
    return Object.freeze(out);
}

const QUICK_FIX_CATALOG = buildCatalog();

function getQuickFixMetadata(ruleId) {
    return QUICK_FIX_CATALOG[ruleId] || null;
}

function getQuickFixActionCount(ruleId) {
    return getQuickFixMetadata(ruleId)?.actionCount || 0;
}

function getQuickFixMessageId(ruleId) {
    return getQuickFixMetadata(ruleId)?.messageId || null;
}

function getQuickFixCatalogEntries() {
    return Object.entries(QUICK_FIX_CATALOG).map(([ruleId, metadata]) => ({
        ruleId,
        ...metadata
    }));
}

export {
    QUICK_FIX_CATALOG,
    getQuickFixMetadata,
    getQuickFixActionCount,
    getQuickFixMessageId,
    getQuickFixCatalogEntries
};