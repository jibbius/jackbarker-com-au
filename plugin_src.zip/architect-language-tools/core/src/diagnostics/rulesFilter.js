/**
 * rulesFilter — compile and apply the `.architect.json` `rules` block.
 *
 * Schema (validated here so MCP server and CLI surface identical errors):
 *   {
 *     "rules": {
 *       "mode": "all" | "allowlist",   // default: "all"
 *       "enabled": ["ACU-IND-*", "ACU-SQL-001", ...]
 *     }
 *   }
 *
 * Glob semantics: `*` matches one or more of `[A-Z0-9-]`. Patterns are
 * anchored (full-match), so `ACU-IND` does NOT match `ACU-IND-001`. Exact
 * IDs (no wildcard) are accepted as-is — useful for tight demo scopes.
 *
 * The filter is applied at the *output boundary*: validators all run, but
 * diagnostics whose `messageId` does not match an enabled pattern are
 * dropped before the result is serialised. This is intentional — the spec
 * §6 ideas note captures why the more invasive validator-skip optimisation
 * is deferred (asymmetric failure mode).
 */

const PATTERN_RE = /^[A-Z0-9*-]+$/;

function compileRulesFilter(architectConfig) {
    const block = architectConfig?.rules;
    if (block === undefined || block === null) return null;

    if (typeof block !== "object" || Array.isArray(block)) {
        throw new Error('"rules" must be an object.');
    }

    const mode = block.mode ?? "all";
    if (mode !== "all" && mode !== "allowlist") {
        throw new Error('"rules.mode" must be "all" or "allowlist".');
    }
    if (mode === "all") return null;

    if (!Array.isArray(block.enabled)) {
        throw new Error('"rules.enabled" must be an array of glob patterns when mode is "allowlist".');
    }
    if (block.enabled.length === 0) {
        throw new Error('"rules.enabled" must be non-empty when mode is "allowlist".');
    }

    const matchers = block.enabled.map((pattern, i) => {
        if (typeof pattern !== "string" || !PATTERN_RE.test(pattern)) {
            throw new Error(
                `rules.enabled[${i}] must contain only A-Z, 0-9, '-' and '*' (got: ${JSON.stringify(pattern)}).`
            );
        }
        const regexBody = pattern.split("*").map(escapeRegex).join("[A-Z0-9-]+");
        return new RegExp(`^${regexBody}$`);
    });

    return { mode: "allowlist", matchers };
}

function escapeRegex(s) {
    return s.replace(/[.+^${}()|[\]\\]/g, "\\$&");
}

/**
 * @param {Array<{messageId?: string|null}>} diagnostics — entries with a
 *   `messageId` field (raw collectDiagnostics output uses `data.messageId`,
 *   normalised CLI/MCP output uses `messageId` or `ruleId`). Pass the
 *   accessor in via `getId` to keep this helper format-agnostic.
 */
function applyRulesFilter(diagnostics, filter, getId) {
    if (!filter) return diagnostics;
    return diagnostics.filter((d) => {
        const id = getId(d);
        if (!id) return false;
        return filter.matchers.some((m) => m.test(id));
    });
}

export { compileRulesFilter, applyRulesFilter };
