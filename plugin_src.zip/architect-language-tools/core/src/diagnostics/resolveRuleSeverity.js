/**
 * Severity-resolution chain shared by every consumer that needs to know
 * the effective severity of a rule for a given context.
 *
 * Precedence (most-specific wins):
 *   1. explicitOverride       — caller-supplied value (e.g. VS Code workspace
 *                                setting `architect.rules.<group>.<rule>.severity`).
 *   2. supplementary override — `severityOverrides` from the loaded
 *                                supplementary module (organisation baseline).
 *   3. profile rule           — the configured profile's per-rule default
 *                                (`getProfileRuleSeverities(...)`).
 *   4. "warning"              — final fallback for catalog entries with no
 *                                explicit profile severity.
 *
 * Returns one of "error" | "warning" | "information" | "info" | "hint" | "off".
 * Callers are responsible for mapping "off" to a no-emit signal and the
 * remaining strings to whatever numeric representation they use
 * (vscode.DiagnosticSeverity, the CLI's SEVERITY_NUMBER map, etc.).
 *
 * Centralising this here means a future fifth consumer cannot silently
 * skip the supplementary layer and bypass employer overrides.
 */

import { getSupplementarySeverityOverrides } from "../supplementaryLoader.js";

/**
 * @param {object} params
 * @param {string|null|undefined} [params.explicitOverride]
 *        Caller-supplied override. When defined and non-null, wins over
 *        every other layer.
 * @param {string} params.ruleId
 *        Rule identifier (e.g. `"interpolationCaseMismatch"`).
 * @param {{ [ruleId: string]: string }} [params.profileRules]
 *        The active profile's per-rule severity map. Optional.
 * @returns {string}
 */
function resolveRuleSeverity({ explicitOverride, ruleId, profileRules } = {}) {
    const supplementaryOverrides = getSupplementarySeverityOverrides();
    return explicitOverride
        ?? supplementaryOverrides?.[ruleId]
        ?? profileRules?.[ruleId]
        ?? "warning";
}

export { resolveRuleSeverity };
