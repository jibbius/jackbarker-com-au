/**
 * Discouraged literal validator for Architect.
 * Warns when the date literal 00/00/0000 is used; MIN_DATE should be used instead.
 * 00/00/0000 is supported by the runtime but is a legacy pattern that carries risk
 * of confusion and is considered non-standard in modern Architect code.
 *
 * - ACU-STY-003: Empty date literal (00/00/0000) — use MIN_DATE
 */

import { TokenType } from "../lexer/tokenTypes.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";

/**
 * Validates that discouraged date literal values are not used.
 * @param {object} document - The document to validate
 * @param {Function} getRuleSeverity
 * @param {object} [options]
 * @param {object[]} [options.tokens] - Token stream from collectDocumentFacts (required)
 * @param {object[]} [options.executionClassificationMap] - Per-line execution classification
 * @returns {object[]} - Array of diagnostics
 */
function validateDiscouragedLiterals(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const { tokens } = options;
    if (!tokens) throw new Error("validateDiscouragedLiterals: options.tokens is required (thread facts.tokens from the dispatcher)");
    const ecm = options.executionClassificationMap || null;

    for (const token of tokens) {
        if (token.type !== TokenType.DATE_LITERAL) continue;
        if (token.value !== "00/00/0000") continue;

        // Skip tokens on output lines (literal text, not executable code).
        if (ecm) {
            const cls = ecm[token.line];
            if (cls && cls.isOutput) continue;
        }

        const range = {
            start: { line: token.line, character: token.char },
            end:   { line: token.line, character: token.char + token.value.length }
        };
        const diag = createDiagnostic(
            range,
            { messageId: "ACU-STY-003", params: {} },
            getRuleSeverity
        );
        if (diag) diagnostics.push(diag);
    }

    return diagnostics;
}

export { validateDiscouragedLiterals };
