/**
 * Array lifecycle usage validator for Architect.
 *
 * Validates warning- and error-level patterns for SORTED_ARRAY function usage:
 *
 * - ACU-ARR-001: Array record operation on a handle that has no INIT_SORTED_ARRAY in the same scope.
 * - ACU-ARR-002: INIT_SORTED_ARRAY not followed by FREE_SORTED_ARRAY or FIN_SORTED_ARRAY.
 * - ACU-ARR-003: Array record operation on a handle after FREE_SORTED_ARRAY.
 * - ACU-ARR-004: GET_UNUSED_ARRAY_HANDLE result variable overwrites handle argument.
 * - ACU-ARR-005: Consecutive GET_UNUSED_ARRAY_HANDLE calls without INIT_SORTED_ARRAY between them.
 * - ACU-STY-005: Hard-coded integer literal used as an array handle argument.
 *
 * Design overview
 * ---------------
 * The validator makes two passes over the document:
 *
 * Pass 1 (AST walk): Visits every statement, parses each value-bearing expression,
 *   and inspects every CALL node. Inline diagnostics (ACU-ARR-003, ACU-ARR-004,
 *   ACU-ARR-005, ACU-STY-005) are emitted here because they depend on local
 *   context only. INIT/FREE/FIN/op records are accumulated per scope for Pass 2.
 *
 * Pass 2 (post-processing): Walks the accumulated records to emit lifecycle diagnostics
 *   (ACU-ARR-001, ACU-ARR-002) that require a complete picture of the scope.
 *
 * The AST replaces the prior maskStringLiterals + regex scan: call names that
 * appear inside string literals are now structurally unrepresentable, and
 * ACU-ARR-004's LHS check becomes "the enclosing AssignStatement.target equals
 * argVar" instead of an "anywhere on the line" regex.
 */

import { buildDocumentAst } from "../ast/documentAst.js";
import { parseExpression } from "../ast/expressionParser.js";
import { walkStatements, walkCalls } from "../ast/astHelpers.js";
import { ExprNodeType } from "../ast/expressionNodes.js";
import { NodeType } from "../ast/nodes.js";
import { getFunctionScopeAtLine } from "../analysis/functionAnalysis.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";

function createCallRange(lineIndex, matchIndex, callName) {
    return { start: { line: lineIndex, character: matchIndex }, end: { line: lineIndex, character: matchIndex + callName.length } };
}

function getScopeKey(scope) {
    return scope ? `function:${scope.id}` : "global";
}

function getScopeRecord(scopeRecords, scopeKey) {
    if (!scopeRecords.has(scopeKey)) {
        scopeRecords.set(scopeKey, {
            arrayInit: [],
            arrayFree: [],
            arrayFin: [],
            arrayOps: []
        });
    }
    return scopeRecords.get(scopeKey);
}

function registerCall(record, type, lineIndex, matchIndex, callName, handle = null) {
    record[type].push({ lineIndex, matchIndex, callName, handle });
}

/**
 * Returns the bare identifier name of a call argument, or null if the argument
 * is anything else (a literal, a complex expression, missing).
 */
function identifierArg(call, argIndex) {
    const arg = call.args?.[argIndex];
    if (!arg || arg.type !== ExprNodeType.IDENTIFIER) return null;
    return arg.name;
}

/**
 * Emits ACU-STY-005 if the indicated argument is a non-negative integer literal
 * (the same shape that the old `extractArgAt` + /^\d+$/ check matched).
 */
function checkHardcodedArrayHandle(call, callName, argIndex, getRuleSeverity, diagnostics) {
    const arg = call.args?.[argIndex];
    if (!arg || arg.type !== ExprNodeType.LITERAL) return;
    if (!/^\d+$/.test(arg.value)) return;
    const tok = call.callee?.token;
    if (!tok) return;
    const diagnostic = createDiagnostic(
        createCallRange(tok.line, tok.char, callName),
        { messageId: "ACU-STY-005", params: { handle: arg.value } },
        getRuleSeverity
    );
    if (diagnostic) diagnostics.push(diagnostic);
}

/**
 * Yields every value-bearing expression span on a statement: value, condition,
 * subject, options, iterator parts, branch values. Mirrors collectAllSpans in
 * astHelpers but inline so we can keep the parent statement bound for the
 * ACU-ARR-004 LHS check.
 */
function* statementSpans(stmt) {
    if (stmt.value)     yield stmt.value;
    if (stmt.condition) yield stmt.condition;
    if (stmt.subject)   yield stmt.subject;
    if (stmt.options)   yield stmt.options;
    if (stmt.iterator) {
        if (stmt.iterator.start) yield stmt.iterator.start;
        if (stmt.iterator.to)    yield stmt.iterator.to;
        if (stmt.iterator.by)    yield stmt.iterator.by;
    }
    if (Array.isArray(stmt.branches)) {
        for (const branch of stmt.branches) {
            if (Array.isArray(branch.values)) {
                for (const v of branch.values) if (v) yield v;
            }
        }
    }
}

/**
 * Validates array lifecycle usage patterns.
 * @param {object} document
 * @param {Function} getRuleSeverity
 * @param {object} options
 * @returns {object[]} diagnostics
 */
function validateArrayUsage(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const functionScopes = options.functionScopes || [];
    const executionClassificationMap = options.executionClassificationMap || [];

    const scopeRecords = new Map();
    // Tracks freed handles per scope — prevents false ACU-ARR-003 after the handle is legitimately re-used.
    const freedArrayHandlesByScopeKey = new Map();
    // Tracks handles obtained via GET_UNUSED_ARRAY_HANDLE but not yet INIT'd — detects double-GET (ACU-ARR-005).
    const pendingInitHandlesByScopeKey = new Map();

    function getFreedArrayHandles(scopeKey) {
        if (!freedArrayHandlesByScopeKey.has(scopeKey)) freedArrayHandlesByScopeKey.set(scopeKey, new Set());
        return freedArrayHandlesByScopeKey.get(scopeKey);
    }

    function getPendingInitHandles(scopeKey) {
        if (!pendingInitHandlesByScopeKey.has(scopeKey)) pendingInitHandlesByScopeKey.set(scopeKey, new Set());
        return pendingInitHandlesByScopeKey.get(scopeKey);
    }

    const { ast } = buildDocumentAst(document);

    // -------------------------------------------------------------------------
    // Pass 1: Walk every statement; for each call inside its expression spans,
    // dispatch on the call name and update per-scope state.
    // Inline diagnostics (ACU-ARR-003, -004, -005, ACU-STY-005) are emitted
    // here. INIT/FREE/FIN/arrayOp entries are recorded for Pass 2.
    // -------------------------------------------------------------------------
    walkStatements(ast.statements, (stmt) => {
        const lineIndex = stmt.line;
        if (lineIndex === undefined) return;
        if (executionClassificationMap[lineIndex]?.isOutput) return;

        const scope = getFunctionScopeAtLine(functionScopes, lineIndex);
        const scopeKey = getScopeKey(scope);
        const record = getScopeRecord(scopeRecords, scopeKey);

        const assignTarget = (stmt.type === NodeType.AssignStatement || stmt.type === NodeType.SetStatement)
            ? stmt.target
            : null;

        for (const span of statementSpans(stmt)) {
            const expr = parseExpression(span);
            walkCalls(expr, (call) => {
                const tok = call.callee?.token;
                if (!tok) return;
                const callName = call.callee.name?.toUpperCase();
                if (!callName) return;
                const callLine = tok.line;
                const callChar = tok.char;

                if (callName === "GET_UNUSED_ARRAY_HANDLE") {
                    const argVar = identifierArg(call, 0);
                    if (argVar) {
                        // ACU-ARR-004: enclosing assignment's LHS is the same
                        // variable as the handle argument — the call would
                        // overwrite the handle it is meant to populate.
                        if (assignTarget === argVar) {
                            const diagnostic = createDiagnostic(
                                createCallRange(callLine, callChar, callName),
                                { messageId: "ACU-ARR-004", params: { variable: argVar } },
                                getRuleSeverity
                            );
                            if (diagnostic) diagnostics.push(diagnostic);
                        }
                        // ACU-ARR-005: a previous GET_UNUSED_ARRAY_HANDLE in
                        // this scope has not yet been INIT'd.
                        const pending = getPendingInitHandles(scopeKey);
                        if (pending.size > 0) {
                            const diagnostic = createDiagnostic(
                                createCallRange(callLine, callChar, callName),
                                { messageId: "ACU-ARR-005", params: {} },
                                getRuleSeverity
                            );
                            if (diagnostic) diagnostics.push(diagnostic);
                        }
                        pending.add(argVar);
                    }
                } else if (callName === "INIT_SORTED_ARRAY") {
                    const initHandle = identifierArg(call, 0);
                    registerCall(record, "arrayInit", callLine, callChar, callName, initHandle);
                    checkHardcodedArrayHandle(call, callName, 0, getRuleSeverity, diagnostics);
                    if (initHandle) getPendingInitHandles(scopeKey).delete(initHandle);
                } else if (callName === "INITIALISE_ARRAY") {
                    checkHardcodedArrayHandle(call, callName, 0, getRuleSeverity, diagnostics);
                } else if (callName === "FREE_SORTED_ARRAY") {
                    const freeHandle = identifierArg(call, 0);
                    if (freeHandle) {
                        getFreedArrayHandles(scopeKey).add(freeHandle);
                        getPendingInitHandles(scopeKey).delete(freeHandle);
                    }
                    registerCall(record, "arrayFree", callLine, callChar, callName, freeHandle);
                    checkHardcodedArrayHandle(call, callName, 0, getRuleSeverity, diagnostics);
                } else if (callName === "FIN_SORTED_ARRAY") {
                    registerCall(record, "arrayFin", callLine, callChar, callName);
                    getPendingInitHandles(scopeKey).clear();
                } else if (
                    callName === "ADD_ARRAY_REC" ||
                    callName === "READ_ARRAY_REC" ||
                    callName.endsWith("_SAY")
                ) {
                    const handleArgIndex = callName === "READ_ARRAY_REC" ? 1 : 0;
                    const opHandle = identifierArg(call, handleArgIndex);
                    registerCall(record, "arrayOps", callLine, callChar, callName, opHandle);
                    if (opHandle && getFreedArrayHandles(scopeKey).has(opHandle)) {
                        const diagnostic = createDiagnostic(
                            createCallRange(callLine, callChar, callName),
                            { messageId: "ACU-ARR-003", params: { handle: opHandle } },
                            getRuleSeverity
                        );
                        if (diagnostic) diagnostics.push(diagnostic);
                    }
                    if (callName === "ADD_ARRAY_REC" || callName === "READ_ARRAY_REC") {
                        checkHardcodedArrayHandle(call, callName, handleArgIndex, getRuleSeverity, diagnostics);
                    }
                }
            });
        }
    });

    function emitDiagnostic(messageId, source, params = {}) {
        const diagnostic = createDiagnostic(
            createCallRange(source.lineIndex, source.matchIndex, source.callName),
            { messageId, params },
            getRuleSeverity
        );
        if (diagnostic) diagnostics.push(diagnostic);
    }

    // -------------------------------------------------------------------------
    // Pass 2: Lifecycle completeness checks across the collected scope records
    // ACU-ARR-001 and ACU-ARR-002 require a complete view of each scope.
    // -------------------------------------------------------------------------
    for (const record of scopeRecords.values()) {
        // ACU-ARR-001: Per-handle — fire once per handle that has ops but no INIT in this scope
        const initializedHandles = new Set(record.arrayInit.map(i => i.handle).filter(Boolean));
        const reportedHandles = new Set();
        for (const op of record.arrayOps) {
            if (!op.handle) continue;
            if (initializedHandles.has(op.handle)) continue;
            if (reportedHandles.has(op.handle)) continue;
            emitDiagnostic("ACU-ARR-001", op, { handle: op.handle });
            reportedHandles.add(op.handle);
        }

        // ACU-ARR-002: INIT_SORTED_ARRAY not covered by a FREE or FIN
        for (const init of record.arrayInit) {
            const initHandle = init.handle || "";
            const hasSubsequentFree = record.arrayFree.some(free => {
                if (free.lineIndex <= init.lineIndex) return false;
                // If either handle could not be extracted, treat it as a wildcard to avoid false positives.
                if (!initHandle) return true;
                return !free.handle || free.handle === initHandle;
            });
            // FIN_SORTED_ARRAY takes no arguments and finalizes all arrays — any subsequent FIN covers any INIT.
            const hasSubsequentFin = record.arrayFin.some(fin => fin.lineIndex > init.lineIndex);
            if (!hasSubsequentFree && !hasSubsequentFin) {
                emitDiagnostic("ACU-ARR-002", init);
            }
        }

        // ACU-ARR-003 is handled sequentially above (op-after-free per handle).
    }

    return diagnostics;
}

export { validateArrayUsage };
