/**
 * String interpolation validator for Architect.
 * Validates variables used in output statements with ^variable^ syntax.
 */

import { isDatabaseHandle } from "../constants.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";
import { getInterpolationTargetsForLine } from "../analysis/executionContext.js";
import { DeprecatedHandles } from "../builtins/deprecatedSymbols.js";

/** Symbol kinds treated as user variables for interpolation checks. */
const VARIABLE_KINDS = new Set(['variable', 'param']);

/**
 * Validates string interpolation in output statements.
 * @param {vscode.TextDocument} document - The document to validate
 * @param {Function} getRuleSeverity - Severity resolver
 * @param {Object} [options={}] - Optional precomputed execution context
 * @param {object} [options.symbolTable] - Symbol table from facts.symbolTable
 * @param {Array} options.executionClassificationMap - Precomputed execution classification by line index.
 * **Required** — without it the validator cannot identify output lines and returns an empty array.
 * @param {Array<Array<{variableName:string, startPos:number, endPos:number, hasClosing:boolean, isFunctionLike:boolean}>>} [options.interpolationTargetsByLine]
 * Precomputed interpolation targets by line index
 * @returns {vscode.Diagnostic[]} - Array of interpolation diagnostics
 */
function validateStringInterpolation(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const symbolTable = options.symbolTable || null;
    const executionClassificationMap = options.executionClassificationMap || null;

    // Without the classification map we cannot identify output lines — nothing to validate.
    if (!executionClassificationMap) {
        return diagnostics;
    }
    const outputDelimiters = options.outputDelimiters || { oicc: "@", cicc: "@" };
    const includedVariablesByLine = options.includedVariablesByLine || null;

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex += 1) {
        const lineText = document.lineAt(lineIndex).text;

        // Interpolation checks only apply in output text lines.
        if (!executionClassificationMap[lineIndex].isOutput) {
            continue;
        }

        const interpolationTargets = options.interpolationTargetsByLine?.[lineIndex]
            || getInterpolationTargetsForLine(lineText, outputDelimiters);

        for (const target of interpolationTargets) {
            const { variableName, startPos, endPos, hasClosing, isFunctionLike } = target;

            // Skip if this looks like a function call rather than variable interpolation.
            if (isFunctionLike) {
                continue;
            }

            // Resolve through the symbol table (scope-aware, case-insensitive resolve).
            const sym = symbolTable ? symbolTable.resolve(variableName, lineIndex) : null;
            const isKnownVar = sym !== null && VARIABLE_KINDS.has(sym.kind);

            // Case mismatch via symbol table: found but declared name differs.
            if (isKnownVar && sym.declaredName !== variableName) {
                const diag = createDiagnostic(
                    { start: { line: lineIndex, character: startPos }, end: { line: lineIndex, character: endPos } },
                    { messageId: "ACU-INT-002", params: { variableName, declaredName: sym.declaredName } },
                    getRuleSeverity
                );
                if (diag) diagnostics.push(diag);
                continue;
            }

            // Variable is correctly declared (exact case) or is a database handle — check unclosed.
            if (isKnownVar || isDatabaseHandle(variableName)) {
                if (!hasClosing) {
                    const diag = createDiagnostic(
                        { start: { line: lineIndex, character: startPos }, end: { line: lineIndex, character: endPos } },
                        { messageId: "ACU-INT-003", params: { variableName } },
                        getRuleSeverity
                    );
                    if (diag) diagnostics.push(diag);
                }
                continue;
            }

            // Deprecated field handle alias — emit ACU-SYM-001 instead of ACU-INT-001.
            const deprecatedReplacement = DeprecatedHandles[variableName.toUpperCase()];
            if (deprecatedReplacement !== undefined) {
                const diag = createDiagnostic(
                    { start: { line: lineIndex, character: startPos }, end: { line: lineIndex, character: endPos } },
                    { messageId: "ACU-SYM-001", params: { name: variableName, replacement: deprecatedReplacement } },
                    getRuleSeverity
                );
                if (diag) diagnostics.push(diag);
                if (!hasClosing) {
                    const unclosedDiag = createDiagnostic(
                        { start: { line: lineIndex, character: startPos }, end: { line: lineIndex, character: endPos } },
                        { messageId: "ACU-INT-003", params: { variableName } },
                        getRuleSeverity
                    );
                    if (unclosedDiag) diagnostics.push(unclosedDiag);
                }
                continue;
            }

            // Not in symbol table — check included files.
            const includedVars = includedVariablesByLine?.get(lineIndex);
            if (includedVars?.has(variableName)) {
                // Found in includes (exact case) — check unclosed.
                if (!hasClosing) {
                    const diag = createDiagnostic(
                        { start: { line: lineIndex, character: startPos }, end: { line: lineIndex, character: endPos } },
                        { messageId: "ACU-INT-003", params: { variableName } },
                        getRuleSeverity
                    );
                    if (diag) diagnostics.push(diag);
                }
                continue;
            }

            // Check case-insensitive match in included files.
            if (includedVars) {
                const lower = variableName.toLowerCase();
                let caseMatch = null;
                for (const name of includedVars.keys()) {
                    if (name.toLowerCase() === lower) { caseMatch = name; break; }
                }
                if (caseMatch) {
                    const diag = createDiagnostic(
                        { start: { line: lineIndex, character: startPos }, end: { line: lineIndex, character: endPos } },
                        { messageId: "ACU-INT-002", params: { variableName, declaredName: caseMatch } },
                        getRuleSeverity
                    );
                    if (diag) diagnostics.push(diag);
                    continue;
                }
            }

            // Truly unknown — emit undefined interpolation diagnostic.
            const diag = createDiagnostic(
                { start: { line: lineIndex, character: startPos }, end: { line: lineIndex, character: endPos } },
                { messageId: "ACU-INT-001", params: { variableName } },
                getRuleSeverity
            );
            if (diag) diagnostics.push(diag);
        }
    }

    return diagnostics;
}

export {
    validateStringInterpolation
};
