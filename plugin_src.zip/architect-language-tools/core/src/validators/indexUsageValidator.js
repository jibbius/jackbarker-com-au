/**
 * Index lifecycle usage validator for Architect.
 *
 * Validates warning- and error-level patterns for INDEX function usage:
 *
 * - ACU-IND-001: INDEX cursor operations without an INDEX_CLOSE in scope.
 * - ACU-IND-002: INDEX_SAVE_POSITION and INDEX_RESTORE_POSITION used without a matching pair.
 * - ACU-IND-003: Cursor movement (LOAD/READ) without any SAVE/RESTORE.
 * - ACU-IND-004: INDEX_READ_BY_KEY before INDEX_LOAD_KEY_*.
 * - ACU-IND-005: INDEX_READ_BY_KEY before INDEX_OPEN_*.
 * - ACU-IND-006: INDEX_CLOSE before READ/LOAD operations.
 * - ACU-IND-007: Use of a handle variable after INDEX_CLOSE (stale handle).
 * - ACU-IND-008: INDEX_RESTORE_POSITION for a table code with no active save.
 * - ACU-IND-009: INDEX_LOAD_KEY_* type mismatch against the index segment definition.
 * - ACU-IND-010: INDEX_LOAD_KEY_* call count exceeds the segments in the index.
 *
 * The AST replaces the prior maskStringLiterals + regex scan: call names that
 * appear inside string literals are now structurally unrepresentable, and
 * ACU-IND-011's LHS variable is read from the AssignStatement's `targetToken`
 * rather than re-found by a per-line regex.
 */

import { parseExpression } from "../ast/expressionParser.js";
import { walkStatements, walkCalls } from "../ast/astHelpers.js";
import { ExprNodeType } from "../ast/expressionNodes.js";
import { NodeType } from "../ast/nodes.js";
import { ArchitectTypes } from "../types/architectTypes.js";
import { getFunctionScopeAtLine } from "../analysis/functionAnalysis.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";

// Index functions that take a handle at argument position 0.
// A stale handle (post-CLOSE) passed to any of these emits ACU-IND-007.
const INDEX_HANDLE_ARG0_FUNCTIONS = new Set([
    "INDEX_READ_BY_KEY",
    "INDEX_LOAD_KEY_STRING",
    "INDEX_LOAD_KEY_LONG",
    "INDEX_LOAD_KEY_SHORT",
    "INDEX_LOAD_KEY_DATE",
    "INDEX_CLEAR_KEY",
    "SQL_INDEX_READ_BY_KEY",
    "SQL_INDEX_LOAD_KEY_STRING",
    "SQL_INDEX_LOAD_KEY_LONG",
    "SQL_INDEX_LOAD_KEY_SHORT",
    "SQL_INDEX_LOAD_KEY_DATE",
    "SQL_INDEX_CLEAR_KEY"
]);

// Predicates that match either the INDEX_* or SQL_INDEX_* form of each operation.
function isIndexOpen(n)    { return n.startsWith("INDEX_OPEN_") || n === "SQL_INDEX_OPEN_STANDARD"; }
function isIndexLoadKey(n) { return n.startsWith("INDEX_LOAD_KEY_") || n.startsWith("SQL_INDEX_LOAD_KEY_"); }
function isIndexReadByKey(n) { return n === "INDEX_READ_BY_KEY" || n === "SQL_INDEX_READ_BY_KEY"; }
function isIndexClose(n)   { return n === "INDEX_CLOSE" || n === "SQL_INDEX_CLOSE"; }
function isIndexClearKey(n){ return n === "INDEX_CLEAR_KEY" || n === "SQL_INDEX_CLEAR_KEY"; }

/** Returns the load-key type suffix (e.g. "STRING", "LONG") from any load-key call name. */
function getLoadKeySuffix(callName) {
    if (callName.startsWith("SQL_INDEX_LOAD_KEY_")) return callName.slice("SQL_INDEX_LOAD_KEY_".length);
    return callName.slice("INDEX_LOAD_KEY_".length);
}

function createCallRange(lineIndex, matchIndex, callName) {
    return { start: { line: lineIndex, character: matchIndex }, end: { line: lineIndex, character: matchIndex + callName.length } };
}

function getScopeKey(scope) {
    return scope ? `function:${scope.id}` : "global";
}

function getScopeRecord(scopeRecords, scopeKey) {
    if (!scopeRecords.has(scopeKey)) {
        scopeRecords.set(scopeKey, {
            open: [],
            load: [],
            read: [],
            close: [],
            save: [],
            restore: []
        });
    }
    return scopeRecords.get(scopeKey);
}

function registerCall(record, type, lineIndex, matchIndex, callName, handleVar) {
    record[type].push({ lineIndex, matchIndex, callName, handleVar: handleVar || null });
}

// ---------------------------------------------------------------------------
// Argument inspection helpers
// ---------------------------------------------------------------------------

/** Returns the bare identifier name of a call argument, or null. */
function identifierArg(call, idx) {
    const arg = call.args?.[idx];
    if (!arg || arg.type !== ExprNodeType.IDENTIFIER) return null;
    return arg.name;
}

/**
 * Returns the unquoted content of a STRING-literal argument, or null when the
 * argument is not a bare string literal (variable, expression, missing).
 */
function stringLiteralArg(call, idx) {
    const arg = call.args?.[idx];
    if (!arg || arg.type !== ExprNodeType.LITERAL || arg.inferredType !== ArchitectTypes.STRING) return null;
    const raw = arg.value;
    // Lexer captures STRING_LITERAL tokens with the surrounding quotes.
    if (raw.length < 2) return null;
    const q = raw[0];
    if ((q === "\"" || q === "'") && raw[raw.length - 1] === q) return raw.slice(1, -1);
    return null;
}

/** Returns the integer value of a non-negative integer-literal argument, or null. */
function intLiteralArg(call, idx) {
    const arg = call.args?.[idx];
    if (!arg || arg.type !== ExprNodeType.LITERAL) return null;
    if (!/^\d+$/.test(arg.value)) return null;
    return parseInt(arg.value, 10);
}

/**
 * Returns the index-name argument as a plain string. Index names in the
 * registry can be quoted ("PK") or numeric ("0"); fixtures call them as a
 * bare numeric literal (`0`) or string literal. The prior regex extractor
 * forwarded the raw token text via `String(extractArgAt(...).trim())`, so
 * for `0` that produced "0". We replicate that by reading the source token
 * text directly — preserves whatever quoting the call site used, so the
 * comparison against `index.name` matches the registry.
 */
function indexNameArg(call, idx) {
    const arg = call.args?.[idx];
    if (!arg) return null;
    return arg.token?.value ?? null;
}

/**
 * Yields every value-bearing expression span on a statement: value, condition,
 * subject, options, iterator parts, branch values.
 */
function* statementSpans(stmt) {
    if (stmt.value)     yield stmt.value;
    if (stmt.condition) yield stmt.condition;
    if (stmt.subject)   yield stmt.subject;
    if (stmt.options)   yield stmt.options;
    if (stmt.iterator) {
        if (stmt.iterator.start) yield stmt.iterator.start;
        if (stmt.iterator.to)    yield stmt.iterator.to;
        if (stmt.iterator.by)    yield stmt.iterator.by;
    }
    if (Array.isArray(stmt.branches)) {
        for (const branch of stmt.branches) {
            if (Array.isArray(branch.values)) {
                for (const v of branch.values) if (v) yield v;
            }
        }
    }
}

// Maps INDEX_LOAD_KEY_* and SQL_INDEX_LOAD_KEY_* call names to the segment types they satisfy.
const LOAD_KEY_ACCEPTED_TYPES = {
    "INDEX_LOAD_KEY_STRING":     new Set(["STRING", "ZSTRING"]),
    "INDEX_LOAD_KEY_SHORT":      new Set(["SHORT"]),
    "INDEX_LOAD_KEY_LONG":       new Set(["LONG"]),
    "INDEX_LOAD_KEY_DATE":       new Set(["DATE"]),
    "SQL_INDEX_LOAD_KEY_STRING": new Set(["STRING", "ZSTRING"]),
    "SQL_INDEX_LOAD_KEY_SHORT":  new Set(["SHORT"]),
    "SQL_INDEX_LOAD_KEY_LONG":   new Set(["LONG"]),
    "SQL_INDEX_LOAD_KEY_DATE":   new Set(["DATE"])
};

/**
 * Validates index lifecycle usage patterns.
 * @param {object} document
 * @param {Function} getRuleSeverity
 * @param {object} options
 * @returns {object[]} diagnostics
 */
function validateIndexUsage(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const functionScopes = options.functionScopes || [];
    const executionClassificationMap = options.executionClassificationMap || [];
    const tableStructures = options.tableStructures || null;

    const scopeRecords = new Map();
    // Per-scope set of variable names whose index cursors have been closed.
    const closedHandlesByScopeKey = new Map();
    // Per-scope map of tableCode -> active save count for ACU-IND-008.
    const saveCountsByScopeKey = new Map();
    // Per-scope map of handleVar -> { tableCode, indexName, nextLoadPosition } for ACU-IND-009/015.
    const loadPositionsByScopeKey = new Map();
    // Per-scope set of currently active (opened, not-yet-closed) handle variable names for ACU-IND-011.
    const activeHandlesByScopeKey = new Map();

    function getLoadPositions(scopeKey) {
        if (!loadPositionsByScopeKey.has(scopeKey)) loadPositionsByScopeKey.set(scopeKey, new Map());
        return loadPositionsByScopeKey.get(scopeKey);
    }
    function getClosedHandles(scopeKey) {
        if (!closedHandlesByScopeKey.has(scopeKey)) closedHandlesByScopeKey.set(scopeKey, new Set());
        return closedHandlesByScopeKey.get(scopeKey);
    }
    function getActiveHandles(scopeKey) {
        if (!activeHandlesByScopeKey.has(scopeKey)) activeHandlesByScopeKey.set(scopeKey, new Set());
        return activeHandlesByScopeKey.get(scopeKey);
    }
    function getSaveCounts(scopeKey) {
        if (!saveCountsByScopeKey.has(scopeKey)) saveCountsByScopeKey.set(scopeKey, new Map());
        return saveCountsByScopeKey.get(scopeKey);
    }

    const { ast } = options;
    if (!ast) throw new Error("validateIndexUsage: options.ast is required (thread facts.ast from the dispatcher)");

    walkStatements(ast.statements, (stmt) => {
        const lineIndex = stmt.line;
        if (lineIndex === undefined) return;
        if (executionClassificationMap[lineIndex]?.isOutput) return;

        const scope = getFunctionScopeAtLine(functionScopes, lineIndex);
        const scopeKey = getScopeKey(scope);
        const record = getScopeRecord(scopeRecords, scopeKey);

        // ACU-IND-011 needs the LHS of the enclosing assignment. Section C
        // populated `targetToken` so we can position the diagnostic at the
        // exact LHS column without re-scanning the line text.
        const isAssign = stmt.type === NodeType.AssignStatement || stmt.type === NodeType.SetStatement;
        const lhsToken = isAssign ? stmt.targetToken : null;
        const lhsVar = lhsToken ? lhsToken.value : null;
        const lhsLine = lhsToken ? lhsToken.line : lineIndex;
        const lhsCol = lhsToken ? lhsToken.char : 0;

        for (const span of statementSpans(stmt)) {
            const expr = parseExpression(span);
            walkCalls(expr, (call) => {
                const tok = call.callee?.token;
                if (!tok) return;
                const callName = call.callee.name?.toUpperCase();
                if (!callName) return;
                const callLine = tok.line;
                const callChar = tok.char;

                if (isIndexOpen(callName)) {
                    registerCall(record, "open", callLine, callChar, callName, identifierArg(call, 2));
                } else if (isIndexLoadKey(callName)) {
                    registerCall(record, "load", callLine, callChar, callName, identifierArg(call, 0));
                } else if (isIndexReadByKey(callName)) {
                    registerCall(record, "read", callLine, callChar, callName, identifierArg(call, 0));
                } else if (isIndexClose(callName)) {
                    registerCall(record, "close", callLine, callChar, callName, identifierArg(call, 0));
                } else if (callName === "INDEX_SAVE_POSITION") {
                    registerCall(record, "save", callLine, callChar, callName);
                } else if (callName === "INDEX_RESTORE_POSITION") {
                    registerCall(record, "restore", callLine, callChar, callName);
                }

                // --- Load-position tracking (ACU-IND-009/010/012) — sequential ---
                if (tableStructures) {
                    const loadPositions = getLoadPositions(scopeKey);
                    if (isIndexOpen(callName)) {
                        const tableCodeRaw = stringLiteralArg(call, 0);
                        const indexName = indexNameArg(call, 1);
                        const handleVar = identifierArg(call, 2);
                        if (tableCodeRaw && indexName != null && handleVar) {
                            loadPositions.set(handleVar, { tableCode: tableCodeRaw.toUpperCase(), indexName, nextLoadPosition: 0 });
                        }
                    } else if (isIndexClearKey(callName)) {
                        const handleVar = identifierArg(call, 0);
                        if (handleVar) {
                            const entry = loadPositions.get(handleVar);
                            if (entry) entry.nextLoadPosition = 0;
                        }
                    } else if (isIndexLoadKey(callName) && LOAD_KEY_ACCEPTED_TYPES[callName]) {
                        const handleVar = identifierArg(call, 0);
                        if (handleVar) {
                            const entry = loadPositions.get(handleVar);
                            if (entry) {
                                const structure = tableStructures[entry.tableCode];
                                const index = structure ? structure.indexes.find((i) => i.name === entry.indexName) : null;
                                if (index) {
                                    const pos = entry.nextLoadPosition;
                                    if (pos >= index.segments.length) {
                                        const diagnostic = createDiagnostic(
                                            createCallRange(callLine, callChar, callName),
                                            {
                                                messageId: "ACU-IND-010",
                                                params: { indexName: entry.indexName, tableCode: entry.tableCode, total: index.segments.length }
                                            },
                                            getRuleSeverity
                                        );
                                        if (diagnostic) diagnostics.push(diagnostic);
                                    } else {
                                        const segment = index.segments[pos];
                                        const acceptedTypes = LOAD_KEY_ACCEPTED_TYPES[callName];
                                        if (acceptedTypes && !acceptedTypes.has(segment.type)) {
                                            const actualSuffix = getLoadKeySuffix(callName);
                                            const diagnostic = createDiagnostic(
                                                createCallRange(callLine, callChar, callName),
                                                {
                                                    messageId: "ACU-IND-009",
                                                    params: { pos, expected: segment.type, callName, actual: actualSuffix }
                                                },
                                                getRuleSeverity
                                            );
                                            if (diagnostic) diagnostics.push(diagnostic);
                                        } else if (
                                            (callName === "INDEX_LOAD_KEY_STRING" || callName === "SQL_INDEX_LOAD_KEY_STRING") &&
                                            segment.length != null
                                        ) {
                                            const lengthVal = intLiteralArg(call, 2);
                                            if (lengthVal != null && lengthVal > segment.length) {
                                                const diagnostic = createDiagnostic(
                                                    createCallRange(callLine, callChar, callName),
                                                    {
                                                        messageId: "ACU-IND-012",
                                                        params: { length: lengthVal, pos, field: segment.field, maxWidth: segment.length }
                                                    },
                                                    getRuleSeverity
                                                );
                                                if (diagnostic) diagnostics.push(diagnostic);
                                            }
                                        }
                                    }
                                    entry.nextLoadPosition += 1;
                                }
                            }
                        }
                    }
                }

                // --- Stale handle tracking (ACU-IND-007) — sequential ---
                const closedHandles = getClosedHandles(scopeKey);
                if (isIndexClose(callName)) {
                    const varName = identifierArg(call, 0);
                    if (varName) closedHandles.add(varName);
                } else if (isIndexOpen(callName)) {
                    const varName = identifierArg(call, 2);
                    if (varName) closedHandles.delete(varName);
                } else if (INDEX_HANDLE_ARG0_FUNCTIONS.has(callName)) {
                    const varName = identifierArg(call, 0);
                    if (varName && closedHandles.has(varName)) {
                        const diagnostic = createDiagnostic(
                            createCallRange(callLine, callChar, callName),
                            { messageId: "ACU-IND-007", params: { handle: varName } },
                            getRuleSeverity
                        );
                        if (diagnostic) diagnostics.push(diagnostic);
                    }
                }

                // --- Active handle tracking for ACU-IND-011 — sequential ---
                if (isIndexOpen(callName)) {
                    const handleVar = identifierArg(call, 2);
                    if (handleVar) getActiveHandles(scopeKey).add(handleVar);
                } else if (isIndexClose(callName)) {
                    const handleVar = identifierArg(call, 0);
                    if (handleVar) getActiveHandles(scopeKey).delete(handleVar);
                }

                // --- Per-table-code save/restore tracking (ACU-IND-008) — sequential ---
                if (callName === "INDEX_SAVE_POSITION" || callName === "INDEX_RESTORE_POSITION") {
                    const tableCodeRaw = stringLiteralArg(call, 0);
                    if (tableCodeRaw) {
                        const tableCode = tableCodeRaw.toUpperCase();
                        const saveCounts = getSaveCounts(scopeKey);
                        if (callName === "INDEX_SAVE_POSITION") {
                            saveCounts.set(tableCode, (saveCounts.get(tableCode) || 0) + 1);
                        } else {
                            const count = saveCounts.get(tableCode) || 0;
                            if (count === 0) {
                                const diagnostic = createDiagnostic(
                                    createCallRange(callLine, callChar, callName),
                                    { messageId: "ACU-IND-008", params: { tableCode } },
                                    getRuleSeverity
                                );
                                if (diagnostic) diagnostics.push(diagnostic);
                            } else {
                                saveCounts.set(tableCode, count - 1);
                            }
                        }
                    }
                }
            });
        }

        // ACU-IND-011: assignment to an active index handle overwrites the cursor reference.
        if (lhsVar && getActiveHandles(scopeKey).has(lhsVar)) {
            const diagnostic = createDiagnostic(
                createCallRange(lhsLine, lhsCol, lhsVar),
                { messageId: "ACU-IND-011", params: { handle: lhsVar } },
                getRuleSeverity
            );
            if (diagnostic) diagnostics.push(diagnostic);
        }
    });

    function emitDiagnostic(messageId, source) {
        const diagnostic = createDiagnostic(
            createCallRange(source.lineIndex, source.matchIndex, source.callName),
            { messageId, params: {} },
            getRuleSeverity
        );
        if (diagnostic) diagnostics.push(diagnostic);
    }

    for (const record of scopeRecords.values()) {
        const hasCursorOps = record.open.length > 0 || record.load.length > 0 || record.read.length > 0;

        // ACU-IND-001: Missing INDEX_CLOSE
        if (hasCursorOps && record.close.length === 0) {
            emitDiagnostic("ACU-IND-001", record.read[0] || record.load[0] || record.open[0]);
        }

        // ACU-IND-002: Unmatched SAVE/RESTORE pairs (one side entirely absent)
        if ((record.save.length > 0 && record.restore.length === 0) ||
            (record.save.length === 0 && record.restore.length > 0)) {
            emitDiagnostic("ACU-IND-002", record.save[0] || record.restore[0]);
        }

        // ACU-IND-003: Consider using SAVE/RESTORE for cursor movement
        if ((record.load.length > 0 || record.read.length > 0) &&
            record.save.length === 0 && record.restore.length === 0) {
            emitDiagnostic("ACU-IND-003", record.read[0] || record.load[0]);
        }

        // ACU-IND-004: READ before LOAD
        if (record.read.length > 0 && record.load.length > 0) {
            const firstRead = record.read[0];
            const firstLoad = record.load[0];
            if (firstRead.lineIndex < firstLoad.lineIndex) emitDiagnostic("ACU-IND-004", firstRead);
        }

        // ACU-IND-005: READ before OPEN
        if (record.read.length > 0 && record.open.length > 0) {
            const firstRead = record.read[0];
            const firstOpen = record.open[0];
            if (firstRead.lineIndex < firstOpen.lineIndex) emitDiagnostic("ACU-IND-005", firstRead);
        }

        // ACU-IND-006: CLOSE before READ/LOAD (per-handle, session-aware)
        // For each close, scope the check to the current session for that handle:
        // from the most recent OPEN for the handle (sessionStart) to the next OPEN
        // for the same handle after the close (sessionEnd). This prevents reads/loads
        // from a later session (after a handle variable is reused) from triggering
        // a false positive against an earlier valid close.
        for (const closeOp of record.close) {
            const handle = closeOp.handleVar;
            let lastOp;
            if (handle) {
                const precedingOpens = record.open.filter((op) => op.handleVar === handle && op.lineIndex < closeOp.lineIndex);
                const sessionStart = precedingOpens.length > 0 ? precedingOpens[precedingOpens.length - 1].lineIndex : -1;
                const followingOpens = record.open.filter((op) => op.handleVar === handle && op.lineIndex > closeOp.lineIndex);
                const sessionEnd = followingOpens.length > 0 ? followingOpens[0].lineIndex : Infinity;
                const sessionReads = record.read.filter((op) => op.handleVar === handle && op.lineIndex > sessionStart && op.lineIndex < sessionEnd);
                const sessionLoads = record.load.filter((op) => op.handleVar === handle && op.lineIndex > sessionStart && op.lineIndex < sessionEnd);
                lastOp = sessionReads.length > 0
                    ? sessionReads[sessionReads.length - 1]
                    : sessionLoads[sessionLoads.length - 1];
            } else {
                lastOp = record.read[record.read.length - 1] || record.load[record.load.length - 1];
            }
            if (lastOp && closeOp.lineIndex < lastOp.lineIndex) emitDiagnostic("ACU-IND-006", closeOp);
        }
    }

    return diagnostics;
}

export { validateIndexUsage };
