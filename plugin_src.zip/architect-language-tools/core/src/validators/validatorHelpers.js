/**
 * Shared helpers used by multiple validators.
 * Kept here to avoid duplicating logic across validator files.
 */

import { findFunctionScopeAtLine } from "../analysis/symbolTable.js";

/**
 * Builds a Map<UPPERCASE_NAME, type> for user-declared variables visible at a given line.
 * Includes file-scope (module-level) variables, overlaid with any function-scope
 * variables (params + locals) active at lineIndex. Function-scoped symbols shadow
 * file-scope symbols when names collide.
 *
 * Only 'variable' and 'param' symbol kinds are included — built-ins are excluded
 * so that type inference sees the same set that was previously in declaredVariables.
 *
 * @param {object} symbolTable - from facts.symbolTable
 * @param {number} lineIndex - 0-based line index
 * @returns {Map<string, string>} Uppercase name → type string
 */
function buildVariablesMapFromSymbolTable(symbolTable, lineIndex) {
    const map = new Map();

    // File-scope variables (globals) first
    for (const sym of symbolTable.fileScope.symbols.values()) {
        if ((sym.kind === 'variable' || sym.kind === 'param') && sym.type) {
            map.set(sym.upperName, sym.type);
        }
    }

    // Function-scope symbols shadow file-scope entries
    const fnEntry = findFunctionScopeAtLine(symbolTable.functionScopes, lineIndex);
    if (fnEntry) {
        for (const sym of fnEntry.scope.symbols.values()) {
            if ((sym.kind === 'variable' || sym.kind === 'param') && sym.type) {
                map.set(sym.upperName, sym.type);
            }
        }
    }

    return map;
}

export { buildVariablesMapFromSymbolTable };
