/**
 * OPTION directive validator for Acurity Architect.
 *
 * Validates OPTION directive settings:
 *   ACU-OPT-001  OICC/CICC character is not in the allowed set { !, @, #, %, ^, |, ~, ? }
 *   ACU-OPT-003  DATEFORM value is not one of: DMY, MDY, YMD
 *   ACU-OPT-004  TIMEFORM value is not one of: HMSC, HMS, HM
 *   ACU-OPT-005  PAGEWIDTH value is not an integer in the range 1–16000
 *   ACU-OPT-006  Unrecognised OPTION keyword
 *
 * Valid OPTION keys: OICC, CICC, DATEFORM, TIMEFORM, PAGEWIDTH
 */

import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";
import { stripTrailingComment } from "../lineParser.js";

const ALLOWED_OPTION_CHARS = new Set(["!", "@", "#", "%", "^", "|", "~", "?"]);
const ALLOWED_CHARS_DISPLAY = "!, @, #, %, ^, |, ~, ?";

const VALID_OPTION_KEYS = new Set(["OICC", "CICC", "DATEFORM", "TIMEFORM", "PAGEWIDTH"]);

const VALID_DATEFORMS = new Set(["DMY", "MDY", "YMD"]);
const VALID_TIMEFORMS = new Set(["HMSC", "HMS", "HM"]);
const PAGEWIDTH_MIN = 1;
const PAGEWIDTH_MAX = 16000;

/**
 * Extracts all KEY='value' pairs from an OPTION directive line.
 * Handles single and double quotes; returns one entry per match.
 *
 * @param {string} lineText - Full line text
 * @returns {{ key: string, value: string, charPos: number }[]}
 *   key      - uppercased key name (e.g. "OICC")
 *   value    - the single character between the quotes (may be empty string)
 *   charPos  - zero-based column of the value character in the original line
 */
function extractOptionPairs(lineText) {
    const pairs = [];
    // Matches: WORD = 'x'  or  WORD = "x"  (x may be absent for empty quotes)
    const regex = /(\w+)\s*=\s*(['"])(.?)\2/g;
    let match;
    while ((match = regex.exec(lineText)) !== null) {
        const key = match[1].toUpperCase();
        // Skip keys that are not OICC/CICC character settings
        if (key !== "OICC" && key !== "CICC") continue;

        const value = match[3];
        // Position of the value char: start of full match + offset to opening quote + 1
        const eqOffset = match[0].indexOf("=");
        const quoteOffset = match[0].indexOf(match[2], eqOffset + 1);
        const charPos = match.index + quoteOffset + 1;
        pairs.push({ key, value, charPos });
    }
    return pairs;
}

/**
 * Extracts all KEY = ... pairs from an OPTION directive line (ignoring comments).
 * Used to detect unrecognised OPTION keywords (ACU-OPT-006).
 * Skips the literal word "OPTION" itself.
 *
 * @param {string} lineText
 * @returns {{ key: string, charPos: number, keyLength: number }[]}
 */
function extractAllOptionKeys(lineText) {
    // Use the canonical comment stripper so `//` inside an OPTION value
    // (e.g. OPTION FOO='a//b') is not mistaken for the start of a comment.
    const text = stripTrailingComment(lineText);
    const pairs = [];
    const regex = /\b([A-Za-z][A-Za-z0-9_]*)\s*=/g;
    let match;
    while ((match = regex.exec(text)) !== null) {
        const key = match[1].toUpperCase();
        if (key === "OPTION") continue;
        pairs.push({ key, charPos: match.index, keyLength: match[1].length });
    }
    return pairs;
}

/**
 * Returns true if the line is an OPTION directive.
 * @param {string} lineText
 * @returns {boolean}
 */
function isOptionLine(lineText) {
    return /^\s*#?\s*OPTION\b/i.test(lineText);
}

/**
 * Extracts DATEFORM, TIMEFORM, and PAGEWIDTH settings from an OPTION directive line.
 * Returns one entry per match found.
 *
 * @param {string} lineText
 * @returns {{ key: string, value: string, charPos: number }[]}
 *   key     - uppercased key name (e.g. "DATEFORM")
 *   value   - the raw value string (e.g. "YMD", "HMS", "80")
 *   charPos - zero-based column of the start of the value in the original line
 */
function extractOptionExtendedPairs(lineText) {
    const pairs = [];
    // Matches: WORD = "value"  or  WORD = 'value'  or  WORD = value  (unquoted word/number)
    const regex = /\b(DATEFORM|TIMEFORM|PAGEWIDTH)\s*=\s*(['"]?)(\w+)\2/gi;
    let match;
    while ((match = regex.exec(lineText)) !== null) {
        const key = match[1].toUpperCase();
        const value = match[3];
        // charPos: start of the value (after the quote, if any)
        const eqOffset = match[0].indexOf("=");
        const afterEq = match[0].indexOf(match[2], eqOffset + 1) + match[2].length; // after opening quote (or after '=' if no quote)
        const charPos = match.index + afterEq;
        pairs.push({ key, value, charPos });
    }
    return pairs;
}

/**
 * Pre-scans raw document text for OPTION DATEFORM, TIMEFORM, and PAGEWIDTH settings.
 * Uses only the first occurrence of each setting (document order).
 * Returns defaults when a setting is absent or has an invalid value:
 *   dateform:  "DMY"   (first-seen valid value overrides)
 *   timeform:  "HMSC"  (first-seen valid value overrides)
 *   pagewidth: 16000   (first-seen integer in range overrides)
 *
 * @param {string} rawText
 * @returns {{ dateform: string, timeform: string, pagewidth: number }}
 */
function scanOptionSettings(rawText) {
    let dateform  = null;
    let timeform  = null;
    let pagewidth = null;
    const lines = rawText.split(/\r?\n/);
    for (const line of lines) {
        if (!isOptionLine(line)) continue;
        if (dateform === null) {
            const m = /\bDATEFORM\s*=\s*['"]?([A-Za-z]+)['"]?/i.exec(line);
            if (m) dateform = m[1].toUpperCase();
        }
        if (timeform === null) {
            const m = /\bTIMEFORM\s*=\s*['"]?([A-Za-z]+)['"]?/i.exec(line);
            if (m) timeform = m[1].toUpperCase();
        }
        if (pagewidth === null) {
            const m = /\bPAGEWIDTH\s*=\s*['"]?(\d+)['"]?/i.exec(line);
            if (m) {
                const n = parseInt(m[1], 10);
                if (n >= PAGEWIDTH_MIN && n <= PAGEWIDTH_MAX) pagewidth = n;
            }
        }
    }
    return {
        dateform:  VALID_DATEFORMS.has(dateform)  ? dateform  : "DMY",
        timeform:  VALID_TIMEFORMS.has(timeform)  ? timeform  : "HMSC",
        pagewidth: pagewidth ?? PAGEWIDTH_MAX
    };
}

/**
 * Validates OPTION directive lines.
 *
 * @param {object} document
 * @param {Function} getRuleSeverity
 * @param {object} [options]
 * @returns {object[]}
 */
function validateOptionDirectives(document, getRuleSeverity, options = {}) {
    const diagnostics = [];

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex++) {
        const lineText = document.lineAt(lineIndex).text;
        if (!isOptionLine(lineText)) continue;

        const pairs = extractOptionPairs(lineText);

        for (const { key, value, charPos } of pairs) {
            const range = {
                start: { line: lineIndex, character: charPos },
                end:   { line: lineIndex, character: charPos + 1 }
            };

            if (!ALLOWED_OPTION_CHARS.has(value)) {
                // Character is not in the allowed set — error regardless of key.
                const diag = createDiagnostic(
                    range,
                    { messageId: "ACU-OPT-001", params: { char: value, allowed: ALLOWED_CHARS_DISPLAY } },
                    getRuleSeverity
                );
                if (diag) diagnostics.push(diag);
            }
        }

        const extPairs = extractOptionExtendedPairs(lineText);

        for (const { key, value, charPos } of extPairs) {
            const range = {
                start: { line: lineIndex, character: charPos },
                end:   { line: lineIndex, character: charPos + value.length }
            };

            if (key === "DATEFORM") {
                if (!VALID_DATEFORMS.has(value.toUpperCase())) {
                    const diag = createDiagnostic(range, { messageId: "ACU-OPT-003", params: { value } }, getRuleSeverity);
                    if (diag) diagnostics.push(diag);
                }
            } else if (key === "TIMEFORM") {
                if (!VALID_TIMEFORMS.has(value.toUpperCase())) {
                    const diag = createDiagnostic(range, { messageId: "ACU-OPT-004", params: { value } }, getRuleSeverity);
                    if (diag) diagnostics.push(diag);
                }
            } else if (key === "PAGEWIDTH") {
                const n = parseInt(value, 10);
                if (isNaN(n) || n < PAGEWIDTH_MIN || n > PAGEWIDTH_MAX) {
                    const diag = createDiagnostic(range, { messageId: "ACU-OPT-005", params: { value } }, getRuleSeverity);
                    if (diag) diagnostics.push(diag);
                }
            }
        }

        // ACU-OPT-006 — unrecognised OPTION keyword
        const allKeys = extractAllOptionKeys(lineText);
        for (const { key, charPos, keyLength } of allKeys) {
            if (!VALID_OPTION_KEYS.has(key)) {
                const range = {
                    start: { line: lineIndex, character: charPos },
                    end:   { line: lineIndex, character: charPos + keyLength }
                };
                const diag = createDiagnostic(range, { messageId: "ACU-OPT-006", params: { key } }, getRuleSeverity);
                if (diag) diagnostics.push(diag);
            }
        }
    }

    return diagnostics;
}

export { validateOptionDirectives, scanOptionSettings };
