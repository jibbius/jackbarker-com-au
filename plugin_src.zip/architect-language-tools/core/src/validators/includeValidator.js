/**
 * Include statement validator for Architect.
 *
 * Converts include-resolver findings into diagnostics:
 *   ACU-INC-001  Circular INCLUDE dependency
 *   ACU-INC-002  INCLUDE filename case mismatch
 *   ACU-INC-003  INCLUDE file not found
 *
 * REQUIRE is NOT validated as a file reference here. At runtime it is a
 * Usercalc-only directive listing prerequisite calc codes (e.g.
 * `REQUIRE ACC, NRD, FAS`); a future Usercalc-context validator will
 * check the calc list against the closed vocabulary.
 */

import { buildTokenRange } from "../lineParser.js";
import {
    findCircularIncludeDirectives,
    findIncludeFilenameCaseMismatches,
    findMissingIncludeDirectives
} from "../includeResolver.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";

/**
 * @param {vscode.TextDocument} document
 * @param {Function} getRuleSeverity
 * @returns {vscode.Diagnostic[]}
 */
function validateIncludes(document, getRuleSeverity, options = {}) {
    const diagnostics = [];

    const circularIncludeDirectives = findCircularIncludeDirectives(document);
    const includeFilenameCaseMismatches = findIncludeFilenameCaseMismatches(document);
    const missingIncludeDirectives = findMissingIncludeDirectives(document);

    circularIncludeDirectives.forEach(({ lineIndex, includeFilename }) => {
        const lineText = document.lineAt(lineIndex).text;
        const diag = createDiagnostic(
            buildTokenRange(lineText, lineIndex, includeFilename, 0),
            { messageId: "ACU-INC-001", params: { includeFilename } },
            getRuleSeverity
        );
        if (diag) diagnostics.push(diag);
    });

    includeFilenameCaseMismatches.forEach(({ lineIndex, includeFilename, actualFilename }) => {
        const lineText = document.lineAt(lineIndex).text;
        const diag = createDiagnostic(
            buildTokenRange(lineText, lineIndex, includeFilename, 0),
            { messageId: "ACU-INC-002", params: { includeFilename, actualFilename } },
            getRuleSeverity
        );
        if (diag) diagnostics.push(diag);
    });

    missingIncludeDirectives.forEach(({ lineIndex, includeFilename }) => {
        const lineText = document.lineAt(lineIndex).text;
        const diag = createDiagnostic(
            buildTokenRange(lineText, lineIndex, includeFilename, 0),
            { messageId: "ACU-INC-003", params: { filename: includeFilename } },
            getRuleSeverity
        );
        if (diag) diagnostics.push(diag);
    });

    return diagnostics;
}

export { validateIncludes };
