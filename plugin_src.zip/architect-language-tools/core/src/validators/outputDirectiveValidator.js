/**
 * Output-directive validator for Architect.
 *
 * In HASH-ON mode (the default), a line that does not start with '#' is treated
 * as output text. A small set of compiler-directive keywords are commonly written
 * without the '#' prefix because the author thinks they are configuring the file:
 * NEWINTERPRETER, HASH-OFF, HASH-ON. The bug is silent — the directive becomes
 * literal output and the mode flip / interpreter switch never happens.
 *
 * This validator emits ACU-DIR-001 when an implicit HASH-ON output line consists
 * solely of one of these keywords (case-insensitive, surrounding whitespace
 * tolerated). Restricted to *implicit* output: explicit '>>' output lines are
 * deliberately marked as output by the author and are out of scope.
 *
 * OPTION is intentionally excluded — authors do occasionally output literal
 * "OPTION" text — and detection inside longer output lines is out of scope.
 */

import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";

const DIRECTIVE_PATTERN = /^(NEWINTERPRETER|HASH-OFF|HASH-ON)\s*$/i;

/**
 * @param {object} document
 * @param {Function} getRuleSeverity
 * @param {object} options
 * @param {Array} options.executionClassificationMap - Required; without it nothing is validated.
 * @returns {object[]}
 */
function validateOutputDirectives(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const ecm = options.executionClassificationMap;
    if (!ecm) return diagnostics;

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex += 1) {
        const cls = ecm[lineIndex];
        if (!cls || !cls.isOutput || cls.outputKind !== "implicit") continue;

        const effective = cls.effectiveContent ?? "";
        const trimmed = effective.trim();
        const match = DIRECTIVE_PATTERN.exec(trimmed);
        if (!match) continue;

        const directive = match[1];
        const rawLine = cls.rawLine ?? document.lineAt(lineIndex).text;
        const startCol = rawLine.search(/\S/);
        if (startCol < 0) continue;
        const endCol = startCol + directive.length;

        const diag = createDiagnostic(
            { start: { line: lineIndex, character: startCol }, end: { line: lineIndex, character: endCol } },
            { messageId: "ACU-DIR-001", params: { directive: directive.toUpperCase() } },
            getRuleSeverity
        );
        if (diag) diagnostics.push(diag);
    }

    return diagnostics;
}

export { validateOutputDirectives };
