/**
 * REQUIRE directive validator.
 *
 *   ACU-RQR-001  REQUIRE used outside the Usercalc reports directory.
 *   ACU-RQR-002  Unknown calc code (not in the closed Usercalc vocabulary).
 *   ACU-RQR-003  Duplicate calc code on the same REQUIRE line.
 *   ACU-RQR-004  Empty REQUIRE (no codes after the keyword).
 *
 * TODO(arch-debt): the AST already has a RequireDirective node
 * (core/src/ast/parser.js) but it captures the legacy `filename` shape from
 * when REQUIRE was assumed to be an include-family directive. The correct
 * shape is `{ type: RequireDirective, codes: TokenSpan[], line }`. Reshaping
 * the AST node — and migrating the include resolver off it — belongs to the
 * `include-directive-parser-unification` spec, so this validator does a
 * guarded raw-line scan in the meantime.
 */

import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";
import { stripTrailingComment } from "../lineParser.js";
import { USERCALC_CODES } from "../builtins/usercalcCodes.js";
import { isUsercalcReport } from "../analysis/usercalcContext.js";

const REQUIRE_KEYWORD_RE = /^(\s*#?\s*)(REQUIRE)\b(.*)$/i;

/**
 * Validates REQUIRE directives.
 *
 * @param {object} document
 * @param {Function} getRuleSeverity
 * @returns {object[]}
 */
function validateRequireDirective(document, getRuleSeverity, options = {}) {
    const diagnostics = [];

    const filePath = document.fileName ?? document.uri?.fsPath ?? null;
    const usrcalcDirectory = options.projectConfig?.usrcalcDirectory;
    const inUsercalc = isUsercalcReport(filePath, { usrcalcDirectory });
    // ACU-RQR-001 must not fire when the path is unknown (editor scratch
    // buffers, in-memory test docs) — too many false positives.
    const pathKnown = filePath !== null && filePath !== "";

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex++) {
        const lineText = document.lineAt(lineIndex).text;
        const match = REQUIRE_KEYWORD_RE.exec(lineText);
        if (!match) continue;

        const leading = match[1];
        const keyword = match[2];
        const tail    = stripTrailingComment(match[3]);

        const keywordStart = leading.length;
        const keywordEnd   = keywordStart + keyword.length;
        const tailStart    = keywordEnd; // tail is the slice after the keyword

        // ACU-RQR-001: REQUIRE outside the Usercalc reports directory.
        // Anchored on the REQUIRE keyword (consistent with ACU-RQR-004).
        if (pathKnown && !inUsercalc) {
            const range = {
                start: { line: lineIndex, character: keywordStart },
                end:   { line: lineIndex, character: keywordEnd }
            };
            const diag = createDiagnostic(range, { messageId: "ACU-RQR-001" }, getRuleSeverity);
            if (diag) diagnostics.push(diag);
        }

        // Tokenise the tail by commas, tracking offsets within the original line.
        const segments = splitWithOffsets(tail, tailStart).map(({ text, start }) => {
            const lead = text.match(/^\s*/)[0].length;
            const trimmed = text.trim();
            return { text: trimmed, start: start + lead };
        });
        const codeTokens = segments.filter(({ text }) => text.length > 0);
        const hasEmptySlot = segments.some(({ text }) => text.length === 0);

        // ACU-RQR-004: bare REQUIRE (no codes), or any empty slot in the
        // comma-separated list (e.g. trailing comma `REQUIRE FAS,`). Fired
        // once per line, anchored on the REQUIRE keyword.
        if (codeTokens.length === 0 || hasEmptySlot) {
            const range = {
                start: { line: lineIndex, character: keywordStart },
                end:   { line: lineIndex, character: keywordEnd }
            };
            const diag = createDiagnostic(range, { messageId: "ACU-RQR-004" }, getRuleSeverity);
            if (diag) diagnostics.push(diag);
        }

        // First pass: ACU-RQR-002 (unknown codes). Track which tokens are
        // unknown so the duplicate check can skip them as primary-signal
        // noise.
        const unknownIndices = new Set();
        for (let i = 0; i < codeTokens.length; i++) {
            const { text, start } = codeTokens[i];
            const upper = text.toUpperCase();
            if (USERCALC_CODES.has(upper)) continue;
            unknownIndices.add(i);
            const range = {
                start: { line: lineIndex, character: start },
                end:   { line: lineIndex, character: start + text.length }
            };
            const diag = createDiagnostic(range, { messageId: "ACU-RQR-002", params: { code: text } }, getRuleSeverity);
            if (diag) diagnostics.push(diag);
        }

        // ACU-RQR-003: duplicate calc code on the same REQUIRE line. Fires
        // on the second and subsequent occurrences only; first occurrence
        // is silent. Codes already flagged ACU-RQR-002 are skipped.
        const seen = new Set();
        for (let i = 0; i < codeTokens.length; i++) {
            if (unknownIndices.has(i)) continue;
            const { text, start } = codeTokens[i];
            const upper = text.toUpperCase();
            if (seen.has(upper)) {
                const range = {
                    start: { line: lineIndex, character: start },
                    end:   { line: lineIndex, character: start + text.length }
                };
                const diag = createDiagnostic(range, { messageId: "ACU-RQR-003", params: { code: text } }, getRuleSeverity);
                if (diag) diagnostics.push(diag);
            } else {
                seen.add(upper);
            }
        }
    }

    return diagnostics;
}

/**
 * Splits `text` by commas, returning each segment with its absolute start
 * column (relative to the original line, given the supplied baseOffset).
 * Trailing-comma case `FAS,` returns two segments: ["FAS", ""].
 *
 * @param {string} text
 * @param {number} baseOffset
 * @returns {{ text: string, start: number }[]}
 */
function splitWithOffsets(text, baseOffset) {
    const out = [];
    let segStart = 0;
    for (let i = 0; i < text.length; i++) {
        if (text[i] === ",") {
            out.push({ text: text.slice(segStart, i), start: baseOffset + segStart });
            segStart = i + 1;
        }
    }
    out.push({ text: text.slice(segStart), start: baseOffset + segStart });
    return out;
}

export { validateRequireDirective };
