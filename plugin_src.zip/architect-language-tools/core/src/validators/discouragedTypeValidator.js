/**
 * Discouraged type validator for Architect.
 * Warns when the INTEGER type is used; LONG should be used instead.
 * INTEGER is supported by the runtime but overlaps with LONG and is
 * considered a legacy type in the language specification.
 */

import { TokenType } from "../lexer/tokenTypes.js";
import { buildDocumentAst } from "../ast/documentAst.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";

/**
 * Validates that discouraged type keywords are not used in a document.
 * Currently flags INTEGER, which should be replaced by LONG.
 * @param {object} document - The document to validate
 * @param {Function} getRuleSeverity
 * @param {object} [options]
 * @param {object[]} [options.executionClassificationMap] - Per-line execution classification
 * @returns {object[]} - Array of discouraged-type diagnostics
 */
function validateDiscouragedTypes(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const { tokens } = buildDocumentAst(document);
    const ecm = options.executionClassificationMap || null;

    for (const token of tokens) {
        if (token.type !== TokenType.TYPE_KEYWORD) continue;
        if (token.value.toUpperCase() !== "INTEGER") continue;

        // Skip tokens on output lines (they are literal text, not declarations).
        if (ecm) {
            const cls = ecm[token.line];
            if (cls && cls.isOutput) continue;
        }

        const range = {
            start: { line: token.line, character: token.char },
            end:   { line: token.line, character: token.char + token.value.length }
        };
        const diag = createDiagnostic(
            range,
            { messageId: "ACU-TYPE-003", params: {} },
            getRuleSeverity
        );
        if (diag) diagnostics.push(diag);
    }

    return diagnostics;
}

export { validateDiscouragedTypes };
