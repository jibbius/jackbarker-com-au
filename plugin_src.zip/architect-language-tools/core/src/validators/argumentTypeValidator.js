/**
 * Argument type validator for Architect.
 * Checks that arguments passed to built-in functions match the declared
 * parameter types in the function registry.
 *
 * ACU-FNC-009 — functionArgumentType
 *   Fires when a known argument type does not satisfy the declared parameter
 *   type for a built-in function.
 *
 * Only fires when:
 *   - The function has typed params in the registry
 *   - The argument's type can be inferred (null → skip to avoid false positives)
 *   - The inferred type is not compatible with the declared parameter type
 */

import { buildDocumentAst } from "../ast/documentAst.js";
import { parseExpression } from "../ast/expressionParser.js";
import { inferExpressionType } from "../analysis/expressionTypeInference.js";
import { areTypesCompatible } from "../types/architectTypes.js";
import { BuiltInFunctions } from "../builtins/functionsRegistry.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";
import { buildVariablesMapFromSymbolTable } from "./validatorHelpers.js";
import { collectStatementValueSpans, walkCalls, firstToken } from "../ast/astHelpers.js";
import { findFunctionScopeAtLine } from "../analysis/symbolTable.js";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Returns true if `inferredType` satisfies `paramType`.
 * paramType is either a string or an array of strings (union).
 * Uses areTypesCompatible so that numeric widening is treated as compatible.
 */
function paramTypeMatches(inferredType, paramType) {
    if (Array.isArray(paramType)) {
        return paramType.some(t => areTypesCompatible(t, inferredType));
    }
    return areTypesCompatible(paramType, inferredType);
}

/**
 * Returns the display string for a parameter type.
 * Union types are rendered as "A | B | C".
 */
function formatParamType(paramType) {
    if (Array.isArray(paramType)) return paramType.join(" | ");
    return paramType;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Validates function argument types against the built-in function registry.
 * Emits ACU-FNC-009 for each argument whose inferred type is incompatible
 * with the declared parameter type.
 *
 * @param {object} document  VS Code TextDocument or test shim
 * @param {Function} getRuleSeverity
 * @param {object} [options]
 * @param {object} [options.symbolTable]  Symbol table from facts.symbolTable
 * @param {object} [options.userDefinedFunctionCatalog]
 * @param {object[]|null} [options.executionClassificationMap]
 * @returns {object[]}
 */
function validateArgumentTypes(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const symbolTable = options.symbolTable;
    if (!symbolTable) return diagnostics;
    const userDefinedFunctionCatalog = options.userDefinedFunctionCatalog || {};
    const executionClassificationMap = options.executionClassificationMap || null;

    const { ast } = buildDocumentAst(document);
    const spans = collectStatementValueSpans(ast.statements);

    // Cache variable maps per scope to avoid rebuilding.
    const variableMapCache = new Map();

    for (const { span, lineIndex } of spans) {
        if (executionClassificationMap && executionClassificationMap[lineIndex]?.isOutput) {
            continue;
        }

        const fnEntry = findFunctionScopeAtLine(symbolTable.functionScopes, lineIndex);
        const cacheKey = fnEntry ? "fn:" + fnEntry.id : "global";

        if (!variableMapCache.has(cacheKey)) {
            variableMapCache.set(cacheKey, buildVariablesMapFromSymbolTable(symbolTable, lineIndex));
        }
        const variables = variableMapCache.get(cacheKey);
        const inferContext = { variables, userDefinedFunctionCatalog };

        const exprTree = parseExpression(span);
        if (!exprTree) continue;

        walkCalls(exprTree, (callNode) => {
            const name = callNode.callee?.name?.toUpperCase();
            if (!name) return;

            const sig = BuiltInFunctions[name];
            if (!sig || sig.varArgs) return;
            if (!sig.params || sig.params.length === 0) return;

            for (let i = 0; i < sig.params.length; i++) {
                const arg = callNode.args[i];
                if (!arg) break; // arg count mismatch — handled by ACU-FNC-006

                const inferred = inferExpressionType(arg, inferContext);
                if (inferred === null) continue; // unknown type — skip to avoid false positive

                if (!paramTypeMatches(inferred, sig.params[i])) {
                    const tok = firstToken(arg);
                    if (!tok) continue;

                    const range = {
                        start: { line: tok.line, character: tok.char },
                        end:   { line: tok.line, character: tok.char + (tok.value?.length ?? 1) }
                    };

                    const diag = createDiagnostic(
                        range,
                        {
                            messageId: "ACU-FNC-009",
                            params: {
                                n: i + 1,
                                function: name,
                                expectedType: formatParamType(sig.params[i]),
                                actualType: inferred
                            }
                        },
                        getRuleSeverity
                    );
                    if (diag) diagnostics.push(diag);
                }
            }
        });
    }

    return diagnostics;
}

export { validateArgumentTypes };
