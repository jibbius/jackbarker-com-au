/**
 * Function return-type validator for Acurity Architect.
 *
 * ACU-FNC-010  functionReturnTypeMismatch
 *   Fires when a RETURN expression's inferred type does not match the function's
 *   declared return type. Uses full expression type inference so that complex
 *   return expressions (binary arithmetic, function calls, etc.) are covered.
 *
 * ACU-FNC-011  functionMissingReturn
 *   Fires when a typed function contains no RETURN statement.
 *   Emitted on the ENDFUNCTION line.
 */

import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";
import { buildDocumentAst } from "../ast/documentAst.js";
import { parseExpression } from "../ast/expressionParser.js";
import { NodeType } from "../ast/nodes.js";
import { walkStatements } from "../ast/astHelpers.js";
import { inferExpressionType } from "../analysis/expressionTypeInference.js";
import { areTypesCompatible } from "../types/architectTypes.js";
import { buildTokenRange } from "../lineParser.js";

// ---------------------------------------------------------------------------
// AST helpers
// ---------------------------------------------------------------------------

/**
 * Build a map of function-declaration start-line → body statement array.
 * Recurses into nested block bodies so guards like `IF NOT SYMBOL(...)` are found.
 * Each FunctionDeclaration registers its own body; nested functions do the same
 * recursively via the visitor returning false only after registering.
 */
function collectFunctionBodies(statements, out) {
    walkStatements(statements, stmt => {
        if (stmt.type === NodeType.FunctionDeclaration) {
            out.set(stmt.line, stmt.body || []);
            // Register nested functions by recursing into the body explicitly.
            collectFunctionBodies(stmt.body || [], out);
            return false; // walkStatements would re-descend; we handled it above
        }
    });
}

/**
 * Collect all ReturnStatement nodes from a function body.
 * Does NOT descend into nested FunctionDeclaration or MacroDeclaration bodies
 * (their returns belong to a different scope).
 */
function collectReturnStatements(body) {
    const out = [];
    walkStatements(body, stmt => {
        if (stmt.type === NodeType.ReturnStatement) { out.push(stmt); }
        if (stmt.type === NodeType.FunctionDeclaration ||
            stmt.type === NodeType.MacroDeclaration) { return false; }
    });
    return out;
}

// ---------------------------------------------------------------------------
// Type inference
// ---------------------------------------------------------------------------

/**
 * Infers the return type from a ReturnStatement AST node using full expression
 * type inference. Returns the ArchitectTypes string, or null when the type cannot
 * be determined (unknown variables, unresolved macro calls, etc.) — callers
 * treat null as "unknown, skip" to avoid false positives.
 *
 * @param {object} returnStmt - ReturnStatement AST node
 * @param {Map<string,string>} params - Function parameter name → type map (as-declared keys)
 * @param {Map<string,string>} locals - Function local variable name → type map (as-declared keys)
 * @param {object} [userDefinedFunctionCatalog] - User-defined function catalog for return-type lookup
 * @returns {string|null}
 */
// Build an uppercase-keyed variables map so inferExpressionType can look up
// identifiers by their uppercased name (its convention). Locals are added
// first; params shadow them when names collide.
function buildScopeVariablesMap(params, locals) {
    const variables = new Map();
    for (const [name, type] of locals) {
        if (type) variables.set(name.toUpperCase(), type);
    }
    for (const [name, type] of params) {
        if (type) variables.set(name.toUpperCase(), type);
    }
    return variables;
}

function inferReturnExpressionType(returnStmt, variables, userDefinedFunctionCatalog) {
    if (!returnStmt.value) return null; // bare RETURN

    const expr = parseExpression(returnStmt.value);
    if (!expr) return null;

    return inferExpressionType(expr, {
        variables,
        userDefinedFunctionCatalog: userDefinedFunctionCatalog || {}
    });
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Validates return types for all user-defined functions in the document.
 * @param {object} document - VS Code TextDocument or PlainTextDocument
 * @param {Function} getRuleSeverity
 * @param {object} [options={}]
 * @param {Array} [options.functionScopes] - Pre-computed function scopes (from documentFacts)
 * @param {object} [options.userDefinedFunctionCatalog] - User-defined function catalog for return-type lookup
 * @returns {object[]} Array of diagnostics
 */
function validateReturnTypes(document, getRuleSeverity, options = {}) {
    const { functionScopes = [], userDefinedFunctionCatalog = {} } = options;
    const diagnostics = [];

    const { ast } = buildDocumentAst(document);
    const funcBodyByLine = new Map();
    collectFunctionBodies(ast.statements, funcBodyByLine);

    for (const scope of functionScopes) {
        if (!scope.returnType) continue;

        const { name, startLine, endLine, params, locals, returnType } = scope;
        const expectedType = returnType.toUpperCase();

        const body = funcBodyByLine.get(startLine) || [];
        const returnStmts = collectReturnStatements(body);

        const hasReturn = returnStmts.length > 0;
        const variables = hasReturn ? buildScopeVariablesMap(params, locals) : null;

        for (const returnStmt of returnStmts) {
            const actualType = inferReturnExpressionType(returnStmt, variables, userDefinedFunctionCatalog);

            if (actualType && !areTypesCompatible(expectedType, actualType)) {
                const lineText = document.lineAt(returnStmt.line).text;
                const col = returnStmt.keywordChar ?? 0;
                const diag = createDiagnostic(
                    {
                        start: { line: returnStmt.line, character: col },
                        end:   { line: returnStmt.line, character: lineText.length }
                    },
                    {
                        messageId: "ACU-FNC-010",
                        params: {
                            functionName: name,
                            expectedType,
                            expression: returnStmt.value
                                ? returnStmt.value.tokens.map(t => t.value).join("").trim()
                                : "",
                            actualType
                        }
                    },
                    getRuleSeverity
                );
                if (diag) diagnostics.push(diag);
            }
        }

        if (!hasReturn) {
            const lineText = document.lineAt(endLine).text;
            const col = scope.endKeywordChar;
            const diag = createDiagnostic(
                {
                    start: { line: endLine, character: col ?? 0 },
                    end:   { line: endLine, character: col != null ? col + "ENDFUNCTION".length : lineText.length }
                },
                {
                    messageId: "ACU-FNC-011",
                    params: { functionName: name, returnType: expectedType }
                },
                getRuleSeverity
            );
            if (diag) diagnostics.push(diag);
        }
    }

    return diagnostics;
}

// ---------------------------------------------------------------------------
// ACU-FNC-018 — Discarded function result
// ---------------------------------------------------------------------------

/**
 * Validates that user-defined function calls with a declared return type are not
 * used as bare statements (result discarded). Void UDFs (no return type) and
 * built-in function calls are excluded.
 *
 * @param {object} document - VS Code TextDocument or PlainTextDocument
 * @param {Function} getRuleSeverity
 * @param {object} [options={}]
 * @param {object} [options.userDefinedFunctionCatalog]
 * @param {object[]|null} [options.executionClassificationMap]
 * @returns {object[]} Array of diagnostics
 */
function validateDiscardedResults(document, getRuleSeverity, options = {}) {
    const { userDefinedFunctionCatalog = {}, executionClassificationMap = null } = options;
    const diagnostics = [];

    const { ast } = buildDocumentAst(document);

    walkStatements(ast.statements, stmt => {
        if (stmt.type !== NodeType.FunctionCallStatement) return;

        const lineIndex = stmt.line;
        if (executionClassificationMap && executionClassificationMap[lineIndex]?.isOutput) return;

        const tokens = stmt.value?.tokens;
        if (!tokens || tokens.length === 0) return;

        const rawName = tokens[0].value;
        if (!rawName) return;

        const upperName = rawName.toUpperCase();
        const entry = userDefinedFunctionCatalog[upperName];
        if (!entry || !entry.returnType) return;

        const lineText = document.lineAt(lineIndex).text;
        const diag = createDiagnostic(
            buildTokenRange(lineText, lineIndex, rawName, 0),
            { messageId: "ACU-FNC-018", params: { functionName: entry.declaredName ?? rawName } },
            getRuleSeverity
        );
        if (diag) diagnostics.push(diag);
    });

    return diagnostics;
}

export { validateReturnTypes, inferReturnExpressionType, validateDiscardedResults };
