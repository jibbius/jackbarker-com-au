/**
 * Function call validator for Acurity Architect.
 * Validates built-in function signatures, user-defined functions, and scope.
 */

import { isBuiltInGlobalVariable } from "../builtins/functions.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";
import { stripTrailingComment, parseFunctionDeclaration } from "../lineParser.js";
import { NodeType } from "../ast/nodes.js";
import { buildDocumentAst } from "../ast/documentAst.js";
import { walkStatements } from "../ast/astHelpers.js";
import { parseExpression } from "../ast/expressionParser.js";
import { ExprNodeType } from "../ast/expressionNodes.js";
import { tokenize } from "../lexer/lexer.js";
import { TokenType } from "../lexer/tokenTypes.js";
import { ACURITY_KEYWORDS } from "../constants.js";
import { buildIncludedSymbolsInScope } from "../includeResolver.js";
import { findBuiltinCollisionDeclarations } from "../analysis/functionAnalysis.js";
import {
    resolveKnownFunction,
    validateKnownFunctionArgumentCount
} from "../analysis/functionResolution.js";
import { extractOutputDelimiters, getFunctionValidationTargetsForLine } from "../analysis/executionContext.js";
import { validateOutputDirective } from "../analysis/outputDirectiveCallCheck.js";


function isKnownCallableFunctionAtLine(functionName, lineIndex, userDefinedFunctionCatalog, includedFunctionsByLine) {
    const upperName = functionName.toUpperCase();
    const knownFunction = resolveKnownFunction(functionName, userDefinedFunctionCatalog);

    if (knownFunction?.kind === "builtin") {
        return true;
    }

    const userFunctionMetadata = userDefinedFunctionCatalog[upperName];
    if (userFunctionMetadata && userFunctionMetadata.lineIndex < lineIndex) {
        return true;
    }

    const includedFunctions = includedFunctionsByLine.get(lineIndex) || new Set();
    if (includedFunctions.has(upperName)) {
        return true;
    }

    return false;
}

/**
 * Validates function calls in a document.
 * @param {vscode.TextDocument} document - The document to validate
 * @returns {vscode.Diagnostic[]} - Array of function call diagnostics
 */
function validateFunctionCalls(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const outputDelimiters = options.outputDelimiters || extractOutputDelimiters(document);
    
    const userDefinedFunctionCatalog = options.userDefinedFunctionCatalog || {};
    const userDefinedFunctionCaseMap = options.userDefinedFunctionCaseMap || {};
    const functionDuplicates = options.functionDuplicates || [];
    const builtinCollisions = options.builtinCollisions || findBuiltinCollisionDeclarations(document);
    let includedFunctionsByLine = options.includedFunctionsByLine;
    let includedFunctionCasesByLine = options.includedFunctionCaseMapByLine;
    if (!includedFunctionsByLine || !includedFunctionCasesByLine) {
        const symbolScope = buildIncludedSymbolsInScope(document);
        includedFunctionsByLine = includedFunctionsByLine || symbolScope.includedFunctionsByLine;
        includedFunctionCasesByLine = includedFunctionCasesByLine || symbolScope.includedFunctionCaseMapByLine;
    }
    const macroCatalog = options.macroCatalog || null;
    const pagewidth = options.pagewidth ?? 16000;

    let nodeTypeByLine = options.nodeTypeByLine || null;
    let stmtByLine = options.stmtByLine || null;
    if (!nodeTypeByLine || !stmtByLine) {
        const { ast } = buildDocumentAst(document);
        const _ntbl = new Map();
        const _sbl = new Map();
        walkStatements(ast.statements, stmt => {
            if (typeof stmt.line === "number") {
                _ntbl.set(stmt.line, stmt.type);
                _sbl.set(stmt.line, stmt);
            }
        });
        nodeTypeByLine = nodeTypeByLine || _ntbl;
        stmtByLine = stmtByLine || _sbl;
    }

    // Report builtin name collision declarations
    for (const collision of builtinCollisions) {
        if (collision.isCollision) {
            const lineText = document.lineAt(collision.lineIndex).text;
            const lowerLineText = lineText.toLowerCase();
            const startPos = lowerLineText.indexOf("function");
            if (startPos === -1) continue;
            const endPos = lineText.indexOf("(", startPos);
            if (endPos === -1) continue;
            const colDiag = createDiagnostic(
                { start: { line: collision.lineIndex, character: startPos }, end: { line: collision.lineIndex, character: endPos } },
                { messageId: "ACU-FNC-013", params: { functionName: collision.functionName } },
                getRuleSeverity
            );
            if (colDiag) {
                diagnostics.push(colDiag);
            }
        }
    }

    // Report duplicate function declarations
    for (const duplicate of functionDuplicates) {
        if (duplicate.isDuplicate) {
            const lineText = document.lineAt(duplicate.lineIndex).text;
            const lowerLineText = lineText.toLowerCase();
            const startPos = lowerLineText.indexOf("function");
            
            // Validate position before creating Range
            if (startPos === -1) {
                continue;  // function keyword not found, skip
            }
            
            const endPos = lineText.indexOf("(", startPos);
            if (endPos === -1) {
                continue;  // opening parenthesis not found, skip
            }
            
            const dupDiag = createDiagnostic(
                { start: { line: duplicate.lineIndex, character: startPos }, end: { line: duplicate.lineIndex, character: endPos } },
                { messageId: "ACU-FNC-003", params: { functionName: duplicate.functionName } },
                getRuleSeverity
            );
            if (dupDiag) {
                diagnostics.push(dupDiag);
            }
        }
    }

    // Main pass: validate function calls
    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex += 1) {
        const rawLineText = document.lineAt(lineIndex).text;
        const lineText = stripTrailingComment(rawLineText);
        const isOutputLine = options.executionClassificationMap?.[lineIndex]?.isOutput === true;

        const lineNodeType = nodeTypeByLine.get(lineIndex);
        if (lineNodeType === NodeType.FunctionDeclaration ||
            lineNodeType === NodeType.MacroDeclaration ||
            lineNodeType === NodeType.IncludeDirective ||
            lineNodeType === NodeType.RequireDirective ||
            lineNodeType === NodeType.CommentLine) {
            continue;
        }

        if (!isOutputLine && (lineNodeType === NodeType.ExpressionStatement || lineNodeType === NodeType.FunctionCallStatement)) {
            const stmt = stmtByLine.get(lineIndex);
            const expr = stmt?.value ? parseExpression(stmt.value) : null;
            if (expr?.type === ExprNodeType.CALL &&
                isKnownCallableFunctionAtLine(expr.callee.name, lineIndex, userDefinedFunctionCatalog, includedFunctionsByLine) &&
                !userDefinedFunctionCatalog[expr.callee.name.toUpperCase()]) {
                // Local UDFs are handled by ACU-FNC-018 (validateDiscardedResults). ACU-FNC-008 only
                // covers built-ins and included functions, which cannot be checked per-returnType here.
                const standaloneCallName = expr.callee.name;
                const functionChar = expr.callee.token?.char ?? rawLineText.toUpperCase().indexOf(standaloneCallName.toUpperCase());
                const range = {
                    start: { line: lineIndex, character: functionChar },
                    end:   { line: lineIndex, character: functionChar + standaloneCallName.length }
                };
                const unusedResultDiagnostic = createDiagnostic(
                    range,
                    { messageId: "ACU-FNC-008", params: { functionName: standaloneCallName } },
                    getRuleSeverity
                );
                if (unusedResultDiagnostic) {
                    diagnostics.push(unusedResultDiagnostic);
                }
            }
        }

        const validationTargets = options.functionValidationTargetsByLine?.[lineIndex]
            || getFunctionValidationTargetsForLine(lineText, outputDelimiters);
        for (const { snippet, position } of validationTargets) {
            validateCodeSnippet(
                snippet,
                lineIndex,
                position,
                diagnostics,
                userDefinedFunctionCatalog,
                userDefinedFunctionCaseMap,
                includedFunctionsByLine,
                includedFunctionCasesByLine,
                getRuleSeverity,
                document,
                { isFromOutputLine: isOutputLine, macroCatalog, pagewidth }
            );
        }
    }

    return diagnostics;
}

function createFunctionNameRange(lineIndex, actualCharPos, functionName) {
    return { start: { line: lineIndex, character: actualCharPos }, end: { line: lineIndex, character: actualCharPos + functionName.length } };
}

function addFunctionDiagnostic(diagnostics, range, messageId, params, getRuleSeverity) {
    const diag = createDiagnostic(range, { messageId, params }, getRuleSeverity);
    if (diag) {
        diagnostics.push(diag);
    }
}

function validateNonBuiltinFunctionContext(
    functionName,
    upperFunctionName,
    lineIndex,
    actualCharPos,
    diagnostics,
    userDefinedFunctionCatalog,
    userDefinedFunctionCaseMap,
    includedFunctionsByLine,
    includedFunctionCasesByLine,
    getRuleSeverity
) {
    const userFunctionMetadata = userDefinedFunctionCatalog[upperFunctionName];
    const localDefinitionLine = userFunctionMetadata?.lineIndex;
    const isUserDefined = localDefinitionLine !== undefined;
    const isLocallyInScope = isUserDefined && localDefinitionLine < lineIndex;

    const includedFunctions = includedFunctionsByLine.get(lineIndex) || new Set();
    const isIncludedInScope = includedFunctions.has(upperFunctionName);

    if (!isUserDefined && !isIncludedInScope) {
        addFunctionDiagnostic(
            diagnostics,
            createFunctionNameRange(lineIndex, actualCharPos, functionName),
            "ACU-FNC-001",
            { functionName },
            getRuleSeverity
        );
        return { handled: true, isLocallyInScope: false, userFunctionMetadata: null };
    }

    if (isUserDefined && !isLocallyInScope) {
        addFunctionDiagnostic(
            diagnostics,
            createFunctionNameRange(lineIndex, actualCharPos, functionName),
            "ACU-FNC-002",
            { functionName },
            getRuleSeverity
        );
        return { handled: true, isLocallyInScope, userFunctionMetadata };
    }

    if (isUserDefined) {
        const declaredName = userDefinedFunctionCaseMap[upperFunctionName] || functionName;
        if (declaredName !== functionName) {
            addFunctionDiagnostic(
                diagnostics,
                createFunctionNameRange(lineIndex, actualCharPos, functionName),
                "ACU-FNC-007",
                { functionName, declaredName },
                getRuleSeverity
            );
        }
    } else if (isIncludedInScope) {
        const includedCaseMap = includedFunctionCasesByLine.get(lineIndex) || new Map();
        const declaredName = includedCaseMap.get(upperFunctionName) || functionName;
        if (declaredName !== functionName) {
            addFunctionDiagnostic(
                diagnostics,
                createFunctionNameRange(lineIndex, actualCharPos, functionName),
                "ACU-FNC-007",
                { functionName, declaredName },
                getRuleSeverity
            );
        }
    }

    return { handled: false, isLocallyInScope, userFunctionMetadata };
}

function validateFunctionArgumentShape(
    hasClosingParen,
    argCount,
    lineIndex,
    actualCharPos,
    rawLineText,
    functionName,
    diagnostics,
    userDefinedFunctionCatalog,
    getRuleSeverity
) {
    if (!hasClosingParen) {
        // A continuation marker at line end means this is a deliberate multi-line
        // function call — the closing paren is on a following line. Not an error.
        if (/\.\.\.\s*$/.test(rawLineText)) {
            return;
        }
        addFunctionDiagnostic(
            diagnostics,
            { start: { line: lineIndex, character: actualCharPos }, end: { line: lineIndex, character: rawLineText.length } },
            "ACU-FNC-005",
            { functionName },
            getRuleSeverity
        );
        return;
    }

    const argumentCountError = validateKnownFunctionArgumentCount(functionName, argCount, userDefinedFunctionCatalog);
    if (argumentCountError) {
        addFunctionDiagnostic(
            diagnostics,
            { start: { line: lineIndex, character: actualCharPos }, end: { line: lineIndex, character: actualCharPos + functionName.length + 1 } },
            "ACU-FNC-006",
            { errorDetail: argumentCountError },
            getRuleSeverity
        );
    }
}

/**
 * Scans a flat token array for a function call starting at lparenIdx and returns
 * the closing-paren index, the argument count, and the first argument's token.
 *
 * CONTINUATION ("...") tokens must already be filtered from the array before calling.
 *
 * @param {object[]} tokens      - Filtered meaningful token array
 * @param {number}   lparenIdx   - Index of the LPAREN token
 * @returns {{ closeIndex: number, argCount: number, firstArgToken: object|null }}
 *   closeIndex = -1 means no matching RPAREN was found (unclosed call).
 */
function findCallBounds(tokens, lparenIdx) {
    let depth = 1;
    let commaCount = 0;
    let contentCount = 0;  // tokens inside the outermost parens (excluding trailing RPAREN)
    let firstArgToken = null;

    for (let j = lparenIdx + 1; j < tokens.length; j++) {
        const t = tokens[j];
        if (t.type === TokenType.LPAREN) {
            depth++;
            if (depth === 2 && !firstArgToken) firstArgToken = t;
            contentCount++;
        } else if (t.type === TokenType.RPAREN) {
            depth--;
            if (depth === 0) {
                return { closeIndex: j, argCount: contentCount === 0 ? 0 : commaCount + 1, firstArgToken };
            }
            contentCount++;
        } else if (t.type === TokenType.COMMA && depth === 1) {
            commaCount++;
        } else {
            if (depth === 1 && !firstArgToken) firstArgToken = t;
            contentCount++;
        }
    }
    return { closeIndex: -1, argCount: 0, firstArgToken: null };
}

/**
 * Validates function calls in a code snippet using a token linear scan.
 *
 * The snippet is re-tokenised using the correct hash mode (HASH-ON for # -prefixed
 * snippets, HASH-OFF otherwise). Meaningful tokens are scanned linearly for
 * IDENTIFIER/KEYWORD + LPAREN patterns. This approach handles full-statement
 * snippets (e.g. "SET x = FUNC(y)") and lines with continuation operators ("...")
 * without the limitations of expression-level parsing.
 *
 * @param {string}   code                     - The code snippet to validate
 * @param {number}   lineIndex                - Zero-based line number in the document
 * @param {number}   codePositionInLine       - Char offset of this snippet in the original line
 * @param {object[]} diagnostics              - Diagnostics array to append to
 * @param {object}   userDefinedFunctionCatalog
 * @param {object}   userDefinedFunctionCaseMap
 * @param {Map}      includedFunctionsByLine
 * @param {Map}      includedFunctionCasesByLine
 * @param {Function} getRuleSeverity
 * @param {object}   document                 - VS Code TextDocument
 * @param {object}   [snippetOptions]
 */
function validateCodeSnippet(code, lineIndex, codePositionInLine, diagnostics, userDefinedFunctionCatalog, userDefinedFunctionCaseMap, includedFunctionsByLine, includedFunctionCasesByLine, getRuleSeverity, document, snippetOptions = {}) {
    const { isFromOutputLine = false, macroCatalog = null, pagewidth = 16000 } = snippetOptions;
    const rawLineText = document.lineAt(lineIndex).text;

    // HASH-ON code snippets include the '#' prefix — tokenise in HASH-ON mode so the
    // '#' becomes a HASH_PREFIX token (then filtered), rather than a HASH mid-code token.
    const isHashOnSnippet = /^\s*#/.test(code);
    const snippetTokens = tokenize(code, { initialHashMode: isHashOnSnippet });

    // Filter to meaningful tokens. CONTINUATION ("...") tokens are filtered because
    // they can appear legally inside multi-line function call argument lists and are
    // not part of the expression structure we care about.
    const SKIP_TYPES = new Set([
        TokenType.WHITESPACE, TokenType.NEWLINE, TokenType.HASH_PREFIX, TokenType.HASH,
        TokenType.OUTPUT_TEXT, TokenType.EOF, TokenType.COMMENT, TokenType.CONTINUATION
    ]);
    const meaningful = snippetTokens.filter(t => !SKIP_TYPES.has(t.type));

    // Linear scan for IDENTIFIER / TYPE_KEYWORD / KEYWORD followed directly by LPAREN.
    // This is equivalent to the old /\b([A-Za-z_]\w*)\s*\(/ regex but token-based:
    // string literals and operators are already classified by the lexer, so no
    // quote-masking (stripQuotedStrings) is needed.
    for (let i = 0; i < meaningful.length - 1; i++) {
        const tok = meaningful[i];
        const next = meaningful[i + 1];

        if (tok.type !== TokenType.IDENTIFIER && tok.type !== TokenType.TYPE_KEYWORD && tok.type !== TokenType.KEYWORD) {
            continue;
        }
        if (next.type !== TokenType.LPAREN) {
            continue;
        }

        const functionName = tok.value;
        const upperFunctionName = functionName.toUpperCase();
        const actualCharPos = codePositionInLine + tok.char;

        // Validate position is within bounds before emitting any diagnostic.
        if (actualCharPos < 0 || actualCharPos >= rawLineText.length) {
            continue;
        }

        // Skip structural keywords (e.g., WHILE in "DO WHILE (condition)").
        if (ACURITY_KEYWORDS.has(upperFunctionName)) {
            continue;
        }

        // Skip macro invocations — the macro validator handles those independently.
        if (macroCatalog && macroCatalog[upperFunctionName]) {
            continue;
        }

        // Determine argument count and whether the call has a closing parenthesis.
        const { closeIndex, argCount, firstArgToken } = findCallBounds(meaningful, i + 1);
        const hasClosingParen = closeIndex !== -1;

        // Check if it's a built-in constant used incorrectly with parentheses.
        if (isBuiltInGlobalVariable(functionName)) {
            addFunctionDiagnostic(
                diagnostics,
                createFunctionNameRange(lineIndex, actualCharPos, functionName),
                "ACU-FNC-004",
                { functionName },
                getRuleSeverity
            );
            continue;
        }

        const knownFunction = resolveKnownFunction(functionName, userDefinedFunctionCatalog);

        // Output-positioning directives (CENTER, COL, FROM, TAB, TO) — delegate
        // all context and shape validation to the dedicated validator.
        if (knownFunction && knownFunction.kind === "output-directive") {
            validateOutputDirective(
                hasClosingParen, argCount, firstArgToken,
                lineIndex, actualCharPos,
                functionName, knownFunction, isFromOutputLine,
                diagnostics, getRuleSeverity, pagewidth
            );
            continue;
        }

        const builtInSignature = knownFunction && knownFunction.kind === "builtin";

        // If not a built-in, validate existence/scope and case mismatches.
        if (!builtInSignature) {
            const scopeResult = validateNonBuiltinFunctionContext(
                functionName,
                upperFunctionName,
                lineIndex,
                actualCharPos,
                diagnostics,
                userDefinedFunctionCatalog,
                userDefinedFunctionCaseMap,
                includedFunctionsByLine,
                includedFunctionCasesByLine,
                getRuleSeverity
            );
            if (!scopeResult.handled && scopeResult.isLocallyInScope && scopeResult.userFunctionMetadata) {
                validateFunctionArgumentShape(
                    hasClosingParen,
                    argCount,
                    lineIndex,
                    actualCharPos,
                    rawLineText,
                    functionName,
                    diagnostics,
                    userDefinedFunctionCatalog,
                    getRuleSeverity
                );
            }
            continue;
        }

        // Built-in case — warn if deprecated.
        if (knownFunction.signature.deprecated) {
            addFunctionDiagnostic(
                diagnostics,
                createFunctionNameRange(lineIndex, actualCharPos, functionName),
                "ACU-FNC-016",
                { functionName },
                getRuleSeverity
            );
        }

        // Built-in case — validate argument shape.
        validateFunctionArgumentShape(
            hasClosingParen,
            argCount,
            lineIndex,
            actualCharPos,
            rawLineText,
            functionName,
            diagnostics,
            userDefinedFunctionCatalog,
            getRuleSeverity
        );
    }
}

export {
    validateFunctionCalls,
    validateFunctionDeclarations
};

/**
 * Validates user-defined function declaration syntax.
 * Emits ACU-FNC-014 for parameters missing a type annotation.
 * Emits ACU-FNC-015 for function declarations missing a return type.
 * @param {object} document - VS Code TextDocument or PlainTextDocument
 * @param {Function} getRuleSeverity
 * @returns {object[]}
 */
function validateFunctionDeclarations(document, getRuleSeverity) {
    const diagnostics = [];

    for (let lineIndex = 0; lineIndex < document.lineCount; lineIndex += 1) {
        const rawLineText = document.lineAt(lineIndex).text;
        const decl = parseFunctionDeclaration(rawLineText);
        if (!decl) {
            continue;
        }

        const effectiveText = stripTrailingComment(rawLineText);

        // ACU-FNC-014: one diagnostic per parameter missing a type annotation
        for (const malformed of decl.malformedParams) {
            const openParen = rawLineText.indexOf("(");
            const postParenIndex = openParen >= 0
                ? rawLineText.substring(openParen + 1).toLowerCase().indexOf(malformed.name.toLowerCase())
                : -1;
            let charStart;
            if (postParenIndex >= 0) {
                charStart = openParen + 1 + postParenIndex;
            } else {
                const globalIndex = rawLineText.toLowerCase().indexOf(malformed.name.toLowerCase());
                charStart = globalIndex >= 0 ? globalIndex : 0;
            }
            const range = {
                start: { line: lineIndex, character: charStart },
                end:   { line: lineIndex, character: charStart + malformed.name.length }
            };
            const diag = createDiagnostic(
                range,
                { messageId: "ACU-FNC-014", params: { paramName: malformed.name, functionName: decl.name } },
                getRuleSeverity
            );
            if (diag) diagnostics.push(diag);
        }

        // ACU-FNC-015: return type is absent
        if (decl.returnType === null) {
            const closeParen = effectiveText.lastIndexOf(")");
            const charStart = closeParen >= 0 ? closeParen : 0;
            const charEnd = closeParen >= 0 ? closeParen + 1 : rawLineText.trimEnd().length;
            const range = {
                start: { line: lineIndex, character: charStart },
                end:   { line: lineIndex, character: charEnd }
            };
            const diag = createDiagnostic(
                range,
                { messageId: "ACU-FNC-015", params: { functionName: decl.name } },
                getRuleSeverity
            );
            if (diag) diagnostics.push(diag);
        }

        // ACU-FNC-017: duplicate parameter names within a single function signature
        if (decl.params.length > 1) {
            const openParen = rawLineText.indexOf("(");
            if (openParen >= 0) {
                const seenParams = new Set();
                let remainingSection = rawLineText.substring(openParen + 1);
                let sectionOffset = 0;

                for (const param of decl.params) {
                    const nameInSection = remainingSection.toLowerCase().indexOf(param.name.toLowerCase());
                    if (nameInSection >= 0) {
                        const upperParamName = param.name.toUpperCase();
                        if (seenParams.has(upperParamName)) {
                            const charStart = openParen + 1 + sectionOffset + nameInSection;
                            const range = {
                                start: { line: lineIndex, character: charStart },
                                end:   { line: lineIndex, character: charStart + param.name.length }
                            };
                            const diag = createDiagnostic(
                                range,
                                { messageId: "ACU-FNC-017", params: { paramName: param.name, functionName: decl.name } },
                                getRuleSeverity
                            );
                            if (diag) diagnostics.push(diag);
                        } else {
                            seenParams.add(upperParamName);
                        }
                        const commaIdx = remainingSection.indexOf(",", nameInSection);
                        if (commaIdx >= 0) {
                            sectionOffset += commaIdx + 1;
                            remainingSection = remainingSection.substring(commaIdx + 1);
                        } else {
                            sectionOffset += remainingSection.length;
                            remainingSection = "";
                        }
                    }
                }
            }
        }
    }

    return diagnostics;
}
