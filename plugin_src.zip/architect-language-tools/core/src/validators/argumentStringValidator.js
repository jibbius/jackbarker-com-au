/**
 * Argument string validator for Architect.
 * Validates string-literal (and other literal-shaped) arguments passed to
 * specific built-in functions.
 *
 * Implementation: walks the document AST and inspects CALL nodes directly.
 * The expression tree already distinguishes a STRING_LITERAL token from an
 * IDENTIFIER, so no string-masking pass is needed — a literal argument is
 * exactly an `ExprNodeType.LITERAL` (or DATE/TIME) child of a CALL node.
 *
 * History: this validator originally regex-scanned each line after running it
 * through `maskStringLiterals` to ignore in-string occurrences of function
 * names. The migration to AST traversal (2026-04-28) is the pilot referenced
 * by `planning/ideas/ast-migration-of-string-mask-callers.md`.
 */

import { ExprNodeType } from "../ast/expressionNodes.js";
import { parseExpression } from "../ast/expressionParser.js";
import { walkCalls, nodeRange, collectAllSpans } from "../ast/astHelpers.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";
import { isValidTableSynonym, getHPrefixSuggestion } from "../builtins/tableRegistry.js";
import { BuiltInFunctions, isBuiltInGlobalVariable } from "../builtins/functions.js";

const VALID_CURSOR_DIRECTIONS = new Set([">=", ">", "+", "=", "-", "<", "<="]);
const CURSOR_DIRECTION_SUGGESTIONS = { "=>": ">=", "=<": "<=" };

const DATE_PATTERN = /^(\d{2})\/(\d{2})\/(\d{4})$/;
const MAX_DATE_YEAR = 9998;

const TABLE_SYNONYM_FUNCTIONS = new Set([
    "INDEX_SAVE_POSITION",
    "INDEX_RESTORE_POSITION",
    "INDEX_OPEN_STANDARD",
    "INDEX_OPEN_CUSTOM",
    "SQL_INDEX_OPEN_STANDARD"
]);

const INDEX_READ_BY_KEY_FUNCTIONS = new Set([
    "INDEX_READ_BY_KEY",
    "SQL_INDEX_READ_BY_KEY"
]);

// ---------------------------------------------------------------------------
// AST helpers
// ---------------------------------------------------------------------------

/**
 * Returns true when an expression node is a quoted-string literal.
 * The lexer produces STRING_LITERAL tokens with the surrounding quotes
 * preserved in token.value.
 */
function isStringLiteralNode(node) {
    return node
        && node.type === ExprNodeType.LITERAL
        && node.token
        && (node.token.value?.[0] === '"' || node.token.value?.[0] === "'");
}

/**
 * For a STRING_LITERAL expression node, returns:
 *   { value, start, end }
 * where `value` is the unquoted content, `start` is the column of the opening
 * quote and `end` is one past the closing quote.
 *
 * Mirrors the original `extractStringLiteralArg` contract so that diagnostic
 * ranges line up with the previous regex-based implementation.
 */
function stringLiteralInfo(node) {
    const tok = node.token;
    const raw = tok.value;
    const start = tok.char;
    const end = tok.char + raw.length;
    // Strip the leading quote; strip the trailing quote only if the literal is
    // actually closed (the lexer leaves an unterminated string with no closing
    // quote — preserve every character of the body in that case).
    const opensWithQuote = raw.length >= 1 && (raw[0] === '"' || raw[0] === "'");
    const closesWithQuote = raw.length >= 2 && raw[raw.length - 1] === raw[0];
    const valueStart = opensWithQuote ? 1 : 0;
    const valueEnd = closesWithQuote ? raw.length - 1 : raw.length;
    return {
        value: raw.substring(valueStart, valueEnd),
        start,
        end
    };
}

/**
 * Replicates the original `isLiteralValue` predicate: trimmed argument text
 * starts with a quote, a digit (or `-` then a digit), or names a built-in
 * pseudo-constant such as MIN_STR.
 *
 * Implemented over the expression tree by inspecting the leftmost atom.
 */
function isLiteralExprArg(node) {
    if (!node) return false;
    switch (node.type) {
        case ExprNodeType.LITERAL:
        case ExprNodeType.DATE:
        case ExprNodeType.TIME:
            return true;
        case ExprNodeType.IDENTIFIER:
            return isBuiltInGlobalVariable(node.name);
        case ExprNodeType.UNARY:
            // Match the original /^-?\d/ semantics: -<numeric-literal> only.
            // -<identifier> (e.g. `-x`) is not a literal.
            if (node.op === "-") return node.operand?.type === ExprNodeType.LITERAL;
            return false;
        case ExprNodeType.BINARY:
            // Original regex matched on the leading character of the trimmed
            // argument text — preserve that by inspecting the leftmost atom.
            return isLiteralExprArg(node.left);
        case ExprNodeType.PAREN:
            return isLiteralExprArg(node.expr);
        default:
            return false;
    }
}

// ---------------------------------------------------------------------------
// Per-call checks
// ---------------------------------------------------------------------------

function checkStrToDate(callNode, lineIndex, diagnostics, getRuleSeverity) {
    const arg = callNode.args?.[0];
    if (!isStringLiteralNode(arg)) return;
    const literal = stringLiteralInfo(arg);
    const range = {
        start: { line: lineIndex, character: literal.start },
        end:   { line: lineIndex, character: literal.end }
    };

    const dateMatch = literal.value.match(DATE_PATTERN);
    if (dateMatch) {
        const day = parseInt(dateMatch[1], 10);
        const month = parseInt(dateMatch[2], 10);
        const year = parseInt(dateMatch[3], 10);

        if (day > 31 || month > 12) {
            const diag = createDiagnostic(range, { messageId: "ACU-ARG-001", params: { value: literal.value } }, getRuleSeverity);
            if (diag) diagnostics.push(diag);
            return;
        }

        if (year > MAX_DATE_YEAR) {
            const diag = createDiagnostic(range, { messageId: "ACU-ARG-002", params: { value: literal.value } }, getRuleSeverity);
            if (diag) diagnostics.push(diag);
        }
        return;
    }

    const diag = createDiagnostic(range, { messageId: "ACU-ARG-001", params: { value: literal.value } }, getRuleSeverity);
    if (diag) diagnostics.push(diag);
}

function checkIndexReadByKey(callNode, lineIndex, diagnostics, getRuleSeverity) {
    const arg = callNode.args?.[1];
    if (!isStringLiteralNode(arg)) return;
    const literal = stringLiteralInfo(arg);
    if (VALID_CURSOR_DIRECTIONS.has(literal.value)) return;

    const range = {
        start: { line: lineIndex, character: literal.start },
        end:   { line: lineIndex, character: literal.end }
    };

    const suggestion = CURSOR_DIRECTION_SUGGESTIONS[literal.value];
    if (suggestion) {
        const diag = createDiagnostic(range, { messageId: "ACU-ARG-004", params: { value: literal.value, suggestion } }, getRuleSeverity);
        if (diag) diagnostics.push(diag);
    } else {
        const diag = createDiagnostic(range, { messageId: "ACU-ARG-003", params: { value: literal.value } }, getRuleSeverity);
        if (diag) diagnostics.push(diag);
    }
}

function checkTableSynonym(callNode, lineIndex, diagnostics, getRuleSeverity) {
    const arg = callNode.args?.[0];
    if (!isStringLiteralNode(arg)) return;
    const literal = stringLiteralInfo(arg);
    if (isValidTableSynonym(literal.value)) return;

    const suggestion = getHPrefixSuggestion(literal.value);
    const params = suggestion
        ? { value: literal.value, suggestion }
        : { value: literal.value };

    const range = {
        start: { line: lineIndex, character: literal.start },
        end:   { line: lineIndex, character: literal.end }
    };
    const diag = createDiagnostic(range, { messageId: "ACU-ARG-005", params }, getRuleSeverity);
    if (diag) diagnostics.push(diag);
}

/**
 * Map of `functionName → [{ argIndex, paramLabel }, ...]` for every VAR-mode
 * parameter declared in the built-in registry. Built lazily on first access
 * rather than at module load so that tests using
 * `jest.unstable_mockModule('.../builtins/functions.js', ...)` see the mocked
 * registry — a module-load IIFE would have captured the real registry before
 * the mock took effect.
 */
let varParamChecksByFunction = null;
function getVarParamChecksByFunction() {
    if (varParamChecksByFunction !== null) return varParamChecksByFunction;
    const out = new Map();
    for (const [funcName, entry] of Object.entries(BuiltInFunctions)) {
        const params = entry.params || [];
        for (let i = 0; i < params.length; i++) {
            if (params[i]?.mode === "VAR") {
                const paramLabel = params[i].label ?? `param${i + 1}`;
                if (!out.has(funcName)) out.set(funcName, []);
                out.get(funcName).push({ argIndex: i, paramLabel });
            }
        }
    }
    varParamChecksByFunction = out;
    return varParamChecksByFunction;
}

function checkPathSeparatorLiterals(callNode, functionName, lineIndex, diagnostics, getRuleSeverity) {
    const entry = BuiltInFunctions[functionName];
    const params = entry?.params;
    if (!params) return;

    const args = callNode.args || [];
    for (let i = 0; i < args.length; i++) {
        if (params[i]?.role !== "path") continue;
        const arg = args[i];
        if (!isStringLiteralNode(arg)) continue;

        const literal = stringLiteralInfo(arg);
        const value = literal.value;
        // Skip interpolated literals — too many edge cases.
        if (value.includes("@")) continue;

        let separator = null;
        if (value.includes("/")) separator = "/";
        else if (value.includes("\\")) separator = "\\";
        if (!separator) continue;

        const range = {
            start: { line: lineIndex, character: literal.start },
            end:   { line: lineIndex, character: literal.end }
        };
        const diag = createDiagnostic(
            range,
            { messageId: "ACU-ARG-009", params: { functionName, separator } },
            getRuleSeverity
        );
        if (diag) diagnostics.push(diag);
    }
}

function checkVarParamLiterals(callNode, functionName, lineIndex, diagnostics, getRuleSeverity) {
    const checks = getVarParamChecksByFunction().get(functionName);
    if (!checks) return;

    for (const { argIndex, paramLabel } of checks) {
        const arg = callNode.args?.[argIndex];
        if (!arg) continue;
        if (!isLiteralExprArg(arg)) continue;

        const range = nodeRange(arg);
        if (!range) continue;

        const diag = createDiagnostic(
            range,
            { messageId: "ACU-ARG-008", params: { paramLabel, functionName } },
            getRuleSeverity
        );
        if (diag) diagnostics.push(diag);
    }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Validates string-literal arguments for specific built-in functions.
 * Currently checks STR_TO_DATE (date format DD/MM/YYYY),
 * INDEX_READ_BY_KEY (cursor direction),
 * INDEX_SAVE/RESTORE_POSITION / INDEX_OPEN_* (table synonyms),
 * and any VAR-mode parameter (literal where a handle is expected).
 * @param {object} document
 * @param {Function} getRuleSeverity
 * @param {Object} options
 * @returns {object[]}
 */
function validateArgumentStrings(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const executionClassificationMap = options.executionClassificationMap || null;

    const { ast } = options;
    if (!ast) throw new Error("validateArgumentStrings: options.ast is required (thread facts.ast from the dispatcher)");
    const spans = collectAllSpans(ast.statements);

    for (const { span, lineIndex } of spans) {
        if (executionClassificationMap) {
            const cls = executionClassificationMap[lineIndex];
            if (cls && (cls.isOutput || !cls.isExecutable)) continue;
        }
        const exprTree = parseExpression(span);
        if (!exprTree) continue;

        walkCalls(exprTree, (callNode) => {
            const name = callNode.callee?.name?.toUpperCase();
            if (!name) return;

            if (name === "STR_TO_DATE") {
                checkStrToDate(callNode, lineIndex, diagnostics, getRuleSeverity);
            }
            if (INDEX_READ_BY_KEY_FUNCTIONS.has(name)) {
                checkIndexReadByKey(callNode, lineIndex, diagnostics, getRuleSeverity);
            }
            if (TABLE_SYNONYM_FUNCTIONS.has(name)) {
                checkTableSynonym(callNode, lineIndex, diagnostics, getRuleSeverity);
            }
            checkVarParamLiterals(callNode, name, lineIndex, diagnostics, getRuleSeverity);
            checkPathSeparatorLiterals(callNode, name, lineIndex, diagnostics, getRuleSeverity);
        });
    }

    return diagnostics;
}

export { validateArgumentStrings };
