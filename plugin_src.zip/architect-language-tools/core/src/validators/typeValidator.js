/**
 * Type checking validator for Acurity Architect.
 * Validates type compatibility in assignments.
 *
 * Phase 3 of the expression tree plan: uses the Pratt parser + expressionTypeInference
 * to resolve source types instead of the previous ad-hoc string-scanning approach.
 */

import { ArchitectTypes, areTypesCompatible } from "../types/architectTypes.js";
import { buildTokenRange } from "../lineParser.js";
import { createDiagnostic } from "../diagnostics/diagnosticFactory.js";
import { parseExpression } from "../ast/expressionParser.js";
import { ExprNodeType } from "../ast/expressionNodes.js";
import { NodeType } from "../ast/nodes.js";
import { inferExpressionType, isNumericType } from "../analysis/expressionTypeInference.js";
import { buildVariablesMapFromSymbolTable } from "./validatorHelpers.js";
import { findFunctionScopeAtLine } from "../analysis/symbolTable.js";

// ---------------------------------------------------------------------------
// Expression walking
// ---------------------------------------------------------------------------

/**
 * Recursively collect all UNARY expression nodes within an expression tree.
 * Descends into nested unary operands so each node is independently validated.
 * @param {object|null} node
 * @param {object[]} [out]
 * @returns {object[]}
 */
function collectUnaryNodes(node, out = []) {
    if (!node) return out;
    if (node.type === ExprNodeType.UNARY) {
        out.push(node);
        collectUnaryNodes(node.operand, out);
    } else {
        if (node.operand) collectUnaryNodes(node.operand, out);
        if (node.left)    collectUnaryNodes(node.left, out);
        if (node.right)   collectUnaryNodes(node.right, out);
        if (node.expr)    collectUnaryNodes(node.expr, out);
        if (node.args)    for (const arg of node.args) collectUnaryNodes(arg, out);
    }
    return out;
}

// Arithmetic operators subject to ACU-TYPE-006 type checking.
// ** is excluded because inferBinaryType always returns DOUBLE for it regardless of operands.
const ARITHMETIC_OPS  = new Set(["+", "-", "*", "/", "MOD"]);
// Logical and comparison operators subject to ACU-TYPE-009 type checking.
const LOGICAL_OPS     = new Set(["AND", "OR"]);
const COMPARISON_OPS  = new Set(["=", "<>", "<", ">", "<=", ">="]);

/**
 * Returns true when leftType and rightType are compatible for relational comparison.
 * Compatible means: both numeric types (any combination), or both the same type
 * (with INTEGER normalised to LONG).
 * @param {string} leftType
 * @param {string} rightType
 * @returns {boolean}
 */
function areTypesComparableWith(leftType, rightType) {
    if (isNumericType(leftType) && isNumericType(rightType)) return true;
    const normLeft  = leftType  === ArchitectTypes.INTEGER ? ArchitectTypes.LONG : leftType;
    const normRight = rightType === ArchitectTypes.INTEGER ? ArchitectTypes.LONG : rightType;
    return normLeft === normRight;
}

/**
 * Recursively collect all BINARY expression nodes whose operator is an arithmetic
 * operator. Descends into sub-expressions so nested operations are also checked.
 * @param {object|null} node
 * @param {object[]} [out]
 * @returns {object[]}
 */
function collectBinaryArithmeticNodes(node, out = []) {
    if (!node) return out;
    if (node.type === ExprNodeType.BINARY) {
        if (ARITHMETIC_OPS.has(node.op?.toUpperCase?.() ?? node.op)) out.push(node);
        collectBinaryArithmeticNodes(node.left, out);
        collectBinaryArithmeticNodes(node.right, out);
    } else {
        if (node.operand) collectBinaryArithmeticNodes(node.operand, out);
        if (node.left)    collectBinaryArithmeticNodes(node.left, out);
        if (node.right)   collectBinaryArithmeticNodes(node.right, out);
        if (node.expr)    collectBinaryArithmeticNodes(node.expr, out);
        if (node.args)    for (const arg of node.args) collectBinaryArithmeticNodes(arg, out);
    }
    return out;
}

/**
 * Recursively collect all BINARY expression nodes whose operator is in the given set.
 * Descends into all sub-expressions so nested operations are also checked.
 * @param {object|null} node
 * @param {Set<string>} ops - Uppercase operator strings to match against
 * @param {object[]} [out]
 * @returns {object[]}
 */
function collectBinaryNodesWithOps(node, ops, out = []) {
    if (!node) return out;
    if (node.type === ExprNodeType.BINARY) {
        if (ops.has(node.op?.toUpperCase?.() ?? node.op)) out.push(node);
        collectBinaryNodesWithOps(node.left, ops, out);
        collectBinaryNodesWithOps(node.right, ops, out);
    } else {
        if (node.operand) collectBinaryNodesWithOps(node.operand, ops, out);
        if (node.left)    collectBinaryNodesWithOps(node.left, ops, out);
        if (node.right)   collectBinaryNodesWithOps(node.right, ops, out);
        if (node.expr)    collectBinaryNodesWithOps(node.expr, ops, out);
        if (node.args)    for (const arg of node.args) collectBinaryNodesWithOps(arg, ops, out);
    }
    return out;
}

// ---------------------------------------------------------------------------
// AST walking
// ---------------------------------------------------------------------------

/**
 * Recursively collects all AssignStatement and SetStatement nodes from an
 * array of AST statements, including those nested inside IF/DO/CASE/FUNCTION
 * blocks.
 * @param {object[]} statements
 * @param {object[]} [out]
 * @returns {object[]}
 */
function collectAssignmentNodes(statements, out = []) {
    for (const node of statements) {
        if (node.type === NodeType.AssignStatement || node.type === NodeType.SetStatement) {
            out.push(node);
        }
        if (node.consequent?.length) collectAssignmentNodes(node.consequent, out);
        if (node.alternate?.length)  collectAssignmentNodes(node.alternate, out);
        // Generic body branch covers FunctionDeclaration, DoStatement (iterator/forever/while),
        // and any other node type in collectAssignmentNodes that exposes a body statement array.
        if (Array.isArray(node.body)) collectAssignmentNodes(node.body, out);
        if (node.branches) {
            for (const branch of node.branches) {
                if (branch.body) collectAssignmentNodes(branch.body, out);
            }
        }
        if (Array.isArray(node.otherwise)) collectAssignmentNodes(node.otherwise, out);
    }
    return out;
}

/**
 * Collects expression spans from all contexts where binary-operator type checking
 * applies: assignment RHS values, IF/DO conditions, and standalone UNTIL conditions.
 * Each entry is { span, lineIndex } where span is a TokenSpan.
 * @param {object[]} statements
 * @param {object[]} [out]
 * @returns {object[]}
 */
function collectExpressionSpans(statements, out = []) {
    for (const node of statements) {
        if ((node.type === NodeType.AssignStatement || node.type === NodeType.SetStatement) && node.value) {
            out.push({ span: node.value, lineIndex: node.line });
        }
        if (node.type === NodeType.IfStatement && node.condition) {
            out.push({ span: node.condition, lineIndex: node.line });
        }
        if (node.type === NodeType.DoStatement && node.condition) {
            out.push({ span: node.condition, lineIndex: node.line });
        }
        if (node.type === NodeType.EndDoStatement && node.condition) {
            out.push({ span: node.condition, lineIndex: node.line });
        }
        if (node.consequent?.length) collectExpressionSpans(node.consequent, out);
        if (node.alternate?.length)  collectExpressionSpans(node.alternate, out);
        if (Array.isArray(node.body)) collectExpressionSpans(node.body, out);
        if (node.branches) {
            for (const branch of node.branches) {
                if (branch.body) collectExpressionSpans(branch.body, out);
            }
        }
        if (Array.isArray(node.otherwise)) collectExpressionSpans(node.otherwise, out);
    }
    return out;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Validates type compatibility in assignments across a document.
 * @param {object} document - TextDocument (VS Code or test shim)
 * @param {Function} getRuleSeverity
 * @param {object} [options]
 * @param {object} [options.symbolTable] - Symbol table from facts.symbolTable
 * @param {object} [options.userDefinedFunctionCatalog]
 * @param {object[]|null} [options.executionClassificationMap]
 * @returns {object[]} Diagnostics array
 */
function validateTypes(document, getRuleSeverity, options = {}) {
    const diagnostics = [];
    const symbolTable = options.symbolTable;
    if (!symbolTable) return diagnostics;
    const userDefinedFunctionCatalog = options.userDefinedFunctionCatalog || {};
    const executionClassificationMap = options.executionClassificationMap || null;
    const ast = options.ast;
    if (!ast) return diagnostics;

    const assignments = collectAssignmentNodes(ast.statements);

    // Cache variables maps by scope key — most assignments share the same scope.
    const variableMapCache = new Map();

    for (const node of assignments) {
        const lineIndex = node.line;

        if (executionClassificationMap && executionClassificationMap[lineIndex]?.isOutput) {
            continue;
        }

        const fnEntry = findFunctionScopeAtLine(symbolTable.functionScopes, lineIndex);
        const cacheKey = fnEntry ? String(fnEntry.startLine) : "global";

        if (!variableMapCache.has(cacheKey)) {
            variableMapCache.set(cacheKey, buildVariablesMapFromSymbolTable(symbolTable, lineIndex));
        }
        const variables = variableMapCache.get(cacheKey);
        const targetType = variables.get(node.target.toUpperCase());

        if (!targetType) {
            continue; // Undeclared variable — handled by undeclared-variable validator
        }

        const exprNode = parseExpression(node.value);
        const sourceType = inferExpressionType(exprNode, {
            variables,
            userDefinedFunctionCatalog
        });

        // ACU-TYPE-006: Arithmetic operator applied to incompatible operand types.
        // Check: both operand types known (non-null) but the operation returns null
        // (inferBinaryType propagates null for unknown types, so both-known-but-null
        //  means a genuine type incompatibility, not just missing information).
        for (const binaryNode of collectBinaryArithmeticNodes(exprNode)) {
            const leftType  = inferExpressionType(binaryNode.left,  { variables, userDefinedFunctionCatalog });
            const rightType = inferExpressionType(binaryNode.right, { variables, userDefinedFunctionCatalog });
            if (leftType === null || rightType === null) continue; // unknown type — skip to avoid false positives
            const resultType = inferExpressionType(binaryNode, { variables, userDefinedFunctionCatalog });
            if (resultType !== null) continue; // valid combination
            const opTok = binaryNode.token;
            if (!opTok) continue;
            const diag = createDiagnostic(
                {
                    start: { line: lineIndex, character: opTok.char },
                    end:   { line: lineIndex, character: opTok.char + (opTok.value?.length ?? 1) }
                },
                { messageId: "ACU-TYPE-006", params: { op: binaryNode.op, leftType, rightType } },
                getRuleSeverity
            );
            if (diag) diagnostics.push(diag);
        }

        if (sourceType && !areTypesCompatible(targetType, sourceType)) {
            const lineText = document.lineAt(lineIndex).text;
            const diag = createDiagnostic(
                buildTokenRange(lineText, lineIndex, node.target, 0),
                {
                    messageId: "ACU-TYPE-002",
                    params: { sourceType, targetType, target: node.target }
                },
                getRuleSeverity
            );
            if (diag) {
                diagnostics.push(diag);
            }
        }
    }

    // ACU-TYPE-009: AND/OR on non-BOOLEAN operands; relational comparison between
    // incompatible types. Checked across all expression contexts (assignments,
    // IF/DO conditions, standalone UNTIL conditions).
    const expressionSpans = collectExpressionSpans(ast.statements);

    for (const { span, lineIndex } of expressionSpans) {
        if (executionClassificationMap && executionClassificationMap[lineIndex]?.isOutput) {
            continue;
        }

        const fnEntry = findFunctionScopeAtLine(symbolTable.functionScopes, lineIndex);
        const cacheKey = fnEntry ? String(fnEntry.startLine) : "global";

        if (!variableMapCache.has(cacheKey)) {
            variableMapCache.set(cacheKey, buildVariablesMapFromSymbolTable(symbolTable, lineIndex));
        }
        const variables = variableMapCache.get(cacheKey);

        const exprNode = parseExpression(span);
        if (!exprNode) continue;

        // AND/OR: both operands must be BOOLEAN
        for (const logicalNode of collectBinaryNodesWithOps(exprNode, LOGICAL_OPS)) {
            const leftType  = inferExpressionType(logicalNode.left,  { variables, userDefinedFunctionCatalog });
            const rightType = inferExpressionType(logicalNode.right, { variables, userDefinedFunctionCatalog });
            if (leftType === null || rightType === null) continue;
            if (leftType === ArchitectTypes.BOOLEAN && rightType === ArchitectTypes.BOOLEAN) continue;
            const opTok = logicalNode.token;
            if (!opTok) continue;
            const diag = createDiagnostic(
                {
                    start: { line: lineIndex, character: opTok.char },
                    end:   { line: lineIndex, character: opTok.char + (opTok.value?.length ?? 3) }
                },
                { messageId: "ACU-TYPE-009", params: { op: logicalNode.op, leftType, rightType } },
                getRuleSeverity
            );
            if (diag) diagnostics.push(diag);
        }

        // Relational comparisons: operand types must be mutually comparable
        for (const compNode of collectBinaryNodesWithOps(exprNode, COMPARISON_OPS)) {
            const leftType  = inferExpressionType(compNode.left,  { variables, userDefinedFunctionCatalog });
            const rightType = inferExpressionType(compNode.right, { variables, userDefinedFunctionCatalog });
            if (leftType === null || rightType === null) continue;
            if (areTypesComparableWith(leftType, rightType)) continue;
            const opTok = compNode.token;
            if (!opTok) continue;
            const diag = createDiagnostic(
                {
                    start: { line: lineIndex, character: opTok.char },
                    end:   { line: lineIndex, character: opTok.char + (opTok.value?.length ?? 1) }
                },
                { messageId: "ACU-TYPE-009", params: { op: compNode.op, leftType, rightType } },
                getRuleSeverity
            );
            if (diag) diagnostics.push(diag);
        }

        // ACU-TYPE-004: NOT applied to a non-BOOLEAN operand
        // ACU-TYPE-005: Unary minus applied to a non-numeric operand
        // Checked across all expression contexts (assignments and conditions).
        for (const unaryNode of collectUnaryNodes(exprNode)) {
            const upperOp = unaryNode.op.toUpperCase();
            const operandType = inferExpressionType(unaryNode.operand, {
                variables,
                userDefinedFunctionCatalog
            });
            if (operandType === null) continue;

            if (upperOp === "NOT" && operandType !== ArchitectTypes.BOOLEAN) {
                const kwChar = unaryNode.token ? unaryNode.token.char : 0;
                const diag = createDiagnostic(
                    {
                        start: { line: lineIndex, character: kwChar },
                        end:   { line: lineIndex, character: kwChar + 3 }
                    },
                    { messageId: "ACU-TYPE-004", params: { operandType } },
                    getRuleSeverity
                );
                if (diag) diagnostics.push(diag);
            }

            if (unaryNode.op === "-" && !isNumericType(operandType)) {
                const kwChar = unaryNode.token ? unaryNode.token.char : 0;
                const diag = createDiagnostic(
                    {
                        start: { line: lineIndex, character: kwChar },
                        end:   { line: lineIndex, character: kwChar + 1 }
                    },
                    { messageId: "ACU-TYPE-005", params: { operandType } },
                    getRuleSeverity
                );
                if (diag) diagnostics.push(diag);
            }
        }
    }

    return diagnostics;
}

export { validateTypes };
