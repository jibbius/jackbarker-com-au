/**
 * Shared AST traversal helpers.
 *
 * Two layers:
 *   - Statement-level walkers (walkStatements, collectStatementValueSpans,
 *     collectAllSpans).
 *   - Expression-level walkers (walkCalls) and per-node positioning
 *     helpers (firstToken, leftmostToken, rightmostToken, nodeRange).
 *
 * These were previously duplicated across argumentTypeValidator,
 * sqlUsageValidator and argumentStringValidator. Consolidating them here
 * makes the call-site-walking pattern obvious for future migrations from
 * raw-text scans (see `planning/ideas/ast-migration-of-string-mask-callers.md`).
 */

import { NodeType } from "./nodes.js";
import { ExprNodeType } from "./expressionNodes.js";

// ---------------------------------------------------------------------------
// Statement-level traversal
// ---------------------------------------------------------------------------

/**
 * Visits every statement in a tree depth-first, calling visitor(stmt) for each node.
 * Recurses into all standard nested statement lists:
 *   body, consequent, alternate, branches[*].body, otherwise
 *
 * The visitor receives (stmt, index, siblings) and may return false to prevent
 * recursion into that node's children. All other return values allow recursion.
 *
 * Example — collect all ReturnStatements without crossing function boundaries:
 *
 *   const returns = [];
 *   walkStatements(body, stmt => {
 *       if (stmt.type === NodeType.ReturnStatement) returns.push(stmt);
 *       if (stmt.type === NodeType.FunctionDeclaration) return false;
 *   });
 *
 * @param {object[]} statements
 * @param {function(stmt: object, index: number, siblings: object[]): boolean|void} visitor
 */
function walkStatements(statements, visitor) {
    for (let i = 0; i < statements.length; i++) {
        const stmt = statements[i];
        const descend = visitor(stmt, i, statements);
        if (descend === false) continue;
        if (Array.isArray(stmt.body))       walkStatements(stmt.body,       visitor);
        if (Array.isArray(stmt.consequent)) walkStatements(stmt.consequent, visitor);
        if (Array.isArray(stmt.alternate))  walkStatements(stmt.alternate,  visitor);
        if (stmt.branches) {
            for (const b of stmt.branches) {
                if (Array.isArray(b.body)) walkStatements(b.body, visitor);
            }
        }
        if (Array.isArray(stmt.otherwise))  walkStatements(stmt.otherwise,  visitor);
    }
}

const VALUE_BEARING_TYPES = new Set([
    NodeType.AssignStatement,
    NodeType.SetStatement,
    NodeType.ExpressionStatement,
    NodeType.FunctionCallStatement,
]);

/**
 * Collects `{ span, lineIndex }` from every value-bearing statement
 * (Assign / Set / Expression / FunctionCall). Does NOT include conditions,
 * subjects, iterator clauses or branch values — use `collectAllSpans` for
 * full coverage.
 *
 * Mirrors the behaviour previously inlined in argumentTypeValidator and
 * sqlUsageValidator, where SQL/type checks intentionally only inspected
 * statement RHS expressions.
 */
function collectStatementValueSpans(statements, out = []) {
    walkStatements(statements, (stmt) => {
        if (VALUE_BEARING_TYPES.has(stmt.type) && stmt.value) {
            out.push({ span: stmt.value, lineIndex: stmt.line });
        }
    });
    return out;
}

/**
 * Collects every token-span on every statement that could contain a callable
 * expression: `value`, `condition`, `subject`, `options`, `iterator.{start,to,by}`
 * and CASE-branch `values[*]`. Use this when you would have line-iterated the
 * raw document text — it preserves that coverage over the AST.
 */
function collectAllSpans(statements, out = []) {
    walkStatements(statements, (stmt) => {
        if (stmt.value)     out.push({ span: stmt.value,     lineIndex: stmt.line });
        if (stmt.condition) out.push({ span: stmt.condition, lineIndex: stmt.line });
        if (stmt.subject)   out.push({ span: stmt.subject,   lineIndex: stmt.line });
        if (stmt.options)   out.push({ span: stmt.options,   lineIndex: stmt.line });
        if (stmt.iterator) {
            if (stmt.iterator.start) out.push({ span: stmt.iterator.start, lineIndex: stmt.line });
            if (stmt.iterator.to)    out.push({ span: stmt.iterator.to,    lineIndex: stmt.line });
            if (stmt.iterator.by)    out.push({ span: stmt.iterator.by,    lineIndex: stmt.line });
        }
        if (Array.isArray(stmt.branches)) {
            for (const branch of stmt.branches) {
                if (Array.isArray(branch.values)) {
                    for (const v of branch.values) {
                        if (v) out.push({ span: v, lineIndex: stmt.line });
                    }
                }
            }
        }
    });
    return out;
}

// ---------------------------------------------------------------------------
// Expression-level traversal
// ---------------------------------------------------------------------------

/**
 * Visits every node in an expression tree depth-first, calling visitor(node)
 * for each — leaves included. Recurses through every child slot the
 * expression nodes use: `operand`, `left`, `right`, `expr`, `args[*]`. Safe
 * to call with a null/undefined `node`.
 *
 * Use this when you want to collect or inspect arbitrary expression nodes
 * (literals, identifiers, binary operators with a specific op, etc.). For
 * the common "visit only CALL nodes" pattern, prefer `walkCalls` — it's a
 * specialisation of this walk that skips non-CALL nodes for ergonomics.
 */
function walkExpression(node, visitor) {
    if (!node) return;
    visitor(node);
    if (node.operand) walkExpression(node.operand, visitor);
    if (node.left)    walkExpression(node.left, visitor);
    if (node.right)   walkExpression(node.right, visitor);
    if (node.expr)    walkExpression(node.expr, visitor);
    if (node.args)    for (const arg of node.args) walkExpression(arg, visitor);
}

/**
 * Visits every CALL node in an expression tree, recursing into BINARY/UNARY/
 * PAREN children and into the arguments of each visited CALL.
 *
 * A specialisation of `walkExpression` that skips non-CALL nodes — kept as a
 * separate helper because call-only traversal is the most common pattern and
 * the call-only signature reads more clearly at the call site.
 */
function walkCalls(node, visitor) {
    if (!node) return;
    switch (node.type) {
        case ExprNodeType.CALL:
            visitor(node);
            for (const arg of node.args || []) walkCalls(arg, visitor);
            break;
        case ExprNodeType.BINARY:
            walkCalls(node.left, visitor);
            walkCalls(node.right, visitor);
            break;
        case ExprNodeType.UNARY:
            walkCalls(node.operand, visitor);
            break;
        case ExprNodeType.PAREN:
            walkCalls(node.expr, visitor);
            break;
        default:
            break;
    }
}

// ---------------------------------------------------------------------------
// Token positioning
// ---------------------------------------------------------------------------

/**
 * Returns the *characteristic* token of a node — the operator for BINARY/UNARY,
 * the open-paren for PAREN, the callee for CALL. Non-recursive.
 *
 * Use this when you want to underline the operator/keyword/callee of a
 * complex expression (e.g. ACU-FNC-009 highlights the arg's defining token).
 * Use `leftmostToken` instead when you want the very first source character.
 */
function firstToken(node) {
    if (!node) return null;
    if (node.token) return node.token;
    if (node.callee?.token) return node.callee.token;
    if (node.startToken) return node.startToken;
    return null;
}

/**
 * Recursively returns the leftmost source token of an expression node.
 * Distinct from `firstToken` for BINARY (returns leftmost operand, not the
 * operator) and CALL (returns the callee).
 */
function leftmostToken(node) {
    if (!node) return null;
    switch (node.type) {
        case ExprNodeType.LITERAL:
        case ExprNodeType.DATE:
        case ExprNodeType.TIME:
        case ExprNodeType.IDENTIFIER:
            return node.token;
        case ExprNodeType.UNARY:
            return node.token;
        case ExprNodeType.BINARY:
            return leftmostToken(node.left);
        case ExprNodeType.PAREN:
            return node.token;
        case ExprNodeType.CALL:
            return node.callee?.token || node.startToken;
        default:
            return node.token || null;
    }
}

/**
 * Recursively returns the rightmost source token of an expression node.
 */
function rightmostToken(node) {
    if (!node) return null;
    switch (node.type) {
        case ExprNodeType.LITERAL:
        case ExprNodeType.DATE:
        case ExprNodeType.TIME:
        case ExprNodeType.IDENTIFIER:
            return node.token;
        case ExprNodeType.UNARY:
            return rightmostToken(node.operand) || node.token;
        case ExprNodeType.BINARY:
            return rightmostToken(node.right);
        case ExprNodeType.PAREN:
            return rightmostToken(node.expr) || node.token;
        case ExprNodeType.CALL:
            return node.endToken || node.startToken;
        default:
            return node.token || null;
    }
}

/**
 * LSP-style range covering the full token span of an expression node,
 * derived from leftmostToken/rightmostToken.
 */
function nodeRange(node) {
    const left = leftmostToken(node);
    const right = rightmostToken(node);
    if (!left || !right) return null;
    return {
        start: { line: left.line, character: left.char },
        end:   { line: right.line, character: right.char + (right.value?.length ?? 1) }
    };
}

export {
    walkStatements,
    collectStatementValueSpans,
    collectAllSpans,
    walkExpression,
    walkCalls,
    firstToken,
    leftmostToken,
    rightmostToken,
    nodeRange,
};
