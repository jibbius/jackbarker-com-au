/**
 * collectDiagnostics — pure validation orchestration for an Architect document.
 *
 * Has no dependency on VS Code. Consumed by:
 *   - vscode-extension/src/diagnostics.js  (passes getRuleSeverity from workspace config)
 *   - cli/index.js                          (passes getRuleSeverity from catalog defaults)
 *
 * @param {object} document       VS Code TextDocument or PlainTextDocument
 * @param {function} getRuleSeverity  (ruleId: string) => number|null
 * @param {object} [options]
 * @param {string|null} [options.workspaceRoot]  Absolute path to the workspace root
 * @returns {object[]}  Array of diagnostic plain objects
 */

import { getTableStructure, isKnownTableStructure } from "./builtins/tableRegistry.js";
import * as logger from "./logger.js";
import { collectDocumentFacts } from "./analysis/documentFacts.js";
import { getSupplementaryValidators } from "./supplementaryLoader.js";
import { createTelemetryRun } from "./telemetry.js";
import { validateBlockStructure } from "./validators/structureValidator.js";
import { validateTypes } from "./validators/typeValidator.js";
import { validateNamingConventions } from "./validators/namingValidator.js";
import { validateStringInterpolation } from "./validators/interpolationValidator.js";
import { validateFunctionCalls, validateFunctionDeclarations } from "./validators/functionValidator.js";
import { validateMacros } from "./validators/macroValidator.js";
import { validateIndexUsage } from "./validators/indexUsageValidator.js";
import { validateArrayUsage } from "./validators/arrayUsageValidator.js";
import { validateRobodoc } from "./validators/robodocValidator.js";
import { validateKeywordCapitalization } from "./validators/keywordCapsValidator.js";
import { validateTypeKeywordCapitalization } from "./validators/typeKeywordCapsValidator.js";
import { validateDiscouragedTypes } from "./validators/discouragedTypeValidator.js";
import { validateDiscouragedLiterals } from "./validators/discouragedLiteralValidator.js";
import { validateDoIterators } from "./validators/doIteratorValidator.js";
import { validateVarDeclarations } from "./validators/varDeclarationValidator.js";
import { validateBreakLevels } from "./validators/breakLevelValidator.js";
import { validateVariableUsage } from "./validators/variableValidator.js";
import { validateIncludes } from "./validators/includeValidator.js";
import { validateHashMode } from "./validators/hashModeValidator.js";
import { validateOptionDirectives } from "./validators/optionValidator.js";
import { validateArgumentStrings } from "./validators/argumentStringValidator.js";
import { validateTodoTags } from "./validators/todoValidator.js";
import { validateBlockIndentation } from "./validators/indentationValidator.js";
import { validateArgumentTypes } from "./validators/argumentTypeValidator.js";
import { validateExitStatements } from "./validators/exitStatementValidator.js";
import { validateOperatorSpacing } from "./validators/operatorSpacingValidator.js";
import { validateReturnTypes, validateDiscardedResults } from "./validators/functionReturnTypeValidator.js";
import { validateFunctionWhitespace } from "./validators/functionWhitespaceValidator.js";
import { validateVarEol } from "./validators/varEolValidator.js";
import { validateSqlUsage } from "./validators/sqlUsageValidator.js";
import { buildSuppressionMap, isSuppressed } from "./suppressionParser.js";
import { isSuppressable } from "./diagnostics/diagnosticCatalog.js";
import { createDiagnostic as _createDiagnostic } from "./diagnostics/diagnosticFactory.js";

function collectDiagnostics(document, getRuleSeverity, options = {}) {
    const workspaceRoot  = options.workspaceRoot  ?? null;
    const namingConfig   = options.namingConfig   ?? null;
    const robodocConfig  = options.robodocConfig  ?? null;

    logger.log("Validating document:", document.fileName || document.uri?.fsPath);
    const telemetry = createTelemetryRun("diagnostics.run", {
        file: document.fileName || document.uri?.fsPath,
        lineCount: document.lineCount
    });

    /**
     * Runs a single validator, wrapping it in telemetry phase timing and error isolation.
     * On error, logs the failure and returns an empty array so validation continues.
     * @param {string} phase - Telemetry phase name (e.g. "validator.block")
     * @param {Function} validatorFn - Zero-arg function that returns diagnostic[]
     * @param {string} [label] - When provided, logs the diagnostic count at DEBUG level
     * @returns {object[]}
     */
    function runValidator(phase, validatorFn, label) {
        telemetry?.startPhase(phase);
        try {
            const result = validatorFn();
            telemetry?.endPhase(phase);
            if (!Array.isArray(result)) {
                logger.warn(`${phase} (${label ?? phase}) returned unexpected value (expected array):`, result);
                return [];
            }
            if (label) logger.log(`${label} returned diagnostics:`, result.length);
            return result;
        } catch (error) {
            telemetry?.endPhase(phase);
            logger.error(`${phase} error:`, { message: error?.message, stack: error?.stack });
            return [];
        }
    }

    const diagnostics = [];

    telemetry?.startPhase("facts.collect");
    const facts = collectDocumentFacts(document);
    telemetry?.endPhase("facts.collect");
    const { functionScopes, userDefinedFunctionCatalog, includedVariablesByLine } = facts;

    diagnostics.push(...runValidator("include.issues", () => validateIncludes(document, getRuleSeverity)));
    diagnostics.push(...runValidator("hash-mode", () => validateHashMode(document, getRuleSeverity, {
        executionClassificationMap: facts.executionClassificationMap,
        tokens: facts.tokens
    })));
    diagnostics.push(...runValidator("validator.option", () => validateOptionDirectives(document, getRuleSeverity)));

    diagnostics.push(...runValidator("validator.block",
        () => validateBlockStructure(document, getRuleSeverity, { executionClassificationMap: facts.executionClassificationMap })));
    diagnostics.push(...runValidator("validator.blockIndentation",
        () => validateBlockIndentation(document, getRuleSeverity, { executionClassificationMap: facts.executionClassificationMap })));
    diagnostics.push(...runValidator("validator.keywordCaps",
        () => validateKeywordCapitalization(document, getRuleSeverity, { executionClassificationMap: facts.executionClassificationMap })));
    diagnostics.push(...runValidator("validator.typeKeywordCaps",
        () => validateTypeKeywordCapitalization(document, getRuleSeverity, { executionClassificationMap: facts.executionClassificationMap })));
    diagnostics.push(...runValidator("validator.discouragedTypes",
        () => validateDiscouragedTypes(document, getRuleSeverity, { executionClassificationMap: facts.executionClassificationMap })));
    diagnostics.push(...runValidator("validator.discouragedLiterals",
        () => validateDiscouragedLiterals(document, getRuleSeverity, { executionClassificationMap: facts.executionClassificationMap })));
    diagnostics.push(...runValidator("validator.doIterators",
        () => validateDoIterators(document, getRuleSeverity, { ast: facts.ast })));
    diagnostics.push(...runValidator("validator.varDeclarations",
        () => validateVarDeclarations(document, getRuleSeverity, {
            ast: facts.ast,
            userDefinedFunctionCatalog: facts.userDefinedFunctionCatalog,
            macroCatalog: facts.macroCatalog
        })));
    diagnostics.push(...runValidator("validator.breakLevels",
        () => validateBreakLevels(document, getRuleSeverity, { ast: facts.ast })));
    diagnostics.push(...runValidator("validator.type", () => validateTypes(document, getRuleSeverity, {
        ast: facts.ast,
        symbolTable: facts.symbolTable,
        userDefinedFunctionCatalog,
        executionClassificationMap: facts.executionClassificationMap
    })));
    diagnostics.push(...runValidator("validator.argumentType", () => validateArgumentTypes(document, getRuleSeverity, {
        symbolTable: facts.symbolTable,
        userDefinedFunctionCatalog,
        executionClassificationMap: facts.executionClassificationMap
    })));
    diagnostics.push(...runValidator("validator.naming",
        () => validateNamingConventions(document, getRuleSeverity, { symbolTable: facts.symbolTable, namingConfig })));
    diagnostics.push(...runValidator("validator.interpolation", () => validateStringInterpolation(document, getRuleSeverity, {
        symbolTable: facts.symbolTable,
        executionClassificationMap: facts.executionClassificationMap,
        outputDelimiters: facts.outputDelimiters,
        interpolationTargetsByLine: facts.interpolationTargetsByLine,
        includedVariablesByLine: facts.includedVariablesByLine
    })));

    diagnostics.push(...runValidator("validator.functionDeclarations",
        () => validateFunctionDeclarations(document, getRuleSeverity)));
    diagnostics.push(...runValidator("validator.function", () => validateFunctionCalls(document, getRuleSeverity, {
        outputDelimiters: facts.outputDelimiters,
        executionClassificationMap: facts.executionClassificationMap,
        functionValidationTargetsByLine: facts.functionValidationTargetsByLine,
        userDefinedFunctionCatalog: facts.userDefinedFunctionCatalog,
        userDefinedFunctionCaseMap: facts.userDefinedFunctionCaseMap,
        functionDuplicates: facts.functionDuplicates,
        includedFunctionsByLine: facts.includedFunctionsByLine,
        includedFunctionCaseMapByLine: facts.includedFunctionCaseMapByLine,
        macroCatalog: facts.macroCatalog,
        nodeTypeByLine: facts.nodeTypeByLine,
        stmtByLine: facts.stmtByLine,
        pagewidth: facts.optionSettings?.pagewidth ?? 16000
    }), "Function validator"));
    diagnostics.push(...runValidator("validator.returnType",
        () => validateReturnTypes(document, getRuleSeverity, { functionScopes: facts.functionScopes, userDefinedFunctionCatalog: facts.userDefinedFunctionCatalog }),
        "Return-type validator"));
    diagnostics.push(...runValidator("validator.discardedResult",
        () => validateDiscardedResults(document, getRuleSeverity, {
            userDefinedFunctionCatalog: facts.userDefinedFunctionCatalog,
            executionClassificationMap: facts.executionClassificationMap
        })));
    diagnostics.push(...runValidator("validator.macro", () => validateMacros(document, getRuleSeverity, {
        macroCatalog: facts.macroCatalog,
        macroCaseMap: facts.macroCaseMap,
        macroDuplicates: facts.macroDuplicates,
        executionClassificationMap: facts.executionClassificationMap
    }), "Macro validator"));
    diagnostics.push(...runValidator("validator.indexUsage", () => validateIndexUsage(document, getRuleSeverity, {
        functionScopes: facts.functionScopes,
        executionClassificationMap: facts.executionClassificationMap,
        tableStructures: options.tableStructures ?? null
    }), "Index usage validator"));
    diagnostics.push(...runValidator("validator.arrayUsage", () => validateArrayUsage(document, getRuleSeverity, {
        functionScopes: facts.functionScopes,
        executionClassificationMap: facts.executionClassificationMap
    }), "Array usage validator"));
    diagnostics.push(...runValidator("validator.robodoc",
        () => validateRobodoc(document, getRuleSeverity, { robodocConfig }),
        "ROBODOC validator"));
    diagnostics.push(...runValidator("validator.argumentStrings", () => validateArgumentStrings(document, getRuleSeverity, {
        executionClassificationMap: facts.executionClassificationMap
    }), "Argument string validator"));
    diagnostics.push(...runValidator("validator.exitStatement",
        () => validateExitStatements(document, getRuleSeverity, { mode: facts.mode, ast: facts.ast })));
    diagnostics.push(...runValidator("validator.operatorSpacing", () => validateOperatorSpacing(document, getRuleSeverity, {
        executionClassificationMap: facts.executionClassificationMap
    })));
    diagnostics.push(...runValidator("validator.functionWhitespace", () => validateFunctionWhitespace(document, getRuleSeverity, {
        executionClassificationMap: facts.executionClassificationMap
    })));
    diagnostics.push(...runValidator("validator.varEol", () => validateVarEol(document, getRuleSeverity, {
        executionClassificationMap: facts.executionClassificationMap
    })));
    diagnostics.push(...runValidator("validator.todo", () => validateTodoTags(document, getRuleSeverity, {
        executionClassificationMap: facts.executionClassificationMap
    }), "TODO validator"));
    diagnostics.push(...runValidator("variables.usage",
        () => validateVariableUsage(document, getRuleSeverity, { facts })));
    diagnostics.push(...runValidator("validator.sqlUsage",
        () => validateSqlUsage(document, getRuleSeverity)));

    telemetry?.startPhase("suppression.filter");
    const suppressionMap = buildSuppressionMap(document);
    const unsuppressed = diagnostics.filter((d) => {
        const messageId = d.data?.messageId;
        if (!messageId) return true;
        if (!isSuppressable(messageId)) return true;
        return !isSuppressed(messageId, d.range.start.line, suppressionMap);
    });
    telemetry?.endPhase("suppression.filter");

    telemetry?.emit({ diagnosticsCount: unsuppressed.length });

    return unsuppressed;
}

/**
 * Async variant of collectDiagnostics that pre-loads table structures referenced
 * in INDEX_OPEN_STANDARD calls before delegating to the sync orchestrator.
 *
 * @param {object} document       VS Code TextDocument or PlainTextDocument
 * @param {function} getRuleSeverity  (ruleId: string) => number|null
 * @param {object} [options]      Same options as collectDiagnostics
 * @returns {Promise<object[]>}   Array of diagnostic plain objects
 */
async function collectDiagnosticsAsync(document, getRuleSeverity, options = {}) {
    const text = document.getText();
    const foundCodes = new Set();
    let m;

    // Scan for INDEX_OPEN_STANDARD / SQL_INDEX_OPEN_STANDARD("CODE", ...) literals.
    const tableCodePattern = /(?:SQL_)?INDEX_OPEN_STANDARD\s*\(\s*["']([A-Za-z0-9_]+)["']/g;
    while ((m = tableCodePattern.exec(text)) !== null) {
        const code = m[1].toUpperCase();
        if (isKnownTableStructure(code)) foundCodes.add(code);
    }

    // Scan for field handle prefixes (hXXy_) to pre-load table structures needed
    // by the variable validator.  Matching hXX at the start of a handle is enough
    // to identify the table — the rest of the pattern guards against false positives.
    const fieldHandlePattern = /\bh([A-Za-z][A-Za-z0-9])[A-Za-z]_/g;
    while ((m = fieldHandlePattern.exec(text)) !== null) {
        const code = m[1].toUpperCase();
        if (isKnownTableStructure(code)) foundCodes.add(code);
    }

    const tableStructures = {};
    for (const code of foundCodes) {
        try {
            const structure = await getTableStructure(code);
            if (structure) tableStructures[code] = structure;
        } catch (err) {
            logger.warn(`collectDiagnosticsAsync: failed to load table structure for ${code}:`, err?.message);
        }
    }

    const processedDiagnostics = collectDiagnostics(document, getRuleSeverity, { ...options, tableStructures });

    // Run supplementary validators (additive — cannot suppress built-in diagnostics,
    // but their own diagnostics participate in the full validation pipeline:
    // getRuleSeverity is passed in so they can emit via createDiagnostic, and their
    // output is filtered through the same @rule-ignore suppression map as core.
    const supplementaryValidators = getSupplementaryValidators();
    if (supplementaryValidators.length === 0) {
        return processedDiagnostics;
    }

    // Re-use the memoized facts already computed during the built-in pass.
    const facts = collectDocumentFacts(document);
    const filePath = document.fileName ?? document.uri?.fsPath ?? null;
    const context = {
        facts,
        filePath,
        config: options.config ?? null,
        getRuleSeverity,
        // Injected so supplementary validators can emit catalog-driven diagnostics
        // without a static import from core — installed companion extensions live
        // in a different path on disk than the sibling dev layout.
        createDiagnostic: (range, diagConfig) => _createDiagnostic(range, diagConfig, getRuleSeverity)
    };

    const supplementaryDiagnostics = [];
    for (let i = 0; i < supplementaryValidators.length; i++) {
        try {
            const result = await supplementaryValidators[i](document, context);
            if (Array.isArray(result)) {
                supplementaryDiagnostics.push(...result);
            } else {
                logger.warn(`supplementaryLoader: validator[${i}] returned a non-array — ignored.`);
            }
        } catch (err) {
            logger.error(`supplementaryLoader: validator[${i}] threw:`, { message: err?.message, stack: err?.stack });
        }
    }

    const suppressionMap = buildSuppressionMap(document);
    const unsuppressedSupplementary = supplementaryDiagnostics.filter((d) => {
        const messageId = d.data?.messageId ?? d.code;
        if (!messageId) return true;
        if (!isSuppressable(messageId)) return true;
        return !isSuppressed(messageId, d.range.start.line, suppressionMap);
    });

    return [...processedDiagnostics, ...unsuppressedSupplementary];
}

export { collectDiagnostics, collectDiagnosticsAsync };
