# builtins-data

Language-neutral source of truth for the built-in registries that the
Architect language server consumes. Lives at the product-layer root so a
future non-JS core can point at the same files.

## Layout

```
builtins-data/
├── schemas/
│   ├── global-variable.schema.json
│   └── table.schema.json
├── global-variables/
│   ├── <NAME>.json          ← one entry per file
│   └── ...
├── tables/
│   ├── <CODE>.json          ← one entry per file (stem = 2-character code)
│   └── ...
├── global-variables.bundle.json   ← built artefact (gitignored)
└── tables.bundle.json             ← built artefact (gitignored)
```

## Adding a new table

1. Create `builtins-data/tables/<CODE>.json`.
   - Use any existing entry as a template (e.g. `MD.json`).
   - The file's stem (`<CODE>`) must equal the entry's `code` field —
     a 2-character uppercase code (digits permitted, e.g. `D2`, `T4`).
   - The `$schema` reference enables VS Code autocomplete and inline
     validation while editing.
2. Run `npm run validate:builtins` to check the entry against the schema.
3. (Optional) Run `npm run build:builtins` to refresh the bundle.

The loader at `core/src/builtins/tableRegistry.js` picks up the new
entry on the next process start. The same JSON file also carries the
optional `recordLength`, `helpPage`, `indexes`, and `fields` blocks —
add those alongside `code`/`name` if you have authoritative data.

## Adding a new global variable

1. Create `builtins-data/global-variables/<NAME>.json`.
   - Use any existing entry as a template (e.g. `PK_INDEX.json`).
   - The file's stem (`<NAME>`) must equal the entry's `name` field.
   - The `$schema` reference enables VS Code autocomplete and inline
     validation while editing.
2. Run `npm run validate:builtins` to check the entry against the schema.
3. (Optional) Run `npm run build:builtins` to refresh the bundle.

The loader at `core/src/builtins/globalVariablesRegistry.js` picks up
the new entry on the next process start.

## Scripts

| Script | Purpose |
|---|---|
| `npm run validate:builtins` | Walks every `*.json` file and validates against its `$schema`. Also runs the legacy duplicate-key scan over `functionsRegistry.js`. Wired as `pretest`. |
| `npm run build:builtins` | Concatenates each registry directory into `<registry>.bundle.json`. Strips `$schema` from each entry. Wired as the npm `prepare` lifecycle hook. |
| `node tools/diff-builtins.js <registry> <other-data-dir>` | Reports semantic differences between two copies of a registry directory. |

## Loader contract

Loaders prefer the bundle (`<registry>.bundle.json`) when present —
single `readFile` + `JSON.parse` cold-start path. Otherwise they walk
the directory. Either path validates every entry against the schema and
fails loud at startup if anything is wrong.

## Schemas

Schemas (draft 2020-12) live under `schemas/`. The validator at
`core/src/builtins/_schemaValidator.js` is hand-rolled and intentionally
covers only the keywords the schemas use. Extend the validator
deliberately when a new schema needs a feature.

Schemas are dev-time only and **must not** ship in the VSIX or
`mcp/dist/` — only the data files do.
