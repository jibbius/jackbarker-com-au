# JSON-Based Syntax Tests

This folder uses a strict split between test input and test expectations.

- `.TXT` files contain only Acurity source.
- `.test-spec.json` files contain metadata and expected results.
- `.FIXED.TXT` files (optional) contain expected result after applying a code action.

This keeps test authors focused on language behavior, not internal validator wiring.

## Directory Structure

Tests are organized into subdirectories by category:

- **`core/`** - General integration tests (functions, types, include resolution)
- **`validators/`** - Tests for diagnostic validators (keyword capitalization, naming conventions, interpolation, etc.)
- **`code-actions/`** - Tests for quick fixes and code transformations with `.FIXED.TXT` files
- **`block-structure/`** - Tests for block structure validation (IF/ENDIF, DO/ENDDO, etc.)

The test runner recursively scans all subdirectories for `.test-spec.json` files.

## Naming

File numbering is **suite-local**. Each subfolder can start at `0001`.

- Entry/input file: `0001.TXT`
- Spec file: `0001.test-spec.json`
- Fixed file (code actions): `0001.FIXED.TXT`
- Include fixtures for a test: `0001.INCLUDE1.TXT`, `0001.INCLUDE2.TXT`, etc.

## Directory Example

```
test/syntax-tests/
├── core/
│   ├── 0001.TXT
│   ├── 0001.test-spec.json
│   └── ...
├── validators/
│   ├── 0001.TXT
│   ├── 0001.test-spec.json
│   └── ...
├── code-actions/
│   ├── 0001.TXT
│   ├── 0001.FIXED.TXT
│   ├── 0001.test-spec.json
│   └── ...
├── block-structure/
│   ├── 0001.TXT
│   ├── 0001.test-spec.json
│   └── ...
└── ...
```

## Spec Schema

### Minimal example (happy path, no diagnostics expected)

```json
{
  "schema-version": "2.0",
  "test-id": "my-rule-0001",
  "test-name": "My rule — well-formed input produces no diagnostics",
  "test-entry": "my-rule-0001.TXT",
  "assert-message-exists": [],
  "assert-message-not-exists": []
}
```

### Asserting specific diagnostics with `assert-only-listed`

```json
{
  "schema-version": "2.0",
  "test-id": "my-rule-0002",
  "test-name": "My rule — fires on bad input",
  "test-entry": "my-rule-0002.TXT",
  "assert-only-listed": true,
  "assert-message-exists": [
    { "id": "ACU-VAR-002", "line": 12, "severity": "error" },
    { "id": "ACU-STY-004", "count": 3 }
  ],
  "assert-message-not-exists": [
    { "id": "ACU-VAR-001" }
  ]
}
```

### Per-mode assertions

```json
{
  "schema-version": "2.0",
  "test-id": "my-rule-0003",
  "test-name": "My rule — severity differs between strict and default",
  "test-entry": "my-rule-0003.TXT",
  "mode-strict":  { "assert-message-exists": [{ "id": "ACU-STY-003", "severity": "error" }] },
  "mode-default": { "assert-message-exists": [{ "id": "ACU-STY-003", "severity": "warning" }] }
}
```

When any `mode-*` block is present, the runner re-runs diagnostics once per declared mode with the profile forced, applying top-level assertions plus the mode-specific assertions each time.

### TDD stub (rule not yet implemented)

```json
{
  "schema-version": "2.0",
  "test-id": "my-rule-0004",
  "test-name": "My rule — not yet implemented (STUB)",
  "test-entry": "my-rule-0004.TXT",
  "comment": "STUB: ACU-XYZ-001 is not yet implemented. This test fails until the validator is written.",
  "assert-message-not-exists": [
    { "id": "ACU-XYZ-001" }
  ]
}
```

### Code action spec (unchanged from v1.0)

```json
{
  "schema-version": "2.0",
  "test-id": "my-rule-0005",
  "test-name": "Code action - capitalize IF keyword",
  "test-entry": "my-rule-0005.TXT",
  "assert-message-exists": [
    { "id": "ACU-STY-001", "line": 3, "severity": "warning" }
  ],
  "code-action-tests": [
    {
      "diagnostic-match": "should be capitalized",
      "line": 3,
      "expected-fixed": "my-rule-0005.FIXED.TXT"
    }
  ]
}
```

### Top-level field reference

| Field | Required | Description |
|---|---|---|
| `schema-version` | Yes | `"2.0"` for new specs. |
| `test-id` | Yes | Unique within the suite folder. |
| `test-name` | Yes | Human-readable description. |
| `test-entry` | Yes | Filename of the `.TXT` input (e.g. `my-rule-0001.TXT`). |
| `description` | No | Extended free-text explanation. |
| `comment` | No | Internal note (e.g. STUB status). |
| `assert-message-exists` | No | Diagnostics that must be emitted. |
| `assert-message-not-exists` | No | Diagnostics that must NOT be emitted (file-wide; `line` is ignored). |
| `assert-only-listed` | No | If `true`, any emitted diagnostic not in `assert-message-exists` is a failure. |
| `mode-strict` | No | Assertions for a strict-profile run. |
| `mode-default` | No | Assertions for a default-profile run. |
| `mode-legacy` | No | Assertions for a legacy-profile run. |
| `code-action-tests` | No | Code action assertions (unchanged from v1.0). |

### Assertion entry fields

| Field | Description |
|---|---|
| `id` | Diagnostic rule ID (e.g. `"ACU-VAR-002"`). Preferred over `message`. |
| `message` | Substring match against the diagnostic message text. |
| `line` | 1-indexed line number. If omitted, matches any line. |
| `severity` | `"error"`, `"warning"`, or `"information"`. If omitted, any severity matches. |
| `count` | Exact number of matching diagnostics expected (`assert-message-exists` only). |
| `params` | Key-value subset of diagnostic params that must match. |

**Important**: Line numbers are 1-based (matching editor line display), even though diagnostics internally use 0-based indexing. The test runner handles this conversion automatically.

### v1.0 Legacy Format

v1.0 specs (using `expected-errors`/`expected-warnings`/`unexpected-errors`/`unexpected-warnings` and `diagnostic-match-mode`) continue to work unchanged. There is no requirement to migrate existing v1.0 specs to v2.0.

## Architectural Direction

The spec intentionally does not include a `validator` field.

The runner should behave like the plugin itself:
- load the entry file,
- run the same diagnostic pipeline the extension uses,
- compare resulting diagnostics to the spec.

This keeps the framework as a thin integration layer over real plugin behavior.

## Include Behavior Example

`0001.TXT` is based on `syntax-test-files/REPORT.TXT` and uses:
- `0001.INCLUDE1.TXT`
- `0001.INCLUDE2.TXT` (includes `0001.INCLUDE3.TXT`)

`0007.test-spec.json` asserts include-scope behavior such as:
- expected early undefined call for `include2Function`,
- expected undefined call for `blahBlah`,
- no false undefined errors for `incVar3` or `blah` from nested include scope.

## Block Structure Validation (`block-structure/0001-0003`)

These tests demonstrate line-precise validation for block structure errors:

- **0001**: Unexpected closing blocks (ENDIF/ENDDO/ENDFUNCTION) without opening blocks
- **0002**: Unclosed blocks detected at end of file  
- **0003**: Mismatched block closures (e.g., IF closed with ENDDO)

These tests use the object format to validate that diagnostics appear on the correct line, ensuring error messages guide developers to the actual problem location.
