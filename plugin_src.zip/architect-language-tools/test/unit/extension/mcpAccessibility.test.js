import { checkMcpAccessibility } from "../../../vscode-extension/src/diagnostics/mcpAccessibility.js";

function makeGet(value) {
    return (section) => {
        if (section !== "chat") return { get: () => undefined };
        return { get: (key) => (key === "mcp.access" ? value : undefined) };
    };
}

describe("checkMcpAccessibility", () => {
    test('returns status="all" with no message when setting is "all"', () => {
        const result = checkMcpAccessibility(makeGet("all"));
        expect(result).toEqual({ status: "all", message: null });
    });

    test('returns status="all" with no message when setting is undefined', () => {
        const result = checkMcpAccessibility(makeGet(undefined));
        expect(result).toEqual({ status: "all", message: null });
    });

    test('returns status="registry" with advisory message', () => {
        const result = checkMcpAccessibility(makeGet("registry"));
        expect(result.status).toBe("registry");
        expect(result.message).toMatch(/registry/);
        expect(result.message).toMatch(/standard provider API/);
    });

    test('returns status="none" with error-level message', () => {
        const result = checkMcpAccessibility(makeGet("none"));
        expect(result.status).toBe("none");
        expect(result.message).toMatch(/will not run/);
        expect(result.message).toMatch(/Non-MCP features/);
    });

    test('returns status="unknown" for an unrecognised value, including the literal in the message', () => {
        const result = checkMcpAccessibility(makeGet("future-mode-x"));
        expect(result.status).toBe("unknown");
        expect(result.message).toMatch(/future-mode-x/);
    });
});
