/**
 * Unit tests for the list_literal_comparisons agent tool.
 */

import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

import { listLiteralComparisons } from "../../../core/src/agentTools/listLiteralComparisons.js";
import { createDocumentRepository } from "../../../core/src/query/documentRepository.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const fixtureDir = path.join(__dirname, "fixtures");

async function run(fixture) {
    const repo = createDocumentRepository();
    const filePath = path.join(fixtureDir, `${fixture}.TXT`);
    const result = await listLiteralComparisons({ filePath, documentRepository: repo });
    if (result.file) result.file = path.basename(result.file);
    return result;
}

describe("agent tool: list_literal_comparisons", () => {
    test("extracts every field-handle / string-literal comparison, both operand orders", async () => {
        const result = await run("list-literal-comparisons-basic");
        expect(result.status).toBe("ok");
        expect(result.literalComparisons).toEqual([
            { handle: "MDc_Account_Status", operator: "=", value: "ACTIVE", line: 5 },
            { handle: "ABz_Client_Status", operator: "<>", value: "SUSPENDED", line: 9 },
            { handle: "CDl_Code", operator: "=", value: "42", line: 13 }
        ]);
    });

    test("returns ok with empty array for a file with no comparisons", async () => {
        const result = await run("list-symbols-basic"); // reuse existing fixture
        expect(result.status).toBe("ok");
        expect(result.literalComparisons).toEqual([]);
    });

    test("returns unknown status with reason for a missing file", async () => {
        const repo = createDocumentRepository();
        const result = await listLiteralComparisons({
            filePath: path.join(fixtureDir, "does-not-exist.TXT"),
            documentRepository: repo
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("file_not_readable");
    });
});
