/**
 * Unit tests for the list_suppressions agent tool.
 */

import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

import { listSuppressions } from "../../../core/src/agentTools/listSuppressions.js";
import { createDocumentRepository } from "../../../core/src/query/documentRepository.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const fixtureDir = path.join(__dirname, "fixtures");

async function run(fixture) {
    const repo = createDocumentRepository();
    const filePath = path.join(fixtureDir, `${fixture}.TXT`);
    const result = await listSuppressions({ filePath, documentRepository: repo });
    if (result.file) result.file = path.basename(result.file);
    return result;
}

describe("agent tool: list_suppressions", () => {
    test("parses single-rule, multi-rule, and REASON-bearing suppressions", async () => {
        const result = await run("list-suppressions-basic");
        expect(result.status).toBe("ok");

        // Single-rule on line 4 suppressing line 5.
        expect(result.suppressions[0]).toMatchObject({
            commentLine: 4,
            suppressedLine: 5,
            ruleIds: ["ACU-VAR-001"],
            reason: null
        });

        // Multi-rule with REASON on line 7 suppressing line 8.
        expect(result.suppressions[1]).toMatchObject({
            commentLine: 7,
            suppressedLine: 8,
            ruleIds: ["ACU-FNC-010", "ACU-TYPE-004"],
            reason: "legacy signature kept for compatibility"
        });
    });

    test("flags invalid rule IDs and unparseable @rule-ignore lines as unknowns", async () => {
        const result = await run("list-suppressions-basic");
        // The `NOT-AN-ID` line should not become a suppression AND should be an unknown.
        const reasons = result.unknowns.map((u) => u.reason);
        expect(reasons).toContain("no_valid_rule_ids");
        // The bare `// @rule-ignore` at EOF is also invalid.
        expect(reasons.filter((r) => r === "no_valid_rule_ids").length).toBeGreaterThanOrEqual(1);
    });

    test("returns ok with empty suppressions for a file with none", async () => {
        const result = await run("list-symbols-basic");
        expect(result.status).toBe("ok");
        expect(result.suppressions).toEqual([]);
        expect(result.unknowns).toEqual([]);
    });

    test("reports supplementary-rule (non-ACU) suppressions", async () => {
        const result = await run("list-suppressions-supplementary");
        expect(result.status).toBe("ok");
        expect(result.suppressions).toHaveLength(2);
        expect(result.suppressions[0]).toMatchObject({
            commentLine: 4,
            suppressedLine: 5,
            ruleIds: ["EMP-STY-002"],
            reason: null
        });
        expect(result.suppressions[1]).toMatchObject({
            commentLine: 7,
            suppressedLine: 8,
            ruleIds: ["ACU-VAR-001", "EMP-STY-002"],
            reason: "mixed core + supplementary"
        });
    });

    test("returns unknown status for a missing file", async () => {
        const repo = createDocumentRepository();
        const result = await listSuppressions({
            filePath: path.join(fixtureDir, "does-not-exist.TXT"),
            documentRepository: repo
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("file_not_readable");
    });
});
