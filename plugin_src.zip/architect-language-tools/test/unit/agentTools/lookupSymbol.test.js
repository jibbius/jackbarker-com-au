/**
 * Unit tests for the lookup_symbol agent tool.
 *
 * Covers the four resolution tiers:
 *   1. Function-local scope (with line)
 *   2. File-scope + BFS include walk (with shadow collection)
 *   3. Built-in catalogue
 *   4. Not found
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

import { lookupSymbol } from "../../../core/src/agentTools/lookupSymbol.js";
import { createDocumentRepository } from "../../../core/src/query/documentRepository.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const fixtureDir = path.join(__dirname, "fixtures");

const UPDATE_GOLDEN = process.env.UPDATE_GOLDEN === "1";

function normalisePaths(result) {
    if (result.file) result.file = path.basename(result.file);
    if (result.definedIn) result.definedIn = path.basename(result.definedIn);
    for (const u of result.unknowns ?? []) {
        if (u.definedIn) u.definedIn = path.basename(u.definedIn);
    }
    return result;
}

async function run(args) {
    const repo = createDocumentRepository();
    const resolved = args.filePath ? path.join(fixtureDir, args.filePath) : null;
    const result = await lookupSymbol({
        ...args,
        filePath: resolved,
        documentRepository: repo
    });
    return normalisePaths(result);
}

function compareWithGolden(basename, result, suffix = "") {
    const goldenPath = path.join(
        fixtureDir,
        `${basename}${suffix ? "." + suffix : ""}.golden.json`
    );
    const serialised = JSON.stringify(result, null, 2) + "\n";
    if (UPDATE_GOLDEN || !fs.existsSync(goldenPath)) {
        fs.writeFileSync(goldenPath, serialised, "utf8");
        return;
    }
    const expected = fs.readFileSync(goldenPath, "utf8");
    expect(serialised).toBe(expected);
}

describe("agent tool: lookup_symbol", () => {
    test("Case A — defined in the query file wins over include definitions (root's nzName shadows common's)", async () => {
        const result = await run({ symbol: "nzName", filePath: "lookup-symbol-root.TXT" });
        expect(result.status).toBe("ok");
        expect(result.definedIn).toBe("lookup-symbol-root.TXT");
        expect(result.fromInclude).toEqual([]);
        expect(result.unknowns).toHaveLength(1);
        expect(result.unknowns[0]).toMatchObject({
            reason: "shadowed_definition",
            definedIn: "lookup-symbol-common.TXT",
            fromInclude: ["lookup-symbol-common.TXT"]
        });
        compareWithGolden("lookup-symbol", result, "caseA-local-wins");
    });

    test("Case B — reached via a single-hop include, no shadows", async () => {
        const result = await run({ symbol: "sFormatDate", filePath: "lookup-symbol-local-utils.TXT" });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("function");
        expect(result.definedIn).toBe("lookup-symbol-local-utils.TXT");
        expect(result.fromInclude).toEqual([]);
        expect(result.unknowns).toEqual([]);
    });

    test("Case C — ambiguous: two includes both define sFormatDate, BFS winner is local_utils", async () => {
        const result = await run({ symbol: "sFormatDate", filePath: "lookup-symbol-root.TXT" });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("function");
        expect(result.definedIn).toBe("lookup-symbol-local-utils.TXT");
        expect(result.fromInclude).toEqual(["lookup-symbol-local-utils.TXT"]);
        expect(result.unknowns).toHaveLength(1);
        expect(result.unknowns[0]).toMatchObject({
            reason: "shadowed_definition",
            definedIn: "lookup-symbol-date-utils.TXT",
            fromInclude: ["lookup-symbol-common.TXT", "lookup-symbol-date-utils.TXT"]
        });
        compareWithGolden("lookup-symbol", result, "caseC-shadow-via-nested");
    });

    test("Case D — built-in returned when standing in a file too", async () => {
        const result = await run({ symbol: "TRIM_ALL", filePath: "lookup-symbol-root.TXT" });
        expect(result.status).toBe("ok");
        expect(result.scope).toBe("builtin");
        expect(result.definedIn).toBeNull();
        expect(result.kind).toBe("function");
    });

    test("Case D' — built-in returned when no file is provided", async () => {
        const result = await run({ symbol: "TRIM_ALL" });
        expect(result.status).toBe("ok");
        expect(result.file).toBeNull();
        expect(result.scope).toBe("builtin");
    });

    test("Case E — not found returns unknown status", async () => {
        const result = await run({ symbol: "sNoSuchThing", filePath: "lookup-symbol-root.TXT" });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("symbol_not_found");
    });

    test("function-local parameter wins when line is inside the function", async () => {
        // sDouble in root starts at line 9; nsInput is its parameter.
        const result = await run({ symbol: "nsInput", filePath: "lookup-symbol-root.TXT", line: 11 });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("parameter");
        expect(result.scope).toBe("function:SDOUBLE");
        expect(result.fromInclude).toEqual([]);
        expect(result.unknowns).toEqual([]);
    });

    test("function-local variable wins over file-scope collision when line is inside the function", async () => {
        // nsResult is declared inside sDouble. With line=11 we should get the local.
        const result = await run({ symbol: "nsResult", filePath: "lookup-symbol-root.TXT", line: 11 });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("variable");
        expect(result.scope).toBe("function:SDOUBLE");
    });

    test("no file + non-builtin symbol returns file_required_for_user_symbol", async () => {
        const result = await run({ symbol: "sFormatDate" });
        expect(result.status).toBe("unknown");
        expect(result.file).toBeNull();
        expect(result.reason).toBe("file_required_for_user_symbol");
    });

    test("missing file returns file_not_readable", async () => {
        const result = await run({ symbol: "anything", filePath: "does-not-exist.TXT" });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("file_not_readable");
    });

    test("UDF resolution includes params (subsumes get_function_signature)", async () => {
        const result = await run({ symbol: "sFormatDate", filePath: "lookup-symbol-root.TXT" });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("function");
        expect(result.params).toEqual([{ name: "ndInput", type: "DATE" }]);
    });

    test("built-in function resolution includes named, typed params", async () => {
        const result = await run({ symbol: "GET_TOKEN" });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("function");
        expect(result.scope).toBe("builtin");
        expect(result.params).toEqual([
            { name: "inputString", type: "STRING" },
            { name: "delimiter", type: "STRING" },
            { name: "tokenIndex", type: "SHORT" }
        ]);
    });

    test("variable resolution does not emit params", async () => {
        const result = await run({ symbol: "nzName", filePath: "lookup-symbol-root.TXT" });
        expect(result.kind).toBe("variable");
        expect(result.params).toBeUndefined();
    });

    test("field-handle resolution surfaces tableCode, tableName, canonical, and lookupCode", async () => {
        const result = await run({ symbol: "hMDc_Account_Status", filePath: "lookup-symbol-root.TXT" });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("field_handle");
        expect(result.scope).toBe("database_field");
        expect(result.tableCode).toBe("MD");
        expect(result.tableName).toBe("Member Details");
        expect(result.canonical).toBe("hMDc_Account_Status");
        expect(result.lookupCode).toBe("QQMN");
        expect(result.definedIn).toBeNull();
        expect(result.fromInclude).toEqual([]);
    });

    test("field handle without a lookupCode returns null for it (field isn't constrained)", async () => {
        const result = await run({ symbol: "hMDc_Ann_Indexed", filePath: "lookup-symbol-root.TXT" });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("field_handle");
        expect(result.lookupCode).toBeNull();
    });

    test("field handle resolves without a file too (globally visible)", async () => {
        const result = await run({ symbol: "hMDc_Account_Status" });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("field_handle");
        expect(result.file).toBeNull();
        expect(result.lookupCode).toBe("QQMN");
    });

    test("field handle resolves for a digit-bearing table code (e.g. D2)", async () => {
        // Regression: the recogniser previously required two uppercase letters
        // after the leading 'h', which dropped handles for tables whose code
        // contains a digit (D2, T4, …).
        const result = await run({ symbol: "hD2c_Activated_Rev" });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("field_handle");
        expect(result.tableCode).toBe("D2");
        expect(result.canonical).toBe("hD2c_Activated_Rev");
    });

    test("user-defined symbol still wins over field-handle tier (tier order preserved)", async () => {
        // nzName is defined in lookup-symbol-root.TXT; make sure the field
        // tier doesn't intercept and return null for a normal variable.
        const result = await run({ symbol: "nzName", filePath: "lookup-symbol-root.TXT" });
        expect(result.kind).toBe("variable");
    });

    test("same-name VAR + macro: variable wins, macro surfaces as shadowed_definition", async () => {
        // Regression: collectFileScopeMatch previously returned after the first
        // kind it found, silently dropping a same-name macro that followed a
        // VAR declaration in the same file.
        const result = await run({ symbol: "nzCollide", filePath: "lookup-symbol-collision.TXT" });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("variable");
        expect(result.definedIn).toBe("lookup-symbol-collision.TXT");
        expect(result.unknowns).toHaveLength(1);
        expect(result.unknowns[0]).toMatchObject({
            reason: "shadowed_definition",
            definedIn: "lookup-symbol-collision.TXT"
        });
    });

    test("cached forward include map is consumed when workspaceRoot is supplied", async () => {
        // Drives the BFS off documentRepository.getIncludeGraph rather than
        // re-walking each visited doc with parseIncludeDirective. Asserts the same
        // shadow-collection result as the uncached path.
        const repo = createDocumentRepository();
        const result = await lookupSymbol({
            symbol: "nzName",
            filePath: path.join(fixtureDir, "lookup-symbol-root.TXT"),
            documentRepository: repo,
            workspaceRoot: fixtureDir,
            scanRoots: ["."]
        });
        expect(result.status).toBe("ok");
        expect(result.kind).toBe("variable");
        expect(path.basename(result.definedIn)).toBe("lookup-symbol-root.TXT");
    });
});
