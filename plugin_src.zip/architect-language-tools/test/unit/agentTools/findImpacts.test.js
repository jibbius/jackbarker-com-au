/**
 * Unit tests for the find_impacts agent tool.
 *
 * Reuses the what-references-workspace fixture:
 *   root.TXT             — defines sFormatDate, nzGlobal; includes header.TXT
 *   caller.TXT           — includes root.TXT; calls sFormatDate; writes nzGlobal
 *   reader.TXT           — includes root.TXT; reads nzGlobal
 *   header.TXT           — side-effect file (no declared symbols)
 *   nested/second-includer.TXT — includes ../header.TXT directly
 *   unrelated.TXT        — touches nothing
 */

import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

import { findImpacts } from "../../../core/src/agentTools/findImpacts.js";
import { createDocumentRepository } from "../../../core/src/query/documentRepository.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const workspaceRoot = path.join(__dirname, "fixtures", "what-references-workspace");

function rel(absPath) {
    return path.relative(workspaceRoot, absPath).split(path.sep).join("/");
}

async function run(args) {
    const repo = createDocumentRepository();
    const result = await findImpacts({
        documentRepository: repo,
        workspaceRoot,
        scanRoots: ["."],
        ...args
    });
    for (const a of result.affectedFiles ?? []) {
        if (a.file) a.file = rel(a.file);
    }
    return result;
}

describe("agent tool: find_impacts", () => {
    test("symbol input dedupes references to per-file impact rows with usage kinds", async () => {
        const result = await run({
            symbol: "sFormatDate",
            file: path.join(workspaceRoot, "root.TXT")
        });
        expect(result.status).toBe("ok");
        expect(result.inputKind).toBe("symbol");
        const byFile = Object.fromEntries(result.affectedFiles.map((a) => [a.file, a]));
        expect(Object.keys(byFile).sort()).toEqual(["caller.TXT", "root.TXT"]);
        // root.TXT both defines sFormatDate and calls it at the bottom.
        expect(byFile["root.TXT"].usageKinds).toEqual(["call", "definition"]);
        expect(byFile["caller.TXT"].usageKinds).toEqual(["call"]);
        expect(byFile["caller.TXT"].count).toBe(1);
    });

    test("symbol nzGlobal surfaces both read and write sites collapsed per file", async () => {
        const result = await run({
            symbol: "nzGlobal",
            file: path.join(workspaceRoot, "root.TXT")
        });
        expect(result.status).toBe("ok");
        const byFile = Object.fromEntries(result.affectedFiles.map((a) => [a.file, a]));
        expect(byFile["reader.TXT"].usageKinds).toEqual(["read"]);
        expect(byFile["caller.TXT"].usageKinds).toEqual(["write"]);
        expect(byFile["root.TXT"].usageKinds).toContain("write");
    });

    test("file input returns every transitive includer of a side-effect file", async () => {
        const result = await run({ file: path.join(workspaceRoot, "header.TXT") });
        expect(result.status).toBe("ok");
        expect(result.inputKind).toBe("file");
        const paths = result.affectedFiles.map((a) => a.file).sort();
        expect(paths).toEqual([
            "caller.TXT",       // includes root.TXT → header.TXT
            "nested/second-includer.TXT",
            "reader.TXT",       // includes root.TXT → header.TXT
            "root.TXT"          // direct includer
        ]);
        // header.TXT declares no symbols; every includer has an empty references[].
        for (const a of result.affectedFiles) {
            expect(a.references).toEqual([]);
        }
    });

    test("file input annotates each includer with the target's symbols it actually uses", async () => {
        const result = await run({ file: path.join(workspaceRoot, "root.TXT") });
        expect(result.status).toBe("ok");
        const byFile = Object.fromEntries(result.affectedFiles.map((a) => [a.file, a]));
        expect(Object.keys(byFile).sort()).toEqual(["caller.TXT", "reader.TXT"]);
        expect(byFile["caller.TXT"].references.sort()).toEqual(["nzGlobal", "sFormatDate"]);
        expect(byFile["reader.TXT"].references).toEqual(["nzGlobal"]);
    });

    test("file input reports the includedVia chain down to the target", async () => {
        const result = await run({ file: path.join(workspaceRoot, "header.TXT") });
        const byFile = Object.fromEntries(result.affectedFiles.map((a) => [a.file, a]));
        // Direct includers point straight at header.TXT.
        expect(byFile["root.TXT"].includedVia).toEqual(["header.TXT"]);
        expect(byFile["nested/second-includer.TXT"].includedVia).toEqual(["header.TXT"]);
        // Transitive includers go via root.TXT.
        expect(byFile["caller.TXT"].includedVia).toEqual(["root.TXT", "header.TXT"]);
        expect(byFile["reader.TXT"].includedVia).toEqual(["root.TXT", "header.TXT"]);
    });

    test("missing inputs return invalid_input", async () => {
        const result = await run({});
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("invalid_input");
    });

    test("missing workspaceRoot returns workspace_root_required", async () => {
        const repo = createDocumentRepository();
        const result = await findImpacts({
            symbol: "sFormatDate",
            documentRepository: repo,
            workspaceRoot: undefined,
            scanRoots: ["."]
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("workspace_root_required");
    });
});
