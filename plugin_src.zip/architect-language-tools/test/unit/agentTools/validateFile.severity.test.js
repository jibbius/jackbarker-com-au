/**
 * Targeted regression for the previous module-load cache of profile
 * severities in validateFile. The cache caused stale severities to leak
 * across MCP requests when the catalog or supplementary overrides were
 * reloaded mid-process; resolving per call eliminates the staleness.
 */

import { jest } from "@jest/globals";
import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

// Capture the real module exports BEFORE registering the mocks so we can
// re-publish everything except the one symbol under test.
import * as actualDiagnosticCatalog from "../../../core/src/diagnostics/diagnosticCatalog.js";
import * as actualSupplementaryLoader from "../../../core/src/supplementaryLoader.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const fixtureDir = path.join(__dirname, "fixtures");

const profileSeveritiesByCall = [];
const mockGetProfileRuleSeverities = jest.fn(() => {
    // Return a fresh map per call so any caller that snapshots once gets a
    // stale view on subsequent calls — exactly the bug we are guarding.
    const snapshot = profileSeveritiesByCall.shift() ?? {};
    return snapshot;
});
const mockGetSupplementarySeverityOverrides = jest.fn(() => ({}));

await jest.unstable_mockModule("../../../core/src/diagnostics/diagnosticCatalog.js", () => ({
    ...actualDiagnosticCatalog,
    getProfileRuleSeverities: mockGetProfileRuleSeverities
}));

await jest.unstable_mockModule("../../../core/src/supplementaryLoader.js", () => ({
    ...actualSupplementaryLoader,
    getSupplementarySeverityOverrides: mockGetSupplementarySeverityOverrides
}));

const { validateFile } = await import("../../../core/src/agentTools/validateFile.js");
const { createDocumentRepository } = await import("../../../core/src/query/documentRepository.js");

describe("validate_file: profile severities are resolved per call", () => {
    test("getProfileRuleSeverities is invoked again on a subsequent call", async () => {
        const repo = createDocumentRepository();
        const filePath = path.join(fixtureDir, "validate-file-has-issues.TXT");

        mockGetProfileRuleSeverities.mockClear();

        // Two empty-profile calls back-to-back. Before the fix, the second
        // call short-circuited on the module-load constant and never asked
        // the catalog again. After: each call re-resolves.
        profileSeveritiesByCall.push({}, {});
        await validateFile({ filePath, documentRepository: repo });
        const callsAfterFirst = mockGetProfileRuleSeverities.mock.calls.length;
        expect(callsAfterFirst).toBeGreaterThan(0);

        await validateFile({ filePath, documentRepository: repo });
        expect(mockGetProfileRuleSeverities.mock.calls.length).toBeGreaterThan(callsAfterFirst);
    });
});
