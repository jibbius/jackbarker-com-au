/**
 * Unit tests for the refresh_description_codes agent tool.
 *
 * Stubs both the SQL connector and the DescriptionCodesCache so no
 * PowerShell, SQL, or filesystem activity occurs.
 */

import { refreshDescriptionCodes } from "../../../core/src/agentTools/refreshDescriptionCodes.js";

function makeStubCache({ buildShouldThrow = null, fetchedAt = "2026-04-25T00:00:00Z" } = {}) {
    const calls = [];
    return {
        calls,
        async build(rows, server, database, filePath) {
            calls.push({ rows, server, database, filePath });
            if (buildShouldThrow) throw buildShouldThrow;
        },
        getStatus() {
            return { populated: true, fetchedAt, server: "db01", database: "ACURITY" };
        }
    };
}

function makeProjectConfig({ dbServer = "db01", dbDatabase = "ACURITY", dbEncrypt = false, dbTrustServerCertificate = true } = {}) {
    return Object.freeze({
        usrcalcDirectory: "USRCALCS",
        reportDirectory: "REPORTS",
        dbServer,
        dbDatabase,
        dbEncrypt,
        dbTrustServerCertificate,
        sourcePathToCfgFile: null
    });
}

describe("agent tool: refresh_description_codes", () => {
    test("config_missing when dbServer is absent", async () => {
        const cache = makeStubCache();
        const result = await refreshDescriptionCodes({
            projectConfig: makeProjectConfig({ dbServer: "" }),
            cachePath: "/tmp/cache.json",
            queryDescriptionCodes: async () => ({ rows: [], skipped: [] }),
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("config_missing");
        expect(cache.calls).toHaveLength(0);
    });

    test("config_missing when dbDatabase is absent", async () => {
        const cache = makeStubCache();
        const result = await refreshDescriptionCodes({
            projectConfig: makeProjectConfig({ dbDatabase: "" }),
            cachePath: "/tmp/cache.json",
            queryDescriptionCodes: async () => ({ rows: [], skipped: [] }),
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("config_missing");
        expect(cache.calls).toHaveLength(0);
    });

    test("config_missing when cachePath is absent", async () => {
        const cache = makeStubCache();
        const result = await refreshDescriptionCodes({
            projectConfig: makeProjectConfig(),
            cachePath: null,
            queryDescriptionCodes: async () => ({ rows: [], skipped: [] }),
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("config_missing");
        expect(result.hint).toMatch(/ARCH_LANG_DESCRIPTION_CACHE/);
        expect(cache.calls).toHaveLength(0);
    });

    test("sql_error surfaces the underlying message and does not write the cache", async () => {
        const cache = makeStubCache();
        const result = await refreshDescriptionCodes({
            projectConfig: makeProjectConfig(),
            cachePath: "/tmp/cache.json",
            queryDescriptionCodes: async () => { throw new Error("login failed for user"); },
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("sql_error");
        expect(result.hint).toBe("login failed for user");
        expect(cache.calls).toHaveLength(0);
    });

    test("cache_write_failed when cache.build throws", async () => {
        const cache = makeStubCache({ buildShouldThrow: new Error("disk full") });
        const result = await refreshDescriptionCodes({
            projectConfig: makeProjectConfig(),
            cachePath: "/tmp/cache.json",
            queryDescriptionCodes: async () => ({ rows: [{ g: "QQ", t: "MN", c: "1", d: "X", x: "N" }], skipped: [] }),
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("cache_write_failed");
        expect(result.hint).toBe("disk full");
    });

    test("success path: returns ok with rowCount and metadata, and calls build with correct args", async () => {
        const cache = makeStubCache({ fetchedAt: "2026-04-25T12:34:56Z" });
        const rows = [
            { g: "QQ", t: "MN", c: "1", d: "First", x: "N" },
            { g: "QQ", t: "MN", c: "2", d: "Second", x: "Y" }
        ];
        const result = await refreshDescriptionCodes({
            projectConfig: makeProjectConfig(),
            cachePath: "/tmp/cache.json",
            queryDescriptionCodes: async () => ({ rows, skipped: [] }),
            descriptionCodesCache: cache
        });
        expect(result).toEqual({
            status: "ok",
            rowCount: 2,
            skippedCount: 0,
            skipped: [],
            fetchedAt: "2026-04-25T12:34:56Z",
            server: "db01",
            database: "ACURITY"
        });
        expect(cache.calls).toHaveLength(1);
        expect(cache.calls[0]).toEqual({
            rows,
            server: "db01",
            database: "ACURITY",
            filePath: "/tmp/cache.json"
        });
    });

    test("success path: surfaces skipped row reasons in the result", async () => {
        const cache = makeStubCache({ fetchedAt: "2026-04-28T00:00:00Z" });
        const rows = [{ g: "QQ", t: "MN", c: "1", d: "First", x: "N" }];
        const result = await refreshDescriptionCodes({
            projectConfig: makeProjectConfig(),
            cachePath: "/tmp/cache.json",
            queryDescriptionCodes: async () => ({
                rows,
                skipped: ["row 4: missing required column CDz_Group"]
            }),
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("ok");
        expect(result.rowCount).toBe(1);
        expect(result.skippedCount).toBe(1);
        expect(result.skipped).toEqual(["row 4: missing required column CDz_Group"]);
    });

    test("sql_error preserves err.stack and err.cause when present", async () => {
        const cache = makeStubCache();
        const root = new Error("connection reset");
        const wrapped = new Error("login failed for user");
        wrapped.cause = root;
        const result = await refreshDescriptionCodes({
            projectConfig: makeProjectConfig(),
            cachePath: "/tmp/cache.json",
            queryDescriptionCodes: async () => { throw wrapped; },
            descriptionCodesCache: cache
        });
        expect(result.reason).toBe("sql_error");
        expect(result.hint).toBe("login failed for user");
        expect(typeof result.errStack).toBe("string");
        expect(result.errStack).toMatch(/login failed for user/);
        expect(result.errCause).toBe("connection reset");
    });

    test("cache_write_failed preserves err.stack when present, omits errCause when absent", async () => {
        const cache = makeStubCache({ buildShouldThrow: new Error("disk full") });
        const result = await refreshDescriptionCodes({
            projectConfig: makeProjectConfig(),
            cachePath: "/tmp/cache.json",
            queryDescriptionCodes: async () => ({ rows: [], skipped: [] }),
            descriptionCodesCache: cache
        });
        expect(result.reason).toBe("cache_write_failed");
        expect(typeof result.errStack).toBe("string");
        expect(result.errStack).toMatch(/disk full/);
        expect(result).not.toHaveProperty("errCause");
    });

    test("forwards encrypt/trust options to queryDescriptionCodes", async () => {
        const cache = makeStubCache();
        const calls = [];
        const result = await refreshDescriptionCodes({
            projectConfig: makeProjectConfig({ dbEncrypt: true, dbTrustServerCertificate: false }),
            cachePath: "/tmp/cache.json",
            queryDescriptionCodes: async (server, database, options) => {
                calls.push({ server, database, options });
                return { rows: [], skipped: [] };
            },
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("ok");
        expect(calls).toHaveLength(1);
        expect(calls[0]).toEqual({
            server: "db01",
            database: "ACURITY",
            options: { encrypt: true, trustServerCertificate: false }
        });
    });
});
