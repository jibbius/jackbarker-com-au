/**
 * Unit tests for the validate_file agent tool.
 *
 * These deliberately avoid asserting specific rule IDs so the tests remain
 * green as validators evolve. Instead we assert envelope shape and that
 * diagnostics conform to the documented structure.
 */

import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

import { validateFile } from "../../../core/src/agentTools/validateFile.js";
import { createDocumentRepository } from "../../../core/src/query/documentRepository.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const fixtureDir = path.join(__dirname, "fixtures");

const VALID_SEVERITIES = new Set(["error", "warning", "info", "hint"]);

async function run(fixture) {
    const repo = createDocumentRepository();
    const filePath = path.join(fixtureDir, `${fixture}.TXT`);
    const result = await validateFile({ filePath, documentRepository: repo });
    if (result.file) result.file = path.basename(result.file);
    return result;
}

function assertDiagnosticShape(d) {
    expect(typeof d.ruleId === "string" || d.ruleId === null).toBe(true);
    expect(VALID_SEVERITIES.has(d.severity)).toBe(true);
    expect(typeof d.message).toBe("string");
    expect(d.message.length).toBeGreaterThan(0);
    expect(Number.isInteger(d.line)).toBe(true);
    expect(d.line).toBeGreaterThanOrEqual(1);
    expect(Number.isInteger(d.endLine)).toBe(true);
    expect(d.endLine).toBeGreaterThanOrEqual(d.line);
    expect(Number.isInteger(d.startChar)).toBe(true);
    expect(Number.isInteger(d.endChar)).toBe(true);
}

describe("agent tool: validate_file", () => {
    test("returns ok with diagnostics for a file that violates coding standards", async () => {
        const result = await run("validate-file-has-issues");
        expect(result.status).toBe("ok");
        expect(Array.isArray(result.diagnostics)).toBe(true);
        expect(result.diagnostics.length).toBeGreaterThan(0);
        for (const d of result.diagnostics) assertDiagnosticShape(d);
        // Diagnostics should be sorted by line, then start char.
        for (let i = 1; i < result.diagnostics.length; i++) {
            const prev = result.diagnostics[i - 1];
            const cur = result.diagnostics[i];
            const ordered = prev.line < cur.line || (prev.line === cur.line && prev.startChar <= cur.startChar);
            expect(ordered).toBe(true);
        }
    });

    test("returns ok (possibly with empty diagnostics) for a well-formed file", async () => {
        // list-symbols-basic.TXT is a clean fixture we already use.
        const result = await run("list-symbols-basic");
        expect(result.status).toBe("ok");
        expect(Array.isArray(result.diagnostics)).toBe(true);
        for (const d of result.diagnostics) assertDiagnosticShape(d);
    });

    test("returns unknown status for a missing file", async () => {
        const repo = createDocumentRepository();
        const result = await validateFile({
            filePath: path.join(fixtureDir, "does-not-exist.TXT"),
            documentRepository: repo
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("file_not_readable");
    });
});
