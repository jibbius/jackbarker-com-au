/**
 * Unit tests for the find_references agent tool.
 */

import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

import { findReferences } from "../../../core/src/agentTools/findReferences.js";
import { createDocumentRepository } from "../../../core/src/query/documentRepository.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const workspaceRoot = path.join(__dirname, "fixtures", "what-references-workspace");

function rel(absPath) {
    return path.relative(workspaceRoot, absPath).split(path.sep).join("/");
}

async function run(args) {
    const repo = createDocumentRepository();
    const result = await findReferences({
        documentRepository: repo,
        workspaceRoot,
        scanRoots: ["."],
        ...args
    });
    // Normalise absolute paths so assertions are portable.
    if (Array.isArray(result.references)) {
        for (const r of result.references) r.file = rel(r.file);
    }
    if (Array.isArray(result.unknowns)) {
        for (const u of result.unknowns) if (u.file) u.file = rel(u.file);
    }
    return result;
}

describe("agent tool: find_references", () => {
    test("symbol input (kind=calls) returns every call site across the workspace, excluding the declaration line", async () => {
        const result = await run({
            symbol: "sFormatDate",
            file: path.join(workspaceRoot, "root.TXT"),
            kind: "calls"
        });
        expect(result.status).toBe("ok");
        expect(result.inputKind).toBe("symbol");
        const callSites = result.references.map((r) => `${r.file}:${r.line}`);
        expect(callSites).toEqual(
            expect.arrayContaining([
                "caller.TXT:4",
                "root.TXT:13"
            ])
        );
        // None of the hits are the FUNCTION declaration itself.
        expect(callSites).not.toContain("root.TXT:7");
    });

    test("file input returns every #include directive for that file", async () => {
        const result = await run({ file: path.join(workspaceRoot, "header.TXT") });
        expect(result.status).toBe("ok");
        expect(result.inputKind).toBe("file");
        const hits = result.references.map((r) => `${r.file}:${r.line}`);
        expect(hits).toEqual(
            expect.arrayContaining([
                "nested/second-includer.TXT:4",
                "root.TXT:3"
            ])
        );
        expect(result.references.every((r) => r.kind === "include")).toBe(true);
    });

    test("kind=writes surfaces assignment sites but not reads", async () => {
        const result = await run({
            symbol: "nzGlobal",
            file: path.join(workspaceRoot, "root.TXT"),
            kind: "writes"
        });
        expect(result.status).toBe("ok");
        const writeSites = result.references.map((r) => `${r.file}:${r.line}`);
        // root.TXT line 13 (`nzGlobal = sFormatDate(...)`) and caller.TXT line 4
        expect(writeSites).toEqual(
            expect.arrayContaining(["root.TXT:13", "caller.TXT:4"])
        );
        expect(writeSites).not.toContain("reader.TXT:5"); // that's a read
        expect(result.references.every((r) => r.kind === "write")).toBe(true);
    });

    test("kind=reads surfaces non-assignment reads of a variable", async () => {
        const result = await run({
            symbol: "nzGlobal",
            file: path.join(workspaceRoot, "root.TXT"),
            kind: "reads"
        });
        expect(result.status).toBe("ok");
        const readSites = result.references.map((r) => `${r.file}:${r.line}`);
        expect(readSites).toContain("reader.TXT:5");
        expect(result.references.every((r) => r.kind === "read")).toBe(true);
    });

    test("missing inputs return invalid_input", async () => {
        const result = await run({});
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("invalid_input");
    });

    test("missing workspaceRoot returns workspace_root_required", async () => {
        const repo = createDocumentRepository();
        const result = await findReferences({
            symbol: "sFormatDate",
            documentRepository: repo,
            workspaceRoot: undefined,
            scanRoots: ["."]
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("workspace_root_required");
    });

    test("invalid kind returns invalid_kind", async () => {
        const result = await run({ symbol: "sFormatDate", kind: "banana" });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("invalid_kind");
    });
});
