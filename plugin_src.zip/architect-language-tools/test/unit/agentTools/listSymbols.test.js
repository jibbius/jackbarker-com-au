/**
 * Unit tests for the list_symbols agent tool.
 *
 * Exercises the tool against real fixture files via the headless
 * documentRepository — no vscode mock is imported.
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

import { listSymbols } from "../../../core/src/agentTools/listSymbols.js";
import { createDocumentRepository } from "../../../core/src/query/documentRepository.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const fixtureDir = path.join(__dirname, "fixtures");

const UPDATE_GOLDEN = process.env.UPDATE_GOLDEN === "1";

async function runAgainstFixture(fixtureBasename, extraArgs = {}) {
    const repo = createDocumentRepository();
    const filePath = path.join(fixtureDir, `${fixtureBasename}.TXT`);
    const result = await listSymbols({
        filePath,
        documentRepository: repo,
        ...extraArgs
    });
    // Normalise the absolute file path so golden files are portable.
    if (result.file) result.file = path.basename(result.file);
    if (result.filePath) result.filePath = path.basename(result.filePath);
    return result;
}

function compareWithGolden(fixtureBasename, result, suffix = "") {
    const goldenPath = path.join(
        fixtureDir,
        `${fixtureBasename}${suffix ? "." + suffix : ""}.golden.json`
    );
    const serialised = JSON.stringify(result, null, 2) + "\n";
    if (UPDATE_GOLDEN || !fs.existsSync(goldenPath)) {
        fs.writeFileSync(goldenPath, serialised, "utf8");
        return;
    }
    const expected = fs.readFileSync(goldenPath, "utf8");
    expect(serialised).toBe(expected);
}

describe("agent tool: list_symbols", () => {
    test("lists file-scope variables, a UDF with its signature, function-local vars and params, and macros", async () => {
        const result = await runAgainstFixture("list-symbols-basic");
        expect(result.status).toBe("ok");
        compareWithGolden("list-symbols-basic", result);
    });

    test("kindFilter='variable' returns only variables (file + function-local)", async () => {
        const result = await runAgainstFixture("list-symbols-basic", { kindFilter: "variable" });
        expect(result.status).toBe("ok");
        for (const s of result.symbols) expect(s.kind).toBe("variable");
        expect(result.symbols.length).toBeGreaterThanOrEqual(3); // nzName, nsCount, nsResult
    });

    test("kindFilter='function' returns only user-defined functions", async () => {
        const result = await runAgainstFixture("list-symbols-basic", { kindFilter: "function" });
        expect(result.status).toBe("ok");
        expect(result.symbols.map((s) => s.name)).toEqual(["sDouble"]);
    });

    test("kindFilter='parameter' returns only function parameters", async () => {
        const result = await runAgainstFixture("list-symbols-basic", { kindFilter: "parameter" });
        expect(result.status).toBe("ok");
        expect(result.symbols.map((s) => s.name)).toEqual(["nsInput"]);
        expect(result.symbols[0].scope).toBe("function:SDOUBLE");
    });

    test("kindFilter='macro' returns only macro declarations", async () => {
        const result = await runAgainstFixture("list-symbols-basic", { kindFilter: "macro" });
        expect(result.status).toBe("ok");
        expect(result.symbols.map((s) => s.name)).toEqual(["MyMacro"]);
    });

    test("returns unknown status with reason for a missing file", async () => {
        const repo = createDocumentRepository();
        const result = await listSymbols({
            filePath: path.join(fixtureDir, "does-not-exist.TXT"),
            documentRepository: repo
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("file_not_readable");
    });

    test("returns unknown status for an invalid kindFilter", async () => {
        const repo = createDocumentRepository();
        const result = await listSymbols({
            filePath: path.join(fixtureDir, "list-symbols-basic.TXT"),
            documentRepository: repo,
            kindFilter: "banana"
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("invalid_kind_filter");
    });
});
