/**
 * Unit tests for the lookup_description_code agent tool.
 *
 * The real DescriptionCodesCache is populated from SQL; these tests
 * construct a real instance and populate it via its public `build`
 * method against a synthetic in-memory row set, then write/read to a
 * temp cache file (to satisfy the API). Alternatively we inject a
 * lightweight stub with the same public surface — that's what we do
 * here to avoid any filesystem chatter.
 */

import { lookupDescriptionCode } from "../../../core/src/agentTools/lookupDescriptionCode.js";

/**
 * Minimal DescriptionCodesCache stub matching the two methods the tool uses.
 * Populated from a plain object keyed by (table+type) → entries.
 */
function makeStubCache({ data = {}, populated = true, server = "db01", database = "ACURITY" } = {}) {
    const map = new Map(Object.entries(data));
    return {
        lookup(key) { return map.get(key) ?? []; },
        getStatus() {
            return {
                populated,
                fetchedAt: populated ? "2026-04-23T00:00:00Z" : null,
                server: populated ? server : null,
                database: populated ? database : null
            };
        }
    };
}

describe("agent tool: lookup_description_code", () => {
    const cache = makeStubCache({
        data: {
            MDStatus: [
                { code: "A", description: "Active", deprecated: false },
                { code: "S", description: "Suspended", deprecated: false },
                { code: "X", description: "Closed (legacy)", deprecated: true }
            ],
            CDType: [
                { code: "7", description: "Routine", deprecated: false }
            ]
        }
    });

    test("returns description and deprecated flag for a known code", async () => {
        const result = await lookupDescriptionCode({
            table: "MD", type: "Status", code: "A",
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("ok");
        expect(result.description).toBe("Active");
        expect(result.deprecated).toBe(false);
        expect(result.unknowns).toEqual([]);
        expect(result.cacheStatus.server).toBe("db01");
    });

    test("reports deprecated codes faithfully", async () => {
        const result = await lookupDescriptionCode({
            table: "MD", type: "Status", code: "X",
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("ok");
        expect(result.description).toBe("Closed (legacy)");
        expect(result.deprecated).toBe(true);
    });

    test("code_not_found when the group/type exists but the code does not", async () => {
        const result = await lookupDescriptionCode({
            table: "MD", type: "Status", code: "Z",
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("ok");
        expect(result.description).toBeNull();
        expect(result.unknowns).toHaveLength(1);
        expect(result.unknowns[0]).toMatchObject({
            reason: "code_not_found",
            availableCount: 3
        });
    });

    test("group_type_not_found when there are no entries for the (table, type) pair", async () => {
        const result = await lookupDescriptionCode({
            table: "XX", type: "Nope", code: "A",
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("ok");
        expect(result.description).toBeNull();
        expect(result.unknowns).toHaveLength(1);
        expect(result.unknowns[0].reason).toBe("group_type_not_found");
    });

    test("cache_not_populated when the cache is empty", async () => {
        const emptyCache = makeStubCache({ populated: false });
        const result = await lookupDescriptionCode({
            table: "MD", type: "Status", code: "A",
            descriptionCodesCache: emptyCache
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("cache_not_populated");
    });

    test("cache_unavailable when no cache instance is provided", async () => {
        const result = await lookupDescriptionCode({
            table: "MD", type: "Status", code: "A",
            descriptionCodesCache: null
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("cache_unavailable");
    });

    test("invalid_input when neither lookupCode nor (table, type) is provided", async () => {
        const r1 = await lookupDescriptionCode({ code: "A", descriptionCodesCache: cache });
        expect(r1.reason).toBe("invalid_input");
        const r2 = await lookupDescriptionCode({ type: "Status", code: "A", descriptionCodesCache: cache });
        expect(r2.reason).toBe("invalid_input");
    });

    test("enumerate mode: omitting code returns every code for the group/type", async () => {
        const result = await lookupDescriptionCode({
            table: "MD", type: "Status",
            descriptionCodesCache: cache
        });
        expect(result.status).toBe("ok");
        expect(result.description).toBeUndefined();
        expect(result.codes).toEqual([
            { code: "A", description: "Active", deprecated: false },
            { code: "S", description: "Suspended", deprecated: false },
            { code: "X", description: "Closed (legacy)", deprecated: true }
        ]);
        expect(result.unknowns).toEqual([]);
    });

    test("enumerate mode with unknown group/type returns codes: [] and group_type_not_found", async () => {
        const result = await lookupDescriptionCode({
            table: "XX", type: "Nope",
            descriptionCodesCache: cache
        });
        expect(result.codes).toEqual([]);
        expect(result.unknowns[0].reason).toBe("group_type_not_found");
    });

    test("lookupCode input: 4-char key resolves identically to (table, type)", async () => {
        const result = await lookupDescriptionCode({
            lookupCode: "MDStatu",  // too long — prove we validate length
            descriptionCodesCache: cache
        });
        expect(result.reason).toBe("invalid_input");
    });

    test("lookupCode input: valid 4-char key splits into (table=QQ, type=MN) equivalents", async () => {
        // Use a synthesized key for this cache.
        const c = makeStubCache({
            data: { QQMN: [{ code: "1", description: "First", deprecated: false }] }
        });
        const result = await lookupDescriptionCode({
            lookupCode: "QQMN", code: "1",
            descriptionCodesCache: c
        });
        expect(result.status).toBe("ok");
        expect(result.table).toBe("QQ");
        expect(result.type).toBe("MN");
        expect(result.lookupCode).toBe("QQMN");
        expect(result.description).toBe("First");
    });

    test("lookupCode + enumerate: returns every code for that 4-char key", async () => {
        const c = makeStubCache({
            data: {
                QQMN: [
                    { code: "1", description: "First", deprecated: false },
                    { code: "2", description: "Second", deprecated: true }
                ]
            }
        });
        const result = await lookupDescriptionCode({
            lookupCode: "QQMN",
            descriptionCodesCache: c
        });
        expect(result.status).toBe("ok");
        expect(result.codes).toHaveLength(2);
        expect(result.codes[1].deprecated).toBe(true);
    });

    test("providing both lookupCode and (table, type) is rejected as invalid_input", async () => {
        const result = await lookupDescriptionCode({
            lookupCode: "QQMN", table: "QQ", type: "MN",
            descriptionCodesCache: cache
        });
        expect(result.reason).toBe("invalid_input");
    });
});
