/**
 * Unit tests for the list_includes agent tool.
 *
 * Exercises direct and transitive modes against real fixture files via the
 * headless documentRepository — no vscode mock is imported.
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

import { listIncludes } from "../../../core/src/agentTools/listIncludes.js";
import { createDocumentRepository } from "../../../core/src/query/documentRepository.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const fixtureDir = path.join(__dirname, "fixtures");

const UPDATE_GOLDEN = process.env.UPDATE_GOLDEN === "1";

/**
 * Normalise absolute paths in the result to basenames so golden files are
 * portable across machines. Applies to `file`, every `includes[].resolvedPath`
 * and `includes[].fromFile`, and every `unknowns[].fromFile`.
 */
function normalisePaths(result) {
    if (result.file) result.file = path.basename(result.file);
    for (const inc of result.includes ?? []) {
        if (inc.resolvedPath) inc.resolvedPath = path.basename(inc.resolvedPath);
        if (inc.fromFile) inc.fromFile = path.basename(inc.fromFile);
    }
    for (const u of result.unknowns ?? []) {
        if (u.fromFile) u.fromFile = path.basename(u.fromFile);
    }
    return result;
}

async function runAgainstFixture(fixtureBasename, extraArgs = {}) {
    const repo = createDocumentRepository();
    const filePath = path.join(fixtureDir, `${fixtureBasename}.TXT`);
    const result = await listIncludes({
        filePath,
        documentRepository: repo,
        ...extraArgs
    });
    return normalisePaths(result);
}

function compareWithGolden(fixtureBasename, result, suffix = "") {
    const goldenPath = path.join(
        fixtureDir,
        `${fixtureBasename}${suffix ? "." + suffix : ""}.golden.json`
    );
    const serialised = JSON.stringify(result, null, 2) + "\n";
    if (UPDATE_GOLDEN || !fs.existsSync(goldenPath)) {
        fs.writeFileSync(goldenPath, serialised, "utf8");
        return;
    }
    const expected = fs.readFileSync(goldenPath, "utf8");
    expect(serialised).toBe(expected);
}

describe("agent tool: list_includes", () => {
    test("direct mode lists only root-level includes with line numbers and flags the unresolved one", async () => {
        const result = await runAgainstFixture("list-includes-root");
        expect(result.status).toBe("ok");
        expect(result.includes.map((i) => i.filename)).toEqual([
            "list-includes-child-a.TXT",
            "list-includes-child-b.TXT",
            "does-not-exist.TXT"
        ]);
        for (const inc of result.includes) expect(inc.fromFile).toBeUndefined();
        expect(result.unknowns).toHaveLength(1);
        expect(result.unknowns[0]).toMatchObject({
            filename: "does-not-exist.TXT",
            fromFile: "list-includes-root.TXT",
            line: 5,
            reason: "unresolved_include"
        });
        compareWithGolden("list-includes-root", result, "direct");
    });

    test("followIncludes mode walks the graph breadth-first and carries fromFile on every record", async () => {
        const result = await runAgainstFixture("list-includes-root", { followIncludes: true });
        expect(result.status).toBe("ok");
        // Root's three directives come first (BFS), then child-a's nested directive.
        expect(result.includes.map((i) => i.filename)).toEqual([
            "list-includes-child-a.TXT",
            "list-includes-child-b.TXT",
            "does-not-exist.TXT",
            "list-includes-grandchild.TXT"
        ]);
        expect(result.includes[0].fromFile).toBe("list-includes-root.TXT");
        expect(result.includes[3].fromFile).toBe("list-includes-child-a.TXT");
        compareWithGolden("list-includes-root", result, "followIncludes");
    });

    test("returns unknown status with reason for a missing root file", async () => {
        const repo = createDocumentRepository();
        const result = await listIncludes({
            filePath: path.join(fixtureDir, "does-not-exist.TXT"),
            documentRepository: repo
        });
        expect(result.status).toBe("unknown");
        expect(result.reason).toBe("file_not_readable");
    });

    test("returns ok with empty includes for a file with no directives", async () => {
        const result = await runAgainstFixture("list-includes-grandchild");
        expect(result.status).toBe("ok");
        expect(result.includes).toEqual([]);
        expect(result.unknowns).toEqual([]);
    });

    test("cached forward include map is consumed when workspaceRoot is supplied", async () => {
        // Same direct-includes result whether we walk the doc or look it up
        // in documentRepository.getIncludeGraph.
        const repo = createDocumentRepository();
        const result = await listIncludes({
            filePath: path.join(fixtureDir, "list-includes-root.TXT"),
            documentRepository: repo,
            workspaceRoot: fixtureDir,
            scanRoots: ["."]
        });
        expect(result.status).toBe("ok");
        expect(result.includes.map((i) => i.filename)).toEqual([
            "list-includes-child-a.TXT",
            "list-includes-child-b.TXT",
            "does-not-exist.TXT"
        ]);
    });
});
