import * as vscode from "../__mocks__/vscode.js";
import { createMockDocument } from "../helpers/mockDocument.js";
import { createMacroCompletionItems, buildMacroInsertText } from "../../vscode-extension/src/completionProvider.js";

describe("completionProvider", () => {
    it("buildMacroInsertText returns macro name for no-param macros", () => {
        expect(buildMacroInsertText("_reset", [])).toBe("_reset");
    });

    it("buildMacroInsertText adds parameter placeholders", () => {
        expect(buildMacroInsertText("_copies", ["?"])).toBe("_copies(?)");
    });

    it("buildMacroInsertText handles multiple parameters", () => {
        expect(buildMacroInsertText("_calc", ["?", "?"])).toBe("_calc(?, ?)");
    });

    it("returns macro completions filtered by typed prefix", () => {
        const document = createMockDocument([
            "#HASH-OFF",
            "MACRO _reset E",
            "MACRO _copies(?) &l?X",
            "SET x = _re"
        ], "/test/completion-prefix.architect");

        const items = createMacroCompletionItems(document, new vscode.Position(3, 11));

        expect(items.length).toBe(1);
        expect(items[0].label).toBe("_reset");
        expect(items[0].insertText).toBe("_reset");
        expect(items[0].detail).toBe("MACRO");
    });

    it("includes parameterized macro insert text in completion", () => {
        const document = createMockDocument([
            "#HASH-OFF",
            "MACRO _copies(?) &l?X",
            "SET x = _cop"
        ], "/test/completion-param.architect");

        const items = createMacroCompletionItems(document, new vscode.Position(2, 12));

        expect(items.length).toBe(1);
        expect(items[0].label).toBe("_copies");
        expect(items[0].insertText).toBe("_copies(?)");
        expect(items[0].detail).toContain("1 parameter");
    });

    it("returns empty array when no macros are defined", () => {
        const document = createMockDocument([
            "#HASH-OFF",
            "SET x = _re"
        ], "/test/completion-no-macros.architect");

        const items = createMacroCompletionItems(document, new vscode.Position(1, 11));

        expect(items).toEqual([]);
    });

    it("returns all macros when no prefix is typed", () => {
        const document = createMockDocument([
            "#HASH-OFF",
            "MACRO _reset E",
            "MACRO _copies(?) &l?X",
            "SET x = "
        ], "/test/completion-no-prefix.architect");

        // cursor at end of "SET x = " — no word characters before it
        const items = createMacroCompletionItems(document, new vscode.Position(3, 8));

        expect(items.length).toBe(2);
    });

    it("returns empty array when cursor is on a comment line", () => {
        const document = createMockDocument([
            "#HASH-OFF",
            "MACRO _reset E",
            "// SET x = _re"
        ], "/test/completion-comment.architect");

        // cursor at end of the comment line
        const items = createMacroCompletionItems(document, new vscode.Position(2, 14));

        expect(items).toEqual([]);
    });
});
