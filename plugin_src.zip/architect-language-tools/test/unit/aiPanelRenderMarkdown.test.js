import { renderMarkdown } from "../../vscode-extension/src/ai/aiPanel.js";

describe("aiPanel.renderMarkdown", () => {
    describe("code-block isolation", () => {
        it("does not re-render markdown inside a fenced code block", () => {
            const md = "```text\n**important**\n# header\n- bullet\n```";
            const html = renderMarkdown(md);
            expect(html).toContain("<pre><code>");
            // Inline/heading/list passes must not have rewritten the contents.
            expect(html).not.toContain("<strong>important</strong>");
            expect(html).not.toContain("<h1>header</h1>");
            expect(html).not.toContain("<li>bullet</li>");
            expect(html).toContain("**important**");
            expect(html).toContain("# header");
            expect(html).toContain("- bullet");
        });

        it("escapes HTML metacharacters inside fenced code", () => {
            const html = renderMarkdown("```\n<script>alert(1)</script>\n```");
            expect(html).toContain("&lt;script&gt;");
            expect(html).not.toContain("<script>");
        });

        it("supports ~~~ fences", () => {
            const html = renderMarkdown("~~~\nplain\n~~~");
            expect(html).toContain("<pre><code>plain</code></pre>");
        });

        it("does not re-render markdown inside an inline code span", () => {
            const html = renderMarkdown("Use `**not bold**` here.");
            expect(html).toContain("<code>**not bold**</code>");
            expect(html).not.toContain("<strong>not bold</strong>");
        });
    });

    describe("inline formatting", () => {
        it("renders bold, italic, bold-italic, strikethrough", () => {
            const html = renderMarkdown("a **b** *c* ***d*** ~~e~~");
            expect(html).toContain("<strong>b</strong>");
            expect(html).toContain("<em>c</em>");
            expect(html).toContain("<strong><em>d</em></strong>");
            expect(html).toContain("<del>e</del>");
        });

        it("renders links", () => {
            const html = renderMarkdown("see [docs](https://example.com)");
            expect(html).toContain('<a href="https://example.com"');
            expect(html).toContain(">docs</a>");
        });
    });

    describe("headings", () => {
        it("renders h1/h2/h3 at line start", () => {
            const html = renderMarkdown("# A\n\n## B\n\n### C");
            expect(html).toContain("<h1>A</h1>");
            expect(html).toContain("<h2>B</h2>");
            expect(html).toContain("<h3>C</h3>");
        });

        it("does not render headings inside fenced code", () => {
            const html = renderMarkdown("```\n# not a heading\n```");
            expect(html).not.toContain("<h1>not a heading</h1>");
            expect(html).toContain("# not a heading");
        });
    });

    describe("lists", () => {
        it("consolidates consecutive bullets into a single <ul>", () => {
            const html = renderMarkdown("- one\n- two\n- three");
            expect((html.match(/<ul>/g) || []).length).toBe(1);
            expect(html).toContain("<li>one</li>");
            expect(html).toContain("<li>three</li>");
        });

        it("does not merge two lists separated by a blank line", () => {
            const html = renderMarkdown("- a\n- b\n\n- c\n- d");
            expect((html.match(/<ul>/g) || []).length).toBe(2);
        });

        it("handles numbered lists", () => {
            const html = renderMarkdown("1. first\n2. second");
            expect(html).toContain("<ul><li>first</li>\n<li>second</li></ul>");
        });
    });

    describe("escaping", () => {
        it("escapes < > & \" in plain prose", () => {
            const html = renderMarkdown('A & B <c> "d"');
            expect(html).toContain("&amp;");
            expect(html).toContain("&lt;c&gt;");
            expect(html).toContain("&quot;d&quot;");
        });
    });

    describe("paragraph wrapping", () => {
        it("wraps standalone prose in <p>", () => {
            const html = renderMarkdown("hello world");
            expect(html).toContain("<p>hello world</p>");
        });

        it("does not wrap a standalone code block in <p>", () => {
            const html = renderMarkdown("```\nfoo\n```");
            expect(html).toContain("<pre><code>foo</code></pre>");
            expect(html).not.toMatch(/<p>\s*<pre>/);
        });

        it("does wrap standalone inline code in a paragraph", () => {
            const html = renderMarkdown("`x`");
            expect(html).toContain("<p><code>x</code></p>");
        });
    });
});
