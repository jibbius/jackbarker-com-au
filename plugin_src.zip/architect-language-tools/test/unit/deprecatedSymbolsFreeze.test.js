/**
 * Contract tests for the DeprecatedHandles read-only guarantee.
 *
 * Mirrors `globalVariablesRegistryFreeze.test.js`: external writes against
 * the exported registry throw TypeError; the registered API is the only
 * way in.
 *
 * Adds register/unregister round-trip coverage for the new
 * registerSupplementaryDeprecatedHandle / unregisterSupplementaryDeprecatedHandle
 * APIs.
 */

import {
    DeprecatedHandles,
    registerSupplementaryDeprecatedHandle,
    unregisterSupplementaryDeprecatedHandle
} from "../../core/src/builtins/deprecatedSymbols.js";

describe("DeprecatedHandles — external mutation is rejected", () => {
    test("direct property assignment throws TypeError", () => {
        expect(() => {
            DeprecatedHandles.NEW_HANDLE = "hZZx_Replacement";
        }).toThrow(TypeError);
    });

    test("delete on an existing key throws TypeError", () => {
        const existingKey = Object.keys(DeprecatedHandles)[0];
        expect(() => {
            delete DeprecatedHandles[existingKey];
        }).toThrow(TypeError);
    });

    test("Object.defineProperty throws TypeError", () => {
        expect(() => {
            Object.defineProperty(DeprecatedHandles, "DEFINED_HANDLE", {
                value: "hZZx_Replacement",
                writable: true,
                configurable: true,
                enumerable: true
            });
        }).toThrow(TypeError);
    });

    test("the rejection message points the caller at the supported API", () => {
        try {
            DeprecatedHandles.ANOTHER_HANDLE = "x";
        } catch (err) {
            expect(err.message).toMatch(/registerSupplementaryDeprecatedHandle/);
            return;
        }
        throw new Error("expected mutation to throw, but it succeeded");
    });
});

describe("registerSupplementaryDeprecatedHandle / unregisterSupplementaryDeprecatedHandle", () => {
    const TEST_KEY = "__TEST_REG_DEP__";

    afterEach(() => {
        unregisterSupplementaryDeprecatedHandle(TEST_KEY);
    });

    test("register adds a brand-new entry; result reports added=true", () => {
        const result = registerSupplementaryDeprecatedHandle(TEST_KEY, "hZZx_Replacement");
        expect(result).toEqual({ added: true, replaced: false, skipped: false });
        expect(DeprecatedHandles[TEST_KEY]).toBe("hZZx_Replacement");
    });

    test("register replaces an existing core entry; result reports replaced=true", () => {
        const existingKey = Object.keys(DeprecatedHandles)[0];
        const originalValue = DeprecatedHandles[existingKey];
        const result = registerSupplementaryDeprecatedHandle(existingKey, "OVERRIDE_VALUE");
        expect(result).toEqual({ added: false, replaced: true, skipped: false });
        expect(DeprecatedHandles[existingKey]).toBe("OVERRIDE_VALUE");

        unregisterSupplementaryDeprecatedHandle(existingKey);
        expect(DeprecatedHandles[existingKey]).toBe(originalValue);
    });

    test("register skips when preferCore=true and the name conflicts", () => {
        const existingKey = Object.keys(DeprecatedHandles)[0];
        const originalValue = DeprecatedHandles[existingKey];
        const result = registerSupplementaryDeprecatedHandle(existingKey, "OVERRIDE", true);
        expect(result).toEqual({ added: false, replaced: false, skipped: true });
        expect(DeprecatedHandles[existingKey]).toBe(originalValue);
    });

    test("unregister removes an injected key", () => {
        registerSupplementaryDeprecatedHandle(TEST_KEY, "hZZx_Replacement");
        expect(DeprecatedHandles[TEST_KEY]).toBeDefined();
        unregisterSupplementaryDeprecatedHandle(TEST_KEY);
        expect(DeprecatedHandles[TEST_KEY]).toBeUndefined();
    });

    test("unregister is a safe no-op on an unknown name", () => {
        expect(() => unregisterSupplementaryDeprecatedHandle("__NEVER_REGISTERED__")).not.toThrow();
    });

    test("name is normalised to upper-case", () => {
        registerSupplementaryDeprecatedHandle(TEST_KEY.toLowerCase(), "hZZx_Replacement");
        expect(DeprecatedHandles[TEST_KEY]).toBe("hZZx_Replacement");
    });

    test("rejects non-string replacement", () => {
        expect(() => registerSupplementaryDeprecatedHandle(TEST_KEY, 123))
            .toThrow(/replacement must be a non-empty string/);
    });
});
