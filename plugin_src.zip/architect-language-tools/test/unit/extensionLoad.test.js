/**
 * Smoke test: verifies that the extension entry point and every module it
 * requires at load-time can be resolved without error.
 *
 * This catches broken import paths (wrong number of "../" segments, missing
 * files, etc.) that would prevent the extension from activating in VS Code.
 * It does NOT test activation behaviour — only that the module graph loads.
 *
 * In ESM, if the module fails to load the whole test file fails, which itself
 * confirms the "loads without errors" property.
 */

import * as ext from "../../vscode-extension/extension.js";

describe("extension entry point", () => {
    it("exports activate and deactivate functions", () => {
        expect(typeof ext.activate).toBe("function");
        expect(typeof ext.deactivate).toBe("function");
    });
});
