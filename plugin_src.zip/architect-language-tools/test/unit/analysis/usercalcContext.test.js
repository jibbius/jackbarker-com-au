import { isUsercalcReport, DEFAULT_USRCALC_DIRECTORY } from "../../../core/src/analysis/usercalcContext.js";

describe("isUsercalcReport", () => {
    test("matches USRCALCS segment in middle of path (forward slashes)", () => {
        expect(isUsercalcReport("/projects/foo/USRCALCS/calc.txt")).toBe(true);
    });

    test("matches usrcalcs segment case-insensitively", () => {
        expect(isUsercalcReport("/projects/foo/usrcalcs/calc.txt")).toBe(true);
        expect(isUsercalcReport("/projects/foo/Usrcalcs/calc.txt")).toBe(true);
        expect(isUsercalcReport("/projects/foo/UsRcAlCs/calc.txt")).toBe(true);
    });

    test("matches with backslash separators", () => {
        expect(isUsercalcReport("C:\\projects\\foo\\USRCALCS\\calc.txt")).toBe(true);
    });

    test("matches with mixed separators", () => {
        expect(isUsercalcReport("C:\\projects/foo\\usrcalcs/calc.txt")).toBe(true);
    });

    test("matches at root", () => {
        expect(isUsercalcReport("USRCALCS/calc.txt")).toBe(true);
        expect(isUsercalcReport("/USRCALCS/calc.txt")).toBe(true);
    });

    test("does not match a substring (segment match only)", () => {
        expect(isUsercalcReport("/projects/MyUsrcalcsHelper/calc.txt")).toBe(false);
        expect(isUsercalcReport("/projects/foo/usrcalcs2/calc.txt")).toBe(false);
        expect(isUsercalcReport("/projects/foo/preusrcalcs/calc.txt")).toBe(false);
    });

    test("returns false when no segment matches", () => {
        expect(isUsercalcReport("/projects/foo/REPORTS/report.txt")).toBe(false);
    });

    test("returns false for null, undefined, and empty inputs", () => {
        expect(isUsercalcReport(null)).toBe(false);
        expect(isUsercalcReport(undefined)).toBe(false);
        expect(isUsercalcReport("")).toBe(false);
    });

    test("returns false for non-string inputs", () => {
        expect(isUsercalcReport(123)).toBe(false);
        expect(isUsercalcReport({})).toBe(false);
    });

    test("respects custom usrcalcDirectory override", () => {
        expect(isUsercalcReport("/projects/foo/myCalcs/calc.txt", { usrcalcDirectory: "myCalcs" })).toBe(true);
        expect(isUsercalcReport("/projects/foo/USRCALCS/calc.txt", { usrcalcDirectory: "myCalcs" })).toBe(false);
    });

    test("custom usrcalcDirectory is case-insensitive", () => {
        expect(isUsercalcReport("/projects/foo/MYCALCS/calc.txt", { usrcalcDirectory: "myCalcs" })).toBe(true);
    });

    test("DEFAULT_USRCALC_DIRECTORY is exported as USRCALCS", () => {
        expect(DEFAULT_USRCALC_DIRECTORY).toBe("USRCALCS");
    });
});
