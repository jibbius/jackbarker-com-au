/**
 * Unit tests for core/src/ast/astHelpers.js.
 *
 * These exercise each exported helper against hand-rolled mini-ASTs so a
 * regression in the shared traversal layer surfaces here directly, rather
 * than only via downstream validator tests.
 */

import {
    walkStatements,
    collectStatementValueSpans,
    collectAllSpans,
    walkExpression,
    walkCalls,
    firstToken,
    leftmostToken,
    rightmostToken,
    nodeRange,
} from "../../core/src/ast/astHelpers.js";
import { NodeType } from "../../core/src/ast/nodes.js";
import { ExprNodeType } from "../../core/src/ast/expressionNodes.js";

// ---------------------------------------------------------------------------
// Builders
// ---------------------------------------------------------------------------

const tok = (value, line, char) => ({ value, line, char });

const ident = (name, line = 0, char = 0) => ({
    type: ExprNodeType.IDENTIFIER, name, token: tok(name, line, char),
});

const lit = (value, line = 0, char = 0) => ({
    type: ExprNodeType.LITERAL, value, token: tok(String(value), line, char),
});

const binary = (op, left, right, line = 0, char = 0) => ({
    type: ExprNodeType.BINARY, op, left, right, token: tok(op, line, char),
});

const unary = (op, operand, line = 0, char = 0) => ({
    type: ExprNodeType.UNARY, op, operand, token: tok(op, line, char),
});

const paren = (expr, line = 0, char = 0) => ({
    type: ExprNodeType.PAREN, expr, token: tok("(", line, char),
});

const call = (calleeName, args, line = 0, startChar = 0, endChar = 0) => ({
    type: ExprNodeType.CALL,
    callee: ident(calleeName, line, startChar),
    args,
    startToken: tok(calleeName, line, startChar),
    endToken:   tok(")", line, endChar),
});

// ---------------------------------------------------------------------------
// Statement-level traversal
// ---------------------------------------------------------------------------

describe("walkStatements", () => {
    test("visits every statement depth-first across body / consequent / alternate / branches / otherwise", () => {
        const stmts = [
            { type: NodeType.AssignStatement, line: 0 },
            {
                type: NodeType.IfStatement, line: 1,
                consequent: [{ type: NodeType.AssignStatement, line: 2 }],
                alternate:  [{ type: NodeType.AssignStatement, line: 3 }],
            },
            {
                type: NodeType.CaseStatement, line: 4,
                branches: [{ body: [{ type: NodeType.AssignStatement, line: 5 }] }],
                otherwise: [{ type: NodeType.AssignStatement, line: 6 }],
            },
            {
                type: NodeType.DoStatement, line: 7,
                body: [{ type: NodeType.AssignStatement, line: 8 }],
            },
        ];

        const lines = [];
        walkStatements(stmts, (s) => { lines.push(s.line); });

        expect(lines).toEqual([0, 1, 2, 3, 4, 5, 6, 7, 8]);
    });

    test("visitor returning false prevents descent into that node's children", () => {
        const stmts = [{
            type: NodeType.FunctionDeclaration, line: 0,
            body: [{ type: NodeType.AssignStatement, line: 1 }],
        }];

        const visited = [];
        walkStatements(stmts, (s) => {
            visited.push(s.line);
            if (s.type === NodeType.FunctionDeclaration) return false;
        });

        expect(visited).toEqual([0]);
    });

    test("visitor receives (stmt, index, siblings) and can identify top-level by sibling identity", () => {
        const top = [
            { type: NodeType.AssignStatement, line: 0 },
            { type: NodeType.IfStatement, line: 1,
              consequent: [{ type: NodeType.AssignStatement, line: 2 }] },
        ];
        const seen = [];
        walkStatements(top, (s, i, siblings) => {
            seen.push({ line: s.line, i, isTop: siblings === top });
        });
        expect(seen).toEqual([
            { line: 0, i: 0, isTop: true },
            { line: 1, i: 1, isTop: true },
            { line: 2, i: 0, isTop: false },
        ]);
    });
});

describe("collectStatementValueSpans", () => {
    test("collects only Assign / Set / Expression / FunctionCall .value spans", () => {
        const valSpan = { kind: "value" };
        const condSpan = { kind: "condition" };
        const stmts = [
            { type: NodeType.AssignStatement, line: 1, value: valSpan },
            { type: NodeType.IfStatement,    line: 2, condition: condSpan, consequent: [] },
            { type: NodeType.SetStatement,   line: 3, value: { ...valSpan, n: 2 } },
        ];

        const spans = collectStatementValueSpans(stmts);

        expect(spans).toEqual([
            { span: valSpan, lineIndex: 1 },
            { span: { kind: "value", n: 2 }, lineIndex: 3 },
        ]);
    });
});

describe("collectAllSpans", () => {
    test("collects value, condition, subject, options, iterator and case-branch values", () => {
        const stmts = [
            { type: NodeType.AssignStatement, line: 1, value: { k: "v" } },
            {
                type: NodeType.DoStatement, line: 2,
                iterator: { start: { k: "s" }, to: { k: "t" }, by: { k: "b" } },
                body: [],
            },
            {
                type: NodeType.CaseStatement, line: 3,
                subject: { k: "subj" },
                branches: [{ values: [{ k: "v1" }, { k: "v2" }], body: [] }],
            },
            { type: NodeType.IfStatement, line: 4, condition: { k: "c" }, consequent: [] },
        ];

        const spans = collectAllSpans(stmts).map((e) => ({ kind: e.span.k, line: e.lineIndex }));

        expect(spans).toEqual([
            { kind: "v",    line: 1 },
            { kind: "s",    line: 2 },
            { kind: "t",    line: 2 },
            { kind: "b",    line: 2 },
            { kind: "subj", line: 3 },
            { kind: "v1",   line: 3 },
            { kind: "v2",   line: 3 },
            { kind: "c",    line: 4 },
        ]);
    });
});

// ---------------------------------------------------------------------------
// Expression-level traversal
// ---------------------------------------------------------------------------

describe("walkExpression", () => {
    test("visits leaves and inner nodes through operand / left / right / expr / args", () => {
        const expr = paren(
            binary("+",
                unary("-", ident("a")),
                call("F", [lit(1), ident("b")]),
            ),
        );

        const types = [];
        walkExpression(expr, (n) => { types.push(n.type); });

        // Note: walkExpression does not recurse through `callee`, only through
        // operand / left / right / expr / args.
        expect(types).toEqual([
            ExprNodeType.PAREN,
            ExprNodeType.BINARY,
            ExprNodeType.UNARY,
            ExprNodeType.IDENTIFIER, // -a operand
            ExprNodeType.CALL,
            ExprNodeType.LITERAL,    // arg 1
            ExprNodeType.IDENTIFIER, // arg b
        ]);
    });

    test("safe to call with null", () => {
        expect(() => walkExpression(null, () => {})).not.toThrow();
    });
});

describe("walkCalls", () => {
    test("visits only CALL nodes, recursing through BINARY / UNARY / PAREN / args", () => {
        const expr = paren(
            binary("+",
                unary("-", call("INNER", [])),
                call("OUTER", [call("ARG", [])]),
            ),
        );

        const names = [];
        walkCalls(expr, (n) => { names.push(n.callee.name); });

        expect(names).toEqual(["INNER", "OUTER", "ARG"]);
    });
});

// ---------------------------------------------------------------------------
// Token positioning
// ---------------------------------------------------------------------------

describe("firstToken", () => {
    test("returns the characteristic token: operator for BINARY, callee for CALL", () => {
        const bin = binary("+", ident("a", 0, 0), ident("b", 0, 4), 0, 2);
        expect(firstToken(bin)).toEqual(tok("+", 0, 2));

        const c = call("F", [], 0, 0, 3);
        expect(firstToken(c)).toEqual(tok("F", 0, 0));

        expect(firstToken(null)).toBeNull();
    });
});

describe("leftmostToken", () => {
    test("recurses through BINARY to leftmost operand", () => {
        const bin = binary("+",
            binary("*", ident("a", 0, 0), ident("b", 0, 4), 0, 2),
            ident("c", 0, 8),
            0, 6,
        );
        expect(leftmostToken(bin)).toEqual(tok("a", 0, 0));
    });
});

describe("rightmostToken", () => {
    test("recurses through BINARY to rightmost operand", () => {
        const bin = binary("+",
            ident("a", 0, 0),
            binary("*", ident("b", 0, 4), ident("c", 0, 8), 0, 6),
            0, 2,
        );
        expect(rightmostToken(bin)).toEqual(tok("c", 0, 8));
    });
});

describe("nodeRange", () => {
    test("returns LSP range from leftmost to rightmost+length", () => {
        const bin = binary("+", ident("a", 0, 0), ident("bb", 0, 4), 0, 2);
        expect(nodeRange(bin)).toEqual({
            start: { line: 0, character: 0 },
            end:   { line: 0, character: 6 }, // 4 + len("bb")
        });
    });

    test("returns null when tokens are missing", () => {
        expect(nodeRange({ type: ExprNodeType.LITERAL })).toBeNull();
    });
});
