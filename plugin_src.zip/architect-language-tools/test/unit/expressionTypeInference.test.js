/**
 * Unit tests for expressionTypeInference — Phase 2 of the expression tree plan.
 *
 * Nodes are constructed directly using the node factory helpers from
 * expressionNodes.js so that tests exercise the inference logic in isolation,
 * without depending on the parser.
 *
 * A small set of end-to-end tests at the bottom round-trip through the parser
 * to verify the full pipeline still works.
 */

import {
    inferExpressionType,
    isNumericType,
    widenNumericTypes
} from "../../core/src/analysis/expressionTypeInference.js";

import {
    ExprNodeType,
    makeLiteral,
    makeDateNode,
    makeTimeNode,
    makeIdentifier,
    makeCall,
    makeUnary,
    makeBinary,
    makeParen
} from "../../core/src/ast/expressionNodes.js";

import { ArchitectTypes } from "../../core/src/types/architectTypes.js";
import { NodeType } from "../../core/src/ast/nodes.js";
import { parseExpression } from "../../core/src/ast/expressionParser.js";
import { buildDocumentAst } from "../../core/src/ast/documentAst.js";
import { makeDocument } from "./validators/helpers.js";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Synthetic token — enough for the node factories. */
const tok = (value = "x") => ({ value });

/** Short-hand literal node with an explicit inferredType. */
function lit(inferredType) {
    return makeLiteral(tok(inferredType), inferredType);
}

/** Identifier node for a variable whose type is in the context map. */
function varNode(name) {
    return makeIdentifier(tok(name));
}

/** Context map with one variable. */
function ctx(name, type) {
    return { variables: new Map([[name.toUpperCase(), type]]) };
}

// ---------------------------------------------------------------------------
// isNumericType
// ---------------------------------------------------------------------------

describe("isNumericType", () => {
    test.each([
        ArchitectTypes.SHORT,
        ArchitectTypes.LONG,
        ArchitectTypes.INTEGER,
        ArchitectTypes.BIGINT,
        ArchitectTypes.DOUBLE
    ])("returns true for %s", (type) => {
        expect(isNumericType(type)).toBe(true);
    });

    test.each([
        ArchitectTypes.STRING,
        ArchitectTypes.BOOLEAN,
        ArchitectTypes.DATE,
        ArchitectTypes.TIME,
        null,
        undefined
    ])("returns false for %s", (type) => {
        expect(isNumericType(type)).toBe(false);
    });
});

// ---------------------------------------------------------------------------
// widenNumericTypes
// ---------------------------------------------------------------------------

describe("widenNumericTypes", () => {
    test("SHORT + SHORT → SHORT", () => {
        expect(widenNumericTypes(ArchitectTypes.SHORT, ArchitectTypes.SHORT)).toBe(ArchitectTypes.SHORT);
    });

    test("SHORT + LONG → LONG", () => {
        expect(widenNumericTypes(ArchitectTypes.SHORT, ArchitectTypes.LONG)).toBe(ArchitectTypes.LONG);
    });

    test("LONG + BIGINT → BIGINT", () => {
        expect(widenNumericTypes(ArchitectTypes.LONG, ArchitectTypes.BIGINT)).toBe(ArchitectTypes.BIGINT);
    });

    test("BIGINT + DOUBLE → DOUBLE", () => {
        expect(widenNumericTypes(ArchitectTypes.BIGINT, ArchitectTypes.DOUBLE)).toBe(ArchitectTypes.DOUBLE);
    });

    test("INTEGER treated as LONG — INTEGER + SHORT → LONG", () => {
        expect(widenNumericTypes(ArchitectTypes.INTEGER, ArchitectTypes.SHORT)).toBe(ArchitectTypes.LONG);
    });

    test("INTEGER + DOUBLE → DOUBLE", () => {
        expect(widenNumericTypes(ArchitectTypes.INTEGER, ArchitectTypes.DOUBLE)).toBe(ArchitectTypes.DOUBLE);
    });

    test("non-numeric left → null", () => {
        expect(widenNumericTypes(ArchitectTypes.STRING, ArchitectTypes.LONG)).toBeNull();
    });

    test("non-numeric right → null", () => {
        expect(widenNumericTypes(ArchitectTypes.LONG, ArchitectTypes.BOOLEAN)).toBeNull();
    });

    test("both null → null", () => {
        expect(widenNumericTypes(null, null)).toBeNull();
    });
});

// ---------------------------------------------------------------------------
// inferExpressionType — null / missing node
// ---------------------------------------------------------------------------

describe("inferExpressionType — null / missing", () => {
    test("returns null for null node", () => {
        expect(inferExpressionType(null)).toBeNull();
    });

    test("returns null for undefined node", () => {
        expect(inferExpressionType(undefined)).toBeNull();
    });

    test("returns null for unknown node type", () => {
        expect(inferExpressionType({ type: "Unknown" })).toBeNull();
    });
});

// ---------------------------------------------------------------------------
// LITERAL, DATE, TIME — passthrough of inferredType
// ---------------------------------------------------------------------------

describe("inferExpressionType — literals", () => {
    test.each([
        [ExprNodeType.LITERAL, ArchitectTypes.STRING],
        [ExprNodeType.LITERAL, ArchitectTypes.SHORT],
        [ExprNodeType.LITERAL, ArchitectTypes.LONG],
        [ExprNodeType.LITERAL, ArchitectTypes.DOUBLE],
        [ExprNodeType.LITERAL, ArchitectTypes.BOOLEAN]
    ])("%s with inferredType %s", (nodeType, inferredType) => {
        const node = { type: nodeType, inferredType };
        expect(inferExpressionType(node)).toBe(inferredType);
    });

    test("DATE node → DATE", () => {
        expect(inferExpressionType(makeDateNode(tok("01/01/2024")))).toBe(ArchitectTypes.DATE);
    });

    test("TIME node → TIME", () => {
        expect(inferExpressionType(makeTimeNode(tok("12:00:00:00")))).toBe(ArchitectTypes.TIME);
    });

    test("LITERAL with no inferredType → null", () => {
        const node = { type: ExprNodeType.LITERAL };
        expect(inferExpressionType(node)).toBeNull();
    });
});

// ---------------------------------------------------------------------------
// PAREN — passthrough
// ---------------------------------------------------------------------------

describe("inferExpressionType — PAREN", () => {
    test("delegates to inner expression", () => {
        const inner = lit(ArchitectTypes.LONG);
        const node = makeParen(inner, tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.LONG);
    });

    test("nested parens", () => {
        const node = makeParen(makeParen(lit(ArchitectTypes.STRING), tok()), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.STRING);
    });
});

// ---------------------------------------------------------------------------
// IDENTIFIER — variable lookup
// ---------------------------------------------------------------------------

describe("inferExpressionType — IDENTIFIER (variable)", () => {
    test("resolves variable from context map", () => {
        const node = varNode("lTotal");
        expect(inferExpressionType(node, ctx("lTotal", ArchitectTypes.LONG))).toBe(ArchitectTypes.LONG);
    });

    test("lookup is case-insensitive", () => {
        const node = varNode("zName");
        const context = { variables: new Map([["ZNAME", ArchitectTypes.STRING]]) };
        expect(inferExpressionType(node, context)).toBe(ArchitectTypes.STRING);
    });

    test("returns null when variable not in context", () => {
        const node = varNode("lUnknown");
        expect(inferExpressionType(node, ctx("lOther", ArchitectTypes.LONG))).toBeNull();
    });

    test("returns null with empty context", () => {
        const node = varNode("lX");
        expect(inferExpressionType(node)).toBeNull();
    });

    test("variables is not a Map — falls through to constant check", () => {
        const node = varNode("MAX_SHORT");
        // MAX_SHORT is a builtin constant → SHORT
        expect(inferExpressionType(node, { variables: {} })).toBe(ArchitectTypes.SHORT);
    });
});

// ---------------------------------------------------------------------------
// IDENTIFIER — built-in constants
// ---------------------------------------------------------------------------

describe("inferExpressionType — IDENTIFIER (builtin constant)", () => {
    test("MAX_SHORT → SHORT", () => {
        expect(inferExpressionType(varNode("MAX_SHORT"))).toBe(ArchitectTypes.SHORT);
    });

    test("MIN_SHORT → SHORT", () => {
        expect(inferExpressionType(varNode("MIN_SHORT"))).toBe(ArchitectTypes.SHORT);
    });

    test("MAX_DATE → DATE", () => {
        expect(inferExpressionType(varNode("MAX_DATE"))).toBe(ArchitectTypes.DATE);
    });

    test("MIN_DATE → DATE", () => {
        expect(inferExpressionType(varNode("MIN_DATE"))).toBe(ArchitectTypes.DATE);
    });

    test("constant name is case-insensitive", () => {
        expect(inferExpressionType(varNode("max_short"))).toBe(ArchitectTypes.SHORT);
    });

    test("unknown identifier with no context → null", () => {
        expect(inferExpressionType(varNode("COMPLETELY_UNKNOWN"))).toBeNull();
    });
});

// ---------------------------------------------------------------------------
// CALL — built-in function return types
// ---------------------------------------------------------------------------

describe("inferExpressionType — CALL (builtin)", () => {
    function callNode(name) {
        return makeCall(makeIdentifier(tok(name)), [], tok(), tok());
    }

    test("STR(…) → STRING", () => {
        expect(inferExpressionType(callNode("STR"))).toBe(ArchitectTypes.STRING);
    });

    test("TO_LONG(…) → LONG", () => {
        expect(inferExpressionType(callNode("TO_LONG"))).toBe(ArchitectTypes.LONG);
    });

    test("TO_SHORT(…) → SHORT", () => {
        expect(inferExpressionType(callNode("TO_SHORT"))).toBe(ArchitectTypes.SHORT);
    });

    test("TO_DOUBLE(…) → DOUBLE", () => {
        expect(inferExpressionType(callNode("TO_DOUBLE"))).toBe(ArchitectTypes.DOUBLE);
    });

    test("case-insensitive function lookup", () => {
        expect(inferExpressionType(callNode("str"))).toBe(ArchitectTypes.STRING);
    });

    test("unknown function → null", () => {
        expect(inferExpressionType(callNode("TOTALLY_UNKNOWN_FUNC"))).toBeNull();
    });

    test("null callee → null", () => {
        const node = { type: ExprNodeType.CALL, callee: null, args: [] };
        expect(inferExpressionType(node)).toBeNull();
    });
});

// ---------------------------------------------------------------------------
// CALL — user-defined function catalog
// ---------------------------------------------------------------------------

describe("inferExpressionType — CALL (user-defined)", () => {
    const udCatalog = {
        CALC_TOTAL: { declaredName: "CALC_TOTAL", params: [], returnType: ArchitectTypes.DOUBLE },
        GET_NAME:   { declaredName: "GET_NAME",   params: [], returnType: ArchitectTypes.STRING },
        NO_RETURN:  { declaredName: "NO_RETURN",  params: [], returnType: null }
    };

    function callNode(name) {
        return makeCall(makeIdentifier(tok(name)), [], tok(), tok());
    }

    test("user-defined function returning DOUBLE", () => {
        const context = { userDefinedFunctionCatalog: udCatalog };
        expect(inferExpressionType(callNode("CALC_TOTAL"), context)).toBe(ArchitectTypes.DOUBLE);
    });

    test("user-defined function returning STRING", () => {
        const context = { userDefinedFunctionCatalog: udCatalog };
        expect(inferExpressionType(callNode("GET_NAME"), context)).toBe(ArchitectTypes.STRING);
    });

    test("user-defined function with null returnType → null", () => {
        const context = { userDefinedFunctionCatalog: udCatalog };
        expect(inferExpressionType(callNode("NO_RETURN"), context)).toBeNull();
    });

    test("lookup is case-insensitive", () => {
        const context = { userDefinedFunctionCatalog: udCatalog };
        expect(inferExpressionType(callNode("calc_total"), context)).toBe(ArchitectTypes.DOUBLE);
    });
});

// ---------------------------------------------------------------------------
// UNARY
// ---------------------------------------------------------------------------

describe("inferExpressionType — UNARY", () => {
    test("NOT → BOOLEAN", () => {
        const node = makeUnary("NOT", lit(ArchitectTypes.BOOLEAN), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.BOOLEAN);
    });

    test("NOT (lowercase) → BOOLEAN", () => {
        const node = makeUnary("not", lit(ArchitectTypes.BOOLEAN), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.BOOLEAN);
    });

    test("unary minus preserves SHORT", () => {
        const node = makeUnary("-", lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.SHORT);
    });

    test("unary minus preserves DOUBLE", () => {
        const node = makeUnary("-", lit(ArchitectTypes.DOUBLE), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.DOUBLE);
    });

    test("unary minus on non-numeric → null", () => {
        const node = makeUnary("-", lit(ArchitectTypes.STRING), tok());
        expect(inferExpressionType(node)).toBeNull();
    });

    test("unknown unary op → null", () => {
        const node = makeUnary("+", lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node)).toBeNull();
    });
});

// ---------------------------------------------------------------------------
// BINARY — comparison operators → BOOLEAN
// ---------------------------------------------------------------------------

describe("inferExpressionType — BINARY comparisons", () => {
    test.each(["=", "<>", "<", ">", "<=", ">="])("'%s' → BOOLEAN", (op) => {
        const node = makeBinary(op, lit(ArchitectTypes.LONG), lit(ArchitectTypes.LONG), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.BOOLEAN);
    });
});

// ---------------------------------------------------------------------------
// BINARY — logical operators → BOOLEAN
// ---------------------------------------------------------------------------

describe("inferExpressionType — BINARY logical", () => {
    test("AND → BOOLEAN", () => {
        const node = makeBinary("AND", lit(ArchitectTypes.BOOLEAN), lit(ArchitectTypes.BOOLEAN), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.BOOLEAN);
    });

    test("OR → BOOLEAN", () => {
        const node = makeBinary("OR", lit(ArchitectTypes.BOOLEAN), lit(ArchitectTypes.BOOLEAN), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.BOOLEAN);
    });

    test("AND case-insensitive", () => {
        const node = makeBinary("and", lit(ArchitectTypes.BOOLEAN), lit(ArchitectTypes.BOOLEAN), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.BOOLEAN);
    });
});

// ---------------------------------------------------------------------------
// BINARY — exponentiation
// ---------------------------------------------------------------------------

describe("inferExpressionType — BINARY exponentiation", () => {
    test("** always yields DOUBLE", () => {
        const node = makeBinary("**", lit(ArchitectTypes.SHORT), lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.DOUBLE);
    });
});

// ---------------------------------------------------------------------------
// BINARY — MOD
// ---------------------------------------------------------------------------

describe("inferExpressionType — BINARY MOD", () => {
    test("numeric MOD → left type (SHORT)", () => {
        const node = makeBinary("MOD", lit(ArchitectTypes.SHORT), lit(ArchitectTypes.LONG), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.SHORT);
    });

    test("numeric MOD → left type (DOUBLE)", () => {
        const node = makeBinary("MOD", lit(ArchitectTypes.DOUBLE), lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.DOUBLE);
    });

    test("INTEGER MOD → normalized to LONG", () => {
        const node = makeBinary("MOD", lit(ArchitectTypes.INTEGER), lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.LONG);
    });

    test("non-numeric left MOD → null", () => {
        const node = makeBinary("MOD", lit(ArchitectTypes.STRING), lit(ArchitectTypes.LONG), tok());
        expect(inferExpressionType(node)).toBeNull();
    });

    test("MOD case-insensitive", () => {
        const node = makeBinary("mod", lit(ArchitectTypes.LONG), lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.LONG);
    });
});

// ---------------------------------------------------------------------------
// BINARY — addition
// ---------------------------------------------------------------------------

describe("inferExpressionType — BINARY +", () => {
    test("numeric + numeric → widened type", () => {
        const node = makeBinary("+", lit(ArchitectTypes.SHORT), lit(ArchitectTypes.LONG), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.LONG);
    });

    test("SHORT + SHORT → SHORT", () => {
        const node = makeBinary("+", lit(ArchitectTypes.SHORT), lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.SHORT);
    });

    test("LONG + DOUBLE → DOUBLE", () => {
        const node = makeBinary("+", lit(ArchitectTypes.LONG), lit(ArchitectTypes.DOUBLE), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.DOUBLE);
    });

    test("STRING + STRING → STRING", () => {
        const node = makeBinary("+", lit(ArchitectTypes.STRING), lit(ArchitectTypes.STRING), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.STRING);
    });

    test("DATE + numeric → DATE", () => {
        const node = makeBinary("+", lit(ArchitectTypes.DATE), lit(ArchitectTypes.LONG), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.DATE);
    });

    test("numeric + DATE → DATE", () => {
        const node = makeBinary("+", lit(ArchitectTypes.SHORT), lit(ArchitectTypes.DATE), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.DATE);
    });

    test("TIME + numeric → TIME", () => {
        const node = makeBinary("+", lit(ArchitectTypes.TIME), lit(ArchitectTypes.LONG), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.TIME);
    });

    test("numeric + TIME → TIME", () => {
        const node = makeBinary("+", lit(ArchitectTypes.SHORT), lit(ArchitectTypes.TIME), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.TIME);
    });

    test("incompatible types → null", () => {
        const node = makeBinary("+", lit(ArchitectTypes.STRING), lit(ArchitectTypes.LONG), tok());
        expect(inferExpressionType(node)).toBeNull();
    });
});

// ---------------------------------------------------------------------------
// BINARY — subtraction
// ---------------------------------------------------------------------------

describe("inferExpressionType — BINARY -", () => {
    test("numeric - numeric → widened type", () => {
        const node = makeBinary("-", lit(ArchitectTypes.LONG), lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.LONG);
    });

    test("DATE - numeric → DATE", () => {
        const node = makeBinary("-", lit(ArchitectTypes.DATE), lit(ArchitectTypes.LONG), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.DATE);
    });

    test("DATE - DATE → LONG (days between)", () => {
        const node = makeBinary("-", lit(ArchitectTypes.DATE), lit(ArchitectTypes.DATE), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.LONG);
    });

    test("TIME - numeric → TIME", () => {
        const node = makeBinary("-", lit(ArchitectTypes.TIME), lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.TIME);
    });

    test("incompatible types → null", () => {
        const node = makeBinary("-", lit(ArchitectTypes.STRING), lit(ArchitectTypes.LONG), tok());
        expect(inferExpressionType(node)).toBeNull();
    });
});

// ---------------------------------------------------------------------------
// BINARY — multiplication and division
// ---------------------------------------------------------------------------

describe("inferExpressionType — BINARY * and /", () => {
    test("SHORT * LONG → LONG", () => {
        const node = makeBinary("*", lit(ArchitectTypes.SHORT), lit(ArchitectTypes.LONG), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.LONG);
    });

    test("DOUBLE / SHORT → DOUBLE", () => {
        const node = makeBinary("/", lit(ArchitectTypes.DOUBLE), lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node)).toBe(ArchitectTypes.DOUBLE);
    });

    test("non-numeric * numeric → null", () => {
        const node = makeBinary("*", lit(ArchitectTypes.STRING), lit(ArchitectTypes.LONG), tok());
        expect(inferExpressionType(node)).toBeNull();
    });
});

// ---------------------------------------------------------------------------
// BINARY — variable operands resolved from context
// ---------------------------------------------------------------------------

describe("inferExpressionType — BINARY with variable operands", () => {
    test("variable + literal resolved through context", () => {
        const varCtx = { variables: new Map([["LTOTAL", ArchitectTypes.LONG]]) };
        const node = makeBinary("+", varNode("lTotal"), lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node, varCtx)).toBe(ArchitectTypes.LONG);
    });

    test("unknown variable operand → null", () => {
        const node = makeBinary("+", varNode("lUnknown"), lit(ArchitectTypes.SHORT), tok());
        expect(inferExpressionType(node)).toBeNull();
    });
});

// ---------------------------------------------------------------------------
// End-to-end: parser → inference
// ---------------------------------------------------------------------------

describe("inferExpressionType — end-to-end via parser", () => {

    function parseExpr(exprStr) {
        const doc = makeDocument(["#HASH-OFF", `SET zX = ${exprStr}`]);
        const { ast } = buildDocumentAst(doc);
        const setNode = ast.statements.find(s => s.type === NodeType.SetStatement);
        return parseExpression(setNode ? setNode.value : null);
    }

    test("42 (SHORT literal) → SHORT", () => {
        expect(inferExpressionType(parseExpr("42"))).toBe(ArchitectTypes.SHORT);
    });

    test("3.14 (DOUBLE literal) → DOUBLE", () => {
        expect(inferExpressionType(parseExpr("3.14"))).toBe(ArchitectTypes.DOUBLE);
    });

    test('"hello" (STRING literal) → STRING', () => {
        expect(inferExpressionType(parseExpr('"hello"'))).toBe(ArchitectTypes.STRING);
    });

    test("TRUE (BOOLEAN literal) → BOOLEAN", () => {
        expect(inferExpressionType(parseExpr("TRUE"))).toBe(ArchitectTypes.BOOLEAN);
    });

    test("1 + 2 → SHORT (both SHORT, widens to SHORT)", () => {
        expect(inferExpressionType(parseExpr("1 + 2"))).toBe(ArchitectTypes.SHORT);
    });

    test("1 + 40000 → LONG (SHORT + LONG → LONG)", () => {
        expect(inferExpressionType(parseExpr("1 + 40000"))).toBe(ArchitectTypes.LONG);
    });

    test("1 = 1 → BOOLEAN", () => {
        expect(inferExpressionType(parseExpr("1 = 1"))).toBe(ArchitectTypes.BOOLEAN);
    });

    test("2 ** 8 → DOUBLE", () => {
        expect(inferExpressionType(parseExpr("2 ** 8"))).toBe(ArchitectTypes.DOUBLE);
    });

    test("NOT TRUE → BOOLEAN", () => {
        expect(inferExpressionType(parseExpr("NOT TRUE"))).toBe(ArchitectTypes.BOOLEAN);
    });

    test("STR(42) → STRING", () => {
        expect(inferExpressionType(parseExpr("STR(42)"))).toBe(ArchitectTypes.STRING);
    });

    test("(42) → SHORT (paren passthrough)", () => {
        expect(inferExpressionType(parseExpr("(42)"))).toBe(ArchitectTypes.SHORT);
    });

    test("MAX_SHORT (builtin constant) → SHORT", () => {
        expect(inferExpressionType(parseExpr("MAX_SHORT"))).toBe(ArchitectTypes.SHORT);
    });
});
