import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { execSync } from "child_process";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..", "..", "..");
const DATA_ROOT = path.join(ROOT, "builtins-data");
const BUNDLE = path.join(DATA_ROOT, "global-variables.bundle.json");

describe("builtins bundle parity", () => {
    test("bundle (when present) deep-equals the directory walk", () => {
        execSync(`node ${JSON.stringify(path.join(ROOT, "tools", "build-builtins-bundle.js"))}`);
        const bundleEntries = JSON.parse(fs.readFileSync(BUNDLE, "utf8"));

        const dir = path.join(DATA_ROOT, "global-variables");
        const dirEntries = fs.readdirSync(dir).filter(f => f.endsWith(".json")).sort().map(f => {
            const e = JSON.parse(fs.readFileSync(path.join(dir, f), "utf8"));
            delete e.$schema;
            return e;
        });

        expect(bundleEntries).toEqual(dirEntries);
    });
});
