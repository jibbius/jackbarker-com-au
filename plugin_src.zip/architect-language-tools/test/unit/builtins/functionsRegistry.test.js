/**
 * Unit tests for core/src/builtins/functionsRegistry.js.
 *
 * Pins the param-role audit (Brief 3) so a future edit that drops a role
 * annotation surfaces here before reaching the SEP_FOLDER validator. The
 * inlined-params shape stores `role` per-param (Brief 12).
 */

import { BuiltInFunctions } from "../../../core/src/builtins/functionsRegistry.js";

describe("functionsRegistry param roles", () => {
    test("FILE_OPEN tags its filename parameter (index 1) as path", () => {
        const entry = BuiltInFunctions.FILE_OPEN;
        expect(Array.isArray(entry.params)).toBe(true);
        expect(entry.params[1]?.role).toBe("path");
    });

    test("every param.role is a known role string when present", () => {
        const knownRoles = new Set(["path", "cursorDirection", "tableSynonym"]);
        for (const [, entry] of Object.entries(BuiltInFunctions)) {
            for (const param of entry.params || []) {
                if (param.role === undefined) continue;
                expect(knownRoles.has(param.role)).toBe(true);
            }
        }
    });
});
