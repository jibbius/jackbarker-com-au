import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";

import { BuiltInGlobalVariables } from "../../../core/src/builtins/globalVariablesRegistry.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const snapshot = JSON.parse(
    fs.readFileSync(path.join(__dirname, "__fixtures__", "globalVariables.snapshot.json"), "utf8")
);

describe("globalVariablesRegistry (data-driven loader)", () => {
    test("matches pre-migration snapshot exactly", () => {
        const actual = {};
        for (const [k, v] of Object.entries(BuiltInGlobalVariables)) {
            actual[k] = { type: v.type, readOnly: v.readOnly, description: v.description };
        }
        expect(actual).toEqual(snapshot);
    });

    test("entries are frozen (top-level intentionally mutable for supplementary loader)", () => {
        const first = Object.values(BuiltInGlobalVariables)[0];
        expect(Object.isFrozen(first)).toBe(true);
    });

    test("expected count", () => {
        expect(Object.keys(BuiltInGlobalVariables).length).toBe(Object.keys(snapshot).length);
    });
});
