import { validate, validateOrThrow } from "../../../core/src/builtins/_schemaValidator.js";

describe("_schemaValidator", () => {
    test("type and required", () => {
        const schema = {
            type: "object",
            properties: { a: { type: "string" } },
            required: ["a"],
            additionalProperties: false
        };
        expect(validate({ a: "hi" }, schema)).toEqual([]);
        expect(validate({}, schema)[0].message).toMatch(/missing required/);
        expect(validate({ a: 1 }, schema)[0].message).toMatch(/expected type string/);
        expect(validate({ a: "hi", b: 2 }, schema)[0].message).toMatch(/additional property/);
    });

    test("enum", () => {
        const schema = { type: "string", enum: ["X", "Y"] };
        expect(validate("X", schema)).toEqual([]);
        expect(validate("Z", schema)[0].message).toMatch(/not in enum/);
    });

    test("array items + minItems", () => {
        const schema = { type: "array", items: { type: "number" }, minItems: 1 };
        expect(validate([1, 2], schema)).toEqual([]);
        expect(validate([], schema)[0].message).toMatch(/minItems/);
        expect(validate([1, "x"], schema)[0].path).toBe("/1");
    });

    test("pattern", () => {
        const schema = { type: "string", pattern: "^[A-Z]+$" };
        expect(validate("ABC", schema)).toEqual([]);
        expect(validate("abc", schema)[0].message).toMatch(/pattern/);
    });

    test("$ref to $defs", () => {
        const schema = {
            $defs: { name: { type: "string", minLength: 1 } },
            type: "object",
            properties: { n: { $ref: "#/$defs/name" } }
        };
        expect(validate({ n: "x" }, schema)).toEqual([]);
        expect(validate({ n: "" }, schema)[0].message).toMatch(/minLength/);
    });

    test("oneOf", () => {
        const schema = { oneOf: [{ type: "string" }, { type: "number" }] };
        expect(validate("x", schema)).toEqual([]);
        expect(validate(1, schema)).toEqual([]);
        expect(validate(true, schema)[0].message).toMatch(/oneOf/);
    });

    test("validateOrThrow includes location", () => {
        expect(() => validateOrThrow({}, { type: "object", required: ["a"] }, "foo.json"))
            .toThrow(/foo\.json: schema validation failed/);
    });

    test("ignores $schema property on objects", () => {
        const schema = { type: "object", properties: {}, additionalProperties: false };
        expect(validate({ $schema: "../schemas/x.json" }, schema)).toEqual([]);
    });
});
