/**
 * Unit tests for the deprecated-symbol schema and loader.
 *
 * Covers schema accept/reject for the composite-file shape and the
 * preserved behaviour of `DeprecatedHandles` as a directly-readable map.
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { validate } from "../../core/src/builtins/_schemaValidator.js";
import { DeprecatedHandles } from "../../core/src/builtins/deprecatedSymbols.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SCHEMA_FILE = path.resolve(
    __dirname,
    "../../builtins-data/schemas/deprecated-symbol.schema.json"
);
const schema = JSON.parse(fs.readFileSync(SCHEMA_FILE, "utf8"));

describe("deprecated-symbol schema", () => {
    test("accepts a well-formed entry", () => {
        const errors = validate({ ABM_FORMULA_CODE: "hCTz_ABM_FC" }, schema);
        expect(errors).toEqual([]);
    });

    test("accepts a top-level $schema editor pointer", () => {
        const errors = validate(
            { "$schema": "./schemas/deprecated-symbol.schema.json", FOO: "hBAR" },
            schema
        );
        expect(errors).toEqual([]);
    });

    test("rejects a non-string value", () => {
        const errors = validate({ FOO: 123 }, schema);
        expect(errors.length).toBeGreaterThan(0);
    });

    test("rejects an empty-string value", () => {
        const errors = validate({ FOO: "" }, schema);
        expect(errors.length).toBeGreaterThan(0);
    });
});

describe("DeprecatedHandles", () => {
    test("returns the loaded replacement for a known key", () => {
        expect(DeprecatedHandles["ABM_FORMULA_CODE"]).toBe("hCTz_ABM_FC");
    });

    test("returns the loaded replacement for another known key", () => {
        expect(DeprecatedHandles["ZSR_VERSION_DATE"]).toBe("hSRz_Version_DateTime");
    });

    test("is enumerable and includes a substantial number of entries", () => {
        const keys = Object.keys(DeprecatedHandles);
        expect(keys.length).toBeGreaterThanOrEqual(2500);
    });

    test("does not expose a $schema key", () => {
        expect(Object.prototype.hasOwnProperty.call(DeprecatedHandles, "$schema")).toBe(false);
    });
});
