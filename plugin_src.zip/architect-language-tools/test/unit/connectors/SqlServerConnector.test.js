/**
 * Unit tests for SqlServerConnector — exercises the spawn-shaped surface
 * of queryDescriptionCodes via a mocked 'child_process'. Covers:
 *   - PowerShell happy path + script/env shape
 *   - sqlcmd fallback (no `-o -` regression; argv shape)
 *   - timeout (kill chain) → distinct error
 *   - buffer overflow → distinct error
 *   - non-zero exit error includes both stderr and stdout context
 *   - parseRows tolerates non-array (single object)
 */
import { jest } from '@jest/globals';
import { EventEmitter } from 'events';

const spawnCalls = [];
let spawnImpl = null;

function makeFakeProc() {
    const proc = new EventEmitter();
    proc.stdout = new EventEmitter();
    proc.stderr = new EventEmitter();
    proc.kill = jest.fn();
    return proc;
}

await jest.unstable_mockModule('child_process', () => ({
    spawn: (command, args, options) => {
        spawnCalls.push({ command, args, options });
        return spawnImpl(command, args, options);
    }
}));

const { queryDescriptionCodes } = await import('../../../connectors/src/SqlServerConnector.js');

beforeEach(() => {
    spawnCalls.length = 0;
    spawnImpl = null;
});

describe('queryDescriptionCodes — PowerShell happy path', () => {
    test('parses JSON array from PowerShell stdout and stops at primary path', async () => {
        spawnImpl = (command) => {
            const proc = makeFakeProc();
            if (command === 'powershell') {
                process.nextTick(() => {
                    proc.stdout.emit('data', Buffer.from('[{"g":"MD","t":"Status","c":"A","d":"Active","x":"N"}]', 'utf8'));
                    proc.emit('close', 0);
                });
            }
            return proc;
        };
        const { rows, skipped } = await queryDescriptionCodes('S1', 'DB1');
        expect(rows).toEqual([{ g: 'MD', t: 'Status', c: 'A', d: 'Active', x: 'N' }]);
        expect(skipped).toEqual([]);
        expect(spawnCalls).toHaveLength(1);
        expect(spawnCalls[0].command).toBe('powershell');
        expect(spawnCalls[0].args).toEqual(expect.arrayContaining(['-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand']));
        expect(spawnCalls[0].options.env.__ARCH_PS_SERVER).toBe('S1');
        expect(spawnCalls[0].options.env.__ARCH_PS_DATABASE).toBe('DB1');
        // External names must not leak into the spawn env — they're MCP-tier
        // overrides that flow into projectConfig, not values consumed by PS.
        expect(spawnCalls[0].options.env.ARCH_LANG_CONN_SERVER).toBeUndefined();
        expect(spawnCalls[0].options.env.ARCH_LANG_CONN_DATABASE).toBeUndefined();
    });

    test('encoded PowerShell script includes UTF-8 OutputEncoding line and default TLS posture', async () => {
        spawnImpl = () => {
            const proc = makeFakeProc();
            process.nextTick(() => {
                proc.stdout.emit('data', Buffer.from('[]', 'utf8'));
                proc.emit('close', 0);
            });
            return proc;
        };
        await queryDescriptionCodes('S', 'D');
        const encoded = spawnCalls[0].args[spawnCalls[0].args.indexOf('-EncodedCommand') + 1];
        const decoded = Buffer.from(encoded, 'base64').toString('utf16le');
        expect(decoded).toContain('[Console]::OutputEncoding = [System.Text.Encoding]::UTF8');
        // Default behaviour (no options) preserves the historical
        // internal-network posture: encrypt=false, trust=true.
        expect(decoded).toMatch(/\$builder\['Encrypt'\][^\n]*\$false/);
        expect(decoded).toMatch(/\$builder\['TrustServerCertificate'\][^\n]*\$true/);
    });

    test('honours encrypt=true / trustServerCertificate=false options on the PS path', async () => {
        spawnImpl = () => {
            const proc = makeFakeProc();
            process.nextTick(() => {
                proc.stdout.emit('data', Buffer.from('[]', 'utf8'));
                proc.emit('close', 0);
            });
            return proc;
        };
        await queryDescriptionCodes('S', 'D', { encrypt: true, trustServerCertificate: false });
        const encoded = spawnCalls[0].args[spawnCalls[0].args.indexOf('-EncodedCommand') + 1];
        const decoded = Buffer.from(encoded, 'base64').toString('utf16le');
        expect(decoded).toMatch(/\$builder\['Encrypt'\][^\n]*\$true/);
        expect(decoded).toMatch(/\$builder\['TrustServerCertificate'\][^\n]*\$false/);
    });

    test('parseRows wraps a single non-array JSON object into an array', async () => {
        spawnImpl = () => {
            const proc = makeFakeProc();
            process.nextTick(() => {
                proc.stdout.emit('data', Buffer.from('{"g":"X","t":"Y","c":"Z","d":"d","x":"N"}', 'utf8'));
                proc.emit('close', 0);
            });
            return proc;
        };
        const { rows } = await queryDescriptionCodes('S', 'D');
        expect(rows).toEqual([{ g: 'X', t: 'Y', c: 'Z', d: 'd', x: 'N' }]);
    });
});

describe('queryDescriptionCodes — sqlcmd fallback', () => {
    test('falls through to sqlcmd when PS exits non-zero, with no `-o -` regression', async () => {
        spawnImpl = (command) => {
            const proc = makeFakeProc();
            if (command === 'powershell') {
                process.nextTick(() => {
                    proc.stderr.emit('data', Buffer.from('System.Data.SqlClient not available', 'utf8'));
                    proc.emit('close', 1);
                });
            } else if (command === 'sqlcmd') {
                process.nextTick(() => {
                    proc.stdout.emit('data', Buffer.from('[{"g":"A","t":"B","c":"C","d":"D","x":"N"}]\n\n(1 rows affected)\n', 'utf8'));
                    proc.emit('close', 0);
                });
            }
            return proc;
        };
        const { rows } = await queryDescriptionCodes('SRV', 'DB');
        expect(rows).toEqual([{ g: 'A', t: 'B', c: 'C', d: 'D', x: 'N' }]);
        expect(spawnCalls).toHaveLength(2);
        const sqlcmdCall = spawnCalls[1];
        expect(sqlcmdCall.command).toBe('sqlcmd');
        // Regression: `-o -` previously wrote to a file literally named '-'.
        expect(sqlcmdCall.args.indexOf('-o')).toBe(-1);
        expect(sqlcmdCall.args).toEqual(expect.arrayContaining(['-S', 'SRV', '-d', 'DB', '-E', '-C', '-h', '-1', '-W', '-f', '65001']));
    });

    test('sqlcmd argv omits -C when trustServerCertificate=false', async () => {
        spawnImpl = (command) => {
            const proc = makeFakeProc();
            if (command === 'powershell') {
                process.nextTick(() => {
                    proc.stderr.emit('data', Buffer.from('boom', 'utf8'));
                    proc.emit('close', 1);
                });
            } else {
                process.nextTick(() => {
                    proc.stdout.emit('data', Buffer.from('[]\n\n(0 rows affected)\n', 'utf8'));
                    proc.emit('close', 0);
                });
            }
            return proc;
        };
        await queryDescriptionCodes('S', 'D', { trustServerCertificate: false });
        const sqlcmdCall = spawnCalls[1];
        expect(sqlcmdCall.command).toBe('sqlcmd');
        expect(sqlcmdCall.args).not.toContain('-C');
    });

    test('sqlcmd returning no JSON output throws a descriptive combined error', async () => {
        spawnImpl = (command) => {
            const proc = makeFakeProc();
            if (command === 'powershell') {
                process.nextTick(() => {
                    proc.stderr.emit('data', Buffer.from('boom', 'utf8'));
                    proc.emit('close', 1);
                });
            } else {
                process.nextTick(() => {
                    proc.stdout.emit('data', Buffer.from('Login failed\n', 'utf8'));
                    proc.emit('close', 0);
                });
            }
            return proc;
        };
        await expect(queryDescriptionCodes('S', 'D')).rejects.toThrow(/PowerShell:.*\| sqlcmd:.*no JSON output/);
    });
});

describe('queryDescriptionCodes — row-shape tolerance', () => {
    test('accepts a row with a blank CDz_Description_Code', async () => {
        spawnImpl = () => {
            const proc = makeFakeProc();
            process.nextTick(() => {
                proc.stdout.emit('data', Buffer.from(
                    '[{"g":"MD","t":"Status","c":"","d":"INTENTIONALLY BLANK","x":"N"}]',
                    'utf8'
                ));
                proc.emit('close', 0);
            });
            return proc;
        };
        const { rows, skipped } = await queryDescriptionCodes('S', 'D');
        expect(rows).toEqual([{ g: 'MD', t: 'Status', c: '', d: 'INTENTIONALLY BLANK', x: 'N' }]);
        expect(skipped).toEqual([]);
    });

    test('skips rows missing CDz_Group or CDz_Description_Type instead of failing the whole refresh', async () => {
        spawnImpl = () => {
            const proc = makeFakeProc();
            process.nextTick(() => {
                proc.stdout.emit('data', Buffer.from(JSON.stringify([
                    { g: 'MD', t: 'Status', c: 'A', d: 'Active',  x: 'N' },
                    { g: '',   t: 'Status', c: 'B', d: 'no group', x: 'N' },
                    { g: 'MD', t: '',       c: 'C', d: 'no type',  x: 'N' },
                    { g: 'MD', t: 'Status', c: 'D', d: 'Discharged', x: 'N' }
                ]), 'utf8'));
                proc.emit('close', 0);
            });
            return proc;
        };
        const { rows, skipped } = await queryDescriptionCodes('S', 'D');
        expect(rows).toHaveLength(2);
        expect(rows.map(r => r.c)).toEqual(['A', 'D']);
        expect(skipped).toEqual([
            'row 1: missing required column CDz_Group',
            'row 2: missing required column CDz_Description_Type'
        ]);
    });
});

describe('queryDescriptionCodes — error envelope', () => {
    test('non-zero exit includes both stderr and stdout context in the error', async () => {
        spawnImpl = (command) => {
            const proc = makeFakeProc();
            if (command === 'powershell') {
                process.nextTick(() => {
                    proc.stdout.emit('data', Buffer.from('partial output', 'utf8'));
                    proc.stderr.emit('data', Buffer.from('Cannot open database', 'utf8'));
                    proc.emit('close', 2);
                });
            } else {
                process.nextTick(() => {
                    proc.stderr.emit('data', Buffer.from('also failed', 'utf8'));
                    proc.emit('close', 3);
                });
            }
            return proc;
        };
        await expect(queryDescriptionCodes('S', 'D')).rejects.toThrow(/Cannot open database/);
        await expect(queryDescriptionCodes('S', 'D')).rejects.toThrow(/partial output/);
    });
});

describe('queryDescriptionCodes — timeout', () => {
    test('kills the subprocess and surfaces a distinct timeout error', async () => {
        spawnImpl = () => {
            const proc = makeFakeProc();
            // Never resolves on its own; rely on the SIGTERM kill from the timeout
            // path to drive the close event.
            proc.kill = jest.fn((signal) => {
                if (signal === 'SIGTERM') {
                    process.nextTick(() => proc.emit('close', null));
                }
            });
            return proc;
        };
        await expect(queryDescriptionCodes('S', 'D', { timeoutMs: 5 })).rejects.toThrow(
            /PowerShell:.*timed out after 5 ms.*\| sqlcmd:.*timed out after 5 ms/
        );
    }, 2000);
});

describe('queryDescriptionCodes — buffer overflow', () => {
    test('aborts when total stdout exceeds maxBufferBytes', async () => {
        spawnImpl = () => {
            const proc = makeFakeProc();
            proc.kill = jest.fn(() => {
                process.nextTick(() => proc.emit('close', null));
            });
            process.nextTick(() => {
                proc.stdout.emit('data', Buffer.alloc(1024, 0x41));
            });
            return proc;
        };
        await expect(
            queryDescriptionCodes('S', 'D', { maxBufferBytes: 100, timeoutMs: 5_000 })
        ).rejects.toThrow(/output exceeded 100 bytes/);
    });
});
