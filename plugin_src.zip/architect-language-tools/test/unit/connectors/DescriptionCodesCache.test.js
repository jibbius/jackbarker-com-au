/**
 * Unit tests for DescriptionCodesCache — focuses on the atomic-write
 * contract of build(): write to ${filePath}.tmp then rename into place,
 * with best-effort cleanup on failure and crash-safe behaviour under
 * concurrent writers.
 */

import * as fs from "fs";
import * as path from "path";
import * as os from "os";
import { DescriptionCodesCache } from "../../../connectors/src/DescriptionCodesCache.js";

function mktempRoot() {
    return fs.mkdtempSync(path.join(os.tmpdir(), "arch-desc-cache-"));
}

const ROWS = [
    { g: "MD", t: "Status", c: "A", d: "Active",   x: "N" },
    { g: "MD", t: "Status", c: "X", d: "Closed",   x: "Y" },
    { g: "CD", t: "Type",   c: "7", d: "Routine",  x: "N" }
];

describe("DescriptionCodesCache.build (atomic write)", () => {
    let root;
    afterEach(() => {
        if (root) fs.rmSync(root, { recursive: true, force: true });
        root = null;
    });

    test("writes the final cache file and does not leave a .tmp behind", async () => {
        root = mktempRoot();
        const filePath = path.join(root, "cache.json");
        const cache = new DescriptionCodesCache();

        await cache.build(ROWS, "db01", "ACURITY", filePath);

        expect(fs.existsSync(filePath)).toBe(true);
        expect(fs.existsSync(`${filePath}.tmp`)).toBe(false);

        const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
        expect(parsed.version).toBe(1);
        expect(parsed.server).toBe("db01");
        expect(parsed.database).toBe("ACURITY");
        expect(parsed.data.MDStatus).toHaveLength(2);

        // Public state is also populated.
        expect(cache.lookup("MDStatus")).toHaveLength(2);
        expect(cache.getStatus().populated).toBe(true);
    });

    test("a stale ${filePath}.tmp from a prior crashed write is overwritten safely", async () => {
        root = mktempRoot();
        const filePath = path.join(root, "cache.json");
        const tmpPath = `${filePath}.tmp`;

        // Simulate a prior crashed write: a half-written or junk .tmp.
        fs.writeFileSync(tmpPath, "{ this is not valid json", "utf8");

        const cache = new DescriptionCodesCache();
        await cache.build(ROWS, "db01", "ACURITY", filePath);

        expect(fs.existsSync(filePath)).toBe(true);
        // The rename consumed the temp file.
        expect(fs.existsSync(tmpPath)).toBe(false);

        const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
        expect(parsed.data.MDStatus).toBeDefined();
    });

    test("if the write fails, the original cache file is unchanged and no .tmp is left over", async () => {
        root = mktempRoot();
        const filePath = path.join(root, "cache.json");
        const tmpPath = `${filePath}.tmp`;

        // Seed an existing valid cache file.
        const original = JSON.stringify({ version: 1, fetchedAt: "x", server: "old", database: "OLD", data: {} });
        fs.writeFileSync(filePath, original, "utf8");

        // Block the temp-write path: place a directory where the .tmp file
        // would go. writeFile() will reject with EISDIR.
        fs.mkdirSync(tmpPath);

        const cache = new DescriptionCodesCache();
        await expect(cache.build(ROWS, "db01", "ACURITY", filePath)).rejects.toBeDefined();

        // Original is untouched.
        expect(fs.readFileSync(filePath, "utf8")).toBe(original);

        // unlink() of a directory fails (best-effort cleanup is a no-op);
        // the directory we placed is the test's, not stray litter from the
        // implementation. Remove it ourselves so the rmSync afterEach sees a
        // tidy tree.
        fs.rmdirSync(tmpPath);
    });

    test("load() returns reason='missing' when the cache file is absent", async () => {
        root = mktempRoot();
        const filePath = path.join(root, "cache.json");
        const result = await new DescriptionCodesCache().load(filePath);
        expect(result).toEqual({ ok: false, age: null, reason: "missing" });
    });

    test("load() returns reason='invalid' when the file is not valid JSON", async () => {
        root = mktempRoot();
        const filePath = path.join(root, "cache.json");
        fs.writeFileSync(filePath, "{ not json", "utf8");
        const result = await new DescriptionCodesCache().load(filePath);
        expect(result.ok).toBe(false);
        expect(result.reason).toBe("invalid");
    });

    test("load() returns reason='stale-version' when the cache schema is older", async () => {
        root = mktempRoot();
        const filePath = path.join(root, "cache.json");
        fs.writeFileSync(filePath, JSON.stringify({ version: 0, fetchedAt: "x", server: "s", database: "d", data: {} }), "utf8");
        const result = await new DescriptionCodesCache().load(filePath);
        expect(result.ok).toBe(false);
        expect(result.reason).toBe("stale-version");
    });

    test("load() returns reason='loaded' on success", async () => {
        root = mktempRoot();
        const filePath = path.join(root, "cache.json");
        const cache = new DescriptionCodesCache();
        await cache.build(ROWS, "db01", "ACURITY", filePath);

        const result = await new DescriptionCodesCache().load(filePath);
        expect(result.ok).toBe(true);
        expect(result.reason).toBe("loaded");
    });

    test("concurrent build() calls both succeed; final file is valid JSON (last writer wins)", async () => {
        root = mktempRoot();
        const filePath = path.join(root, "cache.json");

        const cacheA = new DescriptionCodesCache();
        const cacheB = new DescriptionCodesCache();

        const rowsA = [{ g: "AA", t: "X", c: "1", d: "fromA", x: "N" }];
        const rowsB = [{ g: "BB", t: "Y", c: "2", d: "fromB", x: "N" }];

        await Promise.all([
            cacheA.build(rowsA, "dbA", "ACURITY", filePath),
            cacheB.build(rowsB, "dbB", "ACURITY", filePath)
        ]);

        // No half-written .tmp left.
        expect(fs.existsSync(`${filePath}.tmp`)).toBe(false);

        // Result must be valid JSON loadable by load().
        const reader = new DescriptionCodesCache();
        const result = await reader.load(filePath);
        expect(result.ok).toBe(true);

        // It must be one of the two writers, not a frankenfile.
        const status = reader.getStatus();
        expect(["dbA", "dbB"]).toContain(status.server);
        if (status.server === "dbA") {
            expect(reader.lookup("AAX")).toHaveLength(1);
        } else {
            expect(reader.lookup("BBY")).toHaveLength(1);
        }
    });
});
