import * as fs from "fs";
import * as os from "os";
import * as path from "path";

import { loadProjectConfig, DEFAULTS, parseYesNo } from "../../../core/src/config/projectConfig.js";

let tmpDir;

beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "projectConfig-test-"));
});

afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
});

function writeCfg(content) {
    const p = path.join(tmpDir, "Acurity.CFG");
    fs.writeFileSync(p, content, "utf8");
    return p;
}

describe("loadProjectConfig", () => {
    test("returns literal defaults when no path and no overrides", () => {
        const cfg = loadProjectConfig({});
        expect(cfg.usrcalcDirectory).toBe(DEFAULTS.usrcalcDirectory);
        expect(cfg.sourcePathToCfgFile).toBeNull();
    });

    test("CFG value is taken when present and no override", () => {
        const p = writeCfg("USRCALCDIRECTORY = MyCalcs\n");
        const cfg = loadProjectConfig({ pathToCfgFile: p });
        expect(cfg.usrcalcDirectory).toBe("MyCalcs");
        expect(cfg.sourcePathToCfgFile).toBe(p);
    });

    test("override beats CFG value", () => {
        const p = writeCfg("USRCALCDIRECTORY = FromCfg\n");
        const cfg = loadProjectConfig({
            pathToCfgFile: p,
            overrides: { usrcalcDirectory: "FromOverride" }
        });
        expect(cfg.usrcalcDirectory).toBe("FromOverride");
    });

    test("override applies even without a CFG path", () => {
        const cfg = loadProjectConfig({
            overrides: { usrcalcDirectory: "OnlyOverride" }
        });
        expect(cfg.usrcalcDirectory).toBe("OnlyOverride");
        expect(cfg.sourcePathToCfgFile).toBeNull();
    });

    test("missing CFG file throws (loud-fail)", () => {
        expect(() => loadProjectConfig({
            pathToCfgFile: path.join(tmpDir, "does-not-exist.CFG")
        })).toThrow(/does not exist/);
    });

    test("malformed CFG throws with line context", () => {
        const p = writeCfg("VALID = ok\nNO_EQUALS\n");
        expect(() => loadProjectConfig({ pathToCfgFile: p })).toThrow(/line 2/);
    });

    test("CFG without the directory key falls back to defaults", () => {
        const p = writeCfg("DBSERVER = LOCAL\n");
        const cfg = loadProjectConfig({ pathToCfgFile: p });
        expect(cfg.usrcalcDirectory).toBe(DEFAULTS.usrcalcDirectory);
    });

    test("override wins when CFG omits the key", () => {
        const p = writeCfg("DBSERVER = LOCAL\n");
        const cfg = loadProjectConfig({
            pathToCfgFile: p,
            overrides: { usrcalcDirectory: "Picked" }
        });
        expect(cfg.usrcalcDirectory).toBe("Picked");
    });

    test("returned config is frozen", () => {
        const cfg = loadProjectConfig({});
        expect(Object.isFrozen(cfg)).toBe(true);
        expect(() => { cfg.usrcalcDirectory = "Mutated"; }).toThrow(TypeError);
    });

    test("empty-string pathToCfgFile is treated as unset", () => {
        const cfg = loadProjectConfig({ pathToCfgFile: "   " });
        expect(cfg.sourcePathToCfgFile).toBeNull();
    });

    test("CFG keys are case-insensitive on lookup", () => {
        const p = writeCfg("usrcalcdirectory = lowercase_key_value\n");
        const cfg = loadProjectConfig({ pathToCfgFile: p });
        expect(cfg.usrcalcDirectory).toBe("lowercase_key_value");
    });

    test("reportDirectory: literal default when nothing supplied", () => {
        const cfg = loadProjectConfig({});
        expect(cfg.reportDirectory).toBe(DEFAULTS.reportDirectory);
        expect(cfg.reportDirectory).toBe("REPORTS");
    });

    test("reportDirectory: CFG value flows through", () => {
        const p = writeCfg("REPORTDIRECTORY = MyReports\n");
        const cfg = loadProjectConfig({ pathToCfgFile: p });
        expect(cfg.reportDirectory).toBe("MyReports");
    });

    test("reportDirectory: override beats CFG value", () => {
        const p = writeCfg("REPORTDIRECTORY = FromCfg\n");
        const cfg = loadProjectConfig({
            pathToCfgFile: p,
            overrides: { reportDirectory: "FromOverride" }
        });
        expect(cfg.reportDirectory).toBe("FromOverride");
    });

    // --- db* fields (Brief 9) -------------------------------------------------

    test("db* fields: defaults when nothing supplied", () => {
        const cfg = loadProjectConfig({});
        expect(cfg.dbServer).toBe("");
        expect(cfg.dbDatabase).toBe("");
        expect(cfg.dbEncrypt).toBe(false);
        expect(cfg.dbTrustServerCertificate).toBe(true);
    });

    test("dbServer/dbDatabase: CFG values flow through", () => {
        const p = writeCfg("DBSERVER = MYBOX\nDBDATABASE = ArchitectDev\n");
        const cfg = loadProjectConfig({ pathToCfgFile: p });
        expect(cfg.dbServer).toBe("MYBOX");
        expect(cfg.dbDatabase).toBe("ArchitectDev");
    });

    test("dbServer/dbDatabase: override beats CFG", () => {
        const p = writeCfg("DBSERVER = FromCfg\nDBDATABASE = FromCfg\n");
        const cfg = loadProjectConfig({
            pathToCfgFile: p,
            overrides: { dbServer: "FromOverride", dbDatabase: "FromOverride" }
        });
        expect(cfg.dbServer).toBe("FromOverride");
        expect(cfg.dbDatabase).toBe("FromOverride");
    });

    test("dbEncrypt/dbTrustServerCertificate: CFG Y/N coerced to booleans", () => {
        const p = writeCfg("DBENCRYPT = Y\nDBTRUSTSERVERCERT = N\n");
        const cfg = loadProjectConfig({ pathToCfgFile: p });
        expect(cfg.dbEncrypt).toBe(true);
        expect(cfg.dbTrustServerCertificate).toBe(false);
    });

    test("dbEncrypt/dbTrustServerCertificate: override booleans win over CFG", () => {
        const p = writeCfg("DBENCRYPT = Y\nDBTRUSTSERVERCERT = Y\n");
        const cfg = loadProjectConfig({
            pathToCfgFile: p,
            overrides: { dbEncrypt: false, dbTrustServerCertificate: false }
        });
        expect(cfg.dbEncrypt).toBe(false);
        expect(cfg.dbTrustServerCertificate).toBe(false);
    });

    test("db* fields: CFG missing one key falls back to literal default", () => {
        const p = writeCfg("DBSERVER = ONLYBOX\n");
        const cfg = loadProjectConfig({ pathToCfgFile: p });
        expect(cfg.dbServer).toBe("ONLYBOX");
        expect(cfg.dbDatabase).toBe("");
        expect(cfg.dbEncrypt).toBe(false);
        expect(cfg.dbTrustServerCertificate).toBe(true);
    });

    test("dbEncrypt: override of `false` is honoured (not treated as unset)", () => {
        // Regression guard: the resolver must distinguish "boolean false"
        // override from "absent" — otherwise CFG `Y` would always win.
        const p = writeCfg("DBENCRYPT = Y\n");
        const cfg = loadProjectConfig({
            pathToCfgFile: p,
            overrides: { dbEncrypt: false }
        });
        expect(cfg.dbEncrypt).toBe(false);
    });

    test("dbTrustServerCertificate: CFG empty value coerces to false per parseYesNo spec", () => {
        // Per parseYesNo: empty/whitespace → false (not default). Default only
        // applies when the CFG omits the key entirely; an explicit-but-blank
        // value is "the user said something, and what they said is not truthy".
        const p = writeCfg("DBTRUSTSERVERCERT =\n");
        const cfg = loadProjectConfig({ pathToCfgFile: p });
        expect(cfg.dbTrustServerCertificate).toBe(false);
    });
});

describe("parseYesNo", () => {
    test.each([
        ["Y", true],
        ["y", true],
        ["YES", true],
        ["yes", true],
        ["Yes", true],
        ["TRUE", true],
        ["true", true],
        ["True", true],
        ["1", true],
        ["T", true],
        ["t", true],
        ["  Y  ", true],
        ["\tyes\t", true]
    ])("truthy: %j → true", (value, expected) => {
        expect(parseYesNo(value, false)).toBe(expected);
    });

    test.each([
        ["N", false],
        ["n", false],
        ["NO", false],
        ["no", false],
        ["FALSE", false],
        ["false", false],
        ["0", false],
        ["F", false],
        ["f", false],
        ["", false],
        ["   ", false],
        ["maybe", false]
    ])("falsy: %j → false", (value, expected) => {
        expect(parseYesNo(value, true)).toBe(expected);
    });

    test("undefined returns default", () => {
        expect(parseYesNo(undefined, true)).toBe(true);
        expect(parseYesNo(undefined, false)).toBe(false);
    });

    test("null returns default", () => {
        expect(parseYesNo(null, true)).toBe(true);
        expect(parseYesNo(null, false)).toBe(false);
    });

    test("non-string non-nullish returns false", () => {
        expect(parseYesNo(1, true)).toBe(false);
        expect(parseYesNo(true, true)).toBe(false);
        expect(parseYesNo({}, true)).toBe(false);
    });
});
