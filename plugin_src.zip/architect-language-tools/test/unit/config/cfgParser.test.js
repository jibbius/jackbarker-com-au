import { parseCfg } from "../../../core/src/config/cfgParser.js";

describe("parseCfg", () => {
    test("parses simple KEY = VALUE pairs and upper-cases keys", () => {
        const { values, errors } = parseCfg(`
REPORTDIRECTORY  = REPORTS
usrcalcdirectory = USRCALCS
        `);
        expect(errors).toEqual([]);
        expect(values.get("REPORTDIRECTORY")).toBe("REPORTS");
        expect(values.get("USRCALCDIRECTORY")).toBe("USRCALCS");
    });

    test("tolerates flexible whitespace around the equals sign", () => {
        const { values, errors } = parseCfg("KEY=value\n  KEY2   =   value2  ");
        expect(errors).toEqual([]);
        expect(values.get("KEY")).toBe("value");
        expect(values.get("KEY2")).toBe("value2");
    });

    test("ignores `#` and `;` comment lines", () => {
        const { values, errors } = parseCfg(`
# leading hash comment
; leading semicolon comment
DBSERVER = LOCALHOST
        `);
        expect(errors).toEqual([]);
        expect(values.size).toBe(1);
        expect(values.get("DBSERVER")).toBe("LOCALHOST");
    });

    test("strips inline `#` / `;` comments and trailing whitespace", () => {
        const { values, errors } = parseCfg(`
KEY1 = value1   ; trailing
KEY2 = value2 # also trailing
        `);
        expect(errors).toEqual([]);
        expect(values.get("KEY1")).toBe("value1");
        expect(values.get("KEY2")).toBe("value2");
    });

    test("preserves spaces and comment chars inside double-quoted values", () => {
        const { values, errors } = parseCfg(`PATH = "C:\\My Reports\\#archive"`);
        expect(errors).toEqual([]);
        expect(values.get("PATH")).toBe("C:\\My Reports\\#archive");
    });

    test("supports backslash escapes for `\"` and `\\` inside quotes", () => {
        const { values, errors } = parseCfg(`Q = "she said \\"hi\\" \\\\ done"`);
        expect(errors).toEqual([]);
        expect(values.get("Q")).toBe(`she said "hi" \\ done`);
    });

    test("errors on a line missing `=`", () => {
        const { values, errors } = parseCfg("VALID = ok\nMISSING_EQUALS_LINE\n");
        expect(values.get("VALID")).toBe("ok");
        expect(errors).toHaveLength(1);
        expect(errors[0].line).toBe(2);
        expect(errors[0].message).toMatch(/expected KEY = VALUE/);
    });

    test("flags a duplicate key but keeps the last value (last-wins)", () => {
        const { values, errors } = parseCfg("KEY = first\nKEY = second\n");
        expect(values.get("KEY")).toBe("second");
        expect(errors).toHaveLength(1);
        expect(errors[0].line).toBe(2);
        expect(errors[0].message).toMatch(/duplicate key KEY/);
    });

    test("returns an empty result for empty input", () => {
        expect(parseCfg("")).toEqual({ values: new Map(), errors: [] });
    });

    test("returns an empty result for an all-comments input", () => {
        const { values, errors } = parseCfg("# only\n; comments\n");
        expect(values.size).toBe(0);
        expect(errors).toEqual([]);
    });

    test("preserves `${var}` markers literally (no env substitution)", () => {
        const { values, errors } = parseCfg("HOME = ${USER_HOME}/reports\n");
        expect(errors).toEqual([]);
        expect(values.get("HOME")).toBe("${USER_HOME}/reports");
    });

    test("errors on an unterminated quoted value", () => {
        const { values, errors } = parseCfg(`KEY = "no closing quote\n`);
        expect(values.has("KEY")).toBe(false);
        expect(errors).toHaveLength(1);
        expect(errors[0].message).toMatch(/unterminated/);
    });

    test("errors on stray text after a closing quote", () => {
        const { values, errors } = parseCfg(`KEY = "abc" garbage\n`);
        expect(values.has("KEY")).toBe(false);
        expect(errors[0].message).toMatch(/unexpected text after closing quote/);
    });

    test("errors on a line with `=` but no key", () => {
        const { values, errors } = parseCfg(`= value\n`);
        expect(values.size).toBe(0);
        expect(errors[0].message).toMatch(/missing key/);
    });
});
