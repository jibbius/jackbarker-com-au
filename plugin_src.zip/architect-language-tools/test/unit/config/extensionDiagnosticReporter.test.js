import { reportExtensionDiagnostic } from "../../../vscode-extension/src/config/extensionDiagnosticReporter.js";

const PREFIX = "projectConfig load failed";

function makeStubs() {
    const lines = [];
    const toasts = [];
    return {
        lines,
        toasts,
        channel: { appendLine: (line) => lines.push(line) },
        showToast: (message) => toasts.push(message),
        seenSet: new Set()
    };
}

function call(err, stubs, prefix = PREFIX) {
    reportExtensionDiagnostic(err, {
        channel: stubs.channel,
        prefix,
        showToast: stubs.showToast,
        seenSet: stubs.seenSet
    });
}

describe("reportExtensionDiagnostic", () => {
    test("appends the message to the channel under the supplied prefix", () => {
        const stubs = makeStubs();
        call(new Error("boom"), stubs);
        expect(stubs.lines).toEqual([
            "[architect] projectConfig load failed: boom"
        ]);
    });

    test("uses whatever prefix the caller supplies", () => {
        const stubs = makeStubs();
        call(new Error("denied"), stubs, "MCP accessibility (none)");
        expect(stubs.lines).toEqual([
            "[architect] MCP accessibility (none): denied"
        ]);
    });

    test("shows a toast on first occurrence", () => {
        const stubs = makeStubs();
        call(new Error("boom"), stubs);
        expect(stubs.toasts).toEqual(["boom"]);
        expect(stubs.seenSet.has("boom")).toBe(true);
    });

    test("does not toast a repeat occurrence of the same message", () => {
        const stubs = makeStubs();
        call(new Error("boom"), stubs);
        call(new Error("boom"), stubs);
        expect(stubs.toasts).toEqual(["boom"]);
        expect(stubs.lines).toHaveLength(2);
    });

    test("toasts each distinct message once", () => {
        const stubs = makeStubs();
        call(new Error("first"), stubs);
        call(new Error("second"), stubs);
        call(new Error("first"), stubs);
        expect(stubs.toasts).toEqual(["first", "second"]);
    });

    test("handles a non-Error argument by stringifying it", () => {
        const stubs = makeStubs();
        call("raw string failure", stubs);
        expect(stubs.lines[0]).toBe("[architect] projectConfig load failed: raw string failure");
        expect(stubs.toasts).toEqual(["raw string failure"]);
    });
});
