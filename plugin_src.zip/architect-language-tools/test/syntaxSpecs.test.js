import { runAllSyntaxSpecs } from "./runSyntaxSpecs.js";

// Regression baseline: update this constant when new spec files are intentionally added.
// It prevents accidental removal of test coverage — if the count drops below this,
// the test fails immediately rather than silently losing coverage.
const MIN_EXPECTED_SYNTAX_SPECS = 0;

const summary = await runAllSyntaxSpecs();
const suites = summary.results.reduce((acc, result) => {
    if (!acc[result.suite]) {
        acc[result.suite] = [];
    }
    acc[result.suite].push(result);
    return acc;
}, {});

describe("syntax test specs", () => {
    it("discovers syntax spec files", () => {
        expect(summary.total).toBeGreaterThanOrEqual(MIN_EXPECTED_SYNTAX_SPECS);
    });

    Object.keys(suites).sort().forEach((suiteName) => {
        describe(suiteName, () => {
            suites[suiteName].forEach((result) => {
                it(`${result.id} - ${result.name}`, () => {
                    expect(result.failures.join("\n\n")).toBe("");
                });
            });
        });
    });
});
