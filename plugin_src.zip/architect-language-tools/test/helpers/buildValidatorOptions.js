/**
 * Test helper: assembles the standard validator options bag.
 *
 * Mirrors what `collectDiagnostics` threads into validators in production:
 * `ast`, `tokens`, and `facts` are all sourced from `collectDocumentFacts`.
 * Test files use this so future validators that pull additional fields off
 * `facts` don't have to be re-wired site by site.
 */

import { collectDocumentFacts } from "../../core/src/analysis/documentFacts.js";

function buildValidatorOptions(document, extra = {}) {
    const facts = collectDocumentFacts(document);
    // Only the contractually-required fields (ast/tokens/facts) are auto-populated.
    // Other facts (executionClassificationMap, symbolTable, userDefinedFunctionCatalog,
    // …) are opt-in via `extra` so existing tests that intentionally omitted them
    // — e.g. to disable ECM-driven line classification and force the validator to
    // visit every line — keep the same behaviour they had before the migration.
    return {
        ast: facts.ast,
        tokens: facts.tokens,
        facts,
        ...extra
    };
}

export { buildValidatorOptions };
