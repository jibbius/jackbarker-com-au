# Include-directive runtime probes

Probes the Acurity Architect runtime for the open questions in
`planning/specs/include-directive-parser-unification.md`:

1. Does the runtime accept Windows-style `\` in **bare** include paths?
2. Does it accept `\` in **quoted** include paths?
3. Does it normalise mixed separators?
4. Do all four include-family keywords (INCLUDE, INCLUDEONCE, INCLUDETEST, REQUIRE) accept the same path forms?

## Layout

```
include-parser/
  subdir/common.def
  subdir/sub2/common.def
  subdir with space/common.def
  probe-1-bare-posix.def
  probe-2-bare-windows.def
  probe-3-quoted-windows.def
  probe-4-quoted-spaced.def
  probe-5-single-quoted.def
  probe-6-mixed-separators.def
  probe-7-require-windows.def
  probe-8-includeonce-includetest-windows.def
```

Run each `probe-*.def` against the Architect runtime independently and
record:

- (a) does the directive parse?
- (b) is the includee located?
- (c) any warning/diagnostic emitted?

NB: file extension `.def` is a placeholder — adjust to whatever the
runtime expects for a runnable script if different.
