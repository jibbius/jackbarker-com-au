// Architect Language Tools — supplementary module (bundled).

// src/builtins/functionsRegistry.js
import * as path2 from "path";
import { fileURLToPath } from "url";

// src/builtins/_dataLoaders.js
import * as fs from "fs";
import * as path from "path";

// src/builtins/_schemaValidator.js
function isPlainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function typeMatches(value, type) {
  switch (type) {
    case "object":
      return isPlainObject(value);
    case "array":
      return Array.isArray(value);
    case "string":
      return typeof value === "string";
    case "number":
      return typeof value === "number" && Number.isFinite(value);
    case "integer":
      return typeof value === "number" && Number.isInteger(value);
    case "boolean":
      return typeof value === "boolean";
    case "null":
      return value === null;
    default:
      return false;
  }
}
function resolveRef(ref, root) {
  if (typeof ref !== "string" || !ref.startsWith("#/")) {
    throw new Error(`Unsupported $ref: ${ref} (only same-file '#/$defs/...' refs supported)`);
  }
  const parts = ref.slice(2).split("/");
  let node = root;
  for (const p of parts) {
    if (node == null || typeof node !== "object" || !(p in node)) {
      throw new Error(`Unresolvable $ref: ${ref}`);
    }
    node = node[p];
  }
  return node;
}
function validateNode(value, schema, root, path7, errors) {
  if (schema == null) return;
  if (schema.$ref) {
    validateNode(value, resolveRef(schema.$ref, root), root, path7, errors);
    return;
  }
  if (schema.type !== void 0) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type];
    if (!types.some((t) => typeMatches(value, t))) {
      errors.push({ path: path7, message: `expected type ${types.join("|")}, got ${Array.isArray(value) ? "array" : value === null ? "null" : typeof value}` });
      return;
    }
  }
  if (schema.enum !== void 0) {
    if (!schema.enum.some((allowed) => allowed === value)) {
      errors.push({ path: path7, message: `value ${JSON.stringify(value)} not in enum [${schema.enum.map((v) => JSON.stringify(v)).join(", ")}]` });
    }
  }
  if (schema.const !== void 0) {
    if (value !== schema.const) {
      errors.push({ path: path7, message: `value ${JSON.stringify(value)} does not equal const ${JSON.stringify(schema.const)}` });
    }
  }
  if (typeof value === "string") {
    if (schema.minLength !== void 0 && value.length < schema.minLength) {
      errors.push({ path: path7, message: `string length ${value.length} < minLength ${schema.minLength}` });
    }
    if (schema.maxLength !== void 0 && value.length > schema.maxLength) {
      errors.push({ path: path7, message: `string length ${value.length} > maxLength ${schema.maxLength}` });
    }
    if (schema.pattern !== void 0) {
      const re = new RegExp(schema.pattern);
      if (!re.test(value)) {
        errors.push({ path: path7, message: `string does not match pattern /${schema.pattern}/` });
      }
    }
  }
  if (typeof value === "number") {
    if (schema.minimum !== void 0 && value < schema.minimum) {
      errors.push({ path: path7, message: `value ${value} < minimum ${schema.minimum}` });
    }
    if (schema.maximum !== void 0 && value > schema.maximum) {
      errors.push({ path: path7, message: `value ${value} > maximum ${schema.maximum}` });
    }
  }
  if (Array.isArray(value)) {
    if (schema.minItems !== void 0 && value.length < schema.minItems) {
      errors.push({ path: path7, message: `array length ${value.length} < minItems ${schema.minItems}` });
    }
    if (schema.maxItems !== void 0 && value.length > schema.maxItems) {
      errors.push({ path: path7, message: `array length ${value.length} > maxItems ${schema.maxItems}` });
    }
    if (schema.items !== void 0) {
      value.forEach((item, i) => {
        validateNode(item, schema.items, root, `${path7}/${i}`, errors);
      });
    }
  }
  if (isPlainObject(value)) {
    const props = schema.properties || {};
    const required = schema.required || [];
    for (const key of required) {
      if (!Object.prototype.hasOwnProperty.call(value, key)) {
        errors.push({ path: path7, message: `missing required property "${key}"` });
      }
    }
    for (const [key, sub] of Object.entries(value)) {
      if (key === "$schema") continue;
      if (props[key] !== void 0) {
        validateNode(sub, props[key], root, `${path7}/${key}`, errors);
      } else if (schema.additionalProperties === false) {
        errors.push({ path: `${path7}/${key}`, message: `additional property "${key}" not allowed` });
      } else if (isPlainObject(schema.additionalProperties)) {
        validateNode(sub, schema.additionalProperties, root, `${path7}/${key}`, errors);
      }
    }
  }
  for (const combinator of ["allOf", "anyOf", "oneOf"]) {
    if (!Array.isArray(schema[combinator])) continue;
    const branchErrors = schema[combinator].map((branch) => {
      const branchErr = [];
      validateNode(value, branch, root, path7, branchErr);
      return branchErr;
    });
    const passing = branchErrors.filter((e) => e.length === 0).length;
    if (combinator === "allOf" && passing !== schema.allOf.length) {
      const failed = branchErrors.find((e) => e.length > 0);
      errors.push({ path: path7, message: `allOf branch failed: ${failed[0].message}` });
    }
    if (combinator === "anyOf" && passing === 0) {
      errors.push({ path: path7, message: `anyOf: no branch matched` });
    }
    if (combinator === "oneOf" && passing !== 1) {
      errors.push({ path: path7, message: `oneOf: expected exactly 1 matching branch, got ${passing}` });
    }
  }
}
function validate(value, schema) {
  const errors = [];
  validateNode(value, schema, schema, "", errors);
  return errors;
}
function validateOrThrow(value, schema, location) {
  const errors = validate(value, schema);
  if (errors.length === 0) return;
  const lines = errors.map((e) => `  ${e.path || "/"}: ${e.message}`).join("\n");
  throw new Error(`${location}: schema validation failed:
${lines}`);
}

// src/builtins/_dataLoaders.js
function preferSubfolder(dirname6, filename, subdir = "builtins") {
  const sub = path.resolve(dirname6, subdir, filename);
  if (fs.existsSync(sub)) return sub;
  return path.resolve(dirname6, filename);
}
function _stripSchema(obj) {
  const { $schema: _ignored, ...rest } = obj;
  return rest;
}
function _readDirEntries({ sourceDir, stemField, label, schema }) {
  const files = fs.readdirSync(sourceDir).filter((f) => f.endsWith(".json")).sort();
  const out = [];
  for (const f of files) {
    const full = path.join(sourceDir, f);
    const raw = JSON.parse(fs.readFileSync(full, "utf8"));
    const entry = _stripSchema(raw);
    const stem = f.slice(0, -".json".length);
    if (entry[stemField] !== stem) {
      throw new Error(
        `${full}: "${stemField}" (${entry[stemField]}) does not match file stem (${stem})`
      );
    }
    if (schema) validateOrThrow(entry, schema, `${label}/${stem}.json`);
    out.push(entry);
  }
  return out;
}
function _readArrayBundle({ bundleFile, schema, stemField, label }) {
  const raw = JSON.parse(fs.readFileSync(bundleFile, "utf8"));
  if (!Array.isArray(raw)) {
    throw new Error(`${bundleFile}: expected an array of entries`);
  }
  const out = [];
  for (const r of raw) {
    const entry = _stripSchema(r);
    if (stemField && (typeof entry[stemField] !== "string" || entry[stemField].length === 0)) {
      throw new Error(
        `${bundleFile}: entry is missing required "${stemField}" identifier`
      );
    }
    if (schema) {
      const stem = entry[stemField] ?? "<unknown>";
      validateOrThrow(entry, schema, `${label}/${stem}.json`);
    }
    out.push(entry);
  }
  return out;
}
function resolveDataFile({ sourceFile, fallbackFile, label }) {
  if (fs.existsSync(sourceFile)) return sourceFile;
  if (fs.existsSync(fallbackFile)) return fallbackFile;
  throw new Error(
    `${label}: data file not found.
  source:   ${sourceFile}
  fallback: ${fallbackFile}`
  );
}
function loadArrayBundle({
  sourceDir,
  bundleFile,
  schema = null,
  label,
  stemField = "name"
}) {
  if (fs.existsSync(sourceDir)) return _readDirEntries({ sourceDir, stemField, label, schema });
  if (fs.existsSync(bundleFile)) return _readArrayBundle({ bundleFile, schema, stemField, label });
  throw new Error(
    `${label}: neither source directory nor bundle found.
  source: ${sourceDir}
  bundle: ${bundleFile}`
  );
}
function loadCompositeFile({ sourceFile, distFile, schema = null, label }) {
  const file = resolveDataFile({ sourceFile, fallbackFile: distFile, label });
  const raw = JSON.parse(fs.readFileSync(file, "utf8"));
  if (schema) validateOrThrow(raw, schema, path.basename(file));
  return _stripSchema(raw);
}
function loadTableBundles({
  sourceDir,
  registryBundleFile,
  structuresBundleFile,
  schema = null,
  label
}) {
  if (fs.existsSync(sourceDir)) {
    return _readDirEntries({ sourceDir, stemField: "code", label, schema });
  }
  if (!fs.existsSync(registryBundleFile)) {
    throw new Error(
      `${label}: neither source directory nor registry bundle found.
  source:   ${sourceDir}
  registry: ${registryBundleFile}`
    );
  }
  if (!fs.existsSync(structuresBundleFile)) {
    throw new Error(
      `${label}: registry bundle present but structures bundle missing.
  registry:   ${registryBundleFile}
  structures: ${structuresBundleFile}`
    );
  }
  const registryMap = JSON.parse(fs.readFileSync(registryBundleFile, "utf8"));
  const structures2 = JSON.parse(fs.readFileSync(structuresBundleFile, "utf8"));
  if (!Array.isArray(structures2)) {
    throw new Error(`${structuresBundleFile}: expected an array of structure objects`);
  }
  const out = [];
  for (const r of structures2) {
    const entry = _stripSchema(r);
    if (!Object.prototype.hasOwnProperty.call(registryMap, entry.code)) {
      throw new Error(
        `${path.basename(structuresBundleFile)}: code "${entry.code}" not present in registry projection`
      );
    }
    if (schema) validateOrThrow(entry, schema, `${label}/${entry.code}.json`);
    out.push(entry);
  }
  return out;
}

// src/builtins/functionsRegistry.js
var __dirname = path2.dirname(fileURLToPath(import.meta.url));
var entries = loadArrayBundle({
  sourceDir: path2.resolve(__dirname, "..", "builtins-data", "functions"),
  bundleFile: preferSubfolder(__dirname, "functions.bundle.json"),
  label: "supplementary functions registry"
});
var functions = Object.fromEntries(
  entries.map(({ name, ...rest }) => [name, rest])
);

// src/builtins/globalVariablesRegistry.js
import * as path3 from "path";
import { fileURLToPath as fileURLToPath2 } from "url";
var __dirname2 = path3.dirname(fileURLToPath2(import.meta.url));
var entries2 = loadArrayBundle({
  sourceDir: path3.resolve(__dirname2, "..", "builtins-data", "global-variables"),
  bundleFile: preferSubfolder(__dirname2, "global-variables.bundle.json"),
  label: "supplementary globalVariables registry"
});
var globalVariables = Object.fromEntries(
  entries2.map(({ name, ...rest }) => [name, rest])
);

// src/builtins/tableRegistry.js
import * as path4 from "path";
import { fileURLToPath as fileURLToPath3 } from "url";
var __dirname3 = path4.dirname(fileURLToPath3(import.meta.url));
var structures = loadTableBundles({
  sourceDir: path4.resolve(__dirname3, "..", "builtins-data", "tables"),
  registryBundleFile: preferSubfolder(__dirname3, "tables-registry.bundle.json"),
  structuresBundleFile: preferSubfolder(__dirname3, "tables.bundle.json"),
  label: "supplementary tables registry"
});
var tables = Object.fromEntries(
  structures.map((s) => [
    s.code,
    {
      entry: { name: s.name },
      structure: {
        code: s.code,
        name: s.name,
        recordLength: s.recordLength,
        helpPage: s.helpPage,
        indexes: s.indexes,
        fields: s.fields
      }
    }
  ])
);

// src/builtins/helpRegistry.js
import * as path5 from "path";
import { fileURLToPath as fileURLToPath4 } from "url";
var __dirname4 = path5.dirname(fileURLToPath4(import.meta.url));
var help = loadCompositeFile({
  sourceFile: path5.resolve(__dirname4, "..", "builtins-data", "help-registry.json"),
  distFile: preferSubfolder(__dirname4, "help-registry.json"),
  label: "supplementary help registry"
});

// src/builtins/deprecatedSymbols.js
import * as path6 from "path";
import { fileURLToPath as fileURLToPath5 } from "url";
var __dirname5 = path6.dirname(fileURLToPath5(import.meta.url));
var deprecatedSymbols = loadCompositeFile({
  sourceFile: path6.resolve(__dirname5, "..", "builtins-data", "deprecated-symbols.json"),
  distFile: preferSubfolder(__dirname5, "deprecated-symbols.json"),
  label: "supplementary deprecatedSymbols registry"
});

// src/validators/empStyleValidator.js
var TEMP_PREFIX_RE = /\bTEMP_[A-Za-z]/g;
function validateEmpStyle(document, _context) {
  const diagnostics = [];
  const lineCount = document.lineCount;
  for (let i = 0; i < lineCount; i++) {
    const text = document.lineAt(i).text;
    TEMP_PREFIX_RE.lastIndex = 0;
    let match;
    while ((match = TEMP_PREFIX_RE.exec(text)) !== null) {
      const col = match.index;
      diagnostics.push({
        range: {
          start: { line: i, character: col },
          end: { line: i, character: col + match[0].length }
        },
        message: "Use 'zTmp_' prefix instead of 'TEMP_' (employer coding standard EMP-STY-001).",
        severity: 1,
        code: "EMP-STY-001",
        source: "architect-ext"
      });
    }
  }
  return diagnostics;
}

// src/validators/demoSeverityValidator.js
var TRIGGERS = [
  { name: "demo_validity", messageId: "DEMO-SEV-001" },
  { name: "demo_advisory", messageId: "DEMO-SEV-002" },
  { name: "demo_strict_style", messageId: "DEMO-SEV-003" },
  { name: "demo_unsuppressable", messageId: "DEMO-SEV-004" },
  { name: "demo_hint", messageId: "DEMO-SEV-005" }
];
var WORD_BOUNDARY_RE = /[A-Za-z0-9_]/;
function validateDemoSeverity(document, context) {
  const diagnostics = [];
  const { createDiagnostic } = context;
  if (typeof createDiagnostic !== "function") return diagnostics;
  const lineCount = document.lineCount;
  for (let lineIndex = 0; lineIndex < lineCount; lineIndex++) {
    const text = document.lineAt(lineIndex).text;
    for (const trigger of TRIGGERS) {
      let from = 0;
      while (true) {
        const idx = text.indexOf(trigger.name, from);
        if (idx === -1) break;
        const before = idx === 0 ? "" : text[idx - 1];
        const after = text[idx + trigger.name.length] ?? "";
        const isWord = WORD_BOUNDARY_RE.test(before) || WORD_BOUNDARY_RE.test(after);
        if (!isWord) {
          const range = {
            start: { line: lineIndex, character: idx },
            end: { line: lineIndex, character: idx + trigger.name.length }
          };
          const diag = createDiagnostic(range, { messageId: trigger.messageId });
          if (diag) diagnostics.push(diag);
        }
        from = idx + trigger.name.length;
      }
    }
  }
  return diagnostics;
}

// src/catalog/demoSeverityCatalog.js
var demoSeverityCatalog = {
  "DEMO-SEV-001": {
    ruleId: "demoSev001",
    message: "Variable name 'demo_validity' is reserved for the validation-model test suite.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    severity: { legacy: "error", default: "error", strict: "error" },
    suppressable: true
  },
  "DEMO-SEV-002": {
    ruleId: "demoSev002",
    message: "Variable name 'demo_advisory' is reserved for the validation-model test suite.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    severity: { legacy: "off", default: "warning", strict: "warning" },
    suppressable: true
  },
  "DEMO-SEV-003": {
    ruleId: "demoSev003",
    message: "Variable name 'demo_strict_style' is reserved for the validation-model test suite.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "standards",
    severity: { legacy: "off", default: "off", strict: "warning" },
    suppressable: true
  },
  "DEMO-SEV-004": {
    ruleId: "demoSev004",
    message: "Variable name 'demo_unsuppressable' is reserved for the validation-model test suite.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "validity",
    severity: { legacy: "error", default: "error", strict: "error" },
    suppressable: false
  },
  "DEMO-SEV-005": {
    ruleId: "demoSev005",
    message: "Variable name 'demo_hint' is reserved for the validation-model test suite.",
    paramKeys: [],
    surfaces: ["ide", "cicd"],
    category: "advisory",
    severity: { legacy: "off", default: "information", strict: "information" },
    suppressable: true
  }
};

// index.js
var index_default = {
  catalogEntries: demoSeverityCatalog,
  // Layer-2 baseline override: exercise the resolution chain end-to-end so
  // integration tests can confirm a supplementary-supplied severity reaches
  // collectDiagnostics. ACU-TODO-001 is a stable, low-noise core rule.
  severityOverrides: { "ACU-TODO-001": "off" },
  validators: [validateEmpStyle, validateDemoSeverity],
  builtins: { functions, globalVariables, tables, help, deprecatedSymbols }
};
export {
  index_default as default
};
//# sourceMappingURL=architect-supplementary.js.map
