/**
 * Build-side projector primitives for the builtins registries.
 *
 * Mirrors the runtime `_dataLoaders.js` shape on the build path. Both core's
 * `tools/build-builtins-bundle.js` and the supplementary module's
 * `build.js` Pass 2 produce the same three artefact shapes from the per-entry
 * authoring tree:
 *
 *   array bundle      — {functions, global-variables}.bundle.json
 *   table dual-bundle — tables-registry.bundle.json + tables.bundle.json
 *   composite copy    — help-registry.json + deprecated-symbols.json
 *
 * Plus a recursive copy for the vendored `schemas/` folder. Centralising the
 * three operations means the build-time and runtime contracts evolve
 * together — same drift risk, same fix surface.
 *
 * Internal — exported only for use by the two build scripts. Not a public
 * API; the underscore prefix matches `core/src/builtins/_dataLoaders.js`.
 *
 * Behaviour shared by every primitive:
 *   - Inputs are read JSON-parsed, sorted by filename for determinism.
 *   - `$schema` keys are stripped from the output to match the runtime
 *     loader's strip-on-load semantics and keep bundles compact.
 *   - Every operation is idempotent — safe to re-run.
 */

import * as fs from "fs";
import * as path from "path";

// Byte-wise comparator. Default Array.prototype.sort() uses locale-dependent
// string compare; that's byte-identical for pure ASCII (current registry
// state) but can vary by locale once non-ASCII filenames enter the data, so
// we pin to byte order to keep the bundles byte-stable across systems.
function _byteCompare(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
}

function _readJsonFilesSorted(dir, stemField) {
    return fs.readdirSync(dir)
        .filter(f => f.endsWith(".json"))
        .sort(_byteCompare)
        .map(f => {
            const full = path.join(dir, f);
            const entry = JSON.parse(fs.readFileSync(full, "utf8"));
            delete entry.$schema;
            if (stemField) {
                const stem = f.slice(0, -".json".length);
                if (entry[stemField] !== stem) {
                    throw new Error(
                        `${full}: "${stemField}" (${entry[stemField]}) does not match file stem (${stem})`
                    );
                }
            }
            return entry;
        });
}

function _writeJson(file, data) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(data) + "\n");
}

function _copyDirRecursive(src, dst) {
    fs.mkdirSync(dst, { recursive: true });
    for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
        const s = path.join(src, entry.name);
        const d = path.join(dst, entry.name);
        if (entry.isDirectory()) _copyDirRecursive(s, d);
        else                     fs.copyFileSync(s, d);
    }
}

/**
 * Project a per-file source directory into a single array bundle. Writes to
 * every output path supplied in `outFiles` (caller-controlled — supplementary
 * writes both `dist/` and a sidecar; core writes one sidecar).
 *
 * When `stemField` is supplied (recommended), each entry's `entry[stemField]`
 * value is asserted to equal the file stem before the bundle is written. This
 * is the load-bearing stem-vs-identifier invariant — once a bundle is in
 * deployment there is no original stem to cross-check against, so the
 * build-time assertion is the only enforcement point against a hand-edit
 * producing a name/code mismatch.
 *
 * @param {{sourceDir:string, outFiles:string[], stemField?:string}} opts
 * @returns {{count:number}} the number of entries written
 */
export function projectArrayBundle({ sourceDir, outFiles, stemField }) {
    const entries = _readJsonFilesSorted(sourceDir, stemField);
    for (const out of outFiles) _writeJson(out, entries);
    return { count: entries.length };
}

/**
 * Project the per-file table source directory into the dual-bundle pair:
 * the lightweight `{code: name}` registry projection AND the full structures
 * array. Both are written to every (registryOut, structuresOut) target pair
 * supplied — supplementary supplies two pairs (dist + sidecar), core
 * supplies one (sidecar only).
 *
 * @param {{
 *   sourceDir: string,
 *   targets: Array<{ registryOut: string, structuresOut: string }>
 * }} opts
 * @returns {{count:number}} the number of structures written
 */
export function projectTableBundles({ sourceDir, targets }) {
    const entries = _readJsonFilesSorted(sourceDir, "code");
    const registry = {};
    for (const e of entries) registry[e.code] = e.name;
    for (const { registryOut, structuresOut } of targets) {
        _writeJson(registryOut, registry);
        _writeJson(structuresOut, entries);
    }
    return { count: entries.length };
}

/**
 * Copy a composite-file source verbatim to one or more output paths.
 *
 * Composite files (`help-registry.json`, `deprecated-symbols.json`) are not
 * normalised on copy — `$schema` survives the trip and is stripped at load
 * time by the runtime helper. This matches existing behaviour and avoids a
 * round-trip parse for files that may carry future metadata.
 *
 * @param {{sourceFile:string, outFiles:string[]}} opts
 */
export function projectCompositeCopy({ sourceFile, outFiles }) {
    for (const out of outFiles) {
        fs.mkdirSync(path.dirname(out), { recursive: true });
        fs.copyFileSync(sourceFile, out);
    }
}

/**
 * Recursively copy the vendored schemas folder to one or more output dirs.
 *
 * @param {{sourceDir:string, outDirs:string[]}} opts
 * @returns {{count:number}} count of *.json files in the source dir
 */
export function projectSchemasFolder({ sourceDir, outDirs }) {
    if (!fs.existsSync(sourceDir)) return { count: 0 };
    for (const out of outDirs) _copyDirRecursive(sourceDir, out);
    const count = fs.readdirSync(sourceDir).filter(f => f.endsWith(".json")).length;
    return { count };
}
