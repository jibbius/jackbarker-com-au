# Change Log

## 0.4.0 — 2026-05-10

- Authoring data extended to demonstrate every field in `function.schema.json`.
  The reference companion now exercises the full schema surface so consumers
  authoring their own supplementary modules can use these entries as
  copy-paste templates:
  - `EMP_LEGACY_LOOKUP` (new) — demos `deprecated`.
  - `EMP_OPEN_DATA` (new) — demos `bindsHandle` and `sideEffects` (the
    `dbIndexChange` and `movesDatabaseCursor` discriminants).
  - `EMP_FETCH_LATEST_RATE` (extended) — adds `knownIssues`, `preconditions`,
    and `returnCodes`.
  - `EMP_LOG_EVENT` (extended) — adds `insertSnippet`.
- `distBundle.test.js` extended with field-presence assertions for each
  newly-demoed field, so a future bundler regression that drops one fails
  loud rather than silently.

## 0.3.0 — 2026-05-10

- Supplementary builtins migrated from JS literals to JSON authoring, in shape
  parity with core. Source of truth is now `src/builtins-data/` (per-entry files
  for functions, global variables, and tables; composite files for help and
  deprecated symbols). Loaders under `src/builtins/` parse the JSON and return
  the in-memory shape; runtime validation lives centrally in core's
  `supplementaryLoader.js`.
- Loaders and `build.js` consume vendored copies of core's
  `_dataLoaders.js`, `_schemaValidator.js`, `_dataProjectors.js`, and the
  builtin schemas. The supplementary tree therefore builds standalone in
  the third-party hand-off scenario — no sibling core checkout required.
  `npm run sync:core` resyncs all four vendored sets; the drift test in
  core's suite (`test/unit/supplementarySchemaSync.test.js`) covers them all.

## 0.1.0

- Initial companion-extension packaging. Registers sample employer builtins,
  the EMP-STY-001 validator, and the test-only DEMO-SEV-* catalog entries used
  by the validation-model syntax test suite.
